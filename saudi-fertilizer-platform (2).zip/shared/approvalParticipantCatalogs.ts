export const APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY = 'approval_reviewer_user_ids';
export const APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY = 'approval_approver_user_ids';

export type ApprovalParticipantDirectoryUser = {
  id: number;
  userType: string;
  isActive: boolean;
  permissions?: unknown;
};

function parseUserIds(value: string | null | undefined): number[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return Array.from(new Set(parsed.filter((id): id is number => Number.isInteger(id) && id > 0)));
  } catch {
    return [];
  }
}

function hasApprovalDelegatePermission(permissions: unknown) {
  return Boolean(permissions && typeof permissions === 'object' && (permissions as Record<string, unknown>).approvalDelegate === true);
}

export function readApprovalParticipantCatalogs(
  settings: Record<string, string | undefined>,
  users: ApprovalParticipantDirectoryUser[],
) {
  const activeUsers = users.filter(user => user.isActive);
  const hasReviewerCatalog = Object.prototype.hasOwnProperty.call(settings, APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY);
  const hasApproverCatalog = Object.prototype.hasOwnProperty.call(settings, APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY);
  const validIds = new Set(activeUsers.map(user => user.id));

  const reviewerUserIds = (hasReviewerCatalog
    ? parseUserIds(settings[APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY])
    : activeUsers.filter(user => user.userType === 'reviewer' || user.userType === 'reviewer_approver').map(user => user.id)
  ).filter(id => validIds.has(id));

  const approverUserIds = (hasApproverCatalog
    ? parseUserIds(settings[APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY])
    : activeUsers.filter(user => user.userType === 'reviewer_approver' || user.userType === 'authorized_partner' || (user.userType === 'finance_manager' && hasApprovalDelegatePermission(user.permissions))).map(user => user.id)
  ).filter(id => validIds.has(id));

  return { reviewerUserIds, approverUserIds, hasReviewerCatalog, hasApproverCatalog };
}

export function validateApprovalParticipantCatalogValue(value: string): string {
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed) || !parsed.every(id => Number.isInteger(id) && id > 0)) {
      throw new Error();
    }
    return JSON.stringify(Array.from(new Set(parsed)));
  } catch {
    throw new Error('قائمة المراجعين أو المفوضين يجب أن تحتوي على أرقام مستخدمين صحيحة فقط');
  }
}
