import { describe, expect, it } from 'vitest';
import { readApprovalParticipantCatalogs, validateApprovalParticipantCatalogValue } from '../shared/approvalParticipantCatalogs';

describe('كتالوج قوائم التعميد المعتمدة', () => {
  const users = [
    { id: 1, userType: 'reviewer', isActive: true },
    { id: 2, userType: 'reviewer_approver', isActive: true },
    { id: 3, userType: 'authorized_partner', isActive: true },
    { id: 4, userType: 'finance_manager', isActive: true, permissions: { approvalDelegate: true } },
    { id: 5, userType: 'delegate', isActive: true },
    { id: 6, userType: 'reviewer_approver', isActive: false },
  ];

  it('يشتق قوائم احتياطية آمنة من نوع المستخدم وصلاحية التعميد قبل أول حفظ', () => {
    expect(readApprovalParticipantCatalogs({}, users)).toEqual({
      reviewerUserIds: [1, 2],
      approverUserIds: [2, 3, 4],
      hasReviewerCatalog: false,
      hasApproverCatalog: false,
    });
  });

  it('يلتزم بالقائمة المحفوظة حتى إن كانت فارغة ولا يعود لإتاحة جميع المستخدمين', () => {
    expect(readApprovalParticipantCatalogs({ approval_reviewer_user_ids: '[]', approval_approver_user_ids: '[3, 5, 6]' }, users)).toEqual({
      reviewerUserIds: [],
      approverUserIds: [3, 5],
      hasReviewerCatalog: true,
      hasApproverCatalog: true,
    });
  });

  it('يتحقق من أن القوائم المحفوظة مصفوفات من معرّفات المستخدمين الموجبة فقط', () => {
    expect(validateApprovalParticipantCatalogValue('[3,3,4]')).toBe('[3,4]');
    expect(() => validateApprovalParticipantCatalogValue('[3,"4"]')).toThrow('قائمة المراجعين أو المفوضين');
  });
});
