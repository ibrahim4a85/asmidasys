import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('تطبيق ترتيب أقسام لوحة التحكم', () => {
  it('يمرر الترتيب المحفوظ إلى النمط التقليدي ويطبقه على الأقسام المرئية', () => {
    const dashboard = readFileSync(new URL('../client/src/pages/Dashboard.tsx', import.meta.url), 'utf8');

    expect(dashboard).toContain('dashboardSectionOrder={effectiveDashboardSectionOrder}');
    expect(dashboard).toContain('dashboardSectionOrder: string[];');
    expect(dashboard).toContain("const sectionOrder = (id: string) => Math.max(0, dashboardSectionOrder.indexOf(id));");
    expect(dashboard).toContain('className="rtl-page flex flex-col gap-5 pb-8"');
    expect(dashboard).toContain('<DashboardSectionContainer id="summary" order={sectionOrder(\'summary\')}');
    expect(dashboard).toContain('<DashboardSectionContainer id="activity" order={sectionOrder(\'activity\')}');
    expect(dashboard).toContain('<DashboardSectionContainer id="records" order={sectionOrder(\'records\')}');
  });

  it('يبقي الإعداد العام أساساً فقط ويعزل ترتيب كل مستخدم في التخزين المحلي', () => {
    const dashboard = readFileSync(new URL('../client/src/pages/Dashboard.tsx', import.meta.url), 'utf8');

    expect(dashboard).toContain("const fallback = ['summary', 'activity', 'records', 'bank'];");
    expect(dashboard).toContain('settings.dashboard_section_order');
    expect(dashboard).toContain('getDashboardPersonalSectionOrderKey(user.id)');
    expect(dashboard).toContain('window.localStorage.setItem');
    expect(dashboard).toContain('moveDashboardPersonalSection');
    expect(dashboard).not.toContain("key: 'dashboard_section_order'");
  });

  it('يحافظ على استعلامات بيانات اللوحة ومسار سجل السندات', () => {
    const dashboard = readFileSync(new URL('../client/src/pages/Dashboard.tsx', import.meta.url), 'utf8');

    expect(dashboard).toContain('trpc.receipts.list.useQuery({})');
    expect(dashboard).toContain('trpc.payments.list.useQuery({})');
    expect(dashboard).toContain("onNavigate('/receipts')");
  });
});
