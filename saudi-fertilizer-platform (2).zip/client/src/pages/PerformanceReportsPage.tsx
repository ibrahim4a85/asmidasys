import { useEffect, useMemo, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart3, CalendarDays, FileText, Pencil, RefreshCw, Save, TrendingDown, TrendingUp, WalletCards } from 'lucide-react';
import { toast } from 'sonner';
import { filterPerformanceReports, summarizePerformanceReports } from '@shared/performanceReportSummary';
import { useSystemLabels } from '@/hooks/useSystemLabels';

type EntryForm = {
  branchId: string;
  reportDate: string;
  salesInvoicesCount: string;
  salesInvoicesValue: string;
  returnsInvoicesCount: string;
  returnsInvoicesValue: string;
};

const today = () => new Date().toISOString().slice(0, 10);

const initialForm = (branchId?: number | null): EntryForm => ({
  branchId: branchId ? String(branchId) : '',
  reportDate: today(),
  salesInvoicesCount: '0',
  salesInvoicesValue: '0',
  returnsInvoicesCount: '0',
  returnsInvoicesValue: '0',
});

const asNumber = (value: string | number | null | undefined) => Number(value || 0);
const formatAmount = (value: string | number | null | undefined) => `${asNumber(value).toLocaleString('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ر.س`;
const dateKey = (value: string | Date) => new Date(value).toISOString().slice(0, 10);
const dateLabel = (value: string | Date) => new Intl.DateTimeFormat('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(value));

function PerformanceReportForm({
  form,
  onChange,
  branches,
  isManager,
  editing,
  existingReport,
  canEditPast,
  onClose,
}: {
  form: EntryForm;
  onChange: (next: EntryForm) => void;
  branches: any[];
  isManager: boolean;
  editing: boolean;
  existingReport?: boolean;
  canEditPast: boolean;
  onClose?: () => void;
}) {
  const utils = trpc.useUtils();
  const { labelFor } = useSystemLabels();
  const branchId = Number(form.branchId);
  const metricsInput = useMemo(() => ({ branchId, reportDate: form.reportDate }), [branchId, form.reportDate]);
  const { data: metrics, isFetching: metricsLoading, refetch: refreshMetrics } = trpc.performanceReports.dailyMetrics.useQuery(metricsInput, { enabled: Boolean(branchId && form.reportDate) });
  const saveMutation = trpc.performanceReports.save.useMutation({
    onSuccess: (result) => {
      toast.success(result.mode === 'updated' ? labelFor('performance_saved_updated', 'تم تحديث تقرير الأداء') : labelFor('performance_saved_created', 'تم حفظ تقرير الأداء اليومي'));
      utils.performanceReports.list.invalidate();
      utils.performanceReports.dailyMetrics.invalidate();
      onClose?.();
    },
    onError: (error) => toast.error(error.message || labelFor('performance_save_error', 'تعذر حفظ التقرير، يرجى المحاولة لاحقاً')),
  });

  const netSales = Math.max(0, asNumber(form.salesInvoicesValue) - asNumber(form.returnsInvoicesValue));
  const lockedHistoricalReport = Boolean(existingReport && !isManager && form.reportDate !== today() && !canEditPast);
  const setValue = (key: keyof EntryForm, value: string) => onChange({ ...form, [key]: value });
  const save = () => {
    if (lockedHistoricalReport) {
      toast.error(labelFor('performance_historical_edit_denied', 'لا تملك صلاحية تعديل تقرير سابق. اختر تاريخ اليوم أو راجع مدير النظام.'));
      return;
    }
    if (!branchId || !form.reportDate) {
      toast.error(labelFor('performance_branch_date_required', 'يرجى تحديد الفرع والتاريخ أولاً'));
      return;
    }
    saveMutation.mutate({
      branchId,
      reportDate: form.reportDate,
      salesInvoicesCount: asNumber(form.salesInvoicesCount),
      salesInvoicesValue: asNumber(form.salesInvoicesValue),
      returnsInvoicesCount: asNumber(form.returnsInvoicesCount),
      returnsInvoicesValue: asNumber(form.returnsInvoicesValue),
    });
  };

  return (
    <div className="space-y-5" dir="rtl">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="performance-date">{labelFor('field_date', 'التاريخ')}</Label>
          <Input id="performance-date" type="date" value={form.reportDate} onChange={(event) => setValue('reportDate', event.target.value)} />
        </div>
        {isManager ? (
          <div className="space-y-2">
            <Label>{labelFor('field_branch', 'الفرع')}</Label>
            <select value={form.branchId} onChange={(event) => setValue('branchId', event.target.value)} className="flex h-9 w-full rounded-md border border-input bg-background px-3 text-sm shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50">
              <option value="">{labelFor('action_select', 'اختر')} {labelFor('field_branch', 'الفرع')}</option>
              {branches.map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
            </select>
          </div>
        ) : (
          <div className="rounded-lg border border-primary/15 bg-primary/5 px-4 py-3">
            <p className="text-xs text-muted-foreground">{labelFor('performance_account_branch', 'الفرع المرتبط بالحساب')}</p>
            <p className="mt-1 font-semibold">{branches.find((branch) => String(branch.id) === form.branchId)?.name || labelFor('performance_user_branch_fallback', 'فرع المستخدم')}</p>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-emerald-200/70 bg-gradient-to-l from-emerald-50 to-background p-4 dark:border-emerald-950/70 dark:from-emerald-950/20">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300">
            <WalletCards className="h-5 w-5" />
            <div>
              <p className="font-semibold">{labelFor('performance_collections_title', 'المتحصلات من سندات القبض')}</p>
              <p className="text-xs text-muted-foreground">{labelFor('performance_collections_description', 'تُحدّث تلقائياً من السندات المعتمدة للفرع في هذا اليوم')}</p>
            </div>
          </div>
          <Button type="button" variant="outline" size="sm" onClick={() => refreshMetrics()} disabled={!branchId || metricsLoading}>
            <RefreshCw className={`ml-1 h-3.5 w-3.5 ${metricsLoading ? 'animate-spin' : ''}`} /> {labelFor('action_refresh', 'تحديث')}
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg bg-background/80 p-3 shadow-sm">
            <p className="text-xs text-muted-foreground">{labelFor('performance_receipts_count', 'عدد سندات القبض')}</p>
            <p className="mt-1 text-xl font-bold text-emerald-700 dark:text-emerald-300">{metrics?.receiptsCount ?? 0}</p>
          </div>
          <div className="rounded-lg bg-background/80 p-3 shadow-sm">
            <p className="text-xs text-muted-foreground">{labelFor('performance_collections_value', 'قيمة المتحصلات')}</p>
            <p className="mt-1 text-xl font-bold text-emerald-700 dark:text-emerald-300">{formatAmount(metrics?.collectionsValue)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-xl border border-blue-200/70 bg-blue-50/60 p-4 dark:border-blue-950/70 dark:bg-blue-950/15">
          <div className="mb-4 flex items-center gap-2 text-blue-800 dark:text-blue-300"><TrendingUp className="h-5 w-5" /><span className="font-semibold">{labelFor('performance_sales_invoices', 'فواتير المبيعات')}</span></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label htmlFor="sales-count">{labelFor('field_count', 'العدد')}</Label><Input id="sales-count" min="0" type="number" value={form.salesInvoicesCount} onChange={(event) => setValue('salesInvoicesCount', event.target.value)} /></div>
            <div className="space-y-2"><Label htmlFor="sales-value">{labelFor('field_value', 'القيمة')} ({labelFor('currency_sar', 'ر.س')})</Label><Input id="sales-value" min="0" step="0.01" type="number" value={form.salesInvoicesValue} onChange={(event) => setValue('salesInvoicesValue', event.target.value)} /></div>
          </div>
        </div>
        <div className="rounded-xl border border-rose-200/70 bg-rose-50/60 p-4 dark:border-rose-950/70 dark:bg-rose-950/15">
          <div className="mb-4 flex items-center gap-2 text-rose-800 dark:text-rose-300"><TrendingDown className="h-5 w-5" /><span className="font-semibold">{labelFor('performance_returns_invoices', 'فواتير المرتجعات')}</span></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label htmlFor="returns-count">{labelFor('field_count', 'العدد')}</Label><Input id="returns-count" min="0" type="number" value={form.returnsInvoicesCount} onChange={(event) => setValue('returnsInvoicesCount', event.target.value)} /></div>
            <div className="space-y-2"><Label htmlFor="returns-value">{labelFor('field_value', 'القيمة')} ({labelFor('currency_sar', 'ر.س')})</Label><Input id="returns-value" min="0" step="0.01" type="number" value={form.returnsInvoicesValue} onChange={(event) => setValue('returnsInvoicesValue', event.target.value)} /></div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4 rounded-xl border border-primary/20 bg-gradient-to-l from-primary/10 to-background p-4 sm:flex-row sm:items-center sm:justify-between">
        <div><p className="text-sm text-muted-foreground">{labelFor('performance_net_sales_auto', 'صافي المبيعات المحتسب تلقائياً')}</p><p className="mt-1 text-2xl font-bold text-primary">{formatAmount(netSales)}</p>{lockedHistoricalReport && <p className="mt-2 text-xs font-medium text-destructive">{labelFor('performance_historical_locked', 'هذا تقرير سابق؛ لا يمكن تعديله من هذا الحساب دون صلاحية صريحة.')}</p>}</div>
        <div className="flex gap-2">
          {editing && <Button type="button" variant="outline" onClick={onClose}>{labelFor('action_cancel', 'إلغاء')}</Button>}
          <Button type="button" onClick={save} disabled={saveMutation.isPending || !branchId || lockedHistoricalReport} className="min-w-36 bg-primary shadow-md shadow-primary/20"><Save className="ml-2 h-4 w-4" />{saveMutation.isPending ? labelFor('performance_saving', 'جارٍ الحفظ...') : labelFor('action_save', 'حفظ')}</Button>
        </div>
      </div>
    </div>
  );
}

export default function PerformanceReportsPage() {
  const { user } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const isManager = user?.userType === 'admin' || user?.userLevel === 'primary';
  const [selectedBranch, setSelectedBranch] = useState('all');
  const [filterDay, setFilterDay] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [form, setForm] = useState<EntryForm>(() => initialForm(user?.branchId));
  const [editReport, setEditReport] = useState<any>(null);
  const { data: branches = [] } = trpc.branches.list.useQuery();
  const { data: reports = [], isLoading } = trpc.performanceReports.list.useQuery();
  const canEditPast = useMemo(() => {
    const permissions = user?.permissions;
    if (Array.isArray(permissions)) return permissions.includes('performanceReportsEditHistorical');
    return Boolean(permissions && typeof permissions === 'object' && permissions.performanceReportsEditHistorical);
  }, [user?.permissions]);

  const visibleReports = useMemo(() => filterPerformanceReports(reports, { branchId: selectedBranch, day: filterDay, startDate: filterStartDate, endDate: filterEndDate }), [filterDay, filterEndDate, filterStartDate, reports, selectedBranch]);
  const branchName = (branchId: number) => branches.find((branch: any) => branch.id === branchId)?.name || `${labelFor('performance_branch_fallback', 'الفرع')} #${branchId}`;

  useEffect(() => {
    if (!isManager && user?.branchId) setForm((current) => ({ ...current, branchId: String(user.branchId) }));
  }, [isManager, user?.branchId]);

  const openEdit = (report: any) => {
    setEditReport(report);
    setForm({
      branchId: String(report.branchId),
      reportDate: dateKey(report.reportDate),
      salesInvoicesCount: String(report.salesInvoicesCount || 0),
      salesInvoicesValue: String(report.salesInvoicesValue || 0),
      returnsInvoicesCount: String(report.returnsInvoicesCount || 0),
      returnsInvoicesValue: String(report.returnsInvoicesValue || 0),
    });
  };

  const secondaryReport = reports.find((report: any) => String(report.branchId) === form.branchId && dateKey(report.reportDate) === form.reportDate);
  const secondaryCanEditSelected = Boolean(!secondaryReport || form.reportDate === today() || canEditPast);
  useEffect(() => {
    if (!isManager && secondaryReport && secondaryCanEditSelected) {
      setForm((current) => ({ ...current, salesInvoicesCount: String(secondaryReport.salesInvoicesCount || 0), salesInvoicesValue: String(secondaryReport.salesInvoicesValue || 0), returnsInvoicesCount: String(secondaryReport.returnsInvoicesCount || 0), returnsInvoicesValue: String(secondaryReport.returnsInvoicesValue || 0) }));
    }
  }, [isManager, secondaryReport?.id, secondaryCanEditSelected, form.reportDate]);

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div className="rounded-2xl border border-primary/10 bg-gradient-to-l from-primary/10 via-background to-sky-50/70 p-6 shadow-sm dark:to-sky-950/10">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex items-start gap-3"><div className="rounded-xl bg-primary p-3 text-primary-foreground shadow-lg shadow-primary/25"><BarChart3 className="h-6 w-6" /></div><div><h1 className="text-2xl font-bold tracking-tight">{labelFor('nav_performance_reports', 'تقارير الأداء')}</h1><p className="mt-1 text-sm text-muted-foreground">{labelFor('performance_subtitle', 'متابعة المبيعات والمرتجعات والمتحصلات لكل فرع بصورة يومية.')}</p></div></div>
          {!isManager && <Badge className="w-fit bg-primary/10 px-3 py-1.5 text-primary hover:bg-primary/10">{labelFor('performance_account_branch_entry', 'إدخال تقارير الفرع المرتبط بحسابك')}</Badge>}
        </div>
      </div>

      {!isManager ? (
        <>
          <Card className="overflow-hidden border-primary/15 shadow-sm"><CardHeader className="border-b bg-muted/25"><CardTitle className="flex items-center gap-2"><CalendarDays className="h-5 w-5 text-primary" />{labelFor('performance_daily_entry', 'إدخال التقرير اليومي')}</CardTitle><CardDescription>{secondaryReport ? secondaryCanEditSelected ? labelFor('performance_existing_editable_description', 'يمكنك تحديث تقرير اليوم المحدد عند توفر الصلاحية.') : labelFor('performance_existing_readonly_description', 'يوجد تقرير سابق لهذا التاريخ، ويمكن عرضه في السجل أدناه فقط.') : labelFor('performance_new_report_description', 'أدخل بيانات المبيعات والمرتجعات، وستُجلب المتحصلات تلقائياً.')}</CardDescription></CardHeader><CardContent className="p-5 sm:p-6"><PerformanceReportForm form={form} onChange={setForm} branches={branches} isManager={false} editing={Boolean(secondaryReport && secondaryCanEditSelected)} existingReport={Boolean(secondaryReport)} canEditPast={canEditPast} /></CardContent></Card>
          <PerformanceFilters branches={branches} selectedBranch={selectedBranch} setSelectedBranch={setSelectedBranch} filterDay={filterDay} setFilterDay={setFilterDay} filterStartDate={filterStartDate} setFilterStartDate={setFilterStartDate} filterEndDate={filterEndDate} setFilterEndDate={setFilterEndDate} canChooseBranch={false} />
          <ReportsTable reports={visibleReports} branchName={branchName} loading={isLoading} onEdit={openEdit} allowEdit={canEditPast} />
        </>
      ) : (
        <>
          <Card className="border-primary/10 shadow-sm"><CardHeader className="pb-3"><CardTitle className="text-lg">{labelFor('performance_branch_tabs_title', 'سجل الأداء حسب الفروع')}</CardTitle><CardDescription>{labelFor('performance_branch_tabs_description', 'اختر تبويباً لعرض تقارير فرع محدد، أو راجع إجمالي التقارير في جميع الفروع.')}</CardDescription></CardHeader><CardContent><Tabs value={selectedBranch} onValueChange={setSelectedBranch} dir="rtl"><TabsList className="h-auto w-full justify-start overflow-x-auto rounded-xl bg-muted/60 p-1"><TabsTrigger value="all" className="shrink-0">{labelFor('performance_all_branches', 'كل الفروع')}</TabsTrigger>{branches.map((branch: any) => <TabsTrigger key={branch.id} value={String(branch.id)} className="shrink-0">{branch.name}</TabsTrigger>)}</TabsList></Tabs></CardContent></Card>
          <PerformanceFilters branches={branches} selectedBranch={selectedBranch} setSelectedBranch={setSelectedBranch} filterDay={filterDay} setFilterDay={setFilterDay} filterStartDate={filterStartDate} setFilterStartDate={setFilterStartDate} filterEndDate={filterEndDate} setFilterEndDate={setFilterEndDate} canChooseBranch />
          <ReportsTable reports={visibleReports} branchName={branchName} loading={isLoading} onEdit={openEdit} allowEdit />
        </>
      )}

      <Dialog open={Boolean(editReport)} onOpenChange={(open) => { if (!open) setEditReport(null); }}>
        <DialogContent className="max-h-[92vh] max-w-3xl overflow-y-auto" dir="rtl"><DialogHeader><DialogTitle>{labelFor('performance_edit_title', 'تعديل تقرير الأداء')}</DialogTitle><DialogDescription>{labelFor('performance_edit_description', 'تعديل بيانات تقرير')} {editReport ? `${branchName(editReport.branchId)} — ${dateLabel(editReport.reportDate)}` : ''}.</DialogDescription></DialogHeader><PerformanceReportForm form={form} onChange={setForm} branches={branches} isManager={isManager} editing existingReport canEditPast={isManager || canEditPast} onClose={() => setEditReport(null)} /></DialogContent>
      </Dialog>
    </div>
  );
}

function PerformanceFilters({ branches, selectedBranch, setSelectedBranch, filterDay, setFilterDay, filterStartDate, setFilterStartDate, filterEndDate, setFilterEndDate, canChooseBranch }: { branches: any[]; selectedBranch: string; setSelectedBranch: (value: string) => void; filterDay: string; setFilterDay: (value: string) => void; filterStartDate: string; setFilterStartDate: (value: string) => void; filterEndDate: string; setFilterEndDate: (value: string) => void; canChooseBranch: boolean }) {
  const { labelFor } = useSystemLabels();
  const clearFilters = () => { setFilterDay(''); setFilterStartDate(''); setFilterEndDate(''); if (canChooseBranch) setSelectedBranch('all'); };
  return <Card className="border-primary/10 shadow-sm"><CardHeader className="pb-3"><CardTitle className="text-base">{labelFor('performance_filters', 'تصفية وفرز السجل')}</CardTitle><CardDescription>{labelFor('performance_filters_description', 'يمكن تحديد يوم محدد أو فترة زمنية، مع اختيار الفرع عند توفر الصلاحية.')}</CardDescription></CardHeader><CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5"><div className="space-y-1.5"><Label>{labelFor('field_specific_day', 'يوم محدد')}</Label><Input type="date" value={filterDay} onChange={event => setFilterDay(event.target.value)} /></div><div className="space-y-1.5"><Label>{labelFor('field_from_date', 'من تاريخ')}</Label><Input type="date" value={filterStartDate} onChange={event => setFilterStartDate(event.target.value)} /></div><div className="space-y-1.5"><Label>{labelFor('field_to_date', 'إلى تاريخ')}</Label><Input type="date" value={filterEndDate} onChange={event => setFilterEndDate(event.target.value)} /></div>{canChooseBranch && <div className="space-y-1.5"><Label>{labelFor('field_branch', 'الفرع')}</Label><select value={selectedBranch} onChange={event => setSelectedBranch(event.target.value)} className="flex h-9 w-full rounded-md border border-input bg-background px-3 text-sm"><option value="all">{labelFor('performance_all_branches', 'كل الفروع')}</option>{branches.map(branch => <option key={branch.id} value={branch.id}>{branch.name}</option>)}</select></div>}<div className="flex items-end"><Button type="button" variant="outline" onClick={clearFilters} className="w-full">{labelFor('action_clear_filters', 'إزالة التصفية')}</Button></div></CardContent></Card>;
}

function ReportsTable({ reports, branchName, loading, onEdit, allowEdit }: { reports: any[]; branchName: (branchId: number) => string; loading: boolean; onEdit: (report: any) => void; allowEdit: boolean }) {
  const { labelFor } = useSystemLabels();
  const totals = summarizePerformanceReports(reports);
  return (
    <Card className="overflow-hidden border-border/80 shadow-sm"><CardHeader className="border-b bg-muted/20"><CardTitle className="flex items-center gap-2 text-lg"><FileText className="h-5 w-5 text-primary" />{labelFor('performance_previous_reports', 'سجل التقارير السابقة')}</CardTitle><CardDescription>{labelFor('performance_previous_reports_description', 'كل صف يمثل يوماً واحداً ولا يمكن إنشاء سجل مكرر للتاريخ نفسه داخل الفرع.')}</CardDescription></CardHeader><CardContent className="p-0"><div className="overflow-x-auto"><Table><TableHeader><TableRow className="bg-muted/40 hover:bg-muted/40"><TableHead className="text-right">{labelFor('field_date', 'التاريخ')}</TableHead><TableHead className="text-right">{labelFor('field_branch', 'الفرع')}</TableHead><TableHead className="text-center">{labelFor('performance_sales_count', 'عدد المبيعات')}</TableHead><TableHead className="text-left">{labelFor('performance_sales_value', 'قيمة المبيعات')}</TableHead><TableHead className="text-center">{labelFor('performance_returns_count', 'عدد المرتجعات')}</TableHead><TableHead className="text-left">{labelFor('performance_returns_value', 'قيمة المرتجعات')}</TableHead><TableHead className="text-left">{labelFor('performance_net_sales', 'صافي المبيعات')}</TableHead><TableHead className="text-center">{labelFor('performance_receipts', 'سندات القبض')}</TableHead><TableHead className="text-left">{labelFor('performance_collections', 'المتحصلات')}</TableHead>{allowEdit && <TableHead className="w-20 text-center">{labelFor('field_actions', 'إجراءات')}</TableHead>}</TableRow></TableHeader><TableBody>{loading ? <TableRow><TableCell colSpan={allowEdit ? 10 : 9} className="h-32 text-center text-muted-foreground">{labelFor('performance_loading', 'جارٍ تحميل تقارير الأداء...')}</TableCell></TableRow> : reports.length === 0 ? <TableRow><TableCell colSpan={allowEdit ? 10 : 9} className="h-36 text-center text-muted-foreground"><BarChart3 className="mx-auto mb-2 h-8 w-8 opacity-30" />{labelFor('performance_no_reports', 'لا توجد تقارير أداء ضمن هذا النطاق.')}</TableCell></TableRow> : reports.map((report) => <TableRow key={report.id} className="hover:bg-primary/[0.025]"><TableCell className="whitespace-nowrap font-medium">{dateLabel(report.reportDate)}</TableCell><TableCell className="whitespace-nowrap">{branchName(report.branchId)}</TableCell><TableCell className="text-center"><Badge variant="secondary">{report.salesInvoicesCount}</Badge></TableCell><TableCell className="whitespace-nowrap text-left">{formatAmount(report.salesInvoicesValue)}</TableCell><TableCell className="text-center"><Badge variant="outline">{report.returnsInvoicesCount}</Badge></TableCell><TableCell className="whitespace-nowrap text-left">{formatAmount(report.returnsInvoicesValue)}</TableCell><TableCell className="whitespace-nowrap text-left font-semibold text-primary">{formatAmount(report.netSalesValue)}</TableCell><TableCell className="text-center">{report.receiptsCount}</TableCell><TableCell className="whitespace-nowrap text-left font-semibold text-emerald-700 dark:text-emerald-300">{formatAmount(report.collectionsValue)}</TableCell>{allowEdit && <TableCell className="text-center"><Button variant="ghost" size="icon" className="h-8 w-8 text-primary" title={labelFor('action_edit', 'تعديل')} onClick={() => onEdit(report)}><Pencil className="h-4 w-4" /></Button></TableCell>}</TableRow>)}</TableBody><TableFooter><TableRow className="bg-primary/5 font-semibold"><TableCell colSpan={2}>{labelFor('action_total', 'الإجمالي')}</TableCell><TableCell className="text-center">{totals.salesCount.toLocaleString('ar-SA')}</TableCell><TableCell className="whitespace-nowrap text-left">{formatAmount(totals.salesValue)}</TableCell><TableCell className="text-center">{totals.returnsCount.toLocaleString('ar-SA')}</TableCell><TableCell className="whitespace-nowrap text-left">{formatAmount(totals.returnsValue)}</TableCell><TableCell className="whitespace-nowrap text-left text-primary">{formatAmount(totals.netSales)}</TableCell><TableCell className="text-center">{totals.receiptsCount.toLocaleString('ar-SA')}</TableCell><TableCell className="whitespace-nowrap text-left text-emerald-700">{formatAmount(totals.collectionsValue)}</TableCell>{allowEdit && <TableCell />}</TableRow></TableFooter></Table></div></CardContent></Card>
  );
}
