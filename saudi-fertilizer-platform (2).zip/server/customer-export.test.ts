import { describe, expect, it } from 'vitest';
import { buildCustomerExportRows, selectCustomersForExport } from '../client/src/lib/customerExport';

const customers = [
  { id: 1, customerNumber: '100', name: 'العميل الأول', branchId: 1, delegateId: 10, phone: '0500000000' },
  { id: 2, customerNumber: '101', name: 'العميل الثاني', branchId: 2, delegateId: 11, phone: null },
];

const branches = [{ id: 1, name: 'الرياض' }, { id: 2, name: 'بريدة' }];
const delegates = [{ id: 10, fullName: 'أحمد حسانين' }, { id: 11, fullName: 'مندوب الفرع' }];

describe('تحديد وتجهيز تصدير العملاء', () => {
  it('يجهز العميل المحدد فقط للتصدير', () => {
    const selectedRows = buildCustomerExportRows(selectCustomersForExport(customers, [2]), branches, delegates);

    expect(selectedRows).toEqual([{
      'رقم العميل': '101',
      'اسم العميل': 'العميل الثاني',
      'الفرع': 'بريدة',
      'المندوب': 'مندوب الفرع',
      'الهاتف': '',
    }]);
  });

  it('يجهز جميع العملاء عند عدم وجود تحديد', () => {
    const allRows = buildCustomerExportRows(selectCustomersForExport(customers, []), branches, delegates);

    expect(allRows).toHaveLength(2);
    expect(allRows.map(row => row['رقم العميل'])).toEqual(['100', '101']);
  });
});
