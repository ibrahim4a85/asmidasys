CREATE TABLE `password_reset_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`recoveryEmail` varchar(320) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`consumedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `password_reset_codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `password_reset_codes_user_unique` UNIQUE(`userId`),
	CONSTRAINT `password_reset_codes_hash_unique` UNIQUE(`codeHash`)
);
