export type CustomerSortKey = "customerNumber" | "name" | "branch" | "delegate" | "phone";
export type CustomerSortDirection = "asc" | "desc";

type SortableCustomer = {
  customerNumber: string;
  name: string;
  branchId: number | null;
  delegateId: number | null;
  phone?: string | null;
};

type NamedRecord = { id: number; name?: string; fullName?: string };

const arabicNumericCollator = new Intl.Collator("ar", { numeric: true, sensitivity: "base" });

export function sortCustomerRows<T extends SortableCustomer>(
  customers: T[],
  key: CustomerSortKey,
  direction: CustomerSortDirection,
  branches: NamedRecord[] = [],
  delegates: NamedRecord[] = [],
): T[] {
  const branchesById = new Map(branches.map((branch) => [branch.id, branch.name ?? ""]));
  const delegatesById = new Map(delegates.map((delegate) => [delegate.id, delegate.fullName ?? delegate.name ?? ""]));
  const directionFactor = direction === "asc" ? 1 : -1;

  const getValue = (customer: T) => {
    if (key === "branch") return branchesById.get(customer.branchId ?? -1) ?? "";
    if (key === "delegate") return delegatesById.get(customer.delegateId ?? -1) ?? "";
    return customer[key] ?? "";
  };

  return customers
    .map((customer, index) => ({ customer, index }))
    .sort((left, right) => {
      const comparison = arabicNumericCollator.compare(String(getValue(left.customer)), String(getValue(right.customer)));
      return comparison === 0 ? left.index - right.index : comparison * directionFactor;
    })
    .map(({ customer }) => customer);
}
