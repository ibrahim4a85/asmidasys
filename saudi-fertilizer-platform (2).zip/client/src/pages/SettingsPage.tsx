import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { FileDropzone } from '@/components/FileDropzone';
import { useSystemAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Plus, Pencil, Trash2, Palette, Building2, Calendar, MapPin, ListChecks, Image, Newspaper, Database, Download, Printer, Upload, AlertTriangle, ShieldCheck, LayoutDashboard, ReceiptText, ArrowUp, ArrowDown, FolderTree, GripVertical, Moon, Sun, Type, UsersRound } from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import { getConfiguredBranchNumber, getVoucherYearSuffix } from '@shared/branchOrdering';
import { DeleteConfirmationDialog } from '@/components/DeleteConfirmationDialog';
import { receiptFormLabelOptions, receiptFormSectionOptions, type ReceiptCustomField, type ReceiptFormSectionId } from '@shared/receiptFormPresentation';
import { readSystemLabelOverrides, systemLabelOptions, type SystemLabelId } from '@shared/systemLabelPresentation';
import { useSystemLabels } from '@/hooks/useSystemLabels';
import { moveDashboardShortcut, parseDashboardShortcutIds } from '@shared/dashboardShortcutOrder';
import { SystemUserTypeSettings } from '@/components/SystemUserTypeSettings';
import { APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY, APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY, readApprovalParticipantCatalogs } from '@shared/approvalParticipantCatalogs';

const blankPeriod = { name: '', startDate: '', endDate: '', isActive: false };
const blankBranch = { name: '', address: '', receiptSerial: '', paymentSerial: '' };
const blankList = { listType: 'payment_method', name: '', parentId: '__root__', requiresAttachment: true, sortOrder: '0' };
const dateValue = (date: unknown) => date ? new Date(date as string).toISOString().slice(0, 10) : '';
const fileToDataUrl = (file: File) => new Promise<string>((resolve, reject) => {
  const reader = new FileReader();
  reader.onerror = () => reject(new Error('تعذر قراءة الملف المختار'));
  reader.onload = () => resolve(String(reader.result));
  reader.readAsDataURL(file);
});

export default function SettingsPage() {
  const { user, isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const canManageData = isAdmin || Boolean((user?.permissions as any)?.dataDelete);
  if (!canManageData) return <div className="rtl-page py-20 text-center text-muted-foreground" dir="rtl">{labelFor('settings_access_denied', 'ليس لديك صلاحية للوصول إلى إعدادات النظام')}</div>;

  return (
    <div className="rtl-page space-y-6 text-right" dir="rtl">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold">{isAdmin ? labelFor('settings_title', 'إعدادات النظام') : labelFor('settings_data_management', 'إدارة البيانات')}</h1>
        <p className="text-sm text-muted-foreground">{isAdmin ? labelFor('settings_administration_description', 'إدارة بيانات المنصة ومظهرها وقوائمها التشغيلية') : labelFor('settings_data_management_description', 'حذف انتقائي ومؤمّن للبيانات التي منحك المدير صلاحية إدارتها')}</p>
      </div>
      <Tabs defaultValue={isAdmin ? 'company' : 'data-admin'} className="space-y-4" dir="rtl">
        <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto p-1 sm:w-fit sm:flex-wrap" dir="rtl">
          {isAdmin && <><TabsTrigger value="company" className="gap-1 whitespace-nowrap"><Building2 className="h-3.5 w-3.5" />{labelFor('settings_tab_company', 'الشركة')}</TabsTrigger><TabsTrigger value="theme" className="gap-1 whitespace-nowrap"><Palette className="h-3.5 w-3.5" />{labelFor('settings_tab_theme', 'المظهر')}</TabsTrigger><TabsTrigger value="dashboard-interface" className="gap-1 whitespace-nowrap"><LayoutDashboard className="h-3.5 w-3.5" />{labelFor('settings_tab_dashboard_interface', 'واجهة اللوحة')}</TabsTrigger><TabsTrigger value="receipt-form" className="gap-1 whitespace-nowrap"><ReceiptText className="h-3.5 w-3.5" />{labelFor('settings_tab_receipt_form', 'نموذج السند')}</TabsTrigger><TabsTrigger value="terminology" className="gap-1 whitespace-nowrap"><Type className="h-3.5 w-3.5" />{labelFor('settings_tab_terminology', 'التسميات')}</TabsTrigger><TabsTrigger value="user-types" className="gap-1 whitespace-nowrap"><UsersRound className="h-3.5 w-3.5" />أنواع المستخدمين</TabsTrigger><TabsTrigger value="periods" className="gap-1 whitespace-nowrap"><Calendar className="h-3.5 w-3.5" />{labelFor('settings_tab_financial_periods', 'الفترات المالية')}</TabsTrigger><TabsTrigger value="branches" className="gap-1 whitespace-nowrap"><MapPin className="h-3.5 w-3.5" />{labelFor('settings_tab_branches', 'الفروع')}</TabsTrigger><TabsTrigger value="lists" className="gap-1 whitespace-nowrap"><ListChecks className="h-3.5 w-3.5" />{labelFor('settings_tab_input_lists', 'قوائم الإدخال')}</TabsTrigger><TabsTrigger value="printing" className="gap-1 whitespace-nowrap"><Printer className="h-3.5 w-3.5" />{labelFor('settings_tab_printing', 'المطبوعات')}</TabsTrigger><TabsTrigger value="approvals" className="gap-1 whitespace-nowrap"><ShieldCheck className="h-3.5 w-3.5" />{labelFor('settings_tab_approval_cycle', 'دورة التعميد')}</TabsTrigger><TabsTrigger value="login" className="gap-1 whitespace-nowrap"><Image className="h-3.5 w-3.5" />{labelFor('settings_tab_login', 'واجهة الدخول')}</TabsTrigger><TabsTrigger value="news" className="gap-1 whitespace-nowrap"><Newspaper className="h-3.5 w-3.5" />{labelFor('settings_tab_news', 'الشريط الإخباري')}</TabsTrigger><TabsTrigger value="backup" className="gap-1 whitespace-nowrap"><Database className="h-3.5 w-3.5" />{labelFor('settings_tab_backup', 'النسخ الاحتياطي')}</TabsTrigger></>}
          <TabsTrigger value="data-admin" className="gap-1 whitespace-nowrap"><ShieldCheck className="h-3.5 w-3.5" />{labelFor('settings_data_management', 'إدارة البيانات')}</TabsTrigger>
        </TabsList>
        {isAdmin && <><TabsContent value="company"><div className="space-y-4"><CompanySettings /><CompanyNameDisplaySettings /><PasswordRecoverySettings /></div></TabsContent><TabsContent value="theme"><ThemeSettings /></TabsContent><TabsContent value="dashboard-interface"><DashboardPresentationSettings /></TabsContent><TabsContent value="receipt-form"><ReceiptFormPresentationSettings /></TabsContent><TabsContent value="terminology"><SystemTerminologySettings /></TabsContent><TabsContent value="user-types"><SystemUserTypeSettings /></TabsContent><TabsContent value="periods"><PeriodsSettings /></TabsContent><TabsContent value="branches"><BranchesSettings /></TabsContent><TabsContent value="lists"><InputListsSettings /></TabsContent><TabsContent value="printing"><PrintSettings /></TabsContent><TabsContent value="approvals"><ApprovalWorkflowSettings /></TabsContent><TabsContent value="login"><div className="space-y-4"><LoginSettings /><LoginDarkModeSettings /></div></TabsContent><TabsContent value="news"><NewsSettings /></TabsContent><TabsContent value="backup"><BackupSettings /></TabsContent></>}
        <TabsContent value="data-admin"><DataAdministration /></TabsContent>
      </Tabs>
    </div>
  );
}

function CompanyNameDisplaySettings() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const [fontSize, setFontSize] = useState('12');
  const [width, setWidth] = useState('185');
  useEffect(() => {
    if (settings) {
      setFontSize(settings.sidebar_company_name_font_size || '12');
      setWidth(settings.sidebar_company_name_width || '185');
    }
  }, [settings]);
  const save = async () => {
    const normalizedFontSize = String(Math.min(24, Math.max(10, Number(fontSize) || 12)));
    const normalizedWidth = String(Math.min(470, Math.max(80, Number(width) || 185)));
    try {
      await updateMutation.mutateAsync({ entries: [
        { key: 'sidebar_company_name_font_size', value: normalizedFontSize },
        { key: 'sidebar_company_name_width', value: normalizedWidth },
      ] });
      await utils.settings.getAll.invalidate();
      await refetch();
      toast.success(labelFor('settings_company_display_saved', 'تم حفظ إعدادات عرض اسم الشركة'));
    } catch (error: any) {
      toast.error(error?.message || labelFor('settings_company_display_save_error', 'تعذر حفظ إعدادات عرض اسم الشركة'));
    }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_company_display_title', 'عرض اسم الشركة في رأس النظام')}</CardTitle></CardHeader><CardContent className="space-y-4"><p className="text-sm text-muted-foreground">{labelFor('settings_company_display_description', 'تحكم بحجم الخط والمساحة المخصصة لاسم الشركة في رأس الشريط الجانبي. تُطبق التغييرات فور حفظها.')}</p><div className="grid gap-4 sm:grid-cols-2"><div className="space-y-2"><Label htmlFor="company-name-font-size">{labelFor('settings_company_display_font_size', 'حجم خط اسم الشركة (10–24 بكسل)')}</Label><Input id="company-name-font-size" type="number" min="10" max="24" value={fontSize} onChange={event => setFontSize(event.target.value)} /></div><div className="space-y-2"><Label htmlFor="company-name-width">{labelFor('settings_company_display_width', 'المساحة المخصصة للاسم (80–470 بكسل)')}</Label><Input id="company-name-width" type="number" min="80" max="470" value={width} onChange={event => setWidth(event.target.value)} /></div></div><div className="rounded-lg border bg-muted/30 p-3"><span className="text-muted-foreground text-xs">{labelFor('settings_company_display_preview', 'معاينة:')} </span><strong style={{ fontSize: `${Math.min(24, Math.max(10, Number(fontSize) || 12))}px`, display: 'inline-block', maxWidth: `${Math.min(470, Math.max(80, Number(width) || 185))}px` }} className="truncate align-middle">شركة الأسمدة المتحدة السعودية</strong></div><Button onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_company_display_saving', 'جارٍ الحفظ...') : labelFor('settings_company_display_save', 'حفظ إعدادات العرض')}</Button></CardContent></Card>;
}

function ApprovalWorkflowSettings() {
  const { labelFor } = useSystemLabels();
  const { data: documentTypes, refetch: refetchDocumentTypes } = trpc.documentTypes.list.useQuery();
  const { data: users } = trpc.systemUsers.list.useQuery();
  const { data: workflows, refetch: refetchWorkflows } = trpc.approvalWorkflows.list.useQuery();
  const { data: approvalSettings, refetch: refetchApprovalSettings } = trpc.settings.getAll.useQuery();
  const updateApprovalSettings = trpc.settings.updateMany.useMutation();
  const [documentTypeId, setDocumentTypeId] = useState('');
  const [newDocumentType, setNewDocumentType] = useState('');
  const [selectedName, setSelectedName] = useState('');
  const [templateRequirement, setTemplateRequirement] = useState<'optional' | 'required'>('optional');
  const [templateFile, setTemplateFile] = useState<File | null>(null);
  const [reviewerUserIds, setReviewerUserIds] = useState<number[]>([]);
  const [reviewerCatalogUserIds, setReviewerCatalogUserIds] = useState<number[]>([]);
  const [reviewerSequential, setReviewerSequential] = useState(false);
  const [approverUserIds, setApproverUserIds] = useState<number[]>([]);
  const [approverCatalogUserIds, setApproverCatalogUserIds] = useState<number[]>([]);
  const [approverSequential, setApproverSequential] = useState(false);
  const [requiredApprovals, setRequiredApprovals] = useState('1');
  const [deleteTypeOpen, setDeleteTypeOpen] = useState(false);
  const [footerEnabled, setFooterEnabled] = useState(true);
  const [footerLabel, setFooterLabel] = useState('تم التعميد');
  const [footerHeight, setFooterHeight] = useState('66');
  const [footerFontSize, setFooterFontSize] = useState('8');
  const [footerColor, setFooterColor] = useState('#0f5132');
  const createDocumentType = trpc.documentTypes.create.useMutation({ onSuccess: () => { setNewDocumentType(''); refetchDocumentTypes(); toast.success('تمت إضافة نوع التعميد'); }, onError: error => toast.error(error.message) });
  const updateDocumentType = trpc.documentTypes.update.useMutation({ onSuccess: () => { setTemplateFile(null); refetchDocumentTypes(); toast.success('تم حفظ إعدادات نوع التعميد'); }, onError: error => toast.error(error.message) });
  const deleteDocumentType = trpc.documentTypes.delete.useMutation({ onSuccess: () => { setDeleteTypeOpen(false); setDocumentTypeId(''); refetchDocumentTypes(); refetchWorkflows(); toast.success('تم حذف نوع التعميد ومساره غير المستخدم'); }, onError: error => toast.error(error.message) });
  const uploadTemplate = trpc.files.uploadApprovalTemplate.useMutation();
  const saveWorkflow = trpc.approvalWorkflows.save.useMutation({ onSuccess: () => { refetchWorkflows(); toast.success('تم حفظ صلاحيات ومسار التعميد'); }, onError: error => toast.error(error.message) });
  const selectedType = documentTypes?.find(type => type.id === Number(documentTypeId));
  const selectedWorkflow = workflows?.find((workflow: any) => workflow.documentTypeId === Number(documentTypeId));
  const activeUsers = users?.filter((systemUser: any) => systemUser.isActive) || [];
  const reviewerCatalogUsers = activeUsers.filter((systemUser: any) => reviewerCatalogUserIds.includes(systemUser.id));
  const approverCatalogUsers = activeUsers.filter((systemUser: any) => approverCatalogUserIds.includes(systemUser.id));
  const toggleUser = (setter: React.Dispatch<React.SetStateAction<number[]>>, id: number) => setter(current => current.includes(id) ? current.filter(value => value !== id) : [...current, id]);

  useEffect(() => { if (!documentTypeId && documentTypes?.[0]) setDocumentTypeId(String(documentTypes[0].id)); }, [documentTypeId, documentTypes]);
  useEffect(() => {
    setSelectedName(selectedType?.name || '');
    setTemplateRequirement(selectedType?.templateRequirement === 'required' ? 'required' : 'optional');
  }, [selectedType?.id, selectedType?.name, selectedType?.templateRequirement]);
  useEffect(() => {
    if (!selectedWorkflow) { setReviewerUserIds([]); setReviewerSequential(false); setApproverUserIds([]); setApproverSequential(false); setRequiredApprovals('1'); return; }
    setReviewerUserIds(selectedWorkflow.reviewers?.map((reviewer: any) => reviewer.systemUserId) || []);
    setReviewerSequential(Boolean(selectedWorkflow.reviewerSequential));
    setApproverUserIds(selectedWorkflow.approvers?.map((approver: any) => approver.systemUserId) || []);
    setApproverSequential(Boolean(selectedWorkflow.approverSequential));
    setRequiredApprovals(String(selectedWorkflow.requiredApprovals || 1));
  }, [selectedWorkflow?.id]);
  useEffect(() => {
    if (!approvalSettings) return;
    setFooterEnabled(approvalSettings.approval_footer_enabled !== 'false'); setFooterLabel(approvalSettings.approval_footer_label || 'تم التعميد'); setFooterHeight(approvalSettings.approval_footer_height || '66'); setFooterFontSize(approvalSettings.approval_footer_font_size || '8'); setFooterColor(approvalSettings.approval_footer_color || '#0f5132');
  }, [approvalSettings]);
  useEffect(() => {
    if (!approvalSettings || !users) return;
    const participantCatalogs = readApprovalParticipantCatalogs(approvalSettings, users);
    setReviewerCatalogUserIds(participantCatalogs.reviewerUserIds);
    setApproverCatalogUserIds(participantCatalogs.approverUserIds);
  }, [approvalSettings, users]);

  const saveTemplate = async () => {
    if (!documentTypeId || !templateFile) return toast.error('اختر نوع التعميد وملف النموذج أولاً');
    if (!/\.(pdf|docx|xlsx)$/i.test(templateFile.name)) return toast.error('يسمح برفع نموذج PDF أو Word أو Excel بصيغة XLSX');
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(new Error('تعذر قراءة النموذج')); reader.readAsDataURL(templateFile); });
      const uploaded = await uploadTemplate.mutateAsync({ fileName: templateFile.name, dataUrl });
      const mimeType = templateFile.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : templateFile.name.toLowerCase().endsWith('.xlsx') ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      await updateDocumentType.mutateAsync({ id: Number(documentTypeId), templateUrl: uploaded.url, templateName: uploaded.fileName, templateMimeType: mimeType });
    } catch (error: any) { toast.error(error?.message || 'تعذر رفع نموذج التعميد'); }
  };
  const saveFooterSettings = async () => { try { await updateApprovalSettings.mutateAsync({ entries: [{ key: 'approval_footer_enabled', value: footerEnabled ? 'true' : 'false' }, { key: 'approval_footer_label', value: footerLabel.trim() || 'تم التعميد' }, { key: 'approval_footer_height', value: String(Math.min(120, Math.max(48, Number(footerHeight) || 66))) }, { key: 'approval_footer_font_size', value: String(Math.min(14, Math.max(7, Number(footerFontSize) || 8))) }, { key: 'approval_footer_color', value: /^#[0-9A-Fa-f]{6}$/.test(footerColor) ? footerColor : '#0f5132' }] }); await refetchApprovalSettings(); toast.success('تم حفظ إعدادات ختم تذييل التعميد'); } catch (error: any) { toast.error(error?.message || 'تعذر حفظ إعدادات ختم التعميد'); } };
  const saveParticipantCatalogs = async () => { try { await updateApprovalSettings.mutateAsync({ entries: [{ key: APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY, value: JSON.stringify(reviewerCatalogUserIds) }, { key: APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY, value: JSON.stringify(approverCatalogUserIds) }] }); await refetchApprovalSettings(); toast.success('تم حفظ قائمتي المراجعين والمفوضين المعتمدتين'); } catch (error: any) { toast.error(error?.message || 'تعذر حفظ قوائم التعميد المعتمدة'); } };
  const saveWorkflowSettings = () => {
    const required = Math.max(1, Number(requiredApprovals) || 1);
    if (!documentTypeId || !approverUserIds.length) return toast.error('اختر نوع التعميد ومفوضاً واحداً على الأقل');
    if (reviewerUserIds.some(id => !reviewerCatalogUserIds.includes(id)) || approverUserIds.some(id => !approverCatalogUserIds.includes(id))) return toast.error('اختر المراجعين والمفوضين من القوائم المعتمدة فقط');
    if (required > approverUserIds.length) return toast.error('الحد الأدنى للمفوضين أكبر من عدد المفوضين المحددين');
    saveWorkflow.mutate({ documentTypeId: Number(documentTypeId), reviewerUserIds, reviewerSequential, approverUserIds, approverSequential, requiredApprovals: required });
  };

  return <><Card><CardHeader><CardTitle>{labelFor('settings_approval_title', 'دورة التعميدات')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_approval_subtitle', 'حدّد لكل نوع التزام النموذج، وصلاحيات المراجعين والمفوضين، والترتيب، والحد الأدنى للموافقات.')}</p></CardHeader><CardContent className="space-y-6">
    <div className="rounded-xl border bg-muted/30 p-4"><Label>{labelFor('settings_approval_editor_add_type', 'إضافة نوع تعميد')}</Label><div className="mt-2 flex flex-col gap-2 sm:flex-row"><Input value={newDocumentType} onChange={event => setNewDocumentType(event.target.value)} placeholder={labelFor('settings_approval_editor_type_example', 'مثال: طلب إجازة')} /><Button className="w-full sm:w-auto" variant="outline" onClick={() => newDocumentType.trim() ? createDocumentType.mutate({ name: newDocumentType.trim(), templateRequirement: 'optional' }) : toast.error('أدخل اسم نوع التعميد')}>{labelFor('action_add', 'إضافة')}</Button></div></div>
    <div className="grid gap-4 md:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_approval_editor_type_label', 'نوع التعميد')}</Label><Select value={documentTypeId} onValueChange={setDocumentTypeId}><SelectTrigger><SelectValue placeholder={labelFor('settings_approval_editor_type_placeholder', 'اختر نوع التعميد')} /></SelectTrigger><SelectContent>{documentTypes?.map(type => <SelectItem key={type.id} value={String(type.id)}>{type.name}{type.isActive ? '' : ' (غير نشط)'}</SelectItem>)}</SelectContent></Select></div><div className="space-y-2"><Label>{labelFor('settings_approval_editor_template_requirement', 'التزام النموذج')}</Label><Select value={templateRequirement} onValueChange={(value: 'optional' | 'required') => setTemplateRequirement(value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="optional">{labelFor('settings_approval_editor_template_optional', 'اختياري')}</SelectItem><SelectItem value="required">{labelFor('settings_approval_editor_template_required', 'إلزامي قبل الإرسال')}</SelectItem></SelectContent></Select></div></div>
    {selectedType && <div className="grid gap-3 rounded-xl border p-4 md:grid-cols-[1fr_auto_auto]"><div className="space-y-2"><Label>{labelFor('settings_approval_editor_type_name', 'اسم نوع التعميد')}</Label><Input value={selectedName} onChange={event => setSelectedName(event.target.value)} /></div><Button className="self-end" variant="outline" onClick={() => updateDocumentType.mutate({ id: selectedType.id, name: selectedName.trim(), templateRequirement })} disabled={!selectedName.trim() || updateDocumentType.isPending}>حفظ النوع</Button><Button className="self-end" variant="destructive" onClick={() => setDeleteTypeOpen(true)}><Trash2 className="ml-1 h-4 w-4" />حذف النوع</Button></div>}
    <div className="rounded-xl border bg-muted/20 p-4"><div className="grid gap-4 md:grid-cols-2"><div className="space-y-2"><FileDropzone label={labelFor('settings_approval_editor_template_file', 'نموذج النوع (PDF أو Word أو Excel)')} description="اسحب النموذج أو انقر لاختياره. لن يُرفع قبل الضغط على زر رفع وحفظ النموذج." accept=".pdf,.docx,.xlsx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" maxBytes={10 * 1024 * 1024} previewImage={false} disabled={uploadTemplate.isPending || updateDocumentType.isPending} isUploading={uploadTemplate.isPending} onFileSelected={file => setTemplateFile(file)} onClear={() => setTemplateFile(null)} /><p className="text-xs text-muted-foreground">{selectedType?.templateName ? `${labelFor('settings_approval_editor_template_current_prefix', 'النموذج الحالي:')} ${selectedType.templateName}` : labelFor('settings_approval_editor_template_missing', 'لم يُرفع نموذج لهذا النوع بعد.')}</p><Button type="button" variant="outline" onClick={saveTemplate} disabled={!templateFile || uploadTemplate.isPending || updateDocumentType.isPending}><Upload className="ml-1 h-4 w-4" />رفع وحفظ النموذج</Button></div><div className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs leading-6 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">تُحفظ الملفات كمراجع تخزين آمنة. يدعم ختم رقم الطلب والتذييل التلقائيان ملفات PDF وWord؛ أما Excel فيُحتفظ به ويُعرض أو يُحمّل بمرجعه الأصلي.</div></div></div>
    <div className="grid gap-4 rounded-xl border border-sky-200 bg-sky-50/40 p-4 dark:border-sky-900 dark:bg-sky-950/20 lg:grid-cols-2"><section className="space-y-3"><div><Label>قائمة المراجعين المعتمدة ({reviewerCatalogUserIds.length})</Label><p className="mt-1 text-xs text-muted-foreground">بعد الحفظ لا يمكن اختيار مراجع لنوع تعميد إلا من هذه القائمة.</p></div><div className="grid gap-2 sm:grid-cols-2">{activeUsers.map((systemUser: any) => <label key={`reviewer-catalog-${systemUser.id}`} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm"><Checkbox checked={reviewerCatalogUserIds.includes(systemUser.id)} onCheckedChange={() => toggleUser(setReviewerCatalogUserIds, systemUser.id)} /><span>{systemUser.fullName}</span></label>)}</div></section><section className="space-y-3"><div><Label>قائمة المفوضين المعتمدة ({approverCatalogUserIds.length})</Label><p className="mt-1 text-xs text-muted-foreground">بعد الحفظ لا يمكن اختيار مفوض لنوع تعميد إلا من هذه القائمة.</p></div><div className="grid gap-2 sm:grid-cols-2">{activeUsers.map((systemUser: any) => <label key={`approver-catalog-${systemUser.id}`} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm"><Checkbox checked={approverCatalogUserIds.includes(systemUser.id)} onCheckedChange={() => toggleUser(setApproverCatalogUserIds, systemUser.id)} /><span>{systemUser.fullName}{systemUser.boardPosition ? ` — ${systemUser.boardPosition}` : ''}</span></label>)}</div></section><div className="lg:col-span-2"><Button type="button" variant="outline" onClick={saveParticipantCatalogs} disabled={updateApprovalSettings.isPending}>{updateApprovalSettings.isPending ? 'جارٍ الحفظ...' : 'حفظ القوائم المعتمدة'}</Button></div></div>
    <div className="grid gap-5 lg:grid-cols-2"><section className="space-y-3 rounded-xl border p-4"><div className="flex items-center justify-between"><div><Label>{labelFor('settings_approval_editor_reviewers', 'المراجعون')} ({reviewerUserIds.length})</Label><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_approval_editor_reviewers_helper', 'المستخدمون المحددون هم فقط المخوّلون بمراجعة هذا النوع.')}</p></div><div className="flex items-center gap-2 text-xs"><Switch checked={reviewerSequential} onCheckedChange={setReviewerSequential} disabled={reviewerUserIds.length < 2} />{labelFor('settings_approval_editor_sequential', 'ترتيب متسلسل')}</div></div><div className="grid gap-2 sm:grid-cols-2">{reviewerCatalogUsers.map((systemUser: any) => <label key={`reviewer-${systemUser.id}`} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm"><Checkbox checked={reviewerUserIds.includes(systemUser.id)} onCheckedChange={() => toggleUser(setReviewerUserIds, systemUser.id)} /><span>{systemUser.fullName}{systemUser.jobTitle ? ` — ${systemUser.jobTitle}` : ''}</span></label>)}</div></section>
      <section className="space-y-3 rounded-xl border p-4"><div className="flex items-center justify-between"><div><Label>{labelFor('settings_approval_editor_approvers', 'المفوضون')} ({approverUserIds.length})</Label><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_approval_editor_approvers_helper', 'المستخدمون المحددون هم فقط المخوّلون بتعميد هذا النوع.')}</p></div><div className="flex items-center gap-2 text-xs"><Switch checked={approverSequential} onCheckedChange={setApproverSequential} disabled={approverUserIds.length < 2} />{labelFor('settings_approval_editor_sequential', 'ترتيب متسلسل')}</div></div><div className="grid gap-2 sm:grid-cols-2">{approverCatalogUsers.map((systemUser: any) => <label key={`approver-${systemUser.id}`} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm"><Checkbox checked={approverUserIds.includes(systemUser.id)} onCheckedChange={() => toggleUser(setApproverUserIds, systemUser.id)} /><span>{systemUser.fullName}{systemUser.boardPosition ? ` — ${systemUser.boardPosition}` : ''}</span></label>)}</div><div className="space-y-2"><Label>{labelFor('settings_approval_editor_minimum', 'الحد الأدنى لعدد المفوضين لإكمال الطلب')}</Label><Input type="number" min="1" max={Math.max(1, approverUserIds.length)} value={requiredApprovals} onChange={event => setRequiredApprovals(event.target.value)} /><p className="text-xs text-muted-foreground">{labelFor('settings_approval_editor_minimum_helper', 'إذا فُعّل التسلسل، ينتقل الطلب للمفوض التالي بالترتيب حتى يبلغ هذا الحد الأدنى.')}</p></div></section></div>
    <Button onClick={saveWorkflowSettings} disabled={saveWorkflow.isPending}>{saveWorkflow.isPending ? 'جارٍ الحفظ...' : 'حفظ صلاحيات ومسار النوع'}</Button>
    <div className="space-y-4 rounded-xl border border-emerald-200 bg-emerald-50/40 p-4 dark:border-emerald-900 dark:bg-emerald-950/20"><div className="flex items-center justify-between gap-3"><div><Label>{labelFor('settings_approval_footer', 'ختم اعتماد المفوض على المرفق')}</Label><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_approval_footer_helper', 'بعد كل موافقة، يُعاد حفظ المرفق مع تذييل من أربع خانات لأسماء المفوضين وتوقيت تعميدهم.')}</p></div><Switch checked={footerEnabled} onCheckedChange={setFooterEnabled} /></div><div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4"><div className="space-y-2"><Label>{labelFor('settings_approval_footer_status', 'نص الحالة')}</Label><Input value={footerLabel} maxLength={40} onChange={event => setFooterLabel(event.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_approval_footer_height', 'ارتفاع التذييل')}</Label><Input type="number" min="48" max="120" value={footerHeight} onChange={event => setFooterHeight(event.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_approval_footer_font_size', 'حجم الخط')}</Label><Input type="number" min="7" max="14" value={footerFontSize} onChange={event => setFooterFontSize(event.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_approval_footer_color', 'لون النص')}</Label><Input type="color" value={footerColor} onChange={event => setFooterColor(event.target.value)} /></div></div><Button type="button" variant="outline" onClick={saveFooterSettings} disabled={updateApprovalSettings.isPending}>{updateApprovalSettings.isPending ? labelFor('settings_approval_saving', 'جارٍ الحفظ...') : labelFor('settings_approval_save_footer', 'حفظ إعدادات الختم')}</Button></div>
  </CardContent></Card>
  <DeleteConfirmationDialog open={deleteTypeOpen} onOpenChange={setDeleteTypeOpen} title="حذف نوع تعميد" itemName={selectedType?.name || 'نوع التعميد'} details={['سيُحذف إعداد المسار والمراجعون والمفوضون المرتبطون بالنوع فقط.', 'سيمنع النظام الحذف إن وُجدت طلبات تاريخية لهذا النوع.']} onConfirm={() => selectedType && deleteDocumentType.mutate({ id: selectedType.id })} isPending={deleteDocumentType.isPending} />
  </>;
}

function CompanySettings() {
  const { labelFor } = useSystemLabels();
  const { data: company, refetch } = trpc.company.get.useQuery();
  const updateMutation = trpc.company.update.useMutation({ onSuccess: () => { refetch(); toast.success(labelFor('settings_company_saved', 'تم حفظ بيانات الشركة')); } });
  const uploadLogoMutation = trpc.files.uploadCompanyLogo.useMutation();
  const [form, setForm] = useState({ companyName: '', address: '', commercialRegister: '', taxNumber: '', phone: '', logoUrl: '' });
  useEffect(() => { if (company) setForm({ companyName: company.companyName || '', address: company.address || '', commercialRegister: company.commercialRegister || '', taxNumber: company.taxNumber || '', phone: company.phone || '', logoUrl: company.logoUrl || '' }); }, [company]);
  const fields = [
    ['companyName', labelFor('settings_company_name', 'اسم الشركة')], ['address', labelFor('settings_company_address', 'العنوان')], ['commercialRegister', labelFor('settings_company_commercial_register', 'السجل التجاري')],
    ['taxNumber', labelFor('settings_company_tax_number', 'الرقم الضريبي')], ['phone', labelFor('settings_company_phone', 'الهاتف')],
  ] as const;
  return <Card><CardHeader><CardTitle>{labelFor('settings_company_profile_title', 'ملف تعريف الشركة')}</CardTitle></CardHeader><CardContent className="space-y-5">
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">{fields.map(([key, label]) => <div key={key} className="space-y-2"><Label>{label}</Label><Input value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} /></div>)}</div>
    <FileDropzone label="شعار الشركة" description="اختر ملفاً جديداً ليُرفع بأمان. ستُطبّق الصورة بعد الضغط على حفظ التغييرات." accept="image/png,image/jpeg,image/webp" maxBytes={2 * 1024 * 1024} value={form.logoUrl} disabled={updateMutation.isPending} isUploading={uploadLogoMutation.isPending} onFileSelected={async file => { try { const dataUrl = await fileToDataUrl(file); const uploaded = await uploadLogoMutation.mutateAsync({ fileName: file.name, dataUrl }); setForm(current => ({ ...current, logoUrl: uploaded.url })); toast.success('تم رفع الشعار؛ اضغط حفظ التغييرات لتطبيقه'); } catch (error: any) { toast.error(error?.message || 'تعذر رفع الشعار'); } }} onClear={() => setForm(current => ({ ...current, logoUrl: '' }))} />
    <div className="flex justify-start"><Button onClick={() => updateMutation.mutate(form)} disabled={updateMutation.isPending}>{labelFor('settings_company_save', 'حفظ التغييرات')}</Button></div>
  </CardContent></Card>;
}

function PasswordRecoverySettings() {
  const { data, refetch } = trpc.settings.getPasswordRecoveryEmail.useQuery();
  const updateMutation = trpc.settings.update.useMutation();
  const [email, setEmail] = useState('');
  useEffect(() => { if (data) setEmail(data.email || ''); }, [data]);
  const save = async () => {
    try {
      await updateMutation.mutateAsync({ key: 'password_recovery_email', value: email.trim() });
      await refetch();
      toast.success('تم حفظ بريد استلام رموز الاسترداد');
    } catch (error: any) {
      toast.error(error?.message || 'تعذر حفظ بريد الاسترداد');
    }
  };
  return <Card><CardHeader><CardTitle>استعادة كلمة مرور الإدارة</CardTitle></CardHeader><CardContent className="space-y-4"><p className="text-sm leading-6 text-muted-foreground">يُرسل رمز الاسترداد إلى هذا البريد فقط. يمكنك تغييره لاحقاً إلى بريد العمل؛ لا تظهر بيانات حساب Gmail المرسل أو كلمة مرور التطبيق في النظام.</p><div className="max-w-xl space-y-2"><Label htmlFor="password-recovery-email">بريد استلام رموز الاسترداد</Label><Input id="password-recovery-email" type="email" dir="ltr" value={email} onChange={event => setEmail(event.target.value)} placeholder="name@company.com" /><p className="text-xs text-muted-foreground">اترك الحقل فارغاً لتعطيل الاسترداد عبر البريد مؤقتاً.</p></div><Button type="button" onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? 'جارٍ الحفظ...' : 'حفظ بريد الاسترداد'}</Button></CardContent></Card>;
}

function ThemeSettings() {
  const { labelFor } = useSystemLabels();
  const { theme, setTheme, colorMode, setColorMode, interactionColor, setInteractionColor } = useTheme();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.update.useMutation({ onSuccess: () => toast.success(labelFor('settings_theme_saved', 'تم تطبيق المظهر وحفظه فوراً')) });
  const themes = [
    { id: 'blue' as const, name: labelFor('settings_theme_blue', 'أزرق احترافي'), swatch: 'from-blue-600 to-cyan-500' },
    { id: 'green' as const, name: labelFor('settings_theme_green', 'أخضر طبيعي'), swatch: 'from-emerald-600 to-teal-500' },
    { id: 'purple' as const, name: labelFor('settings_theme_purple', 'بنفسجي أنيق'), swatch: 'from-violet-600 to-fuchsia-500' },
  ];
  const interactionColors = [
    { id: 'azure' as const, name: 'أزرق سماوي', swatch: 'from-sky-600 to-blue-500' },
    { id: 'emerald' as const, name: 'زمردي', swatch: 'from-emerald-600 to-teal-500' },
    { id: 'violet' as const, name: 'بنفسجي', swatch: 'from-violet-600 to-fuchsia-500' },
    { id: 'coral' as const, name: 'مرجاني', swatch: 'from-rose-600 to-orange-500' },
    { id: 'amber' as const, name: 'كهرماني', swatch: 'from-amber-500 to-yellow-400' },
  ];
  const apply = (next: typeof theme) => { const previous = theme; setTheme(next); updateMutation.mutate({ key: 'theme', value: next }, { onError: () => { setTheme(previous); toast.error(labelFor('settings_theme_save_error', 'تعذر حفظ إعداد المظهر')); } }); };
  const applyInteractionColor = (next: typeof interactionColor) => { const previous = interactionColor; setInteractionColor(next); updateMutation.mutate({ key: 'interaction_color', value: next }, { onError: () => { setInteractionColor(previous); toast.error('تعذر حفظ لون التفاعل'); } }); };
  const applyColorMode = (next: typeof colorMode) => { const previous = colorMode; setColorMode(next); updateMutation.mutate({ key: 'appearance_color_mode', value: next }, { onSuccess: () => { void utils.settings.getAll.invalidate(); }, onError: () => { setColorMode(previous); toast.error(labelFor('settings_theme_save_error', 'تعذر حفظ إعداد المظهر')); } }); };
  return <Card><CardHeader><CardTitle>{labelFor('settings_theme_title', 'تعديل المظهر')}</CardTitle></CardHeader><CardContent className="space-y-6"><div className="rounded-xl border border-primary/20 bg-primary/5 p-4"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><p className="font-semibold">{labelFor('settings_theme_dark_mode', 'الوضع الداكن')}</p><p className="mt-1 text-sm text-muted-foreground">{labelFor('settings_theme_dark_mode_description', 'إعداد مركزي يُحفظ ويُطبّق فوراً على كامل النظام بعد الدخول.')}</p></div><div className="flex rounded-lg border bg-background p-1"><Button type="button" size="sm" variant={colorMode === 'light' ? 'default' : 'ghost'} onClick={() => applyColorMode('light')} disabled={updateMutation.isPending}><Sun className="ml-1 h-4 w-4" />{labelFor('settings_theme_light', 'فاتح')}</Button><Button type="button" size="sm" variant={colorMode === 'dark' ? 'default' : 'ghost'} onClick={() => applyColorMode('dark')} disabled={updateMutation.isPending}><Moon className="ml-1 h-4 w-4" />{labelFor('settings_theme_dark', 'داكن')}</Button></div></div></div><div><p className="mb-5 text-sm text-muted-foreground">{labelFor('settings_theme_description', 'يطبّق اللون المختار فوراً على كامل النظام ويحفظ لاستخدامه عند تسجيل الدخول لاحقاً.')}</p><div className="grid grid-cols-1 gap-4 sm:grid-cols-3">{themes.map(item => <button type="button" key={item.id} onClick={() => apply(item.id)} className={`rounded-xl border-2 p-5 text-right transition-all hover:-translate-y-0.5 ${theme === item.id ? 'border-primary bg-primary/5 shadow-md' : 'border-border hover:border-primary/40'}`}><div className={`mb-4 h-12 rounded-lg bg-gradient-to-l ${item.swatch}`} /><p className="font-semibold">{item.name}</p><p className="mt-1 text-xs text-muted-foreground">{theme === item.id ? labelFor('settings_theme_active', 'المظهر النشط') : labelFor('settings_theme_apply', 'انقر للتطبيق')}</p></button>)}</div></div><div className="rounded-xl border border-border bg-muted/20 p-4"><div className="mb-4"><p className="font-semibold">لون التفاعل والتحديد</p><p className="mt-1 text-sm text-muted-foreground">يتحكم في لون العنصر عند المرور عليه أو تحديده وحلقة التركيز، ولا يغيّر ألوان حالات السندات أو التنبيهات.</p></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-5">{interactionColors.map(item => <button type="button" key={item.id} onClick={() => applyInteractionColor(item.id)} className={`rounded-lg border-2 p-3 text-right transition-all hover:-translate-y-0.5 ${interactionColor === item.id ? 'border-primary bg-primary/5 shadow-sm' : 'border-border hover:border-primary/40'}`}><div className={`mb-2 h-7 rounded-md bg-gradient-to-l ${item.swatch}`} /><p className="text-sm font-semibold">{item.name}</p><p className="mt-1 text-xs text-muted-foreground">{interactionColor === item.id ? 'اللون النشط' : 'اختيار اللون'}</p></button>)}</div></div></CardContent></Card>;
}

function DashboardPresentationCore() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const shortcutOptions = [{ id: 'receipts', label: labelFor('settings_dashboard_shortcut_receipts', 'إصدار سند قبض') }, { id: 'approvals', label: labelFor('settings_dashboard_shortcut_approvals', 'طلبات التعميد') }, { id: 'performance', label: labelFor('settings_dashboard_shortcut_performance', 'تقارير الأداء') }, { id: 'customers', label: labelFor('settings_dashboard_shortcut_customers', 'إدارة العملاء') }];
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [layoutStyle, setLayoutStyle] = useState<'classic' | 'modern'>('classic');
  const [shortcutIds, setShortcutIds] = useState<string[]>(['receipts', 'approvals', 'performance', 'customers']);
  useEffect(() => {
    if (!settings) return;
    setTitle(settings.dashboard_title || ''); setSubtitle(settings.dashboard_subtitle || '');
    setLayoutStyle(settings.interface_style === 'modern' ? 'modern' : 'classic');
    const fallback = shortcutOptions.map(option => option.id);
    try { setShortcutIds(parseDashboardShortcutIds(JSON.parse(settings.dashboard_shortcuts || JSON.stringify(fallback)), fallback)); } catch { setShortcutIds(fallback); }
  }, [settings]);
  const toggleShortcut = (id: string) => setShortcutIds(current => current.includes(id) ? current.filter(value => value !== id) : [...current, id]);
  const save = async () => {
    if (!shortcutIds.length) return toast.error(labelFor('settings_dashboard_shortcut_required', 'اختر اختصاراً واحداً على الأقل لشاشة البداية'));
    try { await updateMutation.mutateAsync({ entries: [{ key: 'interface_style', value: layoutStyle }, { key: 'dashboard_title', value: title.trim() }, { key: 'dashboard_subtitle', value: subtitle.trim() }, { key: 'dashboard_shortcuts', value: JSON.stringify(shortcutIds) }] }); await utils.settings.getAll.invalidate(); await refetch(); toast.success(labelFor('settings_dashboard_saved', 'تم حفظ النمط وتخصيصات واجهة لوحة المعلومات')); } catch (error: any) { toast.error(error?.message || labelFor('settings_dashboard_save_error', 'تعذر حفظ تخصيصات واجهة لوحة المعلومات')); }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_dashboard_presentation_title', 'تخصيص واجهة لوحة المعلومات')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_dashboard_presentation_description', 'النمط التقليدي هو الافتراضي ويعيد القائمة الجانبية واللوحة إلى شكل الإصدار السابق. النمط الحديث يبقي التصميم التشغيلي الجديد كتخطيط بديل.')}</p></CardHeader><CardContent className="space-y-5"><div className="space-y-3 rounded-xl border bg-muted/25 p-4"><Label>{labelFor('settings_dashboard_style', 'نمط واجهة النظام')}</Label><div className="grid gap-3 sm:grid-cols-2"><button type="button" onClick={() => setLayoutStyle('classic')} className={`rounded-xl border-2 p-4 text-right transition ${layoutStyle === 'classic' ? 'border-primary bg-primary/5 shadow-sm' : 'border-border bg-background'}`}><p className="font-bold">{labelFor('settings_dashboard_style_classic', 'النمط التقليدي — الافتراضي')}</p><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_dashboard_style_classic_description', 'قائمة جانبية مفردة ولوحة معلومات مألوفة وبطاقات تشغيلية واضحة.')}</p></button><button type="button" onClick={() => setLayoutStyle('modern')} className={`rounded-xl border-2 p-4 text-right transition ${layoutStyle === 'modern' ? 'border-primary bg-primary/5 shadow-sm' : 'border-border bg-background'}`}><p className="font-bold">{labelFor('settings_dashboard_style_modern', 'النمط التشغيلي الحديث')}</p><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_dashboard_style_modern_description', 'مجموعات جانبية قابلة للطي ولوحة ذات رأس داكن ورسوم نشاط حديثة.')}</p></button></div></div><div className="grid gap-4 md:grid-cols-2"><div className="space-y-2"><Label htmlFor="dashboard-title">{labelFor('settings_dashboard_title_field', 'عنوان لوحة المعلومات')}</Label><Input id="dashboard-title" value={title} onChange={event => setTitle(event.target.value)} placeholder={labelFor('settings_dashboard_title_placeholder', 'مثال: مرحباً بكم في منصة الأسمدة')} /></div><div className="space-y-2"><Label htmlFor="dashboard-subtitle">{labelFor('settings_dashboard_subtitle_field', 'النص التوضيحي')}</Label><Input id="dashboard-subtitle" value={subtitle} onChange={event => setSubtitle(event.target.value)} placeholder={labelFor('settings_dashboard_subtitle_placeholder', 'مثال: متابعة العمليات اليومية للفروع')} /></div></div><div className="space-y-3 rounded-xl border bg-muted/25 p-4"><Label>{labelFor('settings_dashboard_shortcuts_field', 'اختصارات شاشة البداية')}</Label><p className="text-xs text-muted-foreground">{labelFor('settings_dashboard_shortcuts_description', 'اختر العمليات التي تظهر كبطاقات وصول سريع لجميع المستخدمين الذين يملكون صلاحيتها.')}</p><div className="grid gap-3 sm:grid-cols-2">{shortcutOptions.map(option => <label key={option.id} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background p-3 text-sm"><Checkbox checked={shortcutIds.includes(option.id)} onCheckedChange={() => toggleShortcut(option.id)} /><span>{option.label}</span></label>)}</div></div><Button onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_dashboard_saving', 'جارٍ الحفظ...') : labelFor('settings_dashboard_save', 'حفظ النمط وتخصيصات الواجهة')}</Button></CardContent></Card>;
}

function DashboardPresentationSettings() {
  return <div className="space-y-4"><DashboardPresentationCore /><DashboardShortcutOrdering /><DashboardSectionOrdering /></div>;
}

function DashboardShortcutOrdering() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const options = [{ id: 'receipts', label: labelFor('settings_dashboard_shortcut_receipts', 'إصدار سند قبض') }, { id: 'approvals', label: labelFor('settings_dashboard_shortcut_approvals', 'طلبات التعميد') }, { id: 'performance', label: labelFor('settings_dashboard_shortcut_performance', 'تقارير الأداء') }, { id: 'customers', label: labelFor('settings_dashboard_shortcut_customers', 'إدارة العملاء') }];
  const defaultOrder = options.map(option => option.id);
  const [order, setOrder] = useState<string[]>(defaultOrder);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  useEffect(() => {
    try {
      const stored = JSON.parse(settings?.dashboard_shortcuts || JSON.stringify(defaultOrder));
      setOrder(parseDashboardShortcutIds(stored, defaultOrder));
    } catch { setOrder(defaultOrder); }
  }, [settings]);
  const move = (sourceId: string, targetId: string) => setOrder(current => moveDashboardShortcut(current, sourceId, targetId));
  const moveByOffset = (sourceId: string, offset: number) => setOrder(current => {
    const targetId = current[current.indexOf(sourceId) + offset];
    return targetId ? moveDashboardShortcut(current, sourceId, targetId) : current;
  });
  const save = async () => {
    try {
      await updateMutation.mutateAsync({ entries: [{ key: 'dashboard_shortcuts', value: JSON.stringify(order) }] });
      await utils.settings.getAll.invalidate(); await refetch(); toast.success(labelFor('settings_dashboard_shortcut_order_saved', 'تم حفظ ترتيب اختصارات لوحة المعلومات'));
    } catch (error: any) { toast.error(error?.message || labelFor('settings_dashboard_shortcut_order_error', 'تعذر حفظ ترتيب الاختصارات')); }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_dashboard_shortcut_order_title', 'ترتيب اختصارات لوحة المعلومات')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_dashboard_shortcut_order_description', 'اسحب البطاقة إلى موضعها الجديد، ثم احفظ الترتيب. يظهر التغيير مباشرة في شاشة البداية لجميع المستخدمين المخولين.')}</p></CardHeader><CardContent className="space-y-4"><div className="grid gap-2 sm:grid-cols-2">{order.map((id, index) => { const option = options.find(item => item.id === id); if (!option) return null; return <div key={id} draggable onDragStart={() => setDraggedId(id)} onDragEnd={() => setDraggedId(null)} onDragOver={event => event.preventDefault()} onDrop={() => { if (draggedId) move(draggedId, id); setDraggedId(null); }} className={`flex items-center gap-3 rounded-xl border bg-background p-3 ${draggedId === id ? 'opacity-50' : ''}`}><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-xs font-bold text-primary">{index + 1}</span><GripVertical className="h-4 w-4 cursor-grab text-muted-foreground active:cursor-grabbing" aria-hidden="true" /><span className="font-medium">{option.label}</span><div className="mr-auto flex items-center gap-1"><Button type="button" size="icon" variant="ghost" className="h-8 w-8" aria-label={`نقل ${option.label} لأعلى`} onClick={() => moveByOffset(id, -1)} disabled={index === 0}><ArrowUp className="h-4 w-4" /></Button><Button type="button" size="icon" variant="ghost" className="h-8 w-8" aria-label={`نقل ${option.label} لأسفل`} onClick={() => moveByOffset(id, 1)} disabled={index === order.length - 1}><ArrowDown className="h-4 w-4" /></Button></div></div>; })}</div><Button type="button" onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_dashboard_saving', 'جارٍ الحفظ...') : labelFor('settings_dashboard_shortcut_order_save', 'حفظ ترتيب الاختصارات')}</Button></CardContent></Card>;
}

function DashboardSectionOrdering() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const options = [{ id: 'summary', label: labelFor('settings_dashboard_section_summary', 'ملخص المؤشرات') }, { id: 'activity', label: labelFor('settings_dashboard_section_activity', 'اتجاه المتحصلات والاختصارات') }, { id: 'records', label: labelFor('settings_dashboard_section_records', 'آخر السندات والفروع الأعلى تحصيلاً') }, { id: 'bank', label: labelFor('settings_dashboard_section_bank', 'المتحصلات البنكية') }];
  const defaultOrder = options.map(option => option.id);
  const [order, setOrder] = useState<string[]>(defaultOrder);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  useEffect(() => {
    try {
      const stored = JSON.parse(settings?.dashboard_section_order || JSON.stringify(defaultOrder));
      const valid = Array.isArray(stored) ? stored.filter((id): id is string => typeof id === 'string' && defaultOrder.includes(id)) : [];
      setOrder(valid.length ? [...valid, ...defaultOrder.filter(id => !valid.includes(id))] : defaultOrder);
    } catch { setOrder(defaultOrder); }
  }, [settings]);
  const move = (sourceId: string, targetId: string) => setOrder(current => {
    const from = current.indexOf(sourceId); const to = current.indexOf(targetId);
    if (from < 0 || to < 0 || from === to) return current;
    const next = [...current]; next.splice(from, 1); next.splice(to, 0, sourceId); return next;
  });
  const save = async () => {
    try {
      await updateMutation.mutateAsync({ entries: [{ key: 'dashboard_section_order', value: JSON.stringify(order) }] });
      await utils.settings.getAll.invalidate(); await refetch(); toast.success(labelFor('settings_dashboard_section_order_saved', 'تم حفظ ترتيب أقسام لوحة المعلومات'));
    } catch (error: any) { toast.error(error?.message || labelFor('settings_dashboard_section_order_error', 'تعذر حفظ ترتيب أقسام اللوحة')); }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_dashboard_section_order_title', 'ترتيب أقسام شاشة البداية')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_dashboard_section_order_description', 'اسحب القسم إلى ترتيبه الجديد ثم احفظ. يطبّق الترتيب على نمطي اللوحة التقليدي والحديث.')}</p></CardHeader><CardContent className="space-y-4"><div className="space-y-2">{order.map((id, index) => { const option = options.find(item => item.id === id); if (!option) return null; return <div key={id} draggable onDragStart={() => setDraggedId(id)} onDragOver={event => event.preventDefault()} onDrop={() => { if (draggedId) move(draggedId, id); setDraggedId(null); }} className={`flex cursor-grab items-center gap-3 rounded-xl border bg-background p-3 active:cursor-grabbing ${draggedId === id ? 'opacity-50' : ''}`}><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-xs font-bold text-primary">{index + 1}</span><GripVertical className="h-4 w-4 text-muted-foreground" /><span className="font-medium">{option.label}</span></div>; })}</div><Button type="button" onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_dashboard_saving', 'جارٍ الحفظ...') : labelFor('settings_dashboard_section_order_save', 'حفظ ترتيب الأقسام')}</Button></CardContent></Card>;
}

function SystemTerminologySettings() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const [labels, setLabels] = useState<Record<SystemLabelId, string>>(() => readSystemLabelOverrides(undefined));

  useEffect(() => {
    setLabels(readSystemLabelOverrides(settings));
  }, [settings]);

  const save = async () => {
    const sanitized = systemLabelOptions.reduce<Record<string, string>>((result, option) => {
      result[option.id] = (labels[option.id] || option.label).trim().slice(0, 80) || option.label;
      return result;
    }, {});
    try {
      await updateMutation.mutateAsync({ entries: [{ key: 'system_label_overrides', value: JSON.stringify(sanitized) }] });
      await utils.settings.getAll.invalidate();
      await refetch();
      toast.success('تم حفظ تسميات القوائم ولوحة المعلومات');
    } catch (error: any) {
      toast.error(error?.message || 'تعذر حفظ التسميات');
    }
  };

  const reset = () => setLabels(Object.fromEntries(systemLabelOptions.map(option => [option.id, option.label])) as Record<SystemLabelId, string>);

  return <Card><CardHeader><CardTitle>{labelFor('settings_terminology_title', 'إدارة تسميات النظام')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_terminology_description', 'تُستخدم هذه الشاشة لإعادة تسمية الوحدات والقوائم الرئيسية وعناوين لوحة المعلومات بشكل آمن. أما حقول سند القبض فتُدار تفصيلياً من تبويب «نموذج السند».')}</p></CardHeader><CardContent className="space-y-5"><div className="grid gap-3 md:grid-cols-2">{systemLabelOptions.map(option => { const value = labels[option.id] || ''; const changed = value.trim() !== option.label; return <div key={option.id} className={`space-y-2 rounded-xl border p-3 shadow-sm transition-colors ${changed ? 'border-emerald-300 bg-emerald-50/60 dark:border-emerald-900 dark:bg-emerald-950/20' : 'border-sky-200 bg-sky-50/60 dark:border-sky-900 dark:bg-sky-950/20'}`}><div className="flex items-center justify-between gap-2"><Label htmlFor={`system-label-${option.id}`} className="font-semibold">{option.label}</Label><span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${changed ? 'bg-emerald-600 text-white' : 'bg-sky-600 text-white'}`}>{changed ? labelFor('settings_terminology_changed', 'تم التعديل') : labelFor('settings_terminology_current_value', 'القيمة الحالية')}</span></div><div className="rounded-md border border-sky-200 bg-sky-100/80 px-3 py-2 text-sm font-medium text-sky-950 dark:border-sky-900 dark:bg-sky-950/60 dark:text-sky-100"><span className="ml-1 text-xs font-normal text-sky-700 dark:text-sky-300">{labelFor('settings_terminology_current_label', 'الحالية:')}</span>{option.label}</div><div className="space-y-1"><Label className="text-xs text-emerald-800 dark:text-emerald-300" htmlFor={`system-label-${option.id}`}>{labelFor('settings_terminology_edit_field', 'مكان التعديل')}</Label><Input id={`system-label-${option.id}`} className="border-emerald-300 bg-white focus-visible:ring-emerald-600 dark:border-emerald-800 dark:bg-background" value={value} maxLength={80} onChange={event => setLabels(current => ({ ...current, [option.id]: event.target.value }))} /></div></div>; })}</div><div className="flex flex-wrap gap-2"><Button type="button" onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_terminology_saving', 'جارٍ الحفظ...') : labelFor('settings_terminology_save', 'حفظ التسميات')}</Button><Button type="button" variant="outline" onClick={reset} disabled={updateMutation.isPending}>{labelFor('settings_terminology_restore_defaults', 'استعادة التسميات الافتراضية')}</Button></div></CardContent></Card>;
}

function ReceiptFormPresentationCore() {
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const { labelFor } = useSystemLabels();
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [sections, setSections] = useState<ReceiptFormSectionId[]>(receiptFormSectionOptions.map(option => option.id));
  useEffect(() => {
    if (!settings) return;
    setTitle(settings.receipt_form_title || '');
    setSubtitle(settings.receipt_form_subtitle || '');
    try {
      const stored = JSON.parse(settings.receipt_form_sections || '[]');
      const next = Array.isArray(stored) ? stored.filter((id): id is ReceiptFormSectionId => receiptFormSectionOptions.some(option => option.id === id)) : [];
      setSections(next.length ? next : receiptFormSectionOptions.map(option => option.id));
    } catch { setSections(receiptFormSectionOptions.map(option => option.id)); }
  }, [settings]);
  const move = (id: ReceiptFormSectionId, direction: -1 | 1) => setSections(current => {
    const index = current.indexOf(id); const target = index + direction;
    if (index < 0 || target < 0 || target >= current.length) return current;
    const next = [...current]; [next[index], next[target]] = [next[target], next[index]]; return next;
  });
  const toggle = (id: ReceiptFormSectionId) => setSections(current => current.includes(id) ? current.filter(value => value !== id) : [...current, id]);
  const save = async () => {
    if (!sections.includes('customer') || !sections.includes('amount') || !sections.includes('payment')) return toast.error('حقول العميل والمبلغ وتفاصيل الدفع أساسية ولا يمكن إخفاؤها');
    try {
      await updateMutation.mutateAsync({ entries: [
        { key: 'receipt_form_title', value: title.trim() },
        { key: 'receipt_form_subtitle', value: subtitle.trim() },
        { key: 'receipt_form_sections', value: JSON.stringify(sections) },
      ] });
      await utils.settings.getAll.invalidate(); await refetch(); toast.success('تم حفظ تصميم نموذج سند القبض');
    } catch (error: any) { toast.error(error?.message || 'تعذر حفظ تصميم نموذج السند'); }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_receipt_layout_title', 'تصميم شاشة إصدار سند القبض')}</CardTitle><p className="text-sm font-normal text-muted-foreground">{labelFor('settings_receipt_layout_description', 'غيّر عنوان الشاشة وترتيب الأقسام الظاهرة ضمن الحقول المعتمدة، من دون إنشاء حقول مالية حرة قد تؤثر في السندات والتقارير.')}</p></CardHeader><CardContent className="space-y-5"><div className="grid gap-4 md:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_receipt_layout_form_title', 'عنوان نموذج السند')}</Label><Input value={title} onChange={event => setTitle(event.target.value)} placeholder={labelFor('settings_receipt_layout_form_title_placeholder', 'إصدار سند قبض جديد')} /></div><div className="space-y-2"><Label>{labelFor('settings_receipt_layout_subtitle', 'النص التوضيحي')}</Label><Input value={subtitle} onChange={event => setSubtitle(event.target.value)} placeholder={labelFor('settings_receipt_layout_subtitle_placeholder', 'أدخل بيانات التحصيل ثم احفظ السند.')} /></div></div><div className="rounded-xl border bg-muted/20 p-4"><Label>{labelFor('settings_receipt_layout_sections', 'ترتيب وإظهار الأقسام')}</Label><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_receipt_layout_sections_description', 'تُطبّق التغييرات على شاشة إنشاء وتعديل السند فور الحفظ. لا يمكن إخفاء العميل أو المبلغ أو تفاصيل الدفع.')}</p><div className="mt-3 space-y-2">{receiptFormSectionOptions.map(option => { const index = sections.indexOf(option.id); const required = ['customer', 'amount', 'payment'].includes(option.id); const visible = index >= 0; return <div key={option.id} className="flex items-center justify-between rounded-lg border bg-background p-3"><label className="flex cursor-pointer items-center gap-2"><Checkbox checked={visible} disabled={required} onCheckedChange={() => toggle(option.id)} /><span>{option.label}</span>{required && <span className="text-xs text-muted-foreground">({labelFor('settings_receipt_layout_required', 'أساسي')})</span>}</label><div className="flex gap-1"><Button type="button" variant="ghost" size="icon" disabled={!visible || index === 0} onClick={() => move(option.id, -1)}><ArrowUp className="h-4 w-4" /></Button><Button type="button" variant="ghost" size="icon" disabled={!visible || index === sections.length - 1} onClick={() => move(option.id, 1)}><ArrowDown className="h-4 w-4" /></Button></div></div>; })}</div></div><Button onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_receipt_layout_saving', 'جارٍ الحفظ...') : labelFor('settings_receipt_layout_save', 'حفظ تصميم نموذج السند')}</Button></CardContent></Card>;
}

function ReceiptFormPresentationSettings() {
  return <div className="space-y-4"><ReceiptFormPresentationCore /><ReceiptFormLabelsAndCustomFields /></div>;
}

function ReceiptFormLabelsAndCustomFields() {
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const { labelFor } = useSystemLabels();
  const [labels, setLabels] = useState<Record<string, string>>({});
  const [fields, setFields] = useState<ReceiptCustomField[]>([]);

  useEffect(() => {
    if (!settings) return;
    try {
      const parsed = JSON.parse(settings.receipt_form_labels || '{}');
      setLabels(receiptFormLabelOptions.reduce((result, item) => ({ ...result, [item.id]: typeof parsed?.[item.id] === 'string' ? parsed[item.id] : item.label }), {}));
    } catch { setLabels(Object.fromEntries(receiptFormLabelOptions.map(item => [item.id, item.label]))); }
    try {
      const parsed = JSON.parse(settings.receipt_form_custom_fields || '[]');
      setFields(Array.isArray(parsed) ? parsed.filter((field): field is ReceiptCustomField => Boolean(field && typeof field.id === 'string' && typeof field.label === 'string')).slice(0, 8).map(field => ({ ...field, type: ['text', 'textarea', 'number', 'date', 'select'].includes(field.type) ? field.type : 'text', required: field.required === true, options: Array.isArray(field.options) ? field.options.filter(option => typeof option === 'string') : [] })) : []);
    } catch { setFields([]); }
  }, [settings]);

  const updateField = (index: number, patch: Partial<ReceiptCustomField>) => setFields(current => current.map((field, fieldIndex) => fieldIndex === index ? { ...field, ...patch } : field));
  const addField = () => {
    if (fields.length >= 8) return toast.error('الحد الأقصى هو 8 حقول مخصصة');
    const suffix = fields.length + 1;
    setFields(current => [...current, { id: `custom_field_${suffix}`, label: `حقل مخصص ${suffix}`, type: 'text', required: false, options: [] }]);
  };
  const save = async () => {
    const ids = new Set<string>();
    for (const field of fields) {
      if (!/^[a-z][a-z0-9_]{1,39}$/.test(field.id) || !field.label.trim() || field.label.trim().length > 80 || ids.has(field.id)) return toast.error('راجع معرف واسم الحقول المخصصة؛ المعرف إنجليزي فريد من حروف وأرقام وشرطة سفلية');
      if (field.type === 'select' && !field.options.length) return toast.error(`أضف خيارات للقائمة «${field.label}»`);
      ids.add(field.id);
    }
    try {
      await updateMutation.mutateAsync({ entries: [
        { key: 'receipt_form_labels', value: JSON.stringify(labels) },
        { key: 'receipt_form_custom_fields', value: JSON.stringify(fields.map(field => ({ ...field, label: field.label.trim(), options: field.options.map(option => option.trim()).filter(Boolean) }))) },
      ] });
      await utils.settings.getAll.invalidate(); await refetch(); toast.success('تم حفظ تسميات وحقول سند القبض المخصصة');
    } catch (error: any) { toast.error(error?.message || 'تعذر حفظ الحقول المخصصة'); }
  };

  return <Card><CardHeader><CardTitle>{labelFor('settings_receipt_presentation_title', 'تسميات وحقول سند القبض')}</CardTitle><p className="text-sm font-normal text-muted-foreground">غيّر التسمية العربية للحقول المعتمدة وأضف حتى 8 حقول وصفية إضافية. تبقى القيم المالية الأساسية ثابتة لحماية الحسابات والتقارير، ولا تتأثر السندات السابقة.</p></CardHeader><CardContent className="space-y-5"><div className="grid gap-3 md:grid-cols-2">{receiptFormLabelOptions.map(item => <div className="space-y-1.5" key={item.id}><Label htmlFor={`receipt-label-${item.id}`}>{item.label}</Label><Input id={`receipt-label-${item.id}`} value={labels[item.id] || ''} maxLength={80} onChange={event => setLabels(current => ({ ...current, [item.id]: event.target.value }))} /></div>)}</div><div className="rounded-xl border bg-muted/20 p-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><Label>{labelFor('settings_receipt_custom_fields_title', 'الحقول الوصفية المخصصة')}</Label><p className="mt-1 text-xs text-muted-foreground">المعرّف تقني ثابت بعد أول حفظ؛ لا تغيّره لاحقاً إذا كانت له قيم في سندات قائمة.</p></div><Button type="button" variant="outline" size="sm" onClick={addField}><Plus className="ml-1 h-4 w-4" />إضافة حقل</Button></div><div className="mt-4 space-y-3">{fields.map((field, index) => <div key={`${field.id}-${index}`} className="rounded-lg border bg-background p-3"><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4"><div className="space-y-1"><Label>{labelFor('settings_receipt_custom_field_name', 'اسم الحقل')}</Label><Input value={field.label} maxLength={80} onChange={event => updateField(index, { label: event.target.value })} /></div><div className="space-y-1"><Label>{labelFor('settings_receipt_custom_field_identifier', 'المعرّف')}</Label><Input value={field.id} dir="ltr" maxLength={40} onChange={event => updateField(index, { id: event.target.value.toLowerCase() })} /></div><div className="space-y-1"><Label>{labelFor('settings_receipt_custom_field_input_type', 'نوع الإدخال')}</Label><Select value={field.type} onValueChange={value => updateField(index, { type: value as ReceiptCustomField['type'] })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="text">{labelFor('settings_receipt_custom_field_type_text', 'نص قصير')}</SelectItem><SelectItem value="textarea">{labelFor('settings_receipt_custom_field_type_textarea', 'نص متعدد الأسطر')}</SelectItem><SelectItem value="number">{labelFor('settings_receipt_custom_field_type_number', 'رقم')}</SelectItem><SelectItem value="date">{labelFor('settings_receipt_custom_field_type_date', 'تاريخ')}</SelectItem><SelectItem value="select">{labelFor('settings_receipt_custom_field_type_select', 'قائمة خيارات')}</SelectItem></SelectContent></Select></div><div className="flex items-end justify-between gap-2"><label className="flex items-center gap-2 pb-2 text-sm"><Checkbox checked={field.required} onCheckedChange={checked => updateField(index, { required: checked === true })} />مطلوب</label><Button type="button" variant="ghost" size="icon" className="text-destructive" onClick={() => setFields(current => current.filter((_, fieldIndex) => fieldIndex !== index))}><Trash2 className="h-4 w-4" /><span className="sr-only">حذف الحقل</span></Button></div></div>{field.type === 'select' && <div className="mt-3 space-y-1"><Label>{labelFor('settings_receipt_custom_field_options', 'خيارات القائمة (تفصل بفاصلة)')}</Label><Input value={field.options.join(', ')} onChange={event => updateField(index, { options: event.target.value.split(',').map(option => option.trim()).filter(Boolean) })} placeholder={labelFor('settings_receipt_custom_field_options_placeholder', 'مثال: خيار أول, خيار ثان')} /></div>}</div>)}</div>{fields.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">{labelFor('settings_receipt_custom_fields_empty', 'لم تُضف حقول مخصصة بعد.')}</p>}</div><Button onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? 'جارٍ الحفظ...' : 'حفظ التسميات والحقول المخصصة'}</Button></CardContent></Card>;
}

function PrintSettings() {
  const { labelFor } = useSystemLabels();
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const mutation = trpc.settings.update.useMutation();
  const [form, setForm] = useState({ header: '', footer: '', position: 'right', logoSize: '80', headerHeight: '92', footerHeight: '44', accentColor: '#0f766e', titleFontSize: '24', showBarcode: true, orientation: 'portrait', headerPercent: '15', footerPercent: '15' });
  useEffect(() => { if (settings) setForm({ header: settings.print_header_text || '', footer: settings.print_footer_text || '', position: settings.print_logo_position || 'right', logoSize: settings.print_logo_size || '80', headerHeight: settings.print_header_height || '92', footerHeight: settings.print_footer_height || '44', accentColor: settings.print_accent_color || '#0f766e', titleFontSize: settings.print_title_font_size || '24', showBarcode: settings.print_show_barcode !== 'false', orientation: settings.print_page_orientation === 'landscape' ? 'landscape' : 'portrait', headerPercent: settings.print_header_percent || '15', footerPercent: settings.print_footer_percent || '15' }); }, [settings]);
  const set = (key: keyof typeof form, value: string | boolean) => setForm(current => ({ ...current, [key]: value }));
  const save = async () => {
    const values: Array<[string, string]> = [['print_header_text', form.header], ['print_footer_text', form.footer], ['print_logo_position', form.position], ['print_logo_size', form.logoSize], ['print_header_height', form.headerHeight], ['print_footer_height', form.footerHeight], ['print_accent_color', form.accentColor], ['print_title_font_size', form.titleFontSize], ['print_show_barcode', form.showBarcode ? 'true' : 'false'], ['print_page_orientation', form.orientation], ['print_header_percent', form.headerPercent], ['print_footer_percent', form.footerPercent]];
    try { await Promise.all(values.map(([key, value]) => mutation.mutateAsync({ key, value }))); await refetch(); toast.success(labelFor('settings_print_saved', 'تم حفظ تصميم المطبوعات')); } catch { toast.error(labelFor('settings_print_save_error', 'تعذر حفظ تصميم المطبوعات')); }
  };
  const positionLabel = form.position === 'right'
    ? labelFor('settings_print_logo_position_right', 'يمين الرأس')
    : form.position === 'left'
      ? labelFor('settings_print_logo_position_left', 'يسار الرأس')
      : labelFor('settings_print_logo_position_center', 'وسط الرأس');
  return <Card><CardHeader><CardTitle>{labelFor('settings_print_title', 'تصميم المطبوعات')}</CardTitle></CardHeader><CardContent className="space-y-5"><p className="text-sm text-muted-foreground">{labelFor('settings_print_description', 'تطبّق الإعدادات على سندات القبض والتقارير. اختر عناصر التصميم المعتمدة دون الحاجة إلى تعديل قالب برمجي.')}</p><div className="grid grid-cols-1 gap-4 md:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_print_header_text', 'نص الرأس')}</Label><Input value={form.header} onChange={e => set('header', e.target.value)} placeholder={labelFor('settings_print_header_placeholder', 'اسم أو عنوان مخصص')} /></div><div className="space-y-2"><Label>{labelFor('settings_print_footer_text', 'نص التذييل')}</Label><Input value={form.footer} onChange={e => set('footer', e.target.value)} placeholder={labelFor('settings_print_footer_placeholder', 'جميع الحقوق محفوظة')} /></div><div className="space-y-2"><Label>اتجاه صفحة PDF</Label><Select value={form.orientation} onValueChange={value => set('orientation', value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="portrait">رأسي (الافتراضي)</SelectItem><SelectItem value="landscape">أفقي</SelectItem></SelectContent></Select></div><div className="space-y-2"><Label>{labelFor('settings_print_logo_position', 'مكان الشعار')}</Label><Select value={form.position} onValueChange={value => set('position', value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="right">{labelFor('settings_print_logo_position_right', 'يمين الرأس')}</SelectItem><SelectItem value="center">{labelFor('settings_print_logo_position_center', 'وسط الرأس')}</SelectItem><SelectItem value="left">{labelFor('settings_print_logo_position_left', 'يسار الرأس')}</SelectItem></SelectContent></Select></div><div className="space-y-2"><Label>مساحة الرأس من الصفحة (%)</Label><Input type="number" min="10" max="25" value={form.headerPercent} onChange={e => set('headerPercent', e.target.value)} /></div><div className="space-y-2"><Label>مساحة التذييل من الصفحة (%)</Label><Input type="number" min="10" max="25" value={form.footerPercent} onChange={e => set('footerPercent', e.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_print_logo_size', 'حجم الشعار (بكسل)')}</Label><Input type="number" min="40" max="180" value={form.logoSize} onChange={e => set('logoSize', e.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_print_header_height', 'ارتفاع الرأس (بكسل)')}</Label><Input type="number" min="60" max="220" value={form.headerHeight} onChange={e => set('headerHeight', e.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_print_footer_height', 'ارتفاع التذييل (بكسل)')}</Label><Input type="number" min="30" max="160" value={form.footerHeight} onChange={e => set('footerHeight', e.target.value)} /></div><div className="space-y-2"><Label>{labelFor('settings_print_accent_color', 'اللون الرئيسي للسند')}</Label><div className="flex gap-2"><Input type="color" value={form.accentColor} onChange={e => set('accentColor', e.target.value)} className="h-10 w-14 p-1" /><Input value={form.accentColor} onChange={e => set('accentColor', e.target.value)} dir="ltr" /></div></div><div className="space-y-2"><Label>{labelFor('settings_print_title_font_size', 'حجم عنوان السند (بكسل)')}</Label><Input type="number" min="18" max="36" value={form.titleFontSize} onChange={e => set('titleFontSize', e.target.value)} /></div><div className="flex items-center justify-between rounded-lg border p-3 md:col-span-2"><div><p className="text-sm font-medium">{labelFor('settings_print_show_barcode', 'إظهار باركود السند')}</p><p className="text-xs text-muted-foreground">{labelFor('settings_print_show_barcode_description', 'يظهر الباركود في رأس معاينة وطباعة السند.')}</p></div><Switch checked={form.showBarcode} onCheckedChange={checked => set('showBarcode', checked)} /></div></div><div className="rounded-lg border bg-muted/30 p-4 text-center text-sm" style={{ minHeight: `${Math.max(60, Number(form.headerHeight) || 92)}px`, borderTopColor: form.accentColor, borderTopWidth: 4 }}><p className="font-semibold" style={{ color: form.accentColor, fontSize: `${Math.max(18, Number(form.titleFontSize) || 24)}px` }}>{form.header || labelFor('settings_print_preview_default_company', 'بيانات الشركة الافتراضية')}</p><p className="mt-2 text-xs text-muted-foreground">اتجاه PDF: {form.orientation === 'portrait' ? 'رأسي' : 'أفقي'} — الرأس {form.headerPercent}% — التذييل {form.footerPercent}%</p><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_print_preview_logo', 'الشعار')}: {positionLabel} — {form.logoSize}px — {labelFor('settings_print_preview_barcode', 'الباركود')}: {form.showBarcode ? labelFor('settings_print_preview_visible', 'ظاهر') : labelFor('settings_print_preview_hidden', 'مخفي')}</p><div className="mt-4 border-t pt-2" style={{ minHeight: `${Math.max(30, Number(form.footerHeight) || 44)}px` }}>{form.footer || labelFor('settings_print_no_custom_footer', 'لا يوجد تذييل مخصص')}</div></div><Button onClick={save} disabled={mutation.isPending}>{labelFor('settings_print_save', 'حفظ تصميم المطبوعات')}</Button></CardContent></Card>;
}

function PeriodsSettings() {
  const { labelFor } = useSystemLabels();
  const { data: periods, refetch } = trpc.periods.list.useQuery();
  const [open, setOpen] = useState(false); const [editing, setEditing] = useState<any>(null); const [form, setForm] = useState(blankPeriod);
  const createMutation = trpc.periods.create.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_periods_added', 'تمت إضافة الفترة المالية')); } });
  const updateMutation = trpc.periods.update.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_periods_updated', 'تم تعديل الفترة المالية')); } });
  const close = () => { setOpen(false); setEditing(null); setForm(blankPeriod); };
  const submit = () => { if (!form.name || !form.startDate || !form.endDate) return toast.error(labelFor('settings_periods_required', 'يرجى إدخال اسم الفترة وتواريخها')); editing ? updateMutation.mutate({ id: editing.id, data: form }) : createMutation.mutate(form); };
  return <Card><CardHeader className="flex flex-row items-center justify-between"><CardTitle>{labelFor('settings_periods_title', 'الفترات المالية')}</CardTitle><Dialog open={open} onOpenChange={value => value ? setOpen(true) : close()}><DialogTrigger asChild><Button size="sm" onClick={() => close()}><Plus className="ml-1 h-4 w-4" />{labelFor('settings_periods_add', 'إضافة فترة')}</Button></DialogTrigger><DialogContent dir="rtl"><DialogHeader><DialogTitle>{editing ? labelFor('settings_periods_edit_dialog', 'تعديل الفترة المالية') : labelFor('settings_periods_add_dialog', 'إضافة فترة مالية')}</DialogTitle></DialogHeader><div className="space-y-4 pt-3"><div className="space-y-2"><Label>{labelFor('settings_periods_name', 'اسم الفترة')}</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div><div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_periods_start_date', 'تاريخ البداية')}</Label><Input type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })} /></div><div className="space-y-2"><Label>{labelFor('settings_periods_end_date', 'تاريخ النهاية')}</Label><Input type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })} /></div></div><div className="flex justify-start gap-2"><Button variant="outline" onClick={close}>{labelFor('settings_periods_cancel', 'إلغاء')}</Button><Button onClick={submit}>{editing ? labelFor('settings_periods_save_edit', 'حفظ التعديلات') : labelFor('settings_periods_save_add', 'إضافة')}</Button></div></div></DialogContent></Dialog></CardHeader><CardContent><Table dir="rtl"><TableHeader><TableRow><TableHead>{labelFor('settings_periods_table_name', 'الاسم')}</TableHead><TableHead>{labelFor('settings_periods_table_start', 'البداية')}</TableHead><TableHead>{labelFor('settings_periods_table_end', 'النهاية')}</TableHead><TableHead>{labelFor('settings_periods_table_status', 'الحالة')}</TableHead><TableHead>{labelFor('settings_periods_table_actions', 'إجراءات')}</TableHead></TableRow></TableHeader><TableBody>{periods?.map(p => <TableRow key={p.id}><TableCell className="font-medium">{p.name}</TableCell><TableCell>{new Date(p.startDate).toLocaleDateString('ar-SA')}</TableCell><TableCell>{new Date(p.endDate).toLocaleDateString('ar-SA')}</TableCell><TableCell>{p.isActive ? labelFor('settings_periods_active', 'نشطة') : labelFor('settings_periods_closed', 'مغلقة')}</TableCell><TableCell><div className="flex gap-1"><Button variant="ghost" size="sm" onClick={() => { setEditing(p); setForm({ name: p.name, startDate: dateValue(p.startDate), endDate: dateValue(p.endDate), isActive: p.isActive }); setOpen(true); }}><Pencil className="ml-1 h-4 w-4" />{labelFor('settings_periods_edit', 'تعديل')}</Button><Button variant="ghost" size="sm" onClick={() => updateMutation.mutate({ id: p.id, data: { isActive: !p.isActive } })}>{p.isActive ? labelFor('settings_periods_close', 'إغلاق') : labelFor('settings_periods_activate', 'تنشيط')}</Button></div></TableCell></TableRow>)}</TableBody></Table></CardContent></Card>;
}

function BranchesSettings() {
  const { data: branches, refetch } = trpc.branches.list.useQuery();
  const { labelFor } = useSystemLabels();
  const [open, setOpen] = useState(false); const [editing, setEditing] = useState<any>(null); const [form, setForm] = useState(blankBranch);
  const [deleteBranch, setDeleteBranch] = useState<any>(null);
  const createMutation = trpc.branches.create.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_branches_created', 'تمت إضافة الفرع')); } });
  const updateMutation = trpc.branches.update.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_branches_updated', 'تم تعديل الفرع')); } });
  const deleteMutation = trpc.branches.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف الفرع'); } });
  const close = () => { setOpen(false); setEditing(null); setForm(blankBranch); };
  const submit = () => { if (!form.name) return toast.error(labelFor('settings_branches_name_required', 'اسم الفرع مطلوب')); editing ? updateMutation.mutate({ id: editing.id, data: form }) : createMutation.mutate({ name: form.name, address: form.address }); };
  const serialPreview = (name: string, kind: 'receipt' | 'payment') => { const branchNumber = getConfiguredBranchNumber(name); return branchNumber ? `${kind === 'payment' ? 'PY-' : ''}${branchNumber}-${getVoucherYearSuffix()}-001` : 'اسم الفرع خارج الترتيب المعتمد'; };
  return <><Card><CardHeader className="flex flex-row items-center justify-between"><div><CardTitle>{labelFor('settings_branches_title', 'إدارة الفروع')}</CardTitle><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_branches_description', 'يُنشأ الرقم تلقائياً كل سنة وفق ترتيب الفروع: قبض «رقم الفرع-السنة-العداد» وصرف «PY-رقم الفرع-السنة-العداد».')}</p></div><Dialog open={open} onOpenChange={value => value ? setOpen(true) : close()}><DialogTrigger asChild><Button size="sm" onClick={() => close()}><Plus className="ml-1 h-4 w-4" />{labelFor('settings_branches_add', 'إضافة فرع')}</Button></DialogTrigger><DialogContent dir="rtl"><DialogHeader><DialogTitle>{editing ? labelFor('settings_branches_edit_dialog', 'تعديل بيانات الفرع') : labelFor('settings_branches_add_dialog', 'إضافة فرع جديد')}</DialogTitle></DialogHeader><div className="space-y-4 pt-3"><div className="space-y-2"><Label>{labelFor('settings_branches_name', 'اسم الفرع')}</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div><div className="space-y-2"><Label>{labelFor('settings_branches_address', 'العنوان')}</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div><div className="grid grid-cols-1 gap-3 rounded-lg bg-muted/40 p-3 text-sm sm:grid-cols-2"><div><span className="text-muted-foreground">{labelFor('settings_branches_next_receipt', 'السند القادم للقبض')}</span><p className="mt-1 font-semibold" dir="ltr">{serialPreview(form.name, 'receipt')}</p></div><div><span className="text-muted-foreground">{labelFor('settings_branches_next_payment', 'السند القادم للصرف')}</span><p className="mt-1 font-semibold" dir="ltr">{serialPreview(form.name, 'payment')}</p></div></div><div className="flex justify-start gap-2"><Button variant="outline" onClick={close}>{labelFor('action_cancel', 'إلغاء')}</Button><Button onClick={submit}>{editing ? labelFor('action_save', 'حفظ التعديلات') : labelFor('action_add', 'إضافة')}</Button></div></div></DialogContent></Dialog></CardHeader><CardContent><Table dir="rtl"><TableHeader><TableRow><TableHead>{labelFor('settings_branches_table_branch', 'الفرع')}</TableHead><TableHead>{labelFor('settings_branches_table_address', 'العنوان')}</TableHead><TableHead>{labelFor('settings_branches_table_receipt_template', 'القالب السنوي للقبض')}</TableHead><TableHead>{labelFor('settings_branches_table_payment_template', 'القالب السنوي للصرف')}</TableHead><TableHead>{labelFor('field_actions', 'إجراءات')}</TableHead></TableRow></TableHeader><TableBody>{branches?.map(b => <TableRow key={b.id}><TableCell className="font-medium">{b.name}</TableCell><TableCell>{b.address || '-'}</TableCell><TableCell dir="ltr">{serialPreview(b.name, 'receipt')}</TableCell><TableCell dir="ltr">{serialPreview(b.name, 'payment')}</TableCell><TableCell><div className="flex gap-1"><Button variant="ghost" size="icon" title={labelFor('action_edit', 'تعديل')} onClick={() => { setEditing(b); setForm({ name: b.name, address: b.address || '', receiptSerial: b.receiptSerial || '', paymentSerial: b.paymentSerial || '' }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button><Button variant="ghost" size="icon" className="text-destructive" title={labelFor('action_delete', 'حذف')} onClick={() => setDeleteBranch(b)}><Trash2 className="h-4 w-4" /></Button></div></TableCell></TableRow>)}</TableBody></Table></CardContent></Card><DeleteConfirmationDialog open={Boolean(deleteBranch)} onOpenChange={value => !value && setDeleteBranch(null)} title="تأكيد حذف الفرع" itemName={deleteBranch?.name || ''} details={[`العنوان: ${deleteBranch?.address || '-'}`, `سند القبض القادم: ${serialPreview(deleteBranch?.name || '', 'receipt')}`, `سند الصرف القادم: ${serialPreview(deleteBranch?.name || '', 'payment')}`]} isPending={deleteMutation.isPending} onConfirm={() => { if (deleteBranch) deleteMutation.mutate({ id: deleteBranch.id }); setDeleteBranch(null); }} /></>;
}

function InputListsSettings() {
  const { data: lists, refetch } = trpc.inputLists.list.useQuery({});
  const { labelFor } = useSystemLabels();
  const [open, setOpen] = useState(false); const [editing, setEditing] = useState<any>(null); const [form, setForm] = useState(blankList);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const createMutation = trpc.inputLists.create.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_input_lists_created', 'تمت إضافة العنصر')); } });
  const updateMutation = trpc.inputLists.update.useMutation({ onSuccess: () => { refetch(); close(); toast.success(labelFor('settings_input_lists_updated', 'تم تعديل العنصر')); } });
  const deleteMutation = trpc.inputLists.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف العنصر'); } });
  const close = () => { setOpen(false); setEditing(null); setForm(blankList); };
  const labels: Record<string, string> = { payment_method: labelFor('field_payment_method', 'طريقة الدفع'), bank: labelFor('field_bank', 'البنك'), payment_for: labelFor('field_request', 'مقابل') };
  const types = ['payment_method', 'bank', 'payment_for'] as const;
  const descendants = (id: number): number[] => (lists || []).filter(item => item.parentId === id).flatMap(item => [item.id, ...descendants(item.id)]);
  const parentOptions = (lists || []).filter(item => item.listType === form.listType && item.id !== editing?.id && !descendants(editing?.id || -1).includes(item.id));
  const renderBranches = (listType: typeof types[number], parentId: number | null, depth = 0): React.ReactNode => (lists || []).filter(item => item.listType === listType && (item.parentId ?? null) === parentId).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0) || a.name.localeCompare(b.name, 'ar')).map(item => <div key={item.id} className="space-y-1"><div className={`flex items-center justify-between rounded-lg border px-3 py-2 ${item.isActive ? 'bg-card' : 'bg-muted/50 opacity-70'}`} style={{ marginInlineStart: `${depth * 18}px` }}><div className="flex min-w-0 items-center gap-2"><FolderTree className="h-4 w-4 shrink-0 text-primary" /><span className="truncate font-medium">{item.name}</span>{listType === 'payment_method' && <span className={`rounded-full px-2 py-0.5 text-[11px] ${item.requiresAttachment === false ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200'}`}>{item.requiresAttachment === false ? labelFor('settings_input_lists_no_receipt', 'بدون إيصال') : labelFor('settings_input_lists_receipt_required', 'الإيصال مطلوب')}</span>}</div><div className="flex shrink-0 gap-0.5"><Button type="button" variant="ghost" size="icon" title={labelFor('settings_input_lists_add_branch', 'إضافة فرع')} onClick={() => { setEditing(null); setForm({ ...blankList, listType, parentId: String(item.id) }); setOpen(true); }}><Plus className="h-4 w-4" /></Button><Button type="button" variant="ghost" size="icon" title="تعديل" onClick={() => { setEditing(item); setForm({ listType: item.listType, name: item.name, parentId: item.parentId ? String(item.parentId) : '__root__', requiresAttachment: item.requiresAttachment !== false, sortOrder: String(item.sortOrder || 0) }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button><Button type="button" variant="ghost" size="icon" title="حذف" className="text-destructive" onClick={() => setDeleteItem(item)}><Trash2 className="h-4 w-4" /></Button></div></div>{renderBranches(listType, item.id, depth + 1)}</div>);
  const save = () => {
    if (!form.name.trim()) return toast.error(labelFor('settings_input_lists_name_required', 'يرجى إدخال الاسم'));
    const data = { name: form.name.trim(), parentId: form.parentId === '__root__' ? null : Number(form.parentId), requiresAttachment: form.requiresAttachment, sortOrder: Number(form.sortOrder) || 0 };
    editing ? updateMutation.mutate({ id: editing.id, data }) : createMutation.mutate({ listType: form.listType as 'payment_method' | 'bank' | 'payment_for', ...data });
  };
  return <><Card><CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><CardTitle>{labelFor('settings_input_lists_title', 'قوائم الإدخال الشجرية')}</CardTitle><p className="mt-1 text-xs text-muted-foreground">{labelFor('settings_input_lists_description', 'تظهر الجذور الثلاثة في النظام، ويمكن بناء فروع داخل كل قائمة. عنصر الدفع النقدي وحده يضبط بلا إلزام لإرفاق الإيصال.')}</p></div><Dialog open={open} onOpenChange={value => value ? setOpen(true) : close()}><DialogTrigger asChild><Button size="sm" onClick={() => close()}><Plus className="ml-1 h-4 w-4" />{labelFor('settings_input_lists_add_item', 'إضافة عنصر')}</Button></DialogTrigger><DialogContent dir="rtl" className="max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>{editing ? labelFor('settings_input_lists_edit_dialog', 'تعديل عنصر القائمة') : labelFor('settings_input_lists_add_dialog', 'إضافة عنصر جديد')}</DialogTitle></DialogHeader><div className="space-y-4 pt-3"><div className="space-y-2"><Label>{labelFor('settings_input_lists_main_list', 'القائمة الرئيسية')}</Label><Select disabled={Boolean(editing)} value={form.listType} onValueChange={listType => setForm({ ...form, listType, parentId: '__root__' })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{types.map(type => <SelectItem key={type} value={type}>{labels[type]}</SelectItem>)}</SelectContent></Select></div><div className="space-y-2"><Label>{labelFor('settings_input_lists_parent_item', 'العنصر الأب')}</Label><Select value={form.parentId} onValueChange={parentId => setForm({ ...form, parentId })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="__root__">{labelFor('settings_input_lists_root', 'الجذر')}: {labels[form.listType]}</SelectItem>{parentOptions.map(item => <SelectItem key={item.id} value={String(item.id)}>{item.name}</SelectItem>)}</SelectContent></Select></div><div className="grid grid-cols-1 gap-3 sm:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_input_lists_item_name', 'اسم الفرع أو العنصر')}</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div><div className="space-y-2"><Label>{labelFor('settings_input_lists_sort_order', 'ترتيب العرض')}</Label><Input type="number" value={form.sortOrder} onChange={e => setForm({ ...form, sortOrder: e.target.value })} /></div></div>{form.listType === 'payment_method' && <label className="flex cursor-pointer items-center justify-between rounded-lg border p-3"><span><span className="block font-medium">{labelFor('settings_input_lists_requires_attachment', 'إلزام إرفاق الإيصال')}</span><span className="mt-1 block text-xs text-muted-foreground">{labelFor('settings_input_lists_requires_attachment_description', 'ألغِ التحديد لطريقة «نقداً» فقط إذا لا يلزم إيصال تحويل.')}</span></span><Checkbox checked={form.requiresAttachment} onCheckedChange={checked => setForm({ ...form, requiresAttachment: checked === true })} /></label>}<div className="flex justify-start gap-2"><Button variant="outline" onClick={close}>{labelFor('action_cancel', 'إلغاء')}</Button><Button onClick={save}>{editing ? labelFor('action_save', 'حفظ التعديلات') : labelFor('action_add', 'إضافة')}</Button></div></div></DialogContent></Dialog></CardHeader><CardContent className="grid gap-4 lg:grid-cols-3">{types.map(type => <section key={type} className="rounded-xl border bg-muted/15 p-3"><div className="mb-3 flex items-center justify-between border-b pb-2"><div><h3 className="font-semibold">{labels[type]}</h3><p className="text-xs text-muted-foreground">{labelFor('settings_input_lists_main_list', 'القائمة الرئيسية')}</p></div><Button type="button" variant="ghost" size="sm" onClick={() => { setEditing(null); setForm({ ...blankList, listType: type }); setOpen(true); }}><Plus className="ml-1 h-4 w-4" />{labelFor('settings_input_lists_add_branch', 'إضافة فرع')}</Button></div><div className="space-y-2">{renderBranches(type, null) || <p className="py-5 text-center text-sm text-muted-foreground">{labelFor('settings_input_lists_empty', 'لا توجد عناصر بعد.')}</p>}</div></section>)}</CardContent></Card><DeleteConfirmationDialog open={Boolean(deleteItem)} onOpenChange={value => !value && setDeleteItem(null)} title="تأكيد حذف عنصر القائمة" itemName={deleteItem?.name || ''} details={[`القائمة الرئيسية: ${labels[deleteItem?.listType] || '-'}`, deleteItem?.parentId ? 'هذا عنصر فرعي ضمن الشجرة.' : 'هذا عنصر ضمن جذر القائمة.', deleteItem?.listType === 'payment_method' && deleteItem?.requiresAttachment === false ? 'لا يتطلب إيصالاً.' : 'يتطلب إيصالاً عند اختيار طريقة الدفع.' ]} isPending={deleteMutation.isPending} onConfirm={() => { if (deleteItem) deleteMutation.mutate({ id: deleteItem.id }); setDeleteItem(null); }} /></>;
}

function LoginSettings() {
  const { data: backgrounds, refetch } = trpc.backgrounds.list.useQuery();
  const { data: settings, refetch: refetchSettings } = trpc.settings.getAll.useQuery();
  const { labelFor } = useSystemLabels();
  const [url, setUrl] = useState(''); const [editing, setEditing] = useState<any>(null);
  const [deleteBackground, setDeleteBackground] = useState<any>(null);
  const [texts, setTexts] = useState({ subtitle: '', copyright: '' });
  const createMutation = trpc.backgrounds.create.useMutation({ onSuccess: () => { refetch(); setUrl(''); toast.success(labelFor('settings_login_background_added', 'تمت إضافة الخلفية')); } });
  const updateMutation = trpc.backgrounds.update.useMutation({ onSuccess: () => { refetch(); setEditing(null); setUrl(''); toast.success(labelFor('settings_login_background_updated', 'تم تعديل الخلفية')); } });
  const uploadBackgroundMutation = trpc.files.uploadLoginBackground.useMutation();
  const deleteMutation = trpc.backgrounds.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف الخلفية'); } });
  const textMutation = trpc.settings.update.useMutation();
  useEffect(() => {
    if (settings) setTexts({ subtitle: settings.login_subtitle || '', copyright: settings.login_copyright || '' });
  }, [settings]);
  const submit = () => { if (!url) return toast.error('يرجى اختيار ملف الصورة ورفعه أولاً'); editing ? updateMutation.mutate({ id: editing.id, imageUrl: url }) : createMutation.mutate({ imageUrl: url }); };
  const saveTexts = async () => {
    try {
      await Promise.all([
        textMutation.mutateAsync({ key: 'login_subtitle', value: texts.subtitle.trim() }),
        textMutation.mutateAsync({ key: 'login_copyright', value: texts.copyright.trim() }),
      ]);
      await refetchSettings();
      toast.success(labelFor('settings_login_texts_saved', 'تم حفظ نصوص شاشة الدخول وحقوق النشر'));
    } catch {
      toast.error(labelFor('settings_login_texts_save_error', 'تعذر حفظ نصوص شاشة الدخول'));
    }
  };
  return <>
    <Card><CardHeader><CardTitle>{labelFor('settings_login_texts_title', 'نصوص شاشة الدخول وحقوق النشر')}</CardTitle></CardHeader><CardContent className="space-y-5"><p className="text-sm text-muted-foreground">{labelFor('settings_login_texts_description', 'تُعرض هذه النصوص في صفحة الدخول، ويُستخدم نص حقوق النشر نفسه في تذييل جميع الشاشات الداخلية. اترك الحقل فارغاً لاستخدام النص الافتراضي.')}</p><div className="grid grid-cols-1 gap-4 md:grid-cols-2"><div className="space-y-2"><Label htmlFor="login-subtitle">{labelFor('settings_login_subtitle', 'النص أسفل اسم الشركة')}</Label><Input id="login-subtitle" value={texts.subtitle} onChange={event => setTexts(current => ({ ...current, subtitle: event.target.value }))} placeholder={labelFor('settings_login_subtitle_placeholder', 'نظام الإدارة المالية المتكامل')} /></div><div className="space-y-2"><Label htmlFor="login-copyright">{labelFor('settings_login_copyright', 'نص حقوق النشر')}</Label><Input id="login-copyright" value={texts.copyright} onChange={event => setTexts(current => ({ ...current, copyright: event.target.value }))} placeholder={labelFor('settings_login_copyright_placeholder', 'جميع الحقوق محفوظة © 2026 - شركة الأسمدة المتحدة السعودية')} /></div></div><Button onClick={saveTexts} disabled={textMutation.isPending}>{textMutation.isPending ? labelFor('settings_login_saving_texts', 'جارٍ الحفظ...') : labelFor('settings_login_save_texts', 'حفظ النصوص')}</Button></CardContent></Card>
    <Card><CardHeader><CardTitle>{labelFor('settings_login_backgrounds_title', 'خلفيات شاشة تسجيل الدخول')}</CardTitle></CardHeader><CardContent className="space-y-5"><FileDropzone label={editing ? 'صورة بديلة للخلفية' : 'خلفية جديدة لشاشة الدخول'} description={editing ? 'الخلفية الحالية معروضة للمعاينة؛ اختر ملفاً بديلاً ثم احفظ التعديل.' : 'اسحب صورة الخلفية أو انقر لاختيارها، ثم اضغط إضافة الخلفية.'} accept="image/png,image/jpeg,image/webp" maxBytes={5 * 1024 * 1024} value={url || editing?.imageUrl || null} isUploading={uploadBackgroundMutation.isPending} disabled={createMutation.isPending || updateMutation.isPending} onFileSelected={async file => { try { const dataUrl = await fileToDataUrl(file); const uploaded = await uploadBackgroundMutation.mutateAsync({ fileName: file.name, dataUrl }); setUrl(uploaded.url); toast.success('تم رفع الخلفية؛ اضغط حفظ التعديل لتطبيقها'); } catch (error: any) { toast.error(error?.message || 'تعذر رفع خلفية الدخول'); } }} onClear={() => setUrl('')} /><div className="flex flex-wrap gap-2"><Button onClick={submit} disabled={uploadBackgroundMutation.isPending || createMutation.isPending || updateMutation.isPending}>{editing ? labelFor('settings_login_update_background', 'حفظ التعديل') : labelFor('settings_login_add_background', 'إضافة الخلفية')}</Button>{editing && <Button variant="outline" onClick={() => { setEditing(null); setUrl(''); }}>{labelFor('settings_login_cancel_background_edit', 'إلغاء')}</Button>}</div><div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">{backgrounds?.map(bg => <div key={bg.id} className="overflow-hidden rounded-lg border"><img src={bg.imageUrl} alt={labelFor('settings_login_background_alt', 'خلفية تسجيل الدخول')} className="h-32 w-full object-cover" /><div className="flex justify-start gap-1 p-2"><Button variant="ghost" size="sm" onClick={() => { setEditing(bg); setUrl(''); }}><Pencil className="ml-1 h-4 w-4" />{labelFor('settings_login_edit_background', 'تعديل')}</Button><Button variant="ghost" size="sm" className="text-destructive" onClick={() => setDeleteBackground(bg)}><Trash2 className="ml-1 h-4 w-4" />{labelFor('settings_login_delete_background', 'حذف')}</Button></div></div>)}</div></CardContent></Card>
    <DeleteConfirmationDialog open={Boolean(deleteBackground)} onOpenChange={value => !value && setDeleteBackground(null)} title={labelFor('settings_login_background_delete_title', 'تأكيد حذف الخلفية')} itemName={labelFor('settings_login_background_delete_name', 'خلفية شاشة تسجيل الدخول')} details={[`المعرف: ${deleteBackground?.id || '-'}`, `الرابط: ${deleteBackground?.imageUrl || '-'}`]} isPending={deleteMutation.isPending} onConfirm={() => { if (deleteBackground) deleteMutation.mutate({ id: deleteBackground.id }); setDeleteBackground(null); }} />
  </>;
}

function LoginDarkModeSettings() {
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const { labelFor } = useSystemLabels();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const [position, setPosition] = useState('top-left');
  const [size, setSize] = useState('medium');
  useEffect(() => {
    if (!settings) return;
    setPosition(['top-left', 'top-right', 'bottom-left', 'bottom-right'].includes(settings.login_dark_toggle_position || '') ? settings.login_dark_toggle_position : 'top-left');
    setSize(['small', 'medium', 'large'].includes(settings.login_dark_toggle_size || '') ? settings.login_dark_toggle_size : 'medium');
  }, [settings]);
  const save = async () => {
    try {
      await updateMutation.mutateAsync({ entries: [{ key: 'login_dark_toggle_position', value: position }, { key: 'login_dark_toggle_size', value: size }] });
      await refetch();
      toast.success(labelFor('settings_login_dark_toggle_saved', 'تم حفظ موضع وحجم زر الوضع الداكن'));
    } catch (error: any) {
      toast.error(error?.message || labelFor('settings_login_dark_toggle_save_error', 'تعذر حفظ إعدادات زر الوضع الداكن'));
    }
  };
  return <Card><CardHeader><CardTitle>{labelFor('settings_login_dark_toggle_title', 'زر الوضع الداكن في شاشة الدخول')}</CardTitle></CardHeader><CardContent className="space-y-4"><p className="text-sm text-muted-foreground">{labelFor('settings_login_dark_toggle_description', 'اضبط موضع الزر وحجمه ليظهر بصورة متوازنة فوق خلفية شاشة تسجيل الدخول.')}</p><div className="grid gap-4 sm:grid-cols-2"><div className="space-y-2"><Label>{labelFor('settings_login_dark_toggle_position', 'موضع الزر')}</Label><Select value={position} onValueChange={setPosition}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="top-left">{labelFor('settings_login_dark_toggle_position_top_left', 'أعلى اليسار')}</SelectItem><SelectItem value="top-right">{labelFor('settings_login_dark_toggle_position_top_right', 'أعلى اليمين')}</SelectItem><SelectItem value="bottom-left">{labelFor('settings_login_dark_toggle_position_bottom_left', 'أسفل اليسار')}</SelectItem><SelectItem value="bottom-right">{labelFor('settings_login_dark_toggle_position_bottom_right', 'أسفل اليمين')}</SelectItem></SelectContent></Select></div><div className="space-y-2"><Label>{labelFor('settings_login_dark_toggle_size', 'حجم الزر')}</Label><Select value={size} onValueChange={setSize}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="small">{labelFor('settings_login_dark_toggle_size_small', 'صغير')}</SelectItem><SelectItem value="medium">{labelFor('settings_login_dark_toggle_size_medium', 'متوسط')}</SelectItem><SelectItem value="large">{labelFor('settings_login_dark_toggle_size_large', 'كبير')}</SelectItem></SelectContent></Select></div></div><Button onClick={save} disabled={updateMutation.isPending}>{updateMutation.isPending ? labelFor('settings_login_dark_toggle_saving', 'جارٍ الحفظ...') : labelFor('settings_login_dark_toggle_save', 'حفظ إعدادات الزر')}</Button></CardContent></Card>;
}

function NewsSettings() {
  const { labelFor } = useSystemLabels();
  const { data: news, refetch } = trpc.news.list.useQuery();
  const [content, setContent] = useState(''); const [editing, setEditing] = useState<any>(null);
  const [deleteNews, setDeleteNews] = useState<any>(null);
  const createMutation = trpc.news.create.useMutation({ onSuccess: () => { refetch(); setContent(''); toast.success(labelFor('settings_news_added', 'تمت إضافة الخبر')); } });
  const updateMutation = trpc.news.update.useMutation({ onSuccess: () => { refetch(); setEditing(null); setContent(''); toast.success(labelFor('settings_news_updated', 'تم تعديل الخبر')); } });
  const deleteMutation = trpc.news.delete.useMutation({ onSuccess: () => { refetch(); toast.success(labelFor('settings_news_deleted', 'تم حذف الخبر')); } });
  const submit = () => { if (!content.trim()) return toast.error(labelFor('settings_news_required', 'يرجى إدخال نص الخبر')); editing ? updateMutation.mutate({ id: editing.id, data: { content } }) : createMutation.mutate({ content }); };
  return <><Card><CardHeader><CardTitle>{labelFor('settings_news_title', 'الشريط الإخباري')}</CardTitle></CardHeader><CardContent className="space-y-5"><div className="flex flex-col gap-2 sm:flex-row"><Input placeholder={labelFor('settings_news_placeholder', 'نص الخبر أو الإعلان')} value={content} onChange={e => setContent(e.target.value)} className="flex-1" /><Button onClick={submit}>{editing ? labelFor('settings_news_save_edit', 'حفظ التعديل') : labelFor('settings_news_add', 'إضافة الخبر')}</Button>{editing && <Button variant="outline" onClick={() => { setEditing(null); setContent(''); }}>{labelFor('settings_news_cancel', 'إلغاء')}</Button>}</div><div className="space-y-2">{news?.map(item => <div key={item.id} className="flex flex-col justify-between gap-3 rounded-lg bg-muted/60 p-3 sm:flex-row sm:items-center"><span className="text-sm">{item.content}</span><div className="flex gap-1"><Button variant="ghost" size="sm" onClick={() => { setEditing(item); setContent(item.content); }}><Pencil className="ml-1 h-4 w-4" />{labelFor('settings_news_edit', 'تعديل')}</Button><Button variant="ghost" size="sm" className="text-destructive" onClick={() => setDeleteNews(item)}><Trash2 className="ml-1 h-4 w-4" />{labelFor('settings_news_delete', 'حذف')}</Button></div></div>)}</div></CardContent></Card><DeleteConfirmationDialog open={Boolean(deleteNews)} onOpenChange={value => !value && setDeleteNews(null)} title={labelFor('settings_news_delete_title', 'تأكيد حذف الخبر')} itemName={deleteNews?.content || ''} details={[`${labelFor('settings_news_record_id', 'المعرف')}: ${deleteNews?.id || '-'}`, `${labelFor('settings_news_content', 'النص')}: ${deleteNews?.content || '-'}`]} isPending={deleteMutation.isPending} onConfirm={() => { if (deleteNews) deleteMutation.mutate({ id: deleteNews.id }); setDeleteNews(null); }} /></>;
}

function BackupSettings() {
  const { labelFor } = useSystemLabels();
  const utils = trpc.useUtils();
  const { data: logs, refetch: refetchLogs } = trpc.backups.list.useQuery();
  const { data: userDirectory } = trpc.systemUsers.directory.useQuery();
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [pendingBackup, setPendingBackup] = useState<{ fileName: string; payload: any; recordsCount: number } | null>(null);
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const downloadMutation = trpc.backups.downloadFull.useMutation({
    onSuccess: (result) => {
      const blob = new Blob([JSON.stringify(result.payload, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob); const link = document.createElement('a');
      link.href = url; link.download = result.fileName; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
      refetchLogs(); toast.success(`تم تنزيل نسخة كاملة تضم ${Object.values(result.payload.data).reduce((count: number, rows: any) => count + rows.length, 0)} سجلاً`);
    },
    onError: (error) => toast.error(error.message || 'تعذر إنشاء النسخة الاحتياطية'),
  });
  const restoreMutation = trpc.backups.restoreFull.useMutation({
    onSuccess: (result) => {
      setRestoreOpen(false); setPendingBackup(null); setPassword(''); setConfirmation('');
      utils.invalidate(); refetchLogs(); toast.success(`اكتمل استيراد ${result.recordsCount} سجلاً من النسخة الاحتياطية`);
    },
    onError: (error) => toast.error(error.message || 'تعذر استيراد النسخة الاحتياطية'),
  });
  const readBackupFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try {
      const payload = JSON.parse(await file.text());
      if (payload?.format !== 'asmidasys-full-system-backup' || payload?.version !== 2 || !payload?.data || typeof payload.data !== 'object' || !Array.isArray(payload.files)) throw new Error('هذا الملف ليس نسخة احتياطية كاملة ومتوافقة مع النظام');
      const recordsCount = Object.values(payload.data).reduce((count: number, rows: any) => count + (Array.isArray(rows) ? rows.length : 0), 0);
      setPendingBackup({ fileName: file.name, payload, recordsCount }); setRestoreOpen(true);
    } catch (error: any) { toast.error(error?.message || 'تعذر قراءة ملف النسخة الاحتياطية'); }
  };
  const restore = () => {
    if (!pendingBackup) return;
    restoreMutation.mutate({ password, confirmation: 'استيراد النسخة الاحتياطية الكاملة', fileName: pendingBackup.fileName, payload: pendingBackup.payload });
  };
  const displayUser = (userId: number) => userDirectory?.find(user => user.id === userId)?.fullName || `مستخدم رقم ${userId}`;
  return <div className="space-y-5">
    <Card className="border-primary/25"><CardHeader><CardTitle className="flex items-center gap-2"><Database className="h-5 w-5 text-primary" />{labelFor('settings_backup_full_title', 'نسخة احتياطية كاملة للنظام')}</CardTitle></CardHeader><CardContent className="space-y-5"><p className="text-sm leading-6 text-muted-foreground">{labelFor('settings_backup_full_description', 'تتضمن النسخة الكاملة بيانات العملاء والفروع والمستخدمين والإعدادات والسندات والفواتير وسجلات النظام، إضافة إلى المحتوى الفعلي للشعار وخلفيات الدخول ومرفقات التحويل والطلبات. تحفظ النسخة محلياً بصيغة JSON عبر اتصال آمن؛ احتفظ بها في موقع آمن لأنها تحتوي بيانات تشغيلية حساسة.')}</p><div className="grid gap-3 rounded-xl border bg-primary/5 p-4 sm:grid-cols-2"><div><p className="font-semibold">{labelFor('settings_backup_export_title', 'تصدير نسخة كاملة')}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{labelFor('settings_backup_export_description', 'ينشئ ملفاً قابلاً للاستيراد لاحقاً، بما في ذلك الملفات المرفوعة، ويسجل عملية التنزيل باسم المستخدم وتاريخها.')}</p></div><Button className="sm:justify-self-end" onClick={() => downloadMutation.mutate()} disabled={downloadMutation.isPending}><Download className="ml-2 h-4 w-4" />{downloadMutation.isPending ? labelFor('settings_backup_downloading', 'جارٍ تجهيز النسخة...') : labelFor('settings_backup_download', 'تنزيل النسخة الكاملة')}</Button></div><div className="rounded-xl border border-amber-300/70 bg-amber-50/70 p-4 dark:bg-amber-950/15"><p className="flex items-center gap-2 font-semibold text-amber-900 dark:text-amber-200"><AlertTriangle className="h-4 w-4" />{labelFor('settings_backup_import_title', 'استيراد نسخة كاملة')}</p><p className="mt-1 text-xs leading-5 text-amber-800 dark:text-amber-300">{labelFor('settings_backup_import_description', 'الاستيراد يستبدل بيانات النظام الحالية بالكامل ومرفقاتها بمحتوى النسخة المختارة. يتطلب كلمة مرور المدير والعبارة التأكيدية قبل التنفيذ.')}</p><Input type="file" accept="application/json,.json" onChange={readBackupFile} className="mt-3 max-w-xl bg-background" /></div></CardContent></Card>
    <Card><CardHeader><CardTitle>{labelFor('settings_backup_history_title', 'سجل النسخ الاحتياطية')}</CardTitle></CardHeader><CardContent>{logs?.length ? <div className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead>{labelFor('settings_backup_table_operation', 'العملية')}</TableHead><TableHead>{labelFor('settings_backup_table_file_name', 'اسم الملف')}</TableHead><TableHead>{labelFor('settings_backup_table_records', 'السجلات')}</TableHead><TableHead>{labelFor('settings_backup_table_user', 'المستخدم')}</TableHead><TableHead>{labelFor('settings_backup_table_date', 'التاريخ')}</TableHead><TableHead>{labelFor('settings_backup_table_status', 'الحالة')}</TableHead></TableRow></TableHeader><TableBody>{logs.map(log => <TableRow key={log.id}><TableCell>{log.operation === 'download' ? labelFor('settings_backup_operation_download', 'تنزيل نسخة') : labelFor('settings_backup_operation_import', 'استيراد نسخة')}</TableCell><TableCell className="font-mono text-xs" dir="ltr">{log.fileName}</TableCell><TableCell>{log.recordsCount.toLocaleString('ar-SA')}</TableCell><TableCell>{displayUser(log.userId)}</TableCell><TableCell>{new Date(log.createdAt).toLocaleString('ar-SA')}</TableCell><TableCell><span className={log.status === 'success' ? 'text-emerald-700' : 'text-destructive'}>{log.status === 'success' ? labelFor('settings_backup_status_success', 'ناجحة') : labelFor('settings_backup_status_failed', 'فشلت')}</span></TableCell></TableRow>)}</TableBody></Table></div> : <p className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">{labelFor('settings_backup_history_empty', 'لم يتم تنزيل أو استيراد أي نسخة احتياطية كاملة بعد.')}</p>}</CardContent></Card>
    <Dialog open={restoreOpen} onOpenChange={open => { if (!open && !restoreMutation.isPending) { setRestoreOpen(false); setPendingBackup(null); setPassword(''); setConfirmation(''); } }}><DialogContent dir="rtl" className="max-w-lg"><DialogHeader><DialogTitle>تأكيد استيراد النسخة الكاملة</DialogTitle></DialogHeader><div className="space-y-4 text-right"><div className="rounded-lg bg-destructive/10 p-3 text-sm leading-6 text-destructive"><strong>تنبيه:</strong> سيستبدل الاستيراد جميع بيانات النظام الحالية بملف <span dir="ltr" className="font-mono">{pendingBackup?.fileName}</span> ويشمل ذلك السندات والعملاء والإعدادات والمستخدمين.</div><div className="rounded-md bg-muted p-3 text-sm">عدد السجلات المقرر استيرادها: <strong>{pendingBackup?.recordsCount.toLocaleString('ar-SA')}</strong></div><div className="space-y-2"><Label>أعد إدخال كلمة مرور المدير</Label><Input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete="current-password" /></div><div className="space-y-2"><Label>اكتب العبارة التالية للتأكيد: استيراد النسخة الاحتياطية الكاملة</Label><Input value={confirmation} onChange={event => setConfirmation(event.target.value)} /></div><Button variant="destructive" className="w-full" onClick={restore} disabled={!password || confirmation !== 'استيراد النسخة الاحتياطية الكاملة' || restoreMutation.isPending}>{restoreMutation.isPending ? 'جارٍ استيراد النسخة...' : 'تأكيد الاستيراد النهائي'}</Button></div></DialogContent></Dialog>
  </div>;
}

type ImportedCustomer = { customerNumber: string; name: string; phone?: string };

function DataAdministration() {
  const { isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const [preview, setPreview] = useState<ImportedCustomer[]>([]);
  const [fileName, setFileName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [clearDialogOpen, setClearDialogOpen] = useState(false);
  const [selectiveClearDialogOpen, setSelectiveClearDialogOpen] = useState(false);
  const [selectedScopes, setSelectedScopes] = useState<Array<'vouchers' | 'customers' | 'targets'>>([]);
  const [backupBeforeDeletion, setBackupBeforeDeletion] = useState(true);
  const utils = trpc.useUtils();
  const fullCountsQuery = trpc.dataAdministration.previewOperationalClear.useQuery(undefined, { enabled: isAdmin });
  const selectiveCountsQuery = trpc.dataAdministration.previewSelectiveClear.useQuery(undefined, { enabled: !isAdmin });
  const counts = isAdmin ? fullCountsQuery.data : selectiveCountsQuery.data;
  const refetchCounts = () => isAdmin ? fullCountsQuery.refetch() : selectiveCountsQuery.refetch();
  const importMutation = trpc.backup.importCustomers.useMutation({
    onSuccess: (result) => {
      toast.success(`اكتمل استيراد ${result.imported} عميل من أصل ${result.total}`);
      if (result.failed) toast.warning(`تعذر أو تم تجاوز ${result.failed} سجل مكرر أو غير صالح`);
      setPreview([]); setFileName('');
      utils.customers.list.invalidate();
      refetchCounts();
    },
    onError: (error) => toast.error(error.message || 'تعذر استيراد ملف العملاء'),
  });
  const clearMutation = trpc.dataAdministration.clearOperationalData.useMutation({
    onSuccess: () => {
      toast.success('تم حذف البيانات التشغيلية بنجاح مع الإبقاء على حسابات النظام وإعداداته');
      setPassword(''); setConfirmation(''); setClearDialogOpen(false);
      refetchCounts();
      utils.invalidate();
    },
    onError: (error) => toast.error(error.message || 'تعذر حذف البيانات التشغيلية'),
  });
  const clearSelectedMutation = trpc.dataAdministration.clearSelectedOperationalData.useMutation({
    onSuccess: () => {
      toast.success('تم حذف البيانات المحددة بنجاح');
      setPassword(''); setConfirmation(''); setSelectedScopes([]); setSelectiveClearDialogOpen(false);
      refetchCounts();
      utils.invalidate();
    },
    onError: (error) => toast.error(error.message || 'تعذر حذف البيانات المحددة'),
  });
  const preDeletionBackupMutation = trpc.backups.downloadFull.useMutation();

  const saveBackupBeforeDeletion = async () => {
    const result = await preDeletionBackupMutation.mutateAsync();
    const blob = new Blob([JSON.stringify(result.payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = result.fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
    toast.success('تم حفظ النسخة الاحتياطية وتنزيلها قبل متابعة الحذف');
  };
  const clearSelectedWithOptionalBackup = async () => {
    try {
      if (backupBeforeDeletion && isAdmin) await saveBackupBeforeDeletion();
      await clearSelectedMutation.mutateAsync({ password, confirmation: 'حذف البيانات المحددة', scopes: selectedScopes });
    } catch (error: any) {
      if (backupBeforeDeletion && isAdmin && !clearSelectedMutation.isError) toast.error(error?.message || 'تعذر حفظ النسخة الاحتياطية؛ لم يتم حذف أي بيانات');
    }
  };
  const clearOperationalWithOptionalBackup = async () => {
    try {
      if (backupBeforeDeletion) await saveBackupBeforeDeletion();
      await clearMutation.mutateAsync({ password, confirmation: 'حذف البيانات التشغيلية' });
    } catch (error: any) {
      if (!clearMutation.isError) toast.error(error?.message || 'تعذر حفظ النسخة الاحتياطية؛ لم يتم حذف أي بيانات');
    }
  };

  const readCustomerFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' });
      const parsed = rows.map((row) => ({
        customerNumber: String(row['رقم العميل'] ?? row.customerNumber ?? row['Customer Number'] ?? row['رقم'] ?? '').trim(),
        name: String(row['اسم العميل'] ?? row.name ?? row['Customer Name'] ?? row['الاسم'] ?? '').trim(),
        phone: String(row['الهاتف'] ?? row.phone ?? row['Phone'] ?? '').trim(),
      })).filter((customer) => customer.customerNumber && customer.name);
      if (!parsed.length) throw new Error('لم يتم العثور على أعمدة رقم العميل واسم العميل في الملف');
      setPreview(parsed); setFileName(file.name);
      toast.success(`تمت قراءة ${parsed.length} سجلاً؛ راجع المعاينة قبل الاستيراد`);
    } catch (error: any) {
      setPreview([]); setFileName('');
      toast.error(error?.message || 'تعذر قراءة ملف Excel');
    } finally {
      event.target.value = '';
    }
  };

  const countItems = [
    ['السندات', counts?.receipts ?? 0], ['فواتير السندات', counts?.receiptInvoices ?? 0], ['العملاء', counts?.customers ?? 0],
    ['الفروع', counts?.branches ?? 0], ['الأهداف', counts?.branchTargets ?? 0], ['تقارير الأداء', counts?.performanceReports ?? 0],
    ['الإشعارات', counts?.notifications ?? 0], ['سجل قرارات السندات', counts?.decisionAudit ?? 0],
  ];

  return <div className="space-y-5">
    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2"><Upload className="h-5 w-5 text-primary" />استيراد بيانات العملاء</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">ارفع ملف Excel يحتوي أعمدة: رقم العميل، اسم العميل، الهاتف. ستظهر معاينة للسجلات الصالحة قبل الحفظ، وتُتجاوز الأرقام الموجودة مسبقاً.</p>
        <div className="flex flex-col gap-3 rounded-lg border border-dashed bg-muted/20 p-4 sm:flex-row sm:items-center">
          <Input type="file" accept=".xlsx,.xls,.csv" onChange={readCustomerFile} className="max-w-md bg-background" />
          {fileName && <span className="text-sm text-muted-foreground">الملف: {fileName}</span>}
        </div>
        {preview.length > 0 && <div className="space-y-3 rounded-lg border p-4">
          <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center"><p className="font-medium">معاينة {preview.length} عميل صالح</p><Button onClick={() => importMutation.mutate({ customers: preview })} disabled={importMutation.isPending}>{importMutation.isPending ? 'جارٍ الاستيراد...' : `استيراد ${preview.length} عميل`}</Button></div>
          <div className="max-h-52 overflow-auto rounded-md border"><Table><TableHeader><TableRow><TableHead>{labelFor('settings_customer_import_preview_number_heading', 'رقم العميل')}</TableHead><TableHead>الاسم</TableHead><TableHead>الهاتف</TableHead></TableRow></TableHeader><TableBody>{preview.slice(0, 10).map((customer, index) => <TableRow key={`${customer.customerNumber}-${index}`}><TableCell>{customer.customerNumber}</TableCell><TableCell>{customer.name}</TableCell><TableCell>{customer.phone || '—'}</TableCell></TableRow>)}</TableBody></Table></div>
          {preview.length > 10 && <p className="text-xs text-muted-foreground">تُعرض أول 10 سجلات فقط من المعاينة.</p>}
        </div>}
      </CardContent>
    </Card>

    <Card className="border-destructive/35">
      <CardHeader><CardTitle className="flex items-center gap-2 text-destructive"><AlertTriangle className="h-5 w-5" />حذف انتقائي للبيانات</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">اختر نوع البيانات المطلوب حذفها. لا يمكن استرجاع هذا الإجراء، ويستلزم كلمة مرور الحساب وعبارة التأكيد.</p>
        <div className="grid gap-3 sm:grid-cols-3">
          {([
            ['vouchers', 'سندات القبض والصرف', `القبض: ${counts?.receipts ?? 0} — الصرف: ${counts?.payments ?? 0}`],
            ['customers', 'العملاء', `${counts?.customers ?? 0} عميل`],
            ['targets', 'الأهداف', `${counts?.branchTargets ?? 0} هدف`],
          ] as const).map(([scope, label, count]) => <label key={scope} className="flex cursor-pointer items-start gap-3 rounded-lg border bg-background p-3 text-sm"><Checkbox checked={selectedScopes.includes(scope)} onCheckedChange={(checked) => setSelectedScopes(current => checked === true ? [...current, scope] : current.filter(item => item !== scope))} /><span><strong className="block">{label}</strong><small className="text-muted-foreground">{count}</small></span></label>)}
        </div>
        {selectedScopes.includes('customers') && !selectedScopes.includes('vouchers') && <p className="rounded-md bg-amber-50 p-3 text-xs text-amber-800">لن يُسمح بحذف العملاء إذا وُجدت سندات قبض مرتبطة؛ أضف خيار السندات أو احتفظ بسجلات العملاء.</p>}
        <Dialog open={selectiveClearDialogOpen} onOpenChange={setSelectiveClearDialogOpen}><DialogTrigger asChild><Button variant="destructive" disabled={selectedScopes.length === 0}><AlertTriangle className="ml-2 h-4 w-4" />حذف البيانات المحددة</Button></DialogTrigger><DialogContent dir="rtl"><DialogHeader><DialogTitle>تأكيد الحذف الانتقائي</DialogTitle></DialogHeader><div className="space-y-4 text-right"><p className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">ستُحذف فقط البيانات المحددة: {selectedScopes.includes('vouchers') ? 'السندات ' : ''}{selectedScopes.includes('customers') ? 'العملاء ' : ''}{selectedScopes.includes('targets') ? 'الأهداف' : ''}.</p>{isAdmin && <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-amber-300/70 bg-amber-50/70 p-3 text-sm dark:bg-amber-950/20"><Checkbox checked={backupBeforeDeletion} onCheckedChange={(checked) => setBackupBeforeDeletion(checked === true)} /><span><strong className="block text-amber-900 dark:text-amber-200">حفظ نسخة احتياطية قبل الحذف</strong><small className="text-amber-800 dark:text-amber-300">مفعّل افتراضياً. سيتم تنزيل نسخة كاملة وتسجيلها قبل حذف أي سجل.</small></span></label>}<div className="space-y-2"><Label>أعد إدخال كلمة مرور حسابك</Label><Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" /></div><div className="space-y-2"><Label>اكتب العبارة التالية للتأكيد: حذف البيانات المحددة</Label><Input value={confirmation} onChange={(event) => setConfirmation(event.target.value)} /></div><Button variant="destructive" className="w-full" disabled={!password || confirmation !== 'حذف البيانات المحددة' || clearSelectedMutation.isPending || preDeletionBackupMutation.isPending} onClick={() => void clearSelectedWithOptionalBackup()}>{preDeletionBackupMutation.isPending ? 'جارٍ حفظ النسخة...' : clearSelectedMutation.isPending ? 'جارٍ الحذف...' : 'تأكيد الحذف النهائي'}</Button></div></DialogContent></Dialog>
      </CardContent>
    </Card>

    {isAdmin && <Card className="border-destructive/35">
      <CardHeader><CardTitle className="flex items-center gap-2 text-destructive"><AlertTriangle className="h-5 w-5" />إعادة ضبط البيانات التشغيلية</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">تحذف هذه العملية السندات وفواتيرها والعملاء والفروع والأهداف والتقارير والمدفوعات والإشعارات وسجل قرارات السندات. تبقى حسابات المستخدمين وإعدادات النظام متاحة حتى لا تفقد إمكانية الدخول والإدارة.</p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{countItems.map(([label, count]) => <div key={label} className="rounded-md bg-destructive/5 p-3 text-center"><div className="text-lg font-bold text-destructive">{count}</div><div className="text-xs text-muted-foreground">{label}</div></div>)}</div>
        <Dialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}><DialogTrigger asChild><Button variant="destructive"><AlertTriangle className="ml-2 h-4 w-4" />حذف البيانات التشغيلية</Button></DialogTrigger><DialogContent dir="rtl"><DialogHeader><DialogTitle>تأكيد إعادة ضبط البيانات التشغيلية</DialogTitle></DialogHeader><div className="space-y-4 text-right"><p className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">هذه العملية لا يمكن التراجع عنها. لن تُحذف حسابات المستخدمين أو إعدادات النظام.</p><label className="flex cursor-pointer items-start gap-3 rounded-lg border border-amber-300/70 bg-amber-50/70 p-3 text-sm dark:bg-amber-950/20"><Checkbox checked={backupBeforeDeletion} onCheckedChange={(checked) => setBackupBeforeDeletion(checked === true)} /><span><strong className="block text-amber-900 dark:text-amber-200">حفظ نسخة احتياطية قبل الحذف</strong><small className="text-amber-800 dark:text-amber-300">مفعّل افتراضياً. سيتم تنزيل نسخة كاملة وتسجيلها قبل حذف أي بيانات تشغيلية.</small></span></label><div className="space-y-2"><Label>أعد إدخال كلمة مرور المدير</Label><Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" /></div><div className="space-y-2"><Label>اكتب العبارة التالية للتأكيد: حذف البيانات التشغيلية</Label><Input value={confirmation} onChange={(event) => setConfirmation(event.target.value)} /></div><Button variant="destructive" className="w-full" disabled={!password || confirmation !== 'حذف البيانات التشغيلية' || clearMutation.isPending || preDeletionBackupMutation.isPending} onClick={() => void clearOperationalWithOptionalBackup()}>{preDeletionBackupMutation.isPending ? 'جارٍ حفظ النسخة...' : clearMutation.isPending ? 'جارٍ الحذف...' : 'تأكيد الحذف النهائي'}</Button></div></DialogContent></Dialog>
      </CardContent>
    </Card>}
  </div>;
}
