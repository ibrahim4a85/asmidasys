import { describe, expect, it } from "vitest";
import {
  getApprovalRequestIdFromNotification,
  getNotificationTargetPath,
  getReceiptIdFromNotification,
  getReceiptDelegateName,
  getReceiptInvoiceSummary,
  getReceiptStatement,
  hasReceiptInvoices,
} from "../shared/receiptPresentation";

describe("بيانات عرض سند القبض", () => {
  const delegates = [
    { id: 11, fullName: "أحمد حسنين" },
    { id: 12, fullName: "خالد الهاجري" },
  ];

  it("يعرض اسم المندوب المرتبط بالعميل في خانة المستلم", () => {
    expect(getReceiptDelegateName({ delegateId: 11 }, delegates)).toBe("أحمد حسنين");
  });

  it("يستخدم قيمة بديلة واضحة عندما لا يرتبط العميل بمندوب", () => {
    expect(getReceiptDelegateName({ delegateId: null }, delegates)).toBe("غير محدد");
  });

  it("يحتفظ بتفاصيل الفواتير ومبالغها الصحيحة ضمن بيان السند", () => {
    const invoices = [
      { invoiceNumber: "INV-100", invoiceAmount: "175" },
      { invoiceNumber: "INV-101", invoiceAmount: "75" },
      { invoiceNumber: "", invoiceAmount: "0" },
    ];

    expect(hasReceiptInvoices(invoices)).toBe(true);
    expect(getReceiptInvoiceSummary(invoices)).toEqual([
      "ف INV-100 - ١٧٥ ريال",
      "ف INV-101 - ٧٥ ريال",
    ]);
  });

  it("يعرض قيمة وذلك مقابل كبيان عندما لا توجد فواتير مسددة", () => {
    expect(getReceiptStatement([], "سداد الرصيد")).toEqual(["سداد الرصيد"]);
    expect(getReceiptStatement([], undefined)).toEqual(["-"]);
  });

  it("يفتح سند القبض الصحيح عند الضغط على إشعار مرتبط بسند", () => {
    const notification = { receiptId: 42, relatedReceiptId: null };
    expect(getReceiptIdFromNotification(notification)).toBe(42);
    expect(getNotificationTargetPath(notification)).toBe("/receipts?receiptId=42");
  });

  it("يقبل الحقل المرجعي البديل ويتجنب توجيه الإشعارات غير المرتبطة", () => {
    expect(getReceiptIdFromNotification({ relatedReceiptId: "18" })).toBe(18);
    expect(getNotificationTargetPath({ relatedReceiptId: "18" })).toBe("/receipts?receiptId=18");
    expect(getNotificationTargetPath({ receiptId: 0 })).toBe("/notifications");
  });

  it("يفتح طلب التعميد المرتبط من الإشعار في شاشة التعميدات", () => {
    expect(getApprovalRequestIdFromNotification({ approvalRequestId: "24" })).toBe(24);
    expect(getNotificationTargetPath({ relatedApprovalRequestId: 24 })).toBe("/delegates?approvalRequestId=24");
  });
});
