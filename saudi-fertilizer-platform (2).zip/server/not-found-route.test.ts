import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const appSource = readFileSync(resolve(process.cwd(), 'client/src/App.tsx'), 'utf8');

describe('المسار الاحتياطي لصفحة عدم العثور', () => {
  it('يعرض صفحة عدم العثور بدلاً من إعادة توجيه المسار غير المعروف إلى شاشة الدخول', () => {
    expect(appSource).toContain('import NotFound from "./pages/NotFound";');
    expect(appSource).toContain('<Route component={NotFound} />');
    expect(appSource).not.toContain('<Route>{() => <Redirect to="/" />}</Route>');
  });
});
