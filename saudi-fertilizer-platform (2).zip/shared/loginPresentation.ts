type SettingsValues = Record<string, unknown> | null | undefined;

export function getLoginPresentationText(settings: SettingsValues, companyName?: string | null) {
  const copyright = String(settings?.copyright_text || settings?.login_copyright_text || '').trim();
  return {
    copyright: copyright || `جميع الحقوق محفوظة © ${new Date().getFullYear()} ${companyName || 'شركة الأسمدة المتحدة السعودية'}`,
  };
}
