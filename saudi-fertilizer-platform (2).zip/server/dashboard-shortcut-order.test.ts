import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { moveDashboardShortcut, orderDashboardShortcuts, parseDashboardShortcutIds } from '../shared/dashboardShortcutOrder';

describe('ترتيب اختصارات لوحة التحكم', () => {
  const defaultIds = ['receipts', 'approvals', 'performance', 'customers'];

  it('يحافظ على ترتيب المدير ويستبعد المعرفات غير الصالحة والمكررة', () => {
    expect(parseDashboardShortcutIds(['customers', 'receipts', 'customers', 'unknown'], defaultIds)).toEqual(['customers', 'receipts']);
    expect(parseDashboardShortcutIds('invalid-json-result', defaultIds)).toEqual(defaultIds);
  });

  it('ينقل الاختصار إلى موضع مستهدف دون تغيير العناصر الأخرى', () => {
    expect(moveDashboardShortcut(defaultIds, 'customers', 'receipts')).toEqual(['customers', 'receipts', 'approvals', 'performance']);
    expect(moveDashboardShortcut(defaultIds, 'receipts', 'receipts')).toEqual(defaultIds);
  });

  it('يعرض الاختصارات بالتسلسل المحفوظ بدلاً من التسلسل الثابت', () => {
    const items = defaultIds.map(id => ({ id }));
    expect(orderDashboardShortcuts(items, ['customers', 'performance', 'receipts'])).toEqual([
      { id: 'customers' },
      { id: 'performance' },
      { id: 'receipts' },
    ]);
  });

  it('يربط مستهلك لوحة التحكم بدالة ترتيب القيمة المحفوظة', () => {
    const dashboard = readFileSync(new URL('../client/src/pages/Dashboard.tsx', import.meta.url), 'utf8');
    const settings = readFileSync(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url), 'utf8');
    expect(dashboard).toContain('orderDashboardShortcuts(shortcutDefinitions, selectedShortcutIds)');
    expect(settings).toContain('moveDashboardShortcut(current, sourceId, targetId)');
  });
});
