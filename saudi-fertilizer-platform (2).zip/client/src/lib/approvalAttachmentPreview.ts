export function isPdfApprovalAttachment(fileName?: string | null, url?: string | null) {
  return /\.pdf($|\?)/i.test(fileName || '') || /\.pdf($|\?)/i.test(url || '');
}
