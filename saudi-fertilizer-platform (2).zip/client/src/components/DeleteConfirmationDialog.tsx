import { AlertTriangle, Trash2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { getDeleteConfirmationContent } from '@/lib/deleteConfirmation';

interface DeleteConfirmationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  itemName: string;
  details?: string[];
  onConfirm: () => void;
  isPending?: boolean;
  confirmLabel?: string;
}

export function DeleteConfirmationDialog({
  open,
  onOpenChange,
  title = 'تأكيد الحذف',
  itemName,
  details = [],
  onConfirm,
  isPending = false,
  confirmLabel = 'حذف نهائياً',
}: DeleteConfirmationDialogProps) {
  const confirmation = getDeleteConfirmationContent({ itemName, details });

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent dir="rtl" className="max-w-md text-right">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-destructive">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-destructive/10"><AlertTriangle className="h-5 w-5" /></span>
            {title}
          </AlertDialogTitle>
          <AlertDialogDescription className="pt-2 text-right leading-6">
            {confirmation.prefix}<strong className="text-foreground">{confirmation.itemName}</strong>{confirmation.suffix}
          </AlertDialogDescription>
          <p className="rounded-md bg-muted px-3 py-2 text-xs font-medium text-muted-foreground">{confirmation.scopeLabel}</p>
        </AlertDialogHeader>
        {confirmation.hasDetails && (
          <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3 text-sm">
            <p className="mb-2 font-semibold text-foreground">تفاصيل العنصر</p>
            <ul className="space-y-1 text-muted-foreground">
              {confirmation.details.map((detail, index) => <li key={`${detail}-${index}`}>• {detail}</li>)}
            </ul>
          </div>
        )}
        <AlertDialogFooter className="gap-2 sm:flex-row-reverse sm:justify-start">
          <AlertDialogAction
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            disabled={isPending}
            onClick={onConfirm}
          >
            <Trash2 className="ml-1 h-4 w-4" />{isPending ? 'جارٍ الحذف...' : confirmLabel}
          </AlertDialogAction>
          <AlertDialogCancel disabled={isPending}>إلغاء والاحتفاظ بالبيانات</AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
