export function toSafeSystemUser<T extends { password?: unknown }>(user: T): Omit<T, 'password'> {
  const { password: _password, ...safeUser } = user;
  return safeUser;
}
