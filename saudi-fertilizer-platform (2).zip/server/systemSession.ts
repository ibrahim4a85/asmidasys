import { jwtVerify, SignJWT } from "jose";
import { ENV } from "./_core/env";

export const SYSTEM_SESSION_COOKIE = "sfs_system_session";

export type SystemSessionUser = {
  id: number;
  username: string;
  fullName: string;
  userType: string;
  userLevel: "primary" | "secondary";
  branchId: number | null;
  permissions: unknown;
};

function signingKey() {
  if (!ENV.cookieSecret) throw new Error("JWT_SECRET is required for system sessions");
  return new TextEncoder().encode(ENV.cookieSecret);
}

export async function createSystemSession(user: SystemSessionUser) {
  return new SignJWT({
    username: user.username,
    fullName: user.fullName,
    userType: user.userType,
    userLevel: user.userLevel,
    branchId: user.branchId,
    permissions: user.permissions,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(user.id))
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(signingKey());
}

export async function verifySystemSession(token: string): Promise<SystemSessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, signingKey());
    const id = Number(payload.sub);
    const { username, fullName, userType, userLevel, branchId, permissions } = payload;

    if (!Number.isInteger(id) || typeof username !== "string" || typeof fullName !== "string") return null;
    if (typeof userType !== "string" || !/^[a-z][a-z0-9_]{2,63}$/.test(userType)) return null;
    if (!["primary", "secondary"].includes(String(userLevel))) return null;

    return {
      id,
      username,
      fullName,
      userType: userType as SystemSessionUser["userType"],
      userLevel: userLevel as SystemSessionUser["userLevel"],
      branchId: typeof branchId === "number" ? branchId : null,
      permissions: permissions ?? {},
    };
  } catch {
    return null;
  }
}
