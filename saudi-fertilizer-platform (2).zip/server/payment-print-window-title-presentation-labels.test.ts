import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const paymentsPageSource = readFileSync(
  resolve(process.cwd(), 'client/src/pages/PaymentsPage.tsx'),
  'utf8',
);

describe('payment print-window presentation label', () => {
  it('uses the default title and accepts an administrator override', () => {
    expect(getSystemLabel(undefined, 'payment_print_window_title')).toBe('سند صرف');
    expect(
      getSystemLabel(
        {
          system_label_overrides: JSON.stringify({
            payment_print_window_title: 'وثيقة صرف',
          }),
        },
        'payment_print_window_title',
      ),
    ).toBe('وثيقة صرف');
  });

  it('customizes only the title prefix while preserving the serial and print flow', () => {
    const handlerStart = paymentsPageSource.indexOf('const handlePrint');
    const handlerEnd = paymentsPageSource.indexOf('\n\n  return (', handlerStart);
    const handlerSource = paymentsPageSource.slice(handlerStart, handlerEnd);

    expect(handlerSource).toContain("labelFor('payment_print_window_title', 'سند صرف')");
    expect(handlerSource).toContain('${payment.serialNumber}');
    expect(handlerSource).toContain("window.open('', '_blank')");
    expect(handlerSource).toContain('printWindow.document.write(');
    expect(handlerSource).toContain('printWindow.document.close()');
    expect(handlerSource).toContain('printWindow.print()');
  });
});
