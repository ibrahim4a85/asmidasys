export type DeleteConfirmationContent = {
  itemName: string;
  details?: string[];
  scope?: string;
};

export function getDeleteConfirmationContent({ itemName, details = [], scope = 'عنصر واحد' }: DeleteConfirmationContent) {
  return {
    prefix: 'أنت على وشك حذف ',
    suffix: '. لا يمكن التراجع عن هذه العملية بعد تأكيدها.',
    itemName,
    scopeLabel: `نطاق الحذف: ${scope}`,
    hasDetails: details.length > 0,
    details,
  };
}
