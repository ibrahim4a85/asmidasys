CREATE TABLE `administrative_goal_action_attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actionId` int NOT NULL,
	`attachmentUrl` text NOT NULL,
	`attachmentName` varchar(255) NOT NULL,
	`attachmentMimeType` varchar(100) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`createdBy` int NOT NULL,
	CONSTRAINT `administrative_goal_action_attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `administrative_goal_actions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`goalId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`status` enum('planned','in_progress','completed','closed') NOT NULL DEFAULT 'planned',
	`plannedStartDate` date,
	`plannedEndDate` date,
	`proposedAssigneeUserId` int,
	`assigneeUserId` int,
	`completionPercent` decimal(5,2) NOT NULL DEFAULT '0',
	`closedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `administrative_goal_actions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `administrative_goal_reviewers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`goalId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`createdBy` int NOT NULL,
	CONSTRAINT `administrative_goal_reviewers_id` PRIMARY KEY(`id`),
	CONSTRAINT `administrative_goal_reviewer_unique` UNIQUE(`goalId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `administrative_goals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`goalTypeId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`status` enum('planned','in_progress','completed','closed') NOT NULL DEFAULT 'planned',
	`startDate` date,
	`expectedEndDate` date,
	`expectedDurationMonths` int,
	`completionPercent` decimal(5,2) NOT NULL DEFAULT '0',
	`closedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `administrative_goals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `commission_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`salesGoalPlanId` int NOT NULL,
	`salesGoalMetricId` int,
	`name` varchar(255) NOT NULL,
	`baseCommissionRate` decimal(7,4) NOT NULL,
	`minimumPayoutAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `commission_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `commission_tiers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`commissionPlanId` int NOT NULL,
	`minAchievementPercent` decimal(7,2) NOT NULL,
	`maxAchievementPercent` decimal(7,2),
	`payoutMultiplier` decimal(7,4) NOT NULL DEFAULT '1',
	`additionalCommissionRate` decimal(7,4) NOT NULL DEFAULT '0',
	`fixedBonusAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`isEligible` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `commission_tiers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `goal_types` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('administrative','sales') NOT NULL,
	`description` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `goal_types_id` PRIMARY KEY(`id`),
	CONSTRAINT `goal_type_category_name_unique` UNIQUE(`category`,`name`)
);
--> statement-breakpoint
CREATE TABLE `sales_goal_metrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`salesGoalPlanId` int NOT NULL,
	`metricType` enum('sales','collections','new_customers','custom') NOT NULL,
	`name` varchar(255) NOT NULL,
	`targetValue` decimal(15,2) NOT NULL,
	`currentValue` decimal(15,2) NOT NULL DEFAULT '0',
	`dataSource` enum('manual','performance_reports','approved_receipts') NOT NULL DEFAULT 'manual',
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `sales_goal_metrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales_goal_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`goalTypeId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`periodId` int NOT NULL,
	`scopeType` enum('company','branch','user') NOT NULL DEFAULT 'branch',
	`branchId` int,
	`userId` int,
	`status` enum('draft','active','closed') NOT NULL DEFAULT 'draft',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `sales_goal_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `administrative_goal_attachment_action_idx` ON `administrative_goal_action_attachments` (`actionId`);--> statement-breakpoint
CREATE INDEX `administrative_goal_action_goal_idx` ON `administrative_goal_actions` (`goalId`);--> statement-breakpoint
CREATE INDEX `administrative_goal_action_assignee_idx` ON `administrative_goal_actions` (`assigneeUserId`);--> statement-breakpoint
CREATE INDEX `administrative_goal_reviewer_user_idx` ON `administrative_goal_reviewers` (`userId`);--> statement-breakpoint
CREATE INDEX `administrative_goals_type_idx` ON `administrative_goals` (`goalTypeId`);--> statement-breakpoint
CREATE INDEX `administrative_goals_status_idx` ON `administrative_goals` (`status`);--> statement-breakpoint
CREATE INDEX `commission_plan_sales_goal_idx` ON `commission_plans` (`salesGoalPlanId`);--> statement-breakpoint
CREATE INDEX `commission_plan_metric_idx` ON `commission_plans` (`salesGoalMetricId`);--> statement-breakpoint
CREATE INDEX `commission_tier_plan_idx` ON `commission_tiers` (`commissionPlanId`);--> statement-breakpoint
CREATE INDEX `sales_goal_metric_plan_idx` ON `sales_goal_metrics` (`salesGoalPlanId`);--> statement-breakpoint
CREATE INDEX `sales_goal_plan_period_idx` ON `sales_goal_plans` (`periodId`);--> statement-breakpoint
CREATE INDEX `sales_goal_plan_branch_idx` ON `sales_goal_plans` (`branchId`);--> statement-breakpoint
CREATE INDEX `sales_goal_plan_user_idx` ON `sales_goal_plans` (`userId`);