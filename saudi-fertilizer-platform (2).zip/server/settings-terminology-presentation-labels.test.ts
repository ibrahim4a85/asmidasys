import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { systemLabelOptions } from '../shared/systemLabelPresentation';

const settingsPagePath = fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url));

describe('تسميات محرر المصطلحات', () => {
  it('يوفر القاموس القيم الافتراضية لعناوين ومؤشرات محرر التسميات', () => {
    const labels = new Map(systemLabelOptions.map(option => [option.id, option.label]));

    expect(labels.get('settings_terminology_title')).toBe('إدارة تسميات النظام');
    expect(labels.get('settings_terminology_changed')).toBe('تم التعديل');
    expect(labels.get('settings_terminology_restore_defaults')).toBe('استعادة التسميات الافتراضية');
  });

  it('يربط العرض فقط بالقاموس ويبقي إشعارات الحفظ ومسار الطفرة كما هما', () => {
    const source = readFileSync(settingsPagePath, 'utf8');

    expect(source).toContain('function SystemTerminologySettings() {\n  const { labelFor } = useSystemLabels();');
    for (const id of [
      'settings_terminology_title',
      'settings_terminology_description',
      'settings_terminology_changed',
      'settings_terminology_current_value',
      'settings_terminology_current_label',
      'settings_terminology_edit_field',
      'settings_terminology_saving',
      'settings_terminology_save',
      'settings_terminology_restore_defaults',
    ]) {
      expect(source).toContain(`labelFor('${id}'`);
    }
    expect(source).toContain("updateMutation.mutateAsync({ entries: [{ key: 'system_label_overrides'");
    expect(source).toContain("toast.success('تم حفظ تسميات القوائم ولوحة المعلومات')");
    expect(source).toContain("toast.error(error?.message || 'تعذر حفظ التسميات')");
  });
});

