import { describe, expect, it } from "vitest";
import { buildAnnualVoucherSerial, CONFIGURED_BRANCH_ORDER, getConfiguredBranchNumber, sortBranchesByConfiguredOrder } from "@shared/branchOrdering";

describe("ترتيب الفروع المعتمد", () => {
  it("يعيد الفروع وفق الترتيب التشغيلي المحدد بغض النظر عن ترتيب وصولها", () => {
    const unordered = [
      { id: 1, name: "الجوف" },
      { id: 2, name: "جدة" },
      { id: 3, name: "الرياض" },
      { id: 4, name: "الدمام" },
      { id: 5, name: "بريدة" },
      { id: 6, name: "وادي الدواسر" },
    ];

    expect(sortBranchesByConfiguredOrder(unordered).map((branch) => branch.name)).toEqual([
      "الرياض",
      "بريدة",
      "جدة",
      "وادي الدواسر",
      "الدمام",
      "الجوف",
    ]);
  });

  it("يتعامل مع بادئة فرع ويضع الأسماء غير المعرفة بعد الفروع المعتمدة", () => {
    const ordered = sortBranchesByConfiguredOrder([
      { id: 1, name: "فرع الرياض" },
      { id: 2, name: "فرع مستقبلي" },
      { id: 3, name: "حائل" },
    ]);

    expect(ordered.map((branch) => branch.name)).toEqual(["فرع الرياض", "حائل", "فرع مستقبلي"]);
    expect(CONFIGURED_BRANCH_ORDER).toHaveLength(10);
  });

  it("يعامل تسمية القصيم المستوردة كفرع بريدة عند تطبيق الترتيب", () => {
    const ordered = sortBranchesByConfiguredOrder([
      { id: 1, name: "الخرج" },
      { id: 2, name: "القصيم" },
      { id: 3, name: "الرياض" },
    ]);

    expect(ordered.map((branch) => branch.name)).toEqual(["الرياض", "القصيم", "الخرج"]);
  });

  it("يبني أرقام سندات القبض سنوياً برقم الفرع التشغيلي والعداد المصفّر", () => {
    const date = new Date("2026-06-01T12:00:00+03:00");
    expect(getConfiguredBranchNumber("الخرج")).toBe(3);
    expect(buildAnnualVoucherSerial({ branchName: "الخرج", sequence: 1, kind: "receipt", date })).toBe("3-26-001");
    expect(buildAnnualVoucherSerial({ branchName: "القصيم", sequence: 14, kind: "receipt", date })).toBe("2-26-014");
  });

  it("يضيف PY إلى أرقام سندات الصرف مع بقاء العدّاد مستقلاً", () => {
    const date = new Date("2026-06-01T12:00:00+03:00");
    expect(buildAnnualVoucherSerial({ branchName: "الخرج", sequence: 1, kind: "payment", date })).toBe("PY-3-26-001");
  });
});
