ALTER TABLE `input_lists` ADD `parentId` int;--> statement-breakpoint
ALTER TABLE `input_lists` ADD `requiresAttachment` boolean DEFAULT true NOT NULL;