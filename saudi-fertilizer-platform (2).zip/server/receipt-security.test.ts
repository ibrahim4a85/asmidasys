import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getCustomers: vi.fn(),
  getCustomerByNumber: vi.fn(),
  getCustomerById: vi.fn(),
  getReceipts: vi.fn(),
  getReceiptById: vi.fn(),
  createReceiptWithInvoices: vi.fn(),
  updateReceipt: vi.fn(),
  updateReceiptWithInvoices: vi.fn(),
  decideReceiptWithAudit: vi.fn(),
  approveReceiptsWithAudit: vi.fn(),
  getReceiptDecisionAudit: vi.fn(),
  createReceiptIssuedNotifications: vi.fn(),
  getInputListById: vi.fn(),
  getSettings: vi.fn(),
}));

import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function delegateContext(overrides: Partial<NonNullable<TrpcContext["systemUser"]>> = {}): TrpcContext {
  return {
    user: null,
    systemUser: {
      id: 42,
      username: "delegate-42",
      fullName: "مندوب الاختبار",
      userType: "delegate",
      userLevel: "secondary",
      branchId: 5,
      permissions: {},
      ...overrides,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

describe("صلاحيات سندات القبض للمندوب", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(db.getInputListById).mockResolvedValue({ id: 1, listType: 'payment_method', isActive: true, requiresAttachment: true } as never);
    vi.mocked(db.getSettings).mockResolvedValue({} as never);
  });

  it("يقيد بحث العملاء على العملاء المرتبطين بالمندوب الحالي", async () => {
    vi.mocked(db.getCustomers).mockResolvedValue([]);
    await appRouter.createCaller(delegateContext()).customers.list({ search: "1001" });
    expect(db.getCustomers).toHaveBeenCalledWith({ search: "1001", delegateId: 42 });
  });

  it("لا يعيد البحث المباشر عميلاً مرتبطاً بمندوب آخر", async () => {
    vi.mocked(db.getCustomerByNumber).mockResolvedValue({ id: 9, delegateId: 77 } as never);
    await expect(appRouter.createCaller(delegateContext()).customers.getByNumber({ customerNumber: "1001" })).resolves.toBeNull();
  });

  it("يرفض إصدار سند لعميل غير مرتبط بالمندوب", async () => {
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 77 } as never);
    const caller = appRouter.createCaller(delegateContext());
    await expect(caller.receipts.create({
      branchId: 9,
      customerId: 9,
      amount: "250",
      paymentMethodId: 1,
      paymentForId: 1,
      attachmentUrl: "https://files.example/receipt.png",
      status: "approved",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("يحفظ فواتير السند مع الرأس ويثبت فرع وهوية المندوب من الجلسة", async () => {
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    vi.mocked(db.createReceiptWithInvoices).mockResolvedValue({ id: 51, serialNumber: "R-000051" } as never);

    await appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 9,
      customerId: 9,
      amount: "250",
      paymentMethodId: 1,
      paymentForId: 1,
      attachmentUrl: "https://files.example/receipt.png",
      status: "approved",
      invoices: [
        { invoiceNumber: "INV-100", invoiceAmount: "175" },
        { invoiceNumber: "INV-101", invoiceAmount: "75" },
      ],
    });

    expect(db.createReceiptWithInvoices).toHaveBeenCalledWith(expect.objectContaining({
      branchId: 5,
      userId: 42,
      customerId: 9,
      status: "issued",
      createdBy: 42,
      updatedBy: 42,
    }), [
      { invoiceNumber: "INV-100", invoiceAmount: "175" },
      { invoiceNumber: "INV-101", invoiceAmount: "75" },
    ]);
    expect(db.createReceiptIssuedNotifications).toHaveBeenCalledWith({
      receiptId: 51,
      serialNumber: "R-000051",
      issuerName: "مندوب الاختبار",
    });
  });

  it("يحفظ الحقول المخصصة المهيأة في السند دون خلطها بالبيانات المالية", async () => {
    vi.mocked(db.getSettings).mockResolvedValue({ receipt_form_custom_fields: JSON.stringify([{ id: 'reference', label: 'مرجع داخلي', type: 'text', required: true }]) } as never);
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    vi.mocked(db.createReceiptWithInvoices).mockResolvedValue({ id: 54, serialNumber: '1-26-004' } as never);

    await appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5, customerId: 9, amount: '250', paymentMethodId: 1, paymentForId: 1,
      attachmentUrl: 'https://files.example/receipt.png', status: 'issued', customFields: { reference: ' داخلي-17 ' },
    });

    expect(db.createReceiptWithInvoices).toHaveBeenCalledWith(expect.objectContaining({ customFields: JSON.stringify({ reference: 'داخلي-17' }) }), []);
  });

  it("يرفض حقلاً مخصصاً غير مهيأ من العميل", async () => {
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    await expect(appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5, customerId: 9, amount: '250', paymentMethodId: 1, paymentForId: 1,
      attachmentUrl: 'https://files.example/receipt.png', status: 'issued', customFields: { unconfigured: 'قيمة' },
    })).rejects.toMatchObject({ code: 'BAD_REQUEST', message: 'إحدى قيم الحقول المخصصة غير صالحة' });
  });

  it("يلزم الإيصال لطرق الدفع التي تتطلبه قبل إصدار السند", async () => {
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);

    await expect(appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5,
      customerId: 9,
      amount: '250',
      paymentMethodId: 1,
      paymentForId: 1,
      status: 'issued',
    })).rejects.toMatchObject({ code: 'BAD_REQUEST', message: 'إيصال التحويل مطلوب قبل اعتماد سند القبض' });
  });

  it("يستثني طريقة الدفع النقدية المهيأة صراحةً من إلزام الإيصال", async () => {
    vi.mocked(db.getInputListById).mockResolvedValue({ id: 5, listType: 'payment_method', isActive: true, requiresAttachment: false } as never);
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    vi.mocked(db.createReceiptWithInvoices).mockResolvedValue({ id: 53, serialNumber: '1-26-003' } as never);

    await expect(appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5,
      customerId: 9,
      amount: '250',
      paymentMethodId: 5,
      paymentForId: 1,
      status: 'issued',
    })).resolves.toMatchObject({ id: 53 });
    expect(db.createReceiptWithInvoices).toHaveBeenCalledWith(expect.objectContaining({ paymentMethodId: 5, status: 'issued' }), []);
  });

  it("يستثني سجل نقد قديم بالاسم من إلزام الإيصال دون تعديل إعدادات قاعدة البيانات", async () => {
    vi.mocked(db.getInputListById).mockResolvedValue({ id: 5, listType: 'payment_method', isActive: true, name: 'نقداً', requiresAttachment: true } as never);
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    vi.mocked(db.createReceiptWithInvoices).mockResolvedValue({ id: 55, serialNumber: '1-26-005' } as never);

    await expect(appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5,
      customerId: 9,
      amount: '250',
      paymentMethodId: 5,
      paymentForId: 1,
      status: 'issued',
    })).resolves.toMatchObject({ id: 55 });
    expect(db.createReceiptWithInvoices).toHaveBeenCalledWith(expect.objectContaining({ paymentMethodId: 5, status: 'issued' }), []);
  });

  it("لا يسمح للمندوب بإبقاء سند صادر بحالة معتمد مباشرة", async () => {
    vi.mocked(db.getCustomerById).mockResolvedValue({ id: 9, delegateId: 42 } as never);
    vi.mocked(db.createReceiptWithInvoices).mockResolvedValue({ id: 52 } as never);

    await appRouter.createCaller(delegateContext()).receipts.create({
      branchId: 5,
      customerId: 9,
      amount: "250",
      paymentMethodId: 1,
      paymentForId: 1,
      attachmentUrl: "https://files.example/receipt.png",
      status: "approved",
    });

    expect(db.createReceiptWithInvoices).toHaveBeenCalledWith(expect.objectContaining({ status: "issued" }), []);
  });

  it("يسمح لصاحب صلاحية الاعتماد باعتماد سند تم إصداره", async () => {
    vi.mocked(db.getReceiptById).mockResolvedValue({ id: 51, status: "issued" } as never);
    vi.mocked(db.decideReceiptWithAudit).mockResolvedValue({ nextStatus: "approved" } as never);
    const approver = delegateContext({ permissions: { receiptsApprove: true } });

    await appRouter.createCaller(approver).receipts.decide({ id: 51, decision: "approved", note: "تمت المراجعة" });

    expect(db.decideReceiptWithAudit).toHaveBeenCalledWith({
      receiptId: 51,
      decision: "approved",
      decidedBy: 42,
      note: "تمت المراجعة",
    });
  });

  it("يرفض قرار الاعتماد ممن لا يملك الصلاحية", async () => {
    await expect(appRouter.createCaller(delegateContext()).receipts.decide({ id: 51, decision: "rejected", note: "بيانات الإيصال غير مكتملة" }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("يلزم سبباً واضحاً عند رفض سند القبض قبل الوصول إلى طبقة البيانات", async () => {
    const approver = delegateContext({ permissions: { receiptsApprove: true } });

    await expect(appRouter.createCaller(approver).receipts.decide({ id: 51, decision: "rejected" }))
      .rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(db.decideReceiptWithAudit).not.toHaveBeenCalled();
  });

  it("يسمح لصاحب الصلاحية باعتماد السندات المحددة دفعة واحدة", async () => {
    vi.mocked(db.approveReceiptsWithAudit).mockResolvedValue({ count: 2, receiptIds: [51, 52] } as never);
    const approver = delegateContext({ permissions: { receiptsApprove: true } });

    await expect(appRouter.createCaller(approver).receipts.approveBatch({ ids: [51, 52], note: "مراجعة دفعة نهاية اليوم" }))
      .resolves.toMatchObject({ count: 2 });

    expect(db.approveReceiptsWithAudit).toHaveBeenCalledWith({
      receiptIds: [51, 52],
      decidedBy: 42,
      note: "مراجعة دفعة نهاية اليوم",
    });
  });

  it("يرفض الاعتماد الجماعي عند تكرار السند أو غياب صلاحية الاعتماد", async () => {
    const approver = delegateContext({ permissions: { receiptsApprove: true } });
    await expect(appRouter.createCaller(approver).receipts.approveBatch({ ids: [51, 51] }))
      .rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(appRouter.createCaller(delegateContext()).receipts.approveBatch({ ids: [51] }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("يقيد سجل السندات على ما أصدره المندوب فقط", async () => {
    vi.mocked(db.getReceipts).mockResolvedValue([]);
    await appRouter.createCaller(delegateContext()).receipts.list({ branchId: 5 });
    expect(db.getReceipts).toHaveBeenCalledWith({ branchId: 5, userId: 42 });
  });

  it("يمرر الفلاتر المتقدمة لسجل السندات إلى الاستعلام", async () => {
    vi.mocked(db.getReceipts).mockResolvedValue([]);
    const primaryUser = delegateContext({ userLevel: "primary" });
    const input = {
      periodId: 2,
      branchId: 5,
      userId: 42,
      customerId: 9,
      status: "issued" as const,
      paymentMethodId: 3,
      serialNumber: "R-000051",
      startDate: new Date("2026-08-01T00:00:00.000Z"),
      endDate: new Date("2026-08-18T23:59:59.999Z"),
    };

    await appRouter.createCaller(primaryUser).receipts.list(input);

    expect(db.getReceipts).toHaveBeenCalledWith(input);
  });

  it("يعرض سجل القرارات لصاحب صلاحية الاعتماد فقط", async () => {
    vi.mocked(db.getReceiptDecisionAudit).mockResolvedValue([]);
    const approver = delegateContext({ permissions: { receiptsApprove: true } });

    await appRouter.createCaller(approver).receiptAudit.list({ receiptId: 51 });

    expect(db.getReceiptDecisionAudit).toHaveBeenCalledWith(51);
  });

  it("يرفض الاطلاع على سجل القرارات ممن لا يملك صلاحية الاعتماد", async () => {
    await expect(appRouter.createCaller(delegateContext()).receiptAudit.list({ receiptId: 51 }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
