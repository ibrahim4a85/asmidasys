import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, systemAdminProcedure, systemUserProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { createHmac, randomInt } from "node:crypto";
import { z } from "zod";
import * as db from "./db";
import { sendPasswordRecoveryCode } from "./passwordRecoveryMailer";
import { createSystemSession, SYSTEM_SESSION_COOKIE } from "./systemSession";
import { storageGetSignedUrl, storagePut } from "./storage";
import { collectManagedStorageUrls, getManagedStorageKey, relinkManagedStorageUrls, SYSTEM_BACKUP_FORMAT, SYSTEM_BACKUP_VERSION, type SystemBackupFile, createSystemBackupFileName, getSystemBackupRecordCount } from "@shared/systemBackup";
import { normalizeBoardPosition } from "../shared/boardPositions";
import { applySecondaryUserApprovalRequestDefault } from "../shared/systemUserDefaults";
import { getApprovalTemplateOutputName, stampApprovalDecisionFooter, stampApprovalTemplate } from "./approvalTemplates";
import { getReceiptFormPresentation } from "../shared/receiptFormPresentation";
import { readSystemUserTypeDefinitions, SYSTEM_USER_TYPE_SETTINGS_KEY, validateSystemUserTypeDefinitions } from "../shared/systemUserTypes";
import { APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY, APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY, validateApprovalParticipantCatalogValue } from "../shared/approvalParticipantCatalogs";

const systemUserTypeInput = z.string().trim().regex(/^[a-z][a-z0-9_]{2,63}$/);
const PASSWORD_RECOVERY_EMAIL_KEY = "password_recovery_email";
const recoveryEmailInput = z.string().trim().email("أدخل بريداً إلكترونياً صالحاً").max(320);

function hashPasswordRecoveryCode(code: string) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("مفتاح حماية جلسات النظام غير متاح");
  return createHmac("sha256", secret).update(`password-recovery:${code}`).digest("hex");
}

async function assertConfiguredSystemUserType(userType: string) {
  const settings = await db.getSettings();
  const definition = readSystemUserTypeDefinitions(settings[SYSTEM_USER_TYPE_SETTINGS_KEY]).find(candidate => candidate.code === userType);
  if (!definition || !definition.isActive) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "نوع المستخدم غير معتمد أو غير نشط" });
  }
  return definition;
}

async function validateSystemUserTypeSetting(key: string, value: string) {
  if (key === PASSWORD_RECOVERY_EMAIL_KEY) return value.trim() ? recoveryEmailInput.parse(value) : "";
  if (key === SYSTEM_USER_TYPE_SETTINGS_KEY) return JSON.stringify(validateSystemUserTypeDefinitions(JSON.parse(value)));
  if (key === APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY || key === APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY) {
    const normalizedValue = validateApprovalParticipantCatalogValue(value);
    await db.assertActiveSystemUserIds(JSON.parse(normalizedValue));
    return normalizedValue;
  }
  return value;
}

function getApprovalAttachmentMimeType(fileName: string) {
  const normalized = fileName.toLowerCase();
  if (normalized.endsWith(".pdf")) return "application/pdf";
  if (normalized.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  return null;
}

function isPerformanceManager(systemUser: { userType: string; userLevel: string }) {
  return systemUser.userType === "admin" || systemUser.userLevel === "primary";
}

function isSecondarySystemUser(systemUser: { userLevel: string }) {
  return systemUser.userLevel === "secondary";
}

function canEditPastPerformanceReports(permissions: unknown) {
  if (Array.isArray(permissions)) return permissions.includes("performanceReportsEditHistorical");
  if (permissions && typeof permissions === "object") {
    return Boolean((permissions as Record<string, unknown>).performanceReportsEditHistorical);
  }
  return false;
}

function canApproveReceipts(systemUser: { userType: string; userLevel: string; permissions?: unknown }) {
  if (systemUser.userType === "admin" || systemUser.userLevel === "primary") return true;
  if (Array.isArray(systemUser.permissions)) return systemUser.permissions.includes("receiptsApprove");
  if (systemUser.permissions && typeof systemUser.permissions === "object") {
    return Boolean((systemUser.permissions as Record<string, unknown>).receiptsApprove);
  }
  return false;
}

function isCashPaymentMethod(paymentMethod: { name?: unknown; requiresAttachment?: boolean } | null | undefined) {
  if (!paymentMethod) return false;
  if (paymentMethod.requiresAttachment === false) return true;
  const normalizedName = String(paymentMethod.name || '').trim().replace(/[ً-ْ]/g, '');
  return normalizedName === 'نقدا';
}

async function serializeReceiptCustomFields(values: Record<string, string> | undefined) {
  const settings = await db.getSettings();
  const configuredFields = getReceiptFormPresentation(settings).customFields;
  if (configuredFields.length === 0) {
    if (values && Object.keys(values).length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "إحدى قيم الحقول المخصصة غير صالحة" });
    return undefined;
  }
  const submittedValues = values || {};
  const configuredIds = new Set(configuredFields.map(field => field.id));
  const result: Record<string, string> = {};
  for (const [id, value] of Object.entries(submittedValues)) {
    if (!configuredIds.has(id) || typeof value !== "string" || value.trim().length > 500) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "إحدى قيم الحقول المخصصة غير صالحة" });
    }
    result[id] = value.trim();
  }
  const missingRequired = configuredFields.find(field => field.required && !result[field.id]);
  if (missingRequired) throw new TRPCError({ code: "BAD_REQUEST", message: `حقل «${missingRequired.label}» مطلوب` });
  return JSON.stringify(result);
}

function hasSystemPermission(permissions: unknown, permission: "customersManage" | "targetsManage" | "dataDelete" | "approvalRequest" | "approvalDelegate") {
  if (Array.isArray(permissions)) return permissions.includes(permission);
  if (permissions && typeof permissions === "object") return Boolean((permissions as Record<string, unknown>)[permission]);
  return false;
}

function hasPartnerRightsSidebarOverride(permissions: unknown) {
  return Boolean(
    permissions
    && !Array.isArray(permissions)
    && Object.prototype.hasOwnProperty.call(permissions as Record<string, unknown>, "sidebar_partner-rights"),
  );
}

type PartnerRightsPermission = "partnerRightsView" | "partnerRightsCreateEntries" | "partnerRightsEditEntries" | "partnerRightsManage";

function hasPartnerRightsPermission(permissions: unknown, permission: PartnerRightsPermission) {
  if (Array.isArray(permissions)) return permissions.includes(permission);
  return Boolean((permissions as Record<string, unknown> | undefined)?.[permission]);
}

function getPartnerRightsCapabilities(systemUser: { userType: string; permissions?: unknown }) {
  if (systemUser.userType === "admin") return { canView: true, canCreateEntries: true, canEditEntries: true, canManage: true };
  const permissions = systemUser.permissions;
  const explicitlyHiddenInSidebar = hasPartnerRightsSidebarOverride(permissions)
    && !Boolean((permissions as Record<string, unknown>)["sidebar_partner-rights"]);
  if (explicitlyHiddenInSidebar) return { canView: false, canCreateEntries: false, canEditEntries: false, canManage: false };
  const canCreateEntries = hasPartnerRightsPermission(permissions, "partnerRightsCreateEntries");
  const canEditEntries = hasPartnerRightsPermission(permissions, "partnerRightsEditEntries");
  const canManage = hasPartnerRightsPermission(permissions, "partnerRightsManage");
  return {
    canView: systemUser.userType === "authorized_partner" || hasPartnerRightsPermission(permissions, "partnerRightsView") || canCreateEntries || canEditEntries || canManage,
    canCreateEntries,
    canEditEntries,
    canManage,
  };
}

function canViewPartnerRights(systemUser: { userType: string; permissions?: unknown }) {
  return getPartnerRightsCapabilities(systemUser).canView;
}

function requirePartnerRightsView(systemUser: { userType: string; permissions?: unknown }) {
  if (!canViewPartnerRights(systemUser)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية الاطلاع على حقوق الشركاء" });
  }
}

function requirePartnerRightsCapability(systemUser: { userType: string; permissions?: unknown }, capability: "canCreateEntries" | "canEditEntries" | "canManage", message: string) {
  if (!getPartnerRightsCapabilities(systemUser)[capability]) throw new TRPCError({ code: "FORBIDDEN", message });
}

const managedStorageUrl = z.string().max(1024).regex(/^\/manus-storage\//, "مرجع المرفق غير صالح");
const optionalManagedStorageUrl = managedStorageUrl.nullable().optional();
const optionalAttachmentName = z.string().trim().min(1).max(255).nullable().optional();
const optionalAttachmentMimeType = z.string().trim().min(1).max(100).nullable().optional();
const moneyInput = z.coerce.number().finite().positive().max(9999999999999.99);
const shareInput = z.coerce.number().finite().min(0).max(100);
const nonNegativeMoneyInput = z.coerce.number().finite().min(0).max(9999999999999.99);
const percentageInput = z.coerce.number().finite().min(0).max(100);
const achievementPercentageInput = z.coerce.number().finite().min(0).max(10000);
const goalDateInput = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "صيغة التاريخ غير صحيحة");
const optionalGoalText = z.string().trim().max(5000).nullable().optional();

const administrativeGoalWriteInput = z.object({
  goalTypeId: z.number().int().positive(),
  title: z.string().trim().min(1, "عنوان الهدف مطلوب").max(255),
  description: optionalGoalText,
  status: z.enum(["planned", "in_progress", "completed", "closed"]).default("planned"),
  startDate: goalDateInput.nullable().optional(),
  expectedEndDate: goalDateInput.nullable().optional(),
  expectedDurationMonths: z.coerce.number().int().min(1).max(1200).nullable().optional(),
  completionPercent: percentageInput.default(0),
  reviewerIds: z.array(z.number().int().positive()).max(25).default([]),
});

const administrativeActionWriteInput = z.object({
  title: z.string().trim().min(1, "عنوان الإجراء مطلوب").max(255),
  description: optionalGoalText,
  sortOrder: z.coerce.number().int().min(0).max(10000).default(0),
  status: z.enum(["planned", "in_progress", "completed", "closed"]).default("planned"),
  plannedStartDate: goalDateInput.nullable().optional(),
  plannedEndDate: goalDateInput.nullable().optional(),
  proposedAssigneeUserId: z.number().int().positive().nullable().optional(),
  assigneeUserId: z.number().int().positive().nullable().optional(),
  completionPercent: percentageInput.default(0),
});

const salesGoalPlanWriteInput = z.object({
  goalTypeId: z.number().int().positive(),
  title: z.string().trim().min(1, "عنوان خطة المبيعات مطلوب").max(255),
  periodId: z.number().int().positive(),
  scopeType: z.enum(["company", "branch", "user"]),
  branchId: z.number().int().positive().nullable().optional(),
  userId: z.number().int().positive().nullable().optional(),
  status: z.enum(["draft", "active", "closed"]).default("draft"),
  notes: optionalGoalText,
});

const salesGoalMetricWriteInput = z.object({
  metricType: z.enum(["sales", "collections", "new_customers", "custom"]),
  name: z.string().trim().min(1, "اسم المقياس مطلوب").max(255),
  targetValue: moneyInput,
  currentValue: nonNegativeMoneyInput.default(0),
  dataSource: z.enum(["manual", "performance_reports", "approved_receipts"]).default("manual"),
  sortOrder: z.coerce.number().int().min(0).max(10000).default(0),
});

const commissionPlanWriteInput = z.object({
  salesGoalMetricId: z.number().int().positive().nullable().optional(),
  name: z.string().trim().min(1, "اسم خطة العمولة مطلوب").max(255),
  baseCommissionRate: z.coerce.number().finite().min(0).max(100),
  minimumPayoutAmount: nonNegativeMoneyInput.default(0),
  isActive: z.boolean().default(true),
});

const commissionTierInput = z.object({
  minAchievementPercent: achievementPercentageInput,
  maxAchievementPercent: achievementPercentageInput.nullable().optional(),
  payoutMultiplier: z.coerce.number().finite().min(0).max(100),
  additionalCommissionRate: z.coerce.number().finite().min(0).max(100),
  fixedBonusAmount: nonNegativeMoneyInput,
  isEligible: z.boolean(),
});

function canRequestApproval(systemUser: { userType: string; userLevel: string; permissions?: unknown }) {
  return systemUser.userType === "admin" || systemUser.userLevel === "primary" || hasSystemPermission(systemUser.permissions, "approvalRequest");
}

function canDelegateApproval(systemUser: { userType: string; userLevel: string; permissions?: unknown }) {
  return systemUser.userType === "admin" || systemUser.userLevel === "primary" || hasSystemPermission(systemUser.permissions, "approvalDelegate");
}

function canAccessApprovalAttachment(
  request: { requestedBy: number; reviewerUserId?: number | null; reviewerSteps?: Array<{ systemUserId: number }>; steps?: Array<{ systemUserId: number }> },
  systemUser: { id: number; userType: string; userLevel: string },
) {
  return systemUser.userType === "admin"
    || systemUser.userLevel === "primary"
    || request.requestedBy === systemUser.id
    || request.reviewerUserId === systemUser.id
    || Boolean(request.reviewerSteps?.some(step => step.systemUserId === systemUser.id))
    || Boolean(request.steps?.some(step => step.systemUserId === systemUser.id));
}

export function applyNonSigningPartnerRestrictions(data: Record<string, unknown>, currentUser?: { userType: string; boardPosition?: string | null }) {
  const userType = String(data.userType ?? currentUser?.userType ?? "");
  const incomingBoardPosition = typeof data.boardPosition === "string" || data.boardPosition === null
    ? data.boardPosition
    : currentUser?.boardPosition ?? null;
  const boardPosition = normalizeBoardPosition(incomingBoardPosition);
  if (userType === "authorized_partner" && boardPosition === "شريك فقط") {
    return {
      ...data,
      boardPosition,
      userLevel: "secondary",
      permissions: { sidebar_reports: true },
    };
  }
  return { ...data, boardPosition };
}

function canManageCustomers(systemUser: { userType: string; permissions?: unknown }) {
  return systemUser.userType === "admin" || hasSystemPermission(systemUser.permissions, "customersManage");
}

function canManageTargets(systemUser: { userType: string; permissions?: unknown }) {
  return systemUser.userType === "admin" || hasSystemPermission(systemUser.permissions, "targetsManage");
}

type GoalManagementPermission = "goalsView" | "goalsManage" | "goalsReview" | "goalsExecute" | "commissionsManage";
type GoalManagementUser = { id: number; userType: string; permissions?: unknown };

function hasGoalManagementPermission(permissions: unknown, permission: GoalManagementPermission) {
  if (Array.isArray(permissions)) return permissions.includes(permission);
  return Boolean((permissions as Record<string, unknown> | undefined)?.[permission]);
}

function getGoalManagementCapabilities(systemUser: GoalManagementUser) {
  const legacyManagement = canManageTargets(systemUser);
  const canManage = legacyManagement || hasGoalManagementPermission(systemUser.permissions, "goalsManage");
  const canReview = canManage || hasGoalManagementPermission(systemUser.permissions, "goalsReview");
  const canExecute = canManage || hasGoalManagementPermission(systemUser.permissions, "goalsExecute");
  const canManageCommissions = legacyManagement || hasGoalManagementPermission(systemUser.permissions, "commissionsManage");
  return {
    canManage,
    canReview,
    canExecute,
    canManageCommissions,
    canView: canManage || canReview || canExecute || canManageCommissions || hasGoalManagementPermission(systemUser.permissions, "goalsView"),
  };
}

function requireGoalManagementView(systemUser: GoalManagementUser) {
  if (!getGoalManagementCapabilities(systemUser).canView) {
    throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية الاطلاع على إدارة الأهداف" });
  }
}

function requireGoalsManagement(systemUser: GoalManagementUser) {
  if (!getGoalManagementCapabilities(systemUser).canManage) {
    throw new TRPCError({ code: "FORBIDDEN", message: "إدارة الأهداف متاحة لمدير النظام أو لمنحه صلاحية الإدارة" });
  }
}

function requireCommissionsManagement(systemUser: GoalManagementUser) {
  if (!getGoalManagementCapabilities(systemUser).canManageCommissions) {
    throw new TRPCError({ code: "FORBIDDEN", message: "إدارة قواعد العمولات متاحة للمخولين فقط" });
  }
}

function formatGoalDecimal(value: number, scale = 2) {
  return value.toFixed(scale);
}

function normalizeGoalOptionalText(value: string | null | undefined) {
  const normalized = value?.trim();
  return normalized ? normalized : null;
}

function assertOrderedGoalDates(startDate: string | null | undefined, endDate: string | null | undefined, label: string) {
  if (startDate && endDate && startDate > endDate) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `يجب أن يكون تاريخ بداية ${label} قبل تاريخ نهايته` });
  }
}

function normalizeCommissionTiers(tiers: Array<z.infer<typeof commissionTierInput>>) {
  const normalized = tiers
    .map(tier => ({ ...tier, maxAchievementPercent: tier.maxAchievementPercent ?? null }))
    .sort((first, second) => first.minAchievementPercent - second.minAchievementPercent);

  normalized.forEach((tier, index) => {
    if (tier.maxAchievementPercent !== null && tier.maxAchievementPercent <= tier.minAchievementPercent) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "الحد الأعلى للشريحة يجب أن يكون أكبر من الحد الأدنى" });
    }
    if (tier.maxAchievementPercent === null && index !== normalized.length - 1) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "الشريحة المفتوحة يجب أن تكون آخر شريحة" });
    }
    const previous = normalized[index - 1];
    if (previous?.maxAchievementPercent !== null && previous?.maxAchievementPercent !== undefined && tier.minAchievementPercent <= previous.maxAchievementPercent) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن أن تتداخل شرائح الأداء" });
    }
  });

  return normalized.map(tier => ({
    ...tier,
    minAchievementPercent: formatGoalDecimal(tier.minAchievementPercent),
    maxAchievementPercent: tier.maxAchievementPercent === null ? null : formatGoalDecimal(tier.maxAchievementPercent),
    payoutMultiplier: formatGoalDecimal(tier.payoutMultiplier, 4),
    additionalCommissionRate: formatGoalDecimal(tier.additionalCommissionRate, 4),
    fixedBonusAmount: formatGoalDecimal(tier.fixedBonusAmount),
  }));
}

async function assertGoalTypeCategory(goalTypeId: number, category: "administrative" | "sales") {
  const goalType = await db.getGoalTypeById(goalTypeId);
  if (!goalType || goalType.category !== category || !goalType.isActive) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "نوع الهدف غير موجود أو غير نشط أو لا يتوافق مع هذا القسم" });
  }
  return goalType;
}

async function assertSalesGoalPlanScope(input: z.infer<typeof salesGoalPlanWriteInput>) {
  const [periods, branches] = await Promise.all([db.getFinancialPeriods(), db.getBranches()]);
  if (!periods.some(period => period.id === input.periodId)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "الفترة المالية المحددة غير موجودة" });
  }
  if (input.scopeType === "company" && (input.branchId || input.userId)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "النطاق على مستوى الشركة لا يقبل فرعاً أو مستخدماً محدداً" });
  }
  if (input.scopeType === "branch") {
    if (!input.branchId || input.userId) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب تحديد فرع فقط لخطة نطاق الفرع" });
    if (!branches.some(branch => branch.id === input.branchId)) throw new TRPCError({ code: "BAD_REQUEST", message: "الفرع المحدد غير موجود" });
  }
  if (input.scopeType === "user") {
    if (!input.userId || input.branchId) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب تحديد مستخدم فقط لخطة نطاق المستخدم" });
    await db.assertActiveSystemUserIds([input.userId]);
  }
}

async function isAdministrativeGoalReviewer(systemUser: GoalManagementUser, goalId: number) {
  return getGoalManagementCapabilities(systemUser).canReview && db.isAdministrativeGoalReviewer(goalId, systemUser.id);
}

async function requireAdministrativeGoalReviewerOrManager(systemUser: GoalManagementUser, goalId: number) {
  if (getGoalManagementCapabilities(systemUser).canManage) return;
  if (!await isAdministrativeGoalReviewer(systemUser, goalId)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية متاحة لمدير الهدف أو للمراجع المعيّن له فقط" });
  }
}

async function requireAdministrativeGoalActionCollaborator(systemUser: GoalManagementUser, action: { goalId: number; assigneeUserId?: number | null }) {
  if (getGoalManagementCapabilities(systemUser).canManage) return;
  if (await isAdministrativeGoalReviewer(systemUser, action.goalId)) return;
  const capabilities = getGoalManagementCapabilities(systemUser);
  if (capabilities.canExecute && action.assigneeUserId === systemUser.id) return;
  throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية التعامل مع هذا الإجراء" });
}

function requireCustomerManagement(systemUser: { userType: string; permissions?: unknown }) {
  if (!canManageCustomers(systemUser)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "إدارة العملاء متاحة لمدير النظام أو لمنحه هذه الصلاحية" });
  }
}

function requireTargetManagement(systemUser: { userType: string; permissions?: unknown }) {
  if (!canManageTargets(systemUser)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "إدارة الأهداف متاحة لمدير النظام أو لمنحه هذه الصلاحية" });
  }
}

function canDeleteOperationalData(systemUser: { userType: string; permissions?: unknown }) {
  return systemUser.userType === "admin" || hasSystemPermission(systemUser.permissions, "dataDelete");
}

function requireOperationalDataDeletion(systemUser: { userType: string; permissions?: unknown }) {
  if (!canDeleteOperationalData(systemUser)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "حذف البيانات متاح لمدير النظام أو لمنحه هذه الصلاحية" });
  }
}

async function captureSystemBackupFiles(data: db.SystemBackupData): Promise<SystemBackupFile[]> {
  const urls = collectManagedStorageUrls(data);
  return Promise.all(urls.map(async (sourceUrl) => {
    const key = getManagedStorageKey(sourceUrl);
    if (!key) throw new Error(`مرجع ملف غير صالح: ${sourceUrl}`);
    const signedUrl = await storageGetSignedUrl(key);
    const response = await fetch(signedUrl);
    if (!response.ok) throw new Error(`تعذر تضمين الملف ${key} في النسخة الاحتياطية`);
    return {
      sourceUrl,
      contentType: response.headers.get('content-type') || 'application/octet-stream',
      dataBase64: Buffer.from(await response.arrayBuffer()).toString('base64'),
    };
  }));
}

async function restoreSystemBackupFiles(files: SystemBackupFile[]) {
  const urlMap = new Map<string, string>();
  for (const file of files) {
    const sourceKey = getManagedStorageKey(file.sourceUrl);
    if (!sourceKey || !file.dataBase64) throw new Error('يحتوي ملف النسخة الاحتياطية على مرفق غير صالح');
    const restored = await storagePut(`restored-system-backup/${sourceKey.split('/').pop() || 'attachment.bin'}`, Buffer.from(file.dataBase64, 'base64'), file.contentType);
    urlMap.set(file.sourceUrl, restored.url);
  }
  return urlMap;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // System Authentication
  systemAuth: router({
    login: publicProcedure.input(z.object({ username: z.string(), password: z.string() })).mutation(async ({ input, ctx }) => {
      const user = await db.authenticateSystemUser(input.username, input.password);
      if (!user) return { success: false, error: "اسم المستخدم أو كلمة المرور غير صحيحة" };
      const systemUser = { id: user.id, username: user.username, fullName: user.fullName, userType: user.userType, userLevel: user.userLevel, branchId: user.branchId, permissions: user.permissions } as const;
      const token = await createSystemSession(systemUser);
      if (typeof ctx.res.cookie === "function") {
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(SYSTEM_SESSION_COOKIE, token, {
          ...cookieOptions,
          maxAge: 12 * 60 * 60 * 1000,
        });
      }
      return { success: true, user: systemUser };
    }),
    session: systemUserProcedure.query(({ ctx }) => ctx.systemUser),
    getUser: publicProcedure.input(z.object({ userId: z.number() })).query(async ({ input }) => {
      const allUsers = await db.getAllSystemUsers();
      return allUsers.find(u => u.id === input.userId) || null;
    }),
    requestPasswordReset: publicProcedure.input(z.object({ username: z.string().trim().min(1).max(64) })).mutation(async ({ input }) => {
      const genericResponse = { success: true, message: "إذا كانت بيانات الاسترداد مهيأة للحساب، فسيصل رمز إلى البريد المعتمد." } as const;
      const settings = await db.getSettings();
      const recoveryEmail = settings[PASSWORD_RECOVERY_EMAIL_KEY]?.trim();
      const user = recoveryEmail ? await db.getEligibleSystemUserForPasswordReset(input.username) : null;
      if (!user || !recoveryEmail) return genericResponse;

      const code = randomInt(100000, 1_000_000).toString();
      await db.replacePasswordResetCode({
        userId: user.id,
        recoveryEmail,
        codeHash: hashPasswordRecoveryCode(code),
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      });
      try {
        await sendPasswordRecoveryCode({ to: recoveryEmail, code });
      } catch {
        await db.deletePasswordResetCodeForUser(user.id);
      }
      return genericResponse;
    }),
    confirmPasswordReset: publicProcedure.input(z.object({
      username: z.string().trim().min(1).max(64),
      code: z.string().trim().regex(/^\d{6}$/, "أدخل رمزاً من 6 أرقام"),
      password: z.string().min(8, "يجب ألا تقل كلمة المرور عن 8 أحرف").max(256),
    })).mutation(async ({ input }) => {
      const result = await db.confirmPasswordResetCode({ username: input.username, codeHash: hashPasswordRecoveryCode(input.code), password: input.password });
      if (!result.success) return { success: false, error: "رمز الاسترداد غير صالح أو انتهت صلاحيته" } as const;
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(SYSTEM_SESSION_COOKIE, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // System Users Management
  systemUsers: router({
    list: publicProcedure.query(async () => db.getAllSystemUsers()),
    directory: systemUserProcedure.query(async () => db.getSystemUserDirectory()),
    create: systemAdminProcedure.input(z.object({ username: z.string().trim().min(1), password: z.string().min(1), fullName: z.string().trim().min(1), userType: systemUserTypeInput, userLevel: z.enum(["primary", "secondary"]), branchId: z.number().nullable().optional(), phone: z.string().optional(), email: z.string().optional(), boardPosition: z.string().nullable().optional(), permissions: z.union([z.record(z.string(), z.boolean()), z.array(z.string())]).optional() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      await assertConfiguredSystemUserType(input.userType);
      const preparedInput = applySecondaryUserApprovalRequestDefault(input);
      return db.createSystemUser({ ...applyNonSigningPartnerRestrictions(preparedInput), createdBy: userId, updatedBy: userId });
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.object({ username: z.string().trim().min(1).optional(), password: z.string().min(1).optional(), fullName: z.string().trim().min(1).optional(), userType: systemUserTypeInput.optional(), userLevel: z.enum(["primary", "secondary"]).optional(), branchId: z.number().nullable().optional(), phone: z.string().optional(), email: z.string().optional(), boardPosition: z.string().nullable().optional(), permissions: z.union([z.record(z.string(), z.boolean()), z.array(z.string())]).optional() }) })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      const existingUser = (await db.getAllSystemUsers()).find(user => user.id === input.id);
      if (!existingUser) throw new TRPCError({ code: "NOT_FOUND", message: "المستخدم غير موجود" });
      if (input.data.userType) await assertConfiguredSystemUserType(input.data.userType);
      const { password, ...dataWithoutPassword } = input.data;
      const rawData = password ? { ...dataWithoutPassword, password } : dataWithoutPassword;
      const withDefaultApprovalRequest = applySecondaryUserApprovalRequestDefault(rawData, existingUser);
      const data = { ...applyNonSigningPartnerRestrictions(withDefaultApprovalRequest, existingUser), updatedBy: userId };
      return db.updateSystemUser(input.id, data);
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteSystemUser(input.id);
    }),
  }),

  // Company Profile
  company: router({
    get: publicProcedure.query(async () => db.getCompanyProfile()),
    update: systemAdminProcedure.input(z.object({ companyName: z.string().optional(), address: z.string().optional(), commercialRegister: z.string().optional(), taxNumber: z.string().optional(), logoUrl: z.string().max(1024).optional(), phone: z.string().optional() })).mutation(async ({ input }) => {
      const existing = await db.getCompanyProfile();
      if (input.logoUrl && !input.logoUrl.startsWith("/manus-storage/") && input.logoUrl !== existing?.logoUrl) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "يمكن اختيار الشعار الجديد عبر رفع ملف فقط" });
      }
      return db.updateCompanyProfile(input);
    }),
  }),

  // Settings
  settings: router({
    getAll: publicProcedure.query(async () => {
      const settings = await db.getSettings();
      const { [PASSWORD_RECOVERY_EMAIL_KEY]: _recoveryEmail, ...publicSettings } = settings;
      return publicSettings;
    }),
    getPasswordRecoveryEmail: systemAdminProcedure.query(async () => ({ email: (await db.getSettings())[PASSWORD_RECOVERY_EMAIL_KEY] || "" })),
    update: systemAdminProcedure.input(z.object({ key: z.string(), value: z.string() })).mutation(async ({ input }) => {
      return db.updateSetting(input.key, await validateSystemUserTypeSetting(input.key, input.value));
    }),
    updateMany: systemAdminProcedure.input(z.object({ entries: z.array(z.object({ key: z.string().min(1), value: z.string() })).min(1).max(20) })).mutation(async ({ input }) => {
      return db.updateSettings(await Promise.all(input.entries.map(async entry => ({ ...entry, value: await validateSystemUserTypeSetting(entry.key, entry.value) }))));
    }),
  }),

  // Regions
  regions: router({
    list: publicProcedure.query(async () => db.getRegions()),
    create: systemAdminProcedure.input(z.object({ name: z.string() })).mutation(async ({ input }) => {
      return db.createRegion(input.name);
    }),
  }),

  // Branches
  branches: router({
    list: publicProcedure.query(async () => db.getBranches()),
    create: systemAdminProcedure.input(z.object({ name: z.string(), address: z.string().optional(), regionId: z.number().optional(), receiptSerial: z.string().optional(), paymentSerial: z.string().optional() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      return db.createBranch({ ...input, createdBy: userId, updatedBy: userId });
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      return db.updateBranch(input.id, { ...input.data, updatedBy: userId });
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteBranch(input.id);
    }),
  }),

  // Financial Periods
  periods: router({
    list: publicProcedure.query(async () => db.getFinancialPeriods()),
    active: publicProcedure.query(async () => db.getActivePeriod()),
    create: systemAdminProcedure.input(z.object({ name: z.string(), startDate: z.string(), endDate: z.string(), isActive: z.boolean().optional() })).mutation(async ({ input }) => {
      return db.createFinancialPeriod({ ...input, startDate: new Date(input.startDate), endDate: new Date(input.endDate) });
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input }) => {
      return db.updateFinancialPeriod(input.id, input.data);
    }),
  }),

  // Branch Targets
  targets: router({
    list: publicProcedure.input(z.object({ branchId: z.number(), periodId: z.number() })).query(async ({ input }) => {
      return db.getBranchTargets(input.branchId, input.periodId);
    }),
    create: systemUserProcedure.input(z.object({ branchId: z.number(), periodId: z.number(), targetType: z.enum(["sales", "collections", "custom"]), targetName: z.string().optional(), targetValue: z.string() })).mutation(async ({ input, ctx }) => {
      requireTargetManagement(ctx.systemUser);
      return db.createBranchTarget(input);
    }),
    update: systemUserProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input, ctx }) => {
      requireTargetManagement(ctx.systemUser);
      return db.updateBranchTarget(input.id, input.data);
    }),
    delete: systemUserProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      requireTargetManagement(ctx.systemUser);
      return db.deleteBranchTarget(input.id);
    }),
  }),

  // إدارة الأهداف والعمولات الجديدة. يبقى موديول المستهدفات السابق أعلاه متوافقاً للبيانات التاريخية.
  goalManagement: router({
    overview: systemUserProcedure.query(async ({ ctx }) => {
      const capabilities = getGoalManagementCapabilities(ctx.systemUser);
      requireGoalManagementView(ctx.systemUser);

      const [goalTypes, users, periods, branches, allAdministrativeGoals, allReviewers, allActions, allAttachments, allSalesPlans, allMetrics, allCommissionPlans, allCommissionTiers] = await Promise.all([
        db.getGoalTypes(), db.getSystemUserDirectory(), db.getFinancialPeriods(), db.getBranches(),
        db.getAdministrativeGoals(), db.getAdministrativeGoalReviewers(), db.getAdministrativeGoalActions(), db.getAdministrativeGoalActionAttachments(),
        db.getSalesGoalPlans(), db.getSalesGoalMetrics(), db.getCommissionPlans(), db.getCommissionTiers(),
      ]);

      const canViewAllGoals = capabilities.canManage || hasGoalManagementPermission(ctx.systemUser.permissions, "goalsView");
      const reviewedGoalIds = new Set(allReviewers.filter(reviewer => reviewer.userId === ctx.systemUser.id).map(reviewer => reviewer.goalId));
      const executedGoalIds = new Set(allActions.filter(action => action.assigneeUserId === ctx.systemUser.id).map(action => action.goalId));
      const visibleGoalIds = canViewAllGoals ? new Set(allAdministrativeGoals.map(goal => goal.id)) : new Set<number>();
      if (!canViewAllGoals) {
        reviewedGoalIds.forEach(goalId => visibleGoalIds.add(goalId));
        executedGoalIds.forEach(goalId => visibleGoalIds.add(goalId));
      }
      const administrativeGoals = allAdministrativeGoals.filter(goal => visibleGoalIds.has(goal.id));
      const administrativeGoalReviewers = allReviewers.filter(reviewer => visibleGoalIds.has(reviewer.goalId));
      const administrativeGoalActions = allActions.filter(action => visibleGoalIds.has(action.goalId));
      const visibleActionIds = new Set(administrativeGoalActions.map(action => action.id));

      return {
        capabilities,
        goalTypes,
        users,
        periods,
        branches,
        administrativeGoals,
        administrativeGoalReviewers,
        administrativeGoalActions,
        administrativeGoalActionAttachments: allAttachments.filter(attachment => visibleActionIds.has(attachment.actionId)),
        salesGoalPlans: allSalesPlans,
        salesGoalMetrics: allMetrics,
        commissionPlans: allCommissionPlans,
        commissionTiers: allCommissionTiers,
      };
    }),

    goalTypes: router({
      create: systemUserProcedure.input(z.object({ name: z.string().trim().min(1).max(255), category: z.enum(["administrative", "sales"]), description: optionalGoalText, isActive: z.boolean().default(true) })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        return db.createGoalType({ ...input, description: normalizeGoalOptionalText(input.description), createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
      }),
      update: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: z.object({ name: z.string().trim().min(1).max(255), description: optionalGoalText, isActive: z.boolean() }) })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getGoalTypeById(input.id)) throw new TRPCError({ code: "NOT_FOUND", message: "نوع الهدف غير موجود" });
        return db.updateGoalType(input.id, { ...input.data, description: normalizeGoalOptionalText(input.data.description), updatedBy: ctx.systemUser.id });
      }),
    }),

    administrative: router({
      createGoal: systemUserProcedure.input(administrativeGoalWriteInput).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        await assertGoalTypeCategory(input.goalTypeId, "administrative");
        assertOrderedGoalDates(input.startDate, input.expectedEndDate, "الهدف");
        const reviewerIds = Array.from(new Set(input.reviewerIds));
        await db.assertActiveSystemUserIds(reviewerIds);
        return db.createAdministrativeGoal({
          goalTypeId: input.goalTypeId, title: input.title, description: normalizeGoalOptionalText(input.description), status: input.status,
          startDate: input.startDate ?? null, expectedEndDate: input.expectedEndDate ?? null, expectedDurationMonths: input.expectedDurationMonths ?? null,
          completionPercent: formatGoalDecimal(input.completionPercent), closedAt: input.status === "closed" ? new Date() : null,
          createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id,
        }, reviewerIds);
      }),
      updateGoal: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: administrativeGoalWriteInput })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getAdministrativeGoalById(input.id)) throw new TRPCError({ code: "NOT_FOUND", message: "الهدف الإداري غير موجود" });
        await assertGoalTypeCategory(input.data.goalTypeId, "administrative");
        assertOrderedGoalDates(input.data.startDate, input.data.expectedEndDate, "الهدف");
        const reviewerIds = Array.from(new Set(input.data.reviewerIds));
        await db.assertActiveSystemUserIds(reviewerIds);
        await db.updateAdministrativeGoal(input.id, {
          goalTypeId: input.data.goalTypeId, title: input.data.title, description: normalizeGoalOptionalText(input.data.description), status: input.data.status,
          startDate: input.data.startDate ?? null, expectedEndDate: input.data.expectedEndDate ?? null, expectedDurationMonths: input.data.expectedDurationMonths ?? null,
          completionPercent: formatGoalDecimal(input.data.completionPercent), closedAt: input.data.status === "closed" ? new Date() : null, updatedBy: ctx.systemUser.id,
        });
        await db.replaceAdministrativeGoalReviewers(input.id, reviewerIds, ctx.systemUser.id);
        return { id: input.id };
      }),
      reviewGoal: systemUserProcedure.input(z.object({ id: z.number().int().positive(), completionPercent: percentageInput, status: z.enum(["planned", "in_progress", "completed", "closed"]), description: optionalGoalText })).mutation(async ({ input, ctx }) => {
        const goal = await db.getAdministrativeGoalById(input.id);
        if (!goal) throw new TRPCError({ code: "NOT_FOUND", message: "الهدف الإداري غير موجود" });
        await requireAdministrativeGoalReviewerOrManager(ctx.systemUser, input.id);
        return db.updateAdministrativeGoal(input.id, {
          completionPercent: formatGoalDecimal(input.completionPercent), status: input.status, description: normalizeGoalOptionalText(input.description),
          closedAt: input.status === "closed" ? new Date() : null, updatedBy: ctx.systemUser.id,
        });
      }),
      createAction: systemUserProcedure.input(z.object({ goalId: z.number().int().positive(), data: administrativeActionWriteInput })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getAdministrativeGoalById(input.goalId)) throw new TRPCError({ code: "NOT_FOUND", message: "الهدف الإداري غير موجود" });
        assertOrderedGoalDates(input.data.plannedStartDate, input.data.plannedEndDate, "الإجراء");
        await db.assertActiveSystemUserIds([input.data.proposedAssigneeUserId, input.data.assigneeUserId].filter((id): id is number => Boolean(id)));
        return db.createAdministrativeGoalAction({
          goalId: input.goalId, title: input.data.title, description: normalizeGoalOptionalText(input.data.description), sortOrder: input.data.sortOrder,
          status: input.data.status, plannedStartDate: input.data.plannedStartDate ?? null, plannedEndDate: input.data.plannedEndDate ?? null,
          proposedAssigneeUserId: input.data.proposedAssigneeUserId ?? null, assigneeUserId: input.data.assigneeUserId ?? null,
          completionPercent: formatGoalDecimal(input.data.completionPercent), closedAt: input.data.status === "closed" ? new Date() : null,
          createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id,
        });
      }),
      updateAction: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: administrativeActionWriteInput })).mutation(async ({ input, ctx }) => {
        const action = await db.getAdministrativeGoalActionById(input.id);
        if (!action) throw new TRPCError({ code: "NOT_FOUND", message: "إجراء الهدف غير موجود" });
        await requireAdministrativeGoalReviewerOrManager(ctx.systemUser, action.goalId);
        assertOrderedGoalDates(input.data.plannedStartDate, input.data.plannedEndDate, "الإجراء");
        await db.assertActiveSystemUserIds([input.data.proposedAssigneeUserId, input.data.assigneeUserId].filter((id): id is number => Boolean(id)));
        return db.updateAdministrativeGoalAction(input.id, {
          title: input.data.title, description: normalizeGoalOptionalText(input.data.description), sortOrder: input.data.sortOrder, status: input.data.status,
          plannedStartDate: input.data.plannedStartDate ?? null, plannedEndDate: input.data.plannedEndDate ?? null,
          proposedAssigneeUserId: input.data.proposedAssigneeUserId ?? null, assigneeUserId: input.data.assigneeUserId ?? null,
          completionPercent: formatGoalDecimal(input.data.completionPercent), closedAt: input.data.status === "closed" ? new Date() : null, updatedBy: ctx.systemUser.id,
        });
      }),
      updateActionProgress: systemUserProcedure.input(z.object({ id: z.number().int().positive(), completionPercent: percentageInput, status: z.enum(["planned", "in_progress", "completed"]) })).mutation(async ({ input, ctx }) => {
        const action = await db.getAdministrativeGoalActionById(input.id);
        if (!action) throw new TRPCError({ code: "NOT_FOUND", message: "إجراء الهدف غير موجود" });
        await requireAdministrativeGoalActionCollaborator(ctx.systemUser, action);
        return db.updateAdministrativeGoalAction(input.id, { completionPercent: formatGoalDecimal(input.completionPercent), status: input.status, closedAt: null, updatedBy: ctx.systemUser.id });
      }),
      addActionAttachment: systemUserProcedure.input(z.object({ actionId: z.number().int().positive(), attachmentUrl: managedStorageUrl, attachmentName: z.string().trim().min(1).max(255), attachmentMimeType: z.enum(["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "image/png", "image/jpeg"]) })).mutation(async ({ input, ctx }) => {
        const action = await db.getAdministrativeGoalActionById(input.actionId);
        if (!action) throw new TRPCError({ code: "NOT_FOUND", message: "إجراء الهدف غير موجود" });
        await requireAdministrativeGoalActionCollaborator(ctx.systemUser, action);
        return db.createAdministrativeGoalActionAttachment({ ...input, createdBy: ctx.systemUser.id });
      }),
    }),

    sales: router({
      createPlan: systemUserProcedure.input(salesGoalPlanWriteInput).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        await assertGoalTypeCategory(input.goalTypeId, "sales");
        await assertSalesGoalPlanScope(input);
        return db.createSalesGoalPlan({ ...input, notes: normalizeGoalOptionalText(input.notes), branchId: input.branchId ?? null, userId: input.userId ?? null, createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
      }),
      updatePlan: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: salesGoalPlanWriteInput })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getSalesGoalPlanById(input.id)) throw new TRPCError({ code: "NOT_FOUND", message: "خطة المبيعات غير موجودة" });
        await assertGoalTypeCategory(input.data.goalTypeId, "sales");
        await assertSalesGoalPlanScope(input.data);
        return db.updateSalesGoalPlan(input.id, { ...input.data, notes: normalizeGoalOptionalText(input.data.notes), branchId: input.data.branchId ?? null, userId: input.data.userId ?? null, updatedBy: ctx.systemUser.id });
      }),
      createMetric: systemUserProcedure.input(z.object({ salesGoalPlanId: z.number().int().positive(), data: salesGoalMetricWriteInput })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getSalesGoalPlanById(input.salesGoalPlanId)) throw new TRPCError({ code: "NOT_FOUND", message: "خطة المبيعات غير موجودة" });
        return db.createSalesGoalMetric({ salesGoalPlanId: input.salesGoalPlanId, ...input.data, targetValue: formatGoalDecimal(input.data.targetValue), currentValue: formatGoalDecimal(input.data.currentValue), createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
      }),
      updateMetric: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: salesGoalMetricWriteInput })).mutation(async ({ input, ctx }) => {
        requireGoalsManagement(ctx.systemUser);
        if (!await db.getSalesGoalMetricById(input.id)) throw new TRPCError({ code: "NOT_FOUND", message: "مقياس المبيعات غير موجود" });
        return db.updateSalesGoalMetric(input.id, { ...input.data, targetValue: formatGoalDecimal(input.data.targetValue), currentValue: formatGoalDecimal(input.data.currentValue), updatedBy: ctx.systemUser.id });
      }),
    }),

    commissions: router({
      createPlan: systemUserProcedure.input(z.object({ salesGoalPlanId: z.number().int().positive(), data: commissionPlanWriteInput })).mutation(async ({ input, ctx }) => {
        requireCommissionsManagement(ctx.systemUser);
        if (!await db.getSalesGoalPlanById(input.salesGoalPlanId)) throw new TRPCError({ code: "NOT_FOUND", message: "خطة المبيعات غير موجودة" });
        if (input.data.salesGoalMetricId) {
          const metric = await db.getSalesGoalMetricById(input.data.salesGoalMetricId);
          if (!metric || metric.salesGoalPlanId !== input.salesGoalPlanId) throw new TRPCError({ code: "BAD_REQUEST", message: "مقياس العمولة لا يتبع خطة المبيعات المحددة" });
        }
        return db.createCommissionPlan({ salesGoalPlanId: input.salesGoalPlanId, ...input.data, salesGoalMetricId: input.data.salesGoalMetricId ?? null, baseCommissionRate: formatGoalDecimal(input.data.baseCommissionRate, 4), minimumPayoutAmount: formatGoalDecimal(input.data.minimumPayoutAmount), createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
      }),
      updatePlan: systemUserProcedure.input(z.object({ id: z.number().int().positive(), data: commissionPlanWriteInput })).mutation(async ({ input, ctx }) => {
        requireCommissionsManagement(ctx.systemUser);
        const plan = await db.getCommissionPlanById(input.id);
        if (!plan) throw new TRPCError({ code: "NOT_FOUND", message: "خطة العمولة غير موجودة" });
        if (input.data.salesGoalMetricId) {
          const metric = await db.getSalesGoalMetricById(input.data.salesGoalMetricId);
          if (!metric || metric.salesGoalPlanId !== plan.salesGoalPlanId) throw new TRPCError({ code: "BAD_REQUEST", message: "مقياس العمولة لا يتبع خطة المبيعات المحددة" });
        }
        return db.updateCommissionPlan(input.id, { ...input.data, salesGoalMetricId: input.data.salesGoalMetricId ?? null, baseCommissionRate: formatGoalDecimal(input.data.baseCommissionRate, 4), minimumPayoutAmount: formatGoalDecimal(input.data.minimumPayoutAmount), updatedBy: ctx.systemUser.id });
      }),
      replaceTiers: systemUserProcedure.input(z.object({ commissionPlanId: z.number().int().positive(), tiers: z.array(commissionTierInput).min(1).max(50) })).mutation(async ({ input, ctx }) => {
        requireCommissionsManagement(ctx.systemUser);
        if (!await db.getCommissionPlanById(input.commissionPlanId)) throw new TRPCError({ code: "NOT_FOUND", message: "خطة العمولة غير موجودة" });
        const tiers = normalizeCommissionTiers(input.tiers).map(tier => ({ ...tier, createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id }));
        return db.replaceCommissionTiers(input.commissionPlanId, tiers);
      }),
    }),
  }),

  // Customers
  customers: router({
    list: systemUserProcedure.input(z.object({ branchId: z.number().optional(), search: z.string().optional() }).optional()).query(async ({ input, ctx }) => {
      if (isSecondarySystemUser(ctx.systemUser)) {
        return db.getCustomers({ ...input, delegateId: ctx.systemUser.id });
      }
      return db.getCustomers(input || undefined);
    }),
    getByNumber: systemUserProcedure.input(z.object({ customerNumber: z.string() })).query(async ({ input, ctx }) => {
      const customer = await db.getCustomerByNumber(input.customerNumber);
      if (customer && isSecondarySystemUser(ctx.systemUser) && customer.delegateId !== ctx.systemUser.id) return null;
      return customer;
    }),
    create: systemUserProcedure.input(z.object({ customerNumber: z.string(), name: z.string(), branchId: z.number().optional(), delegateId: z.number().optional(), phone: z.string().optional(), email: z.string().optional(), address: z.string().optional() })).mutation(async ({ input, ctx }) => {
      requireCustomerManagement(ctx.systemUser);
      // Server-side duplicate check
      const existing = await db.getCustomerByNumber(input.customerNumber);
      if (existing) throw new Error('رقم العميل مستخدم بالفعل');
      const userId = ctx.systemUser.id;
      return db.createCustomer({ ...input, createdBy: userId, updatedBy: userId });
    }),
    update: systemUserProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input, ctx }) => {
      requireCustomerManagement(ctx.systemUser);
      const userId = ctx.systemUser.id;
      return db.updateCustomer(input.id, { ...input.data, updatedBy: userId });
    }),
    delete: systemUserProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      requireCustomerManagement(ctx.systemUser);
      return db.deleteCustomer(input.id);
    }),
    deleteMany: systemUserProcedure.input(z.object({ ids: z.array(z.number()) })).mutation(async ({ input, ctx }) => {
      requireCustomerManagement(ctx.systemUser);
      return db.deleteCustomers(input.ids);
    }),
  }),

  // Input Lists
  inputLists: router({
    list: publicProcedure.input(z.object({ type: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getInputLists(input?.type);
    }),
    create: systemAdminProcedure.input(z.object({ listType: z.enum(["payment_method", "bank", "payment_for"]), name: z.string().trim().min(1).max(255), parentId: z.number().int().positive().nullable().optional(), requiresAttachment: z.boolean().optional(), sortOrder: z.number().optional() })).mutation(async ({ input }) => {
      if (input.parentId) {
        const parent = await db.getInputListById(input.parentId);
        if (!parent || parent.listType !== input.listType) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب اختيار عنصر أب من نوع القائمة نفسه" });
      }
      return db.createInputList(input);
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.object({ name: z.string().trim().min(1).max(255).optional(), parentId: z.number().int().positive().nullable().optional(), requiresAttachment: z.boolean().optional(), isActive: z.boolean().optional(), sortOrder: z.number().optional() }).passthrough() })).mutation(async ({ input }) => {
      if (input.data.parentId === input.id) throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن جعل العنصر أباً لنفسه" });
      if (input.data.parentId) {
        const [item, parent] = await Promise.all([db.getInputListById(input.id), db.getInputListById(input.data.parentId)]);
        if (!item || !parent || item.listType !== parent.listType) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب اختيار عنصر أب من نوع القائمة نفسه" });
      }
      return db.updateInputList(input.id, input.data);
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      if (await db.hasInputListChildren(input.id)) throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن حذف عنصر يحتوي على عناصر فرعية. انقل العناصر الفرعية أو احذفها أولاً." });
      return db.deleteInputList(input.id);
    }),
  }),

  files: router({
    uploadCompanyLogo: systemAdminProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const match = input.dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح للشعار بصيغ PNG أو JPEG أو WEBP فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 2 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز الشعار 2 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "company-logo";
        const { url } = await storagePut(`company-identity/logos/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadLoginBackground: systemAdminProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const match = input.dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح لخلفية الدخول بصيغ PNG أو JPEG أو WEBP فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 5 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا تتجاوز خلفية الدخول 5 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "login-background";
        const { url } = await storagePut(`company-identity/login-backgrounds/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadReceiptAttachment: systemUserProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const match = input.dataUrl.match(/^data:(image\/(?:png|jpeg|webp)|application\/pdf);base64,([A-Za-z0-9+/=]+)$/);
        if (!match) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح برفع ملفات PDF أو PNG أو JPEG أو WEBP فقط" });
        }

        const mimeType = match[1];
        const fileBuffer = Buffer.from(match[2], "base64");
        const maxBytes = 5 * 1024 * 1024;
        if (!fileBuffer.length || fileBuffer.length > maxBytes) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز حجم مرفق التحويل 5 ميغابايت" });
        }

        const safeFileName = input.fileName
          .replace(/[^a-zA-Z0-9._-]/g, "-")
          .replace(/-+/g, "-")
          .replace(/^[-.]+|[-.]+$/g, "") || "receipt-attachment";
        const { url } = await storagePut(
          `receipt-attachments/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`,
          fileBuffer,
          mimeType,
        );
        return { url, fileName: input.fileName };
      }),
    uploadApprovalTemplate: systemAdminProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const match = input.dataUrl.match(/^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|application\/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet);base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح لنموذج التعميد بصيغة PDF أو Word (DOCX) أو Excel (XLSX) فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 10 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز نموذج التعميد 10 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "approval-template";
        const { url } = await storagePut(`approval-templates/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadApprovalAttachment: systemUserProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const match = input.dataUrl.match(/^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح برفع النموذج المكتمل بصيغة PDF أو Word أو PNG أو JPEG" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 10 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز النموذج المكتمل 10 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "approval-request";
        const { url } = await storagePut(`approval-attachments/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName };
      }),
    uploadAdministrativeGoalAttachment: systemUserProcedure
      .input(z.object({ actionId: z.number().int().positive(), fileName: z.string().trim().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const action = await db.getAdministrativeGoalActionById(input.actionId);
        if (!action) throw new TRPCError({ code: "NOT_FOUND", message: "إجراء الهدف غير موجود" });
        await requireAdministrativeGoalActionCollaborator(ctx.systemUser, action);
        const match = input.dataUrl.match(/^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح لمرفق الإجراء بصيغة PDF أو Word أو PNG أو JPEG فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 10 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز مرفق الإجراء 10 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "goal-action-attachment";
        const { url } = await storagePut(`goal-action-attachments/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadPartnerProfileImage: systemUserProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة صور الشركاء متاحة للمخولين بإدارة حقوق الشركاء فقط");
        const match = input.dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح لصورة الشريك بصيغ PNG أو JPEG أو WEBP فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 2 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا تتجاوز صورة الشريك 2 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "partner-profile";
        const { url } = await storagePut(`partner-rights/profiles/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadPartnerRightsDocument: systemUserProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const capabilities = getPartnerRightsCapabilities(ctx.systemUser);
        if (!capabilities.canCreateEntries && !capabilities.canEditEntries && !capabilities.canManage) {
          throw new TRPCError({ code: "FORBIDDEN", message: "رفع مرفقات حقوق الشركاء متاح للمخولين فقط" });
        }
        const match = input.dataUrl.match(/^data:(application\/pdf|image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح لمستند الشركاء بصيغة PDF أو PNG أو JPEG فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 10 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز مستند الشركاء 10 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "partner-document";
        const { url } = await storagePut(`partner-rights/documents/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
    uploadPartnerRightsAnnualDocument: systemUserProcedure
      .input(z.object({ fileName: z.string().min(1).max(180), dataUrl: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        requirePartnerRightsCapability(ctx.systemUser, "canManage", "رفع المستندات السنوية متاح للمخولين بإدارة حقوق الشركاء فقط");
        const match = input.dataUrl.match(/^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|application\/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/);
        if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "يسمح للمستند السنوي بصيغة PDF أو Word أو Excel أو PNG أو JPEG فقط" });
        const fileBuffer = Buffer.from(match[2], "base64");
        if (!fileBuffer.length || fileBuffer.length > 10 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب ألا يتجاوز المستند السنوي 10 ميغابايت" });
        const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "annual-partner-document";
        const { url } = await storagePut(`partner-rights/annual-documents/${ctx.systemUser.id}/${Date.now()}-${safeFileName}`, fileBuffer, match[1]);
        return { url, fileName: input.fileName, mimeType: match[1] };
      }),
  }),

  // القراءة للشريك المفوض مقيدة بسجل شريكه المرتبط، والعمليات الأخرى تمنح بمفاتيح صريحة.
  partnerRights: router({
    periods: systemUserProcedure.query(async ({ ctx }) => {
      requirePartnerRightsView(ctx.systemUser);
      return db.getFinancialPeriods();
    }),
    overview: systemUserProcedure.input(z.object({ periodId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      requirePartnerRightsView(ctx.systemUser);
      const restrictedSystemUserId = ctx.systemUser.userType === "authorized_partner" ? ctx.systemUser.id : undefined;
      const report = await db.getPartnerRightsReport(input.periodId, restrictedSystemUserId);
      return { ...report, capabilities: getPartnerRightsCapabilities(ctx.systemUser), linked: ctx.systemUser.userType !== "authorized_partner" || report.partners.length > 0 };
    }),
    management: systemUserProcedure.query(async ({ ctx }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الشركاء والحصص متاحة للمخولين فقط");
      const [partners, periods, users] = await Promise.all([db.getPartners(), db.getFinancialPeriods(), db.getSystemUserDirectory()]);
      return { partners, periods, users };
    }),
    createHistoricalPeriod: systemUserProcedure.input(z.object({
      name: z.string().trim().min(2).max(255), startDate: z.string().datetime({ offset: true }), endDate: z.string().datetime({ offset: true }),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إضافة فترة مالية سابقة متاحة للمخولين بإدارة حقوق الشركاء فقط");
      const startDate = new Date(input.startDate);
      const endDate = new Date(input.endDate);
      if (startDate >= endDate) throw new TRPCError({ code: "BAD_REQUEST", message: "يجب أن يسبق تاريخ بداية الفترة تاريخ نهايتها" });
      const periods = await db.getFinancialPeriods();
      if (periods.some(period => period.name.trim() === input.name.trim())) throw new TRPCError({ code: "CONFLICT", message: "توجد فترة مالية بالاسم نفسه بالفعل" });
      return db.createFinancialPeriod({ name: input.name.trim(), startDate, endDate, isActive: false });
    }),
    entryCatalog: systemUserProcedure.query(async ({ ctx }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canCreateEntries", "إضافة سجلات الشركاء متاحة للمخولين فقط");
      return { partners: await db.getPartners() };
    }),
    createPartner: systemUserProcedure.input(z.object({
      name: z.string().trim().min(2).max(255), systemUserId: z.number().int().positive().nullable().optional(), isActive: z.boolean().optional(),
      profileImageUrl: optionalManagedStorageUrl, profileImageName: optionalAttachmentName, profileImageMimeType: optionalAttachmentMimeType,
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الشركاء متاحة للمخولين فقط");
      return db.createPartner({ ...input, createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
    }),
    updatePartner: systemUserProcedure.input(z.object({
      id: z.number().int().positive(), data: z.object({
        name: z.string().trim().min(2).max(255).optional(), systemUserId: z.number().int().positive().nullable().optional(), isActive: z.boolean().optional(),
        profileImageUrl: optionalManagedStorageUrl, profileImageName: optionalAttachmentName, profileImageMimeType: optionalAttachmentMimeType,
      }),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الشركاء متاحة للمخولين فقط");
      return db.updatePartner(input.id, { ...input.data, updatedBy: ctx.systemUser.id });
    }),
    savePeriodSettings: systemUserProcedure.input(z.object({
      periodId: z.number().int().positive(), openingProfitBalance: z.coerce.number().finite().min(0).max(9999999999999.99),
      distributionDecisionUrl: optionalManagedStorageUrl, distributionDecisionName: optionalAttachmentName, distributionDecisionMimeType: optionalAttachmentMimeType,
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الفترات والحصص متاحة للمخولين فقط");
      return db.upsertPartnerPeriodSettings({ ...input, openingProfitBalance: input.openingProfitBalance.toFixed(2), userId: ctx.systemUser.id });
    }),
    saveAllocation: systemUserProcedure.input(z.object({ periodId: z.number().int().positive(), partnerId: z.number().int().positive(), sharePercentage: shareInput })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الحصص متاحة للمخولين فقط");
      return db.upsertPartnerPeriodAllocation({ ...input, sharePercentage: input.sharePercentage.toFixed(2), userId: ctx.systemUser.id });
    }),
    removeAllocation: systemUserProcedure.input(z.object({ periodId: z.number().int().positive(), partnerId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة الحصص متاحة للمخولين فقط");
      return db.removePartnerPeriodAllocation(input.periodId, input.partnerId);
    }),
    saveMembership: systemUserProcedure.input(z.object({
      periodId: z.number().int().positive(), partnerId: z.number().int().positive(), isIncluded: z.boolean(),
      shareUnits: z.coerce.number().finite().min(0).max(9999999999999.99).nullable().optional(), nominalShareValue: z.coerce.number().finite().min(0).max(9999999999999.99).nullable().optional(),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة عضوية الشركاء التاريخية متاحة للمخولين فقط");
      return db.upsertPartnerPeriodMembership({ ...input, shareUnits: input.shareUnits == null ? null : input.shareUnits.toFixed(2), nominalShareValue: input.nominalShareValue == null ? null : input.nominalShareValue.toFixed(2), userId: ctx.systemUser.id });
    }),
    saveEquityLine: systemUserProcedure.input(z.object({
      id: z.number().int().positive().optional(), periodId: z.number().int().positive(), lineType: z.enum(["opening_balance", "capital", "legal_reserve", "retained_earnings", "profit_distribution", "net_income", "actuarial_remeasurement", "custom"]),
      label: z.string().trim().min(1).max(255), capitalAmount: z.coerce.number().finite().min(-9999999999999.99).max(9999999999999.99), legalReserveAmount: z.coerce.number().finite().min(-9999999999999.99).max(9999999999999.99), retainedEarningsAmount: z.coerce.number().finite().min(-9999999999999.99).max(9999999999999.99), notes: z.string().trim().max(3000).nullable().optional(), sortOrder: z.number().int().min(0).max(10000),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة قائمة التغير في حقوق الشركاء متاحة للمخولين فقط");
      return db.upsertPartnerPeriodEquityLine({ ...input, capitalAmount: input.capitalAmount.toFixed(2), legalReserveAmount: input.legalReserveAmount.toFixed(2), retainedEarningsAmount: input.retainedEarningsAmount.toFixed(2), userId: ctx.systemUser.id });
    }),
    deleteEquityLine: systemUserProcedure.input(z.object({ id: z.number().int().positive(), periodId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "حذف سطر من قائمة التغير في الحقوق متاح للمخولين فقط");
      return db.deletePartnerPeriodEquityLine(input.id, input.periodId);
    }),
    saveDocumentedDistribution: systemUserProcedure.input(z.object({
      periodId: z.number().int().positive(), partnerId: z.number().int().positive(), distributionAmount: z.coerce.number().finite().min(0).max(9999999999999.99), distributionDate: z.string().datetime({ offset: true }).nullable().optional(), statement: z.string().trim().max(3000).nullable().optional(), attachmentUrl: optionalManagedStorageUrl, attachmentName: optionalAttachmentName, attachmentMimeType: optionalAttachmentMimeType,
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "توثيق توزيعات الشركاء متاح للمخولين بإدارة حقوق الشركاء فقط");
      return db.upsertPartnerProfitDistribution({ ...input, distributionAmount: input.distributionAmount.toFixed(2), distributionDate: input.distributionDate ? new Date(input.distributionDate) : null, userId: ctx.systemUser.id });
    }),
    createPeriodDocument: systemUserProcedure.input(z.object({
      periodId: z.number().int().positive(), documentType: z.enum(["distribution_minutes", "year_end_settlement", "financial_statements", "custom"]), title: z.string().trim().min(1).max(255), attachmentUrl: managedStorageUrl, attachmentName: z.string().trim().min(1).max(255), attachmentMimeType: z.string().trim().min(1).max(100), notes: z.string().trim().max(3000).nullable().optional(), sortOrder: z.number().int().min(0).max(10000),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة مرفقات الفترة السنوية متاحة للمخولين فقط");
      return db.createPartnerPeriodDocument({ ...input, userId: ctx.systemUser.id });
    }),
    updatePeriodDocument: systemUserProcedure.input(z.object({
      id: z.number().int().positive(), data: z.object({ periodId: z.number().int().positive(), documentType: z.enum(["distribution_minutes", "year_end_settlement", "financial_statements", "custom"]), title: z.string().trim().min(1).max(255), attachmentUrl: managedStorageUrl, attachmentName: z.string().trim().min(1).max(255), attachmentMimeType: z.string().trim().min(1).max(100), notes: z.string().trim().max(3000).nullable().optional(), sortOrder: z.number().int().min(0).max(10000) }),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "إدارة مرفقات الفترة السنوية متاحة للمخولين فقط");
      return db.updatePartnerPeriodDocument(input.id, { ...input.data, userId: ctx.systemUser.id });
    }),
    deletePeriodDocument: systemUserProcedure.input(z.object({ id: z.number().int().positive(), periodId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canManage", "حذف مرفق الفترة السنوية متاح للمخولين فقط");
      return db.deletePartnerPeriodDocument(input.id, input.periodId);
    }),
    createEntry: systemUserProcedure.input(z.object({
      periodId: z.number().int().positive(), partnerId: z.number().int().positive(), entryType: z.enum(["withdrawal", "entitlement", "year_end_settlement"]), settlementDirection: z.enum(["credit", "debit"]).nullable().optional(), amount: moneyInput,
      entryDate: z.string().datetime({ offset: true }), statement: z.string().trim().min(2).max(3000), attachmentUrl: optionalManagedStorageUrl, attachmentName: optionalAttachmentName, attachmentMimeType: optionalAttachmentMimeType,
    }).superRefine((value, refinement) => {
      if (value.entryType === "year_end_settlement" && !value.settlementDirection) refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["settlementDirection"], message: "يلزم تحديد اتجاه التسوية" });
      if (value.entryType !== "year_end_settlement" && value.settlementDirection) refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["settlementDirection"], message: "اتجاه التسوية خاص بتسوية نهاية العام" });
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canCreateEntries", "إضافة سجل شريك متاحة للمخولين فقط");
      return db.createPartnerAccountEntry({ ...input, amount: input.amount.toFixed(2), entryDate: new Date(input.entryDate), createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
    }),
    updateEntry: systemUserProcedure.input(z.object({
      id: z.number().int().positive(), data: z.object({
        entryType: z.enum(["withdrawal", "entitlement", "year_end_settlement"]), settlementDirection: z.enum(["credit", "debit"]).nullable().optional(), amount: moneyInput,
        entryDate: z.string().datetime({ offset: true }), statement: z.string().trim().min(2).max(3000), attachmentUrl: optionalManagedStorageUrl, attachmentName: optionalAttachmentName, attachmentMimeType: optionalAttachmentMimeType,
      }).superRefine((value, refinement) => {
        if (value.entryType === "year_end_settlement" && !value.settlementDirection) refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["settlementDirection"], message: "يلزم تحديد اتجاه التسوية" });
        if (value.entryType !== "year_end_settlement" && value.settlementDirection) refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["settlementDirection"], message: "اتجاه التسوية خاص بتسوية نهاية العام" });
      }),
    })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canEditEntries", "تعديل سجل الشريك متاح للمخولين فقط");
      return db.updatePartnerAccountEntry(input.id, { ...input.data, amount: input.data.amount.toFixed(2), entryDate: new Date(input.data.entryDate), updatedBy: ctx.systemUser.id });
    }),
    deleteEntry: systemUserProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requirePartnerRightsCapability(ctx.systemUser, "canEditEntries", "حذف سجل الشريك متاح للمخولين فقط");
      return db.deletePartnerAccountEntry(input.id);
    }),
  }),

  // Receipts
  receipts: router({
    list: systemUserProcedure.input(z.object({
      branchId: z.number().optional(), userId: z.number().optional(), periodId: z.number().optional(), customerId: z.number().optional(),
      status: z.enum(["draft", "issued", "approved", "rejected"]).optional(), paymentMethodId: z.number().optional(), serialNumber: z.string().optional(),
      startDate: z.date().optional(), endDate: z.date().optional(),
    }).optional()).query(async ({ input, ctx }) => {
      if (isSecondarySystemUser(ctx.systemUser)) return db.getReceipts({ ...input, userId: ctx.systemUser.id });
      return db.getReceipts(input || undefined);
    }),
    getById: systemUserProcedure.input(z.object({ id: z.number() })).query(async ({ input, ctx }) => {
      const receipt = await db.getReceiptById(input.id);
      if (receipt && isSecondarySystemUser(ctx.systemUser) && receipt.userId !== ctx.systemUser.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك الاطلاع على سند مستخدم آخر" });
      }
      return receipt;
    }),
    create: systemUserProcedure.input(z.object({ branchId: z.number(), userId: z.number().optional(), customerId: z.number(), customerStatement: z.string().trim().max(300).optional(), amount: z.string(), amountInWords: z.string().optional(), paymentMethodId: z.number().optional(), bankId: z.number().optional(), paymentForId: z.number().optional(), attachmentUrl: z.string().optional(), notes: z.string().optional(), customFields: z.record(z.string(), z.string().max(500)).optional(), periodId: z.number().optional(), status: z.enum(["draft", "issued", "approved", "rejected"]).optional(), invoices: z.array(z.object({ invoiceNumber: z.string(), invoiceAmount: z.string() })).optional() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      const status = isSecondarySystemUser(ctx.systemUser) && input.status !== "draft" ? "issued" : (input.status || "draft");
      const paymentMethod = input.paymentMethodId ? await db.getInputListById(input.paymentMethodId) : null;
      if (input.paymentMethodId && (!paymentMethod || paymentMethod.listType !== "payment_method" || !paymentMethod.isActive)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "طريقة الدفع المختارة غير متاحة" });
      }
      if (status !== "draft" && !isCashPaymentMethod(paymentMethod) && !input.attachmentUrl) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "إيصال التحويل مطلوب قبل اعتماد سند القبض" });
      }
      const customer = await db.getCustomerById(input.customerId);
      if (!customer) throw new TRPCError({ code: "NOT_FOUND", message: "العميل غير موجود" });
      if (isSecondarySystemUser(ctx.systemUser) && customer.delegateId !== userId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك إصدار سند لعميل غير مرتبط بحسابك" });
      }
      const { invoices = [], customFields, ...receiptData } = input;
      const serializedCustomFields = await serializeReceiptCustomFields(customFields);
      const branchId = isSecondarySystemUser(ctx.systemUser) && ctx.systemUser.branchId ? ctx.systemUser.branchId : receiptData.branchId;
      const created = await db.createReceiptWithInvoices({ ...receiptData, customFields: serializedCustomFields, status, branchId, userId, createdBy: userId, updatedBy: userId }, invoices);
      if (created && status === "issued") {
        await db.createReceiptIssuedNotifications({ receiptId: created.id, serialNumber: created.serialNumber, issuerName: ctx.systemUser.fullName });
      }
      return created;
    }),
    update: systemUserProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      const receipt = await db.getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "السند غير موجود" });
      if (isSecondarySystemUser(ctx.systemUser) && receipt.userId !== userId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك تعديل سند مستخدم آخر" });
      }
      const { invoices, customFields, ...receiptData } = input.data || {};
      const hasCustomFields = Object.prototype.hasOwnProperty.call(input.data || {}, "customFields");
      const serializedCustomFields = hasCustomFields ? await serializeReceiptCustomFields(customFields) : undefined;
      const status = isSecondarySystemUser(ctx.systemUser) && receiptData.status !== "draft"
        ? "issued"
        : receiptData.status;
      const effectivePaymentMethodId = receiptData.paymentMethodId ?? receipt.paymentMethodId;
      const paymentMethod = effectivePaymentMethodId ? await db.getInputListById(effectivePaymentMethodId) : null;
      if (effectivePaymentMethodId && (!paymentMethod || paymentMethod.listType !== "payment_method" || !paymentMethod.isActive)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "طريقة الدفع المختارة غير متاحة" });
      }
      const effectiveStatus = status || receipt.status;
      const effectiveAttachmentUrl = receiptData.attachmentUrl ?? receipt.attachmentUrl;
      if (effectiveStatus !== "draft" && !isCashPaymentMethod(paymentMethod) && !effectiveAttachmentUrl) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "إيصال التحويل مطلوب قبل إصدار أو اعتماد سند القبض" });
      }
      if (Array.isArray(invoices)) {
        return db.updateReceiptWithInvoices(input.id, { ...receiptData, ...(hasCustomFields ? { customFields: serializedCustomFields } : {}), status, updatedBy: userId }, invoices);
      }
      return db.updateReceipt(input.id, { ...receiptData, ...(hasCustomFields ? { customFields: serializedCustomFields } : {}), status, updatedBy: userId });
    }),
    decide: systemUserProcedure.input(z.object({ id: z.number(), decision: z.enum(["approved", "rejected"]), note: z.string().trim().max(1000).optional() }).superRefine((input, refinement) => {
      if (input.decision === "rejected" && !input.note) {
        refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["note"], message: "سبب رفض سند القبض مطلوب" });
      }
    })).mutation(async ({ input, ctx }) => {
      if (!canApproveReceipts(ctx.systemUser)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية اعتماد أو رفض سندات القبض" });
      }
      const receipt = await db.getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "السند غير موجود" });
      if (receipt.status !== "issued") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "يمكن اعتماد أو رفض السندات التي تم إصدارها فقط" });
      }
      return db.decideReceiptWithAudit({ receiptId: input.id, decision: input.decision, decidedBy: ctx.systemUser.id, note: input.note });
    }),
    approveBatch: systemUserProcedure.input(z.object({
      ids: z.array(z.number().int().positive()).min(1).max(100),
      note: z.string().trim().max(1000).optional(),
    }).superRefine((input, refinement) => {
      if (new Set(input.ids).size !== input.ids.length) {
        refinement.addIssue({ code: z.ZodIssueCode.custom, path: ["ids"], message: "لا يمكن تكرار السند ضمن الاعتماد الجماعي" });
      }
    })).mutation(async ({ input, ctx }) => {
      if (!canApproveReceipts(ctx.systemUser)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية اعتماد سندات القبض" });
      }
      return db.approveReceiptsWithAudit({ receiptIds: input.ids, decidedBy: ctx.systemUser.id, note: input.note });
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteReceipt(input.id);
    }),
    addInvoice: systemUserProcedure.input(z.object({ receiptId: z.number(), invoiceNumber: z.string(), invoiceAmount: z.string() })).mutation(async ({ input, ctx }) => {
      const receipt = await db.getReceiptById(input.receiptId);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "السند غير موجود" });
      if (isSecondarySystemUser(ctx.systemUser) && receipt.userId !== ctx.systemUser.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك إضافة فاتورة لسند مستخدم آخر" });
      }
      return db.createReceiptInvoice(input);
    }),
  }),

  notifications: router({
    list: systemUserProcedure.input(z.object({ unreadOnly: z.boolean().optional() }).optional()).query(({ input, ctx }) =>
      db.getInternalNotifications(ctx.systemUser.id, input?.unreadOnly)),
    markRead: systemUserProcedure.input(z.object({ id: z.number() })).mutation(({ input, ctx }) =>
      db.markInternalNotificationRead(input.id, ctx.systemUser.id)),
    markAllRead: systemUserProcedure.mutation(({ ctx }) => db.markAllInternalNotificationsRead(ctx.systemUser.id)),
  }),

  receiptAudit: router({
    list: systemUserProcedure.input(z.object({ receiptId: z.number().optional() }).optional()).query(async ({ input, ctx }) => {
      if (!canApproveReceipts(ctx.systemUser)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية الاطلاع على سجل قرارات السندات" });
      }
      return db.getReceiptDecisionAudit(input?.receiptId);
    }),
  }),

  receiptPrintAudit: router({
    list: systemUserProcedure.input(z.object({ receiptId: z.number() })).query(async ({ input, ctx }) => {
      const receipt = await db.getReceiptById(input.receiptId);
      if (!receipt) throw new TRPCError({ code: 'NOT_FOUND', message: 'السند غير موجود' });
      if (isSecondarySystemUser(ctx.systemUser) && receipt.userId !== ctx.systemUser.id) throw new TRPCError({ code: 'FORBIDDEN', message: 'لا تملك صلاحية الاطلاع على سجل طباعة هذا السند' });
      return db.getReceiptPrintAudit(input.receiptId);
    }),
    record: systemUserProcedure.input(z.object({ receiptId: z.number(), printType: z.enum(['receipt', 'receipt_with_attachment']) })).mutation(async ({ input, ctx }) => {
      const receipt = await db.getReceiptById(input.receiptId);
      if (!receipt) throw new TRPCError({ code: 'NOT_FOUND', message: 'السند غير موجود' });
      if (isSecondarySystemUser(ctx.systemUser) && receipt.userId !== ctx.systemUser.id) throw new TRPCError({ code: 'FORBIDDEN', message: 'لا تملك صلاحية طباعة هذا السند' });
      await db.recordReceiptPrint({ ...input, userId: ctx.systemUser.id });
      return { success: true };
    }),
  }),

  dataAdministration: router({
    previewOperationalClear: systemAdminProcedure.query(() => db.getOperationalDataCounts()),
    clearOperationalData: systemAdminProcedure.input(z.object({ password: z.string().min(1), confirmation: z.literal("حذف البيانات التشغيلية") })).mutation(async ({ input, ctx }) => {
      const validPassword = await db.verifySystemUserPassword(ctx.systemUser.id, input.password);
      if (!validPassword) {
        throw new TRPCError({ code: "FORBIDDEN", message: "كلمة المرور غير صحيحة؛ لم يتم حذف أي بيانات" });
      }
      await db.clearOperationalData(ctx.systemUser.id);
      return { success: true };
    }),
    previewSelectiveClear: systemUserProcedure.query(({ ctx }) => {
      requireOperationalDataDeletion(ctx.systemUser);
      return db.getOperationalDataCounts();
    }),
    clearSelectedOperationalData: systemUserProcedure.input(z.object({
      password: z.string().min(1),
      confirmation: z.literal("حذف البيانات المحددة"),
      scopes: z.array(z.enum(["vouchers", "customers", "targets"])).min(1),
    })).mutation(async ({ input, ctx }) => {
      requireOperationalDataDeletion(ctx.systemUser);
      const validPassword = await db.verifySystemUserPassword(ctx.systemUser.id, input.password);
      if (!validPassword) throw new TRPCError({ code: "FORBIDDEN", message: "كلمة المرور غير صحيحة؛ لم يتم حذف أي بيانات" });
      try {
        await db.clearSelectedOperationalData(ctx.systemUser.id, input.scopes);
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "تعذر تنفيذ الحذف الانتقائي" });
      }
      return { success: true };
    }),
  }),

  backups: router({
    list: systemAdminProcedure.query(() => db.getBackupLogs()),
    downloadFull: systemAdminProcedure.mutation(async ({ ctx }) => {
      const data = await db.createFullSystemBackup();
      const fileName = createSystemBackupFileName();
      const recordsCount = getSystemBackupRecordCount(data);
      const files = await captureSystemBackupFiles(data);
      await db.createBackupLog({
        operation: 'download', fileName, recordsCount, userId: ctx.systemUser.id,
        details: `نسخة كاملة تشمل ${files.length} ملفاً مرفقاً وجميع بيانات وإعدادات النظام`,
      });
      return { fileName, payload: { format: SYSTEM_BACKUP_FORMAT, version: SYSTEM_BACKUP_VERSION, exportedAt: new Date().toISOString(), data, files } };
    }),
    restoreFull: systemAdminProcedure.input(z.object({
      password: z.string().min(1),
      confirmation: z.literal('استيراد النسخة الاحتياطية الكاملة'),
      fileName: z.string().min(1).max(255),
      payload: z.object({
        format: z.literal(SYSTEM_BACKUP_FORMAT),
        version: z.literal(SYSTEM_BACKUP_VERSION),
        exportedAt: z.string(),
        files: z.array(z.object({ sourceUrl: z.string().min(1), contentType: z.string().min(1), dataBase64: z.string().min(1) })),
        data: z.object({
          users: z.array(z.record(z.string(), z.unknown())), systemUsers: z.array(z.record(z.string(), z.unknown())),
          systemSettings: z.array(z.record(z.string(), z.unknown())), companyProfile: z.array(z.record(z.string(), z.unknown())),
          regions: z.array(z.record(z.string(), z.unknown())), branches: z.array(z.record(z.string(), z.unknown())),
          financialPeriods: z.array(z.record(z.string(), z.unknown())), branchTargets: z.array(z.record(z.string(), z.unknown())),
          partners: z.array(z.record(z.string(), z.unknown())).default([]), partnerPeriodSettings: z.array(z.record(z.string(), z.unknown())).default([]),
          partnerPeriodAllocations: z.array(z.record(z.string(), z.unknown())).default([]), partnerPeriodMemberships: z.array(z.record(z.string(), z.unknown())).default([]),
          partnerPeriodEquityLines: z.array(z.record(z.string(), z.unknown())).default([]), partnerProfitDistributions: z.array(z.record(z.string(), z.unknown())).default([]),
          partnerPeriodDocuments: z.array(z.record(z.string(), z.unknown())).default([]), partnerAccountEntries: z.array(z.record(z.string(), z.unknown())).default([]),
          goalTypes: z.array(z.record(z.string(), z.unknown())).default([]), administrativeGoals: z.array(z.record(z.string(), z.unknown())).default([]),
          administrativeGoalReviewers: z.array(z.record(z.string(), z.unknown())).default([]), administrativeGoalActions: z.array(z.record(z.string(), z.unknown())).default([]),
          administrativeGoalActionAttachments: z.array(z.record(z.string(), z.unknown())).default([]), salesGoalPlans: z.array(z.record(z.string(), z.unknown())).default([]),
          salesGoalMetrics: z.array(z.record(z.string(), z.unknown())).default([]), commissionPlans: z.array(z.record(z.string(), z.unknown())).default([]),
          commissionTiers: z.array(z.record(z.string(), z.unknown())).default([]),
          customers: z.array(z.record(z.string(), z.unknown())), inputLists: z.array(z.record(z.string(), z.unknown())),
          receipts: z.array(z.record(z.string(), z.unknown())), receiptInvoices: z.array(z.record(z.string(), z.unknown())),
          payments: z.array(z.record(z.string(), z.unknown())), performanceReports: z.array(z.record(z.string(), z.unknown())),
          delegates: z.array(z.record(z.string(), z.unknown())), documentTypes: z.array(z.record(z.string(), z.unknown())),
          approvalRequests: z.array(z.record(z.string(), z.unknown())), newsItems: z.array(z.record(z.string(), z.unknown())),
          loginBackgrounds: z.array(z.record(z.string(), z.unknown())), activityLog: z.array(z.record(z.string(), z.unknown())),
          internalNotifications: z.array(z.record(z.string(), z.unknown())), receiptDecisionAudit: z.array(z.record(z.string(), z.unknown())),
          backupLogs: z.array(z.record(z.string(), z.unknown())),
        }),
      }),
    })).mutation(async ({ input, ctx }) => {
      const validPassword = await db.verifySystemUserPassword(ctx.systemUser.id, input.password);
      if (!validPassword) throw new TRPCError({ code: 'FORBIDDEN', message: 'كلمة المرور غير صحيحة؛ لم يتم استيراد أي بيانات' });
      const recordsCount = getSystemBackupRecordCount(input.payload.data);
      try {
        const fileUrlMap = await restoreSystemBackupFiles(input.payload.files);
        await db.restoreFullSystemBackup(relinkManagedStorageUrls(input.payload.data, fileUrlMap) as db.SystemBackupData);
        await db.createBackupLog({
          operation: 'restore', fileName: input.fileName, recordsCount, userId: ctx.systemUser.id,
          details: `استيراد نسخة كاملة تضم ${input.payload.files.length} ملفاً وتم تصديرها في ${input.payload.exportedAt}`,
        });
        return { success: true, recordsCount };
      } catch (error) {
        await db.createBackupLog({
          operation: 'restore', fileName: input.fileName, recordsCount, userId: ctx.systemUser.id, status: 'failed',
          details: error instanceof Error ? error.message : 'تعذر استيراد النسخة الاحتياطية',
        });
        throw new TRPCError({ code: 'BAD_REQUEST', message: 'تعذر استيراد النسخة الاحتياطية؛ لم يتم تطبيق تغييرات جزئية' });
      }
    }),
  }),

  // Payments
  payments: router({
    list: publicProcedure.input(z.object({ branchId: z.number().optional(), userId: z.number().optional(), periodId: z.number().optional() }).optional()).query(async ({ input }) => {
      return db.getPayments(input || undefined);
    }),
    create: systemAdminProcedure.input(z.object({ branchId: z.number(), userId: z.number(), beneficiary: z.string(), amount: z.string(), amountInWords: z.string().optional(), expenseCategory: z.string().optional(), paymentMethodId: z.number().optional(), bankId: z.number().optional(), description: z.string().optional(), attachmentUrl: z.string().optional(), notes: z.string().optional(), periodId: z.number().optional(), status: z.enum(["draft", "approved"]).optional() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      return db.createPayment({ ...input, createdBy: userId, updatedBy: userId });
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input, ctx }) => {
      const userId = ctx.systemUser.id;
      return db.updatePayment(input.id, { ...input.data, updatedBy: userId });
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deletePayment(input.id);
    }),
  }),

  // Delegates
  delegates: router({
    list: publicProcedure.query(async () => db.getDelegates()),
    create: systemAdminProcedure.input(z.object({ name: z.string(), position: z.string().optional(), username: z.string(), password: z.string() })).mutation(async ({ input }) => {
      return db.createDelegate(input);
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input }) => {
      return db.updateDelegate(input.id, input.data);
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteDelegate(input.id);
    }),
  }),

  // Document Types
  documentTypes: router({
    list: publicProcedure.query(async () => db.getDocumentTypes()),
    create: systemAdminProcedure.input(z.object({ name: z.string().trim().min(1), description: z.string().optional(), templateRequirement: z.enum(['optional', 'required']).default('optional'), templateUrl: z.string().optional(), templateName: z.string().optional(), templateMimeType: z.string().optional() })).mutation(async ({ input }) => {
      return db.createDocumentType(input);
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), name: z.string().trim().min(1).optional(), description: z.string().optional(), templateRequirement: z.enum(['optional', 'required']).optional(), templateUrl: z.string().nullable().optional(), templateName: z.string().nullable().optional(), templateMimeType: z.string().nullable().optional(), isActive: z.boolean().optional() })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return db.updateDocumentType(id, data);
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      return db.deleteDocumentTypeWithWorkflow(input.id);
    }),
  }),

  approvalWorkflows: router({
    list: systemAdminProcedure.query(async () => db.getApprovalWorkflows()),
    save: systemAdminProcedure.input(z.object({
      documentTypeId: z.number().int().positive(),
      reviewerUserIds: z.array(z.number().int().positive()).default([]),
      reviewerSequential: z.boolean().default(false),
      approverUserIds: z.array(z.number().int().positive()).min(1),
      approverSequential: z.boolean().default(false),
      requiredApprovals: z.number().int().min(1),
    })).mutation(async ({ input }) => {
      await db.saveApprovalWorkflow(input);
      return { success: true };
    }),
  }),

  // Approval Requests
  approvals: router({
    list: systemUserProcedure.input(z.object({ delegateId: z.number().optional(), status: z.string().optional(), requestedBy: z.number().optional() }).optional()).query(async ({ ctx, input }) => {
      const requests = await db.getApprovalRequests(input || undefined);
      return requests.map(request => {
        const attachmentAllowed = canAccessApprovalAttachment(request, ctx.systemUser);
        return {
          ...request,
          hasAttachment: Boolean(request.attachmentUrl),
          attachmentUrl: attachmentAllowed ? request.attachmentUrl : null,
          attachmentName: attachmentAllowed ? request.attachmentName : null,
        };
      });
    }),
    createDraft: systemUserProcedure.input(z.object({ documentTypeId: z.number(), title: z.string().optional(), description: z.string().optional() })).mutation(async ({ ctx, input }) => {
      if (!canRequestApproval(ctx.systemUser)) throw new TRPCError({ code: 'FORBIDDEN', message: 'لا تملك صلاحية طلب التعميد' });
      return db.createApprovalDraftFromWorkflow({ ...input, requestedBy: ctx.systemUser.id });
    }),
    attachDraft: systemUserProcedure.input(z.object({ requestId: z.number(), attachmentUrl: z.string().min(1), attachmentName: z.string().min(1) })).mutation(async ({ ctx, input }) => {
      const request = (await db.getApprovalRequests({ requestedBy: ctx.systemUser.id })).find(item => item.id === input.requestId);
      if (!request?.approvalNumber) throw new TRPCError({ code: "NOT_FOUND", message: "لم يتم العثور على مسودة طلب التعميد" });

      const mimeType = getApprovalAttachmentMimeType(input.attachmentName);
      if (!mimeType) return db.attachApprovalDraft({ ...input, requesterId: ctx.systemUser.id });

      const storageKey = getManagedStorageKey(input.attachmentUrl);
      if (!storageKey) throw new TRPCError({ code: "BAD_REQUEST", message: "مسار مرفق طلب التعميد غير صالح" });

      try {
        const response = await fetch(await storageGetSignedUrl(storageKey));
        if (!response.ok) throw new Error("فشل قراءة المرفق");
        const stampedFile = await stampApprovalTemplate({
          file: Buffer.from(await response.arrayBuffer()),
          mimeType,
          approvalNumber: request.approvalNumber,
        });
        const safeFileName = input.attachmentName.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "approval-request";
        const { url } = await storagePut(
          `approval-attachments/${ctx.systemUser.id}/${Date.now()}-${request.approvalNumber}-${safeFileName}`,
          stampedFile,
          mimeType,
        );
        return db.attachApprovalDraft({ requestId: input.requestId, attachmentUrl: url, attachmentName: `${request.approvalNumber}-${input.attachmentName}`, requesterId: ctx.systemUser.id });
      } catch (error) {
        console.error("[Approvals] Failed to stamp attachment", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر ختم مرفق طلب التعميد برقم الطلب" });
      }
    }),
    submitDraft: systemUserProcedure.input(z.object({ requestId: z.number() })).mutation(async ({ ctx, input }) => {
      return db.submitApprovalDraft({ ...input, requesterId: ctx.systemUser.id });
    }),
    review: systemUserProcedure.input(z.object({ requestId: z.number(), decision: z.enum(['approved', 'rejected']), note: z.string().optional() })).mutation(async ({ ctx, input }) => {
      return db.reviewApprovalRequest({ ...input, reviewerId: ctx.systemUser.id });
    }),
    downloadTemplate: systemUserProcedure.input(z.object({ requestId: z.number() })).query(async ({ ctx, input }) => {
      const requests = await db.getApprovalRequests({ requestedBy: ctx.systemUser.id });
      const request = requests.find(item => item.id === input.requestId);
      if (!request?.documentTypeId || !request.approvalNumber) throw new TRPCError({ code: 'NOT_FOUND', message: 'نموذج طلب التعميد غير متاح' });
      const documentType = (await db.getDocumentTypes()).find(item => item.id === request.documentTypeId);
      if (!documentType?.templateUrl || !documentType.templateMimeType) throw new TRPCError({ code: 'NOT_FOUND', message: 'لم يرفع مدير النظام نموذجاً لهذا النوع' });
      const storageKey = documentType.templateUrl.replace(/^\/manus-storage\//, '');
      const response = await fetch(await storageGetSignedUrl(storageKey));
      if (!response.ok) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'تعذر تحميل نموذج التعميد' });
      const sourceFile = Buffer.from(await response.arrayBuffer());
      if (documentType.templateMimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
        return { dataUrl: `data:${documentType.templateMimeType};base64,${sourceFile.toString('base64')}`, fileName: documentType.templateName || `${request.approvalNumber}.xlsx` };
      }
      const output = await stampApprovalTemplate({ file: sourceFile, mimeType: documentType.templateMimeType, approvalNumber: request.approvalNumber });
      return { dataUrl: `data:${documentType.templateMimeType};base64,${output.toString('base64')}`, fileName: getApprovalTemplateOutputName(request.approvalNumber, documentType.templateMimeType) };
    }),
    downloadAttachment: systemUserProcedure.input(z.object({ requestId: z.number() })).query(async ({ ctx, input }) => {
      const request = (await db.getApprovalRequests()).find(item => item.id === input.requestId);
      if (!request?.attachmentUrl) throw new TRPCError({ code: 'NOT_FOUND', message: 'لا يوجد نموذج مرفق لهذا الطلب' });
      if (!canAccessApprovalAttachment(request, ctx.systemUser)) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'لا تملك صلاحية الاطلاع على مرفق هذا الطلب' });
      }
      const storageKey = request.attachmentUrl.replace(/^\/manus-storage\//, '');
      return {
        url: await storageGetSignedUrl(storageKey),
        fileName: request.attachmentName || `${request.approvalNumber || 'طلب-تعميد'}-مرفق`,
      };
    }),
    create: systemUserProcedure.input(z.object({ documentTypeId: z.number(), title: z.string().min(1), description: z.string().optional(), attachmentUrl: z.string().optional() })).mutation(async ({ ctx, input }) => {
      if (!canRequestApproval(ctx.systemUser)) throw new TRPCError({ code: 'FORBIDDEN', message: 'لا تملك صلاحية طلب التعميد' });
      return db.createApprovalRequestFromWorkflow({ ...input, requestedBy: ctx.systemUser.id });
    }),
    decide: systemUserProcedure.input(z.object({ requestId: z.number(), decision: z.enum(['approved', 'rejected']), note: z.string().trim().max(2000).optional() })).mutation(async ({ ctx, input }) => {
      const result = await db.decideApprovalRequestStep({ ...input, systemUserId: ctx.systemUser.id });

      if (input.decision !== 'approved') return result;
      const [settings, requests] = await Promise.all([db.getSettings(), db.getApprovalRequests()]);
      const request = requests.find(item => item.id === input.requestId);
      const mimeType = request?.attachmentName ? getApprovalAttachmentMimeType(request.attachmentName) : null;
      const footerEnabled = settings.approval_footer_enabled !== 'false';
      if (!footerEnabled || !request?.attachmentUrl || !mimeType) return result;

      const storageKey = getManagedStorageKey(request.attachmentUrl);
      if (!storageKey) return result;
      try {
        const response = await fetch(await storageGetSignedUrl(storageKey));
        if (!response.ok) throw new Error('فشل قراءة مرفق التعميد لختم الاعتماد');
        const signatures = request.steps
          .filter(step => step.status === 'approved' && step.actedAt)
          .map(step => ({ name: step.approverName, actedAt: step.actedAt as Date | string }));
        const stampedFile = await stampApprovalDecisionFooter({
          file: Buffer.from(await response.arrayBuffer()),
          mimeType,
          signatures,
          options: {
            enabled: footerEnabled,
            height: Number(settings.approval_footer_height || 66),
            fontSize: Number(settings.approval_footer_font_size || 8),
            color: settings.approval_footer_color || '#0f5132',
            label: settings.approval_footer_label || 'تم التعميد',
          },
        });
        const safeFileName = (request.attachmentName || 'approval-request').replace(/[^a-zA-Z0-9._-]/g, '-').replace(/-+/g, '-').replace(/^[-.]+|[-.]+$/g, '') || 'approval-request';
        const { url } = await storagePut(
          `approval-attachments/${request.requestedBy}/${Date.now()}-${request.approvalNumber || request.id}-signed-${safeFileName}`,
          stampedFile,
          mimeType,
        );
        await db.updateApprovalRequest(request.id, { attachmentUrl: url });
      } catch (error) {
        console.error('[Approvals] Failed to add approval footer', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'تم حفظ قرار الموافقة، لكن تعذر ختم المرفق بتذييل التعميد' });
      }
      return result;
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input }) => {
      return db.updateApprovalRequest(input.id, input.data);
    }),
    purgeHistory: systemAdminProcedure.input(z.object({ confirmation: z.literal('حذف سجل طلبات التعميد') })).mutation(async () => {
      return db.deleteApprovalHistory();
    }),
  }),

  // News Items
  news: router({
    list: publicProcedure.query(async () => db.getNewsItems()),
    create: systemAdminProcedure.input(z.object({ content: z.string(), speed: z.number().optional(), sortOrder: z.number().optional() })).mutation(async ({ input }) => {
      return db.createNewsItem(input);
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), data: z.any() })).mutation(async ({ input }) => {
      return db.updateNewsItem(input.id, input.data);
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteNewsItem(input.id);
    }),
  }),

  // Login Backgrounds
  backgrounds: router({
    list: publicProcedure.query(async () => db.getLoginBackgrounds()),
    create: systemAdminProcedure.input(z.object({ imageUrl: managedStorageUrl, sortOrder: z.number().optional() })).mutation(async ({ input }) => {
      return db.createLoginBackground(input);
    }),
    update: systemAdminProcedure.input(z.object({ id: z.number(), imageUrl: managedStorageUrl })).mutation(async ({ input }) => {
      return db.updateLoginBackground(input.id, { imageUrl: input.imageUrl });
    }),
    delete: systemAdminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      return db.deleteLoginBackground(input.id);
    }),
  }),

  // Reports
  reports: router({
    receiptsSummary: publicProcedure.input(z.object({ periodId: z.number() })).query(async ({ input }) => {
      return db.getReceiptsSummary(input.periodId);
    }),
    receiptsByUser: publicProcedure.input(z.object({ userId: z.number(), periodId: z.number() })).query(async ({ input }) => {
      return db.getReceiptsByUser(input.userId, input.periodId);
    }),
    bankCollections: systemUserProcedure.input(z.object({
      periodId: z.number().optional(),
      bankId: z.number().optional(),
      startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    })).query(async ({ input }) => db.getBankCollectionsByPeriod(input)),
  }),

  // Daily branch performance reports
  performanceReports: router({
    list: systemUserProcedure.query(async ({ ctx }) => {
      if (isPerformanceManager(ctx.systemUser)) return db.getPerformanceReports();
      if (!ctx.systemUser.branchId) return [];
      return db.getPerformanceReports({ branchId: ctx.systemUser.branchId });
    }),
    dailyMetrics: systemUserProcedure.input(z.object({ branchId: z.number(), reportDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "صيغة التاريخ غير صحيحة") })).query(async ({ input, ctx }) => {
      if (!isPerformanceManager(ctx.systemUser) && ctx.systemUser.branchId !== input.branchId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك الاطلاع على بيانات فرع آخر" });
      }
      return db.getDailyReceiptMetrics(input.branchId, input.reportDate);
    }),
    save: systemUserProcedure.input(z.object({
      branchId: z.number(),
      reportDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "صيغة التاريخ غير صحيحة"),
      salesInvoicesCount: z.coerce.number().int().min(0),
      salesInvoicesValue: z.coerce.number().min(0),
      returnsInvoicesCount: z.coerce.number().int().min(0),
      returnsInvoicesValue: z.coerce.number().min(0),
    })).mutation(async ({ input, ctx }) => {
      const isManager = isPerformanceManager(ctx.systemUser);
      if (!isManager && ctx.systemUser.branchId !== input.branchId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا يمكنك إنشاء تقرير لفرع آخر" });
      }

      const existing = await db.getPerformanceReport(input.branchId, input.reportDate);
      const today = new Date().toISOString().slice(0, 10);
      if (existing && !isManager && input.reportDate !== today && !canEditPastPerformanceReports(ctx.systemUser.permissions)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية تعديل تقرير سابق" });
      }

      const metrics = await db.getDailyReceiptMetrics(input.branchId, input.reportDate);
      const netSalesValue = (input.salesInvoicesValue - input.returnsInvoicesValue).toFixed(2);
      const reportData = {
        branchId: input.branchId,
        reportDate: new Date(`${input.reportDate}T00:00:00.000Z`),
        salesInvoicesCount: input.salesInvoicesCount,
        salesInvoicesValue: input.salesInvoicesValue.toFixed(2),
        returnsInvoicesCount: input.returnsInvoicesCount,
        returnsInvoicesValue: input.returnsInvoicesValue.toFixed(2),
        netSalesValue,
        receiptsCount: metrics.receiptsCount,
        collectionsValue: metrics.collectionsValue,
        updatedBy: ctx.systemUser.id,
      };

      if (existing) {
        await db.updatePerformanceReport(existing.id, reportData);
        return { mode: "updated" as const, report: { ...reportData, id: existing.id } };
      }
      await db.createPerformanceReport({ ...reportData, createdBy: ctx.systemUser.id });
      return { mode: "created" as const, report: reportData };
    }),
  }),

  // Backup & Export
  backup: router({
    exportData: systemAdminProcedure.query(async () => {
      const customers = await db.getCustomers({});
      const branches = await db.getBranches();
      const receipts = await db.getReceipts({});
      const payments = await db.getPayments({});
      const users = await db.getAllSystemUsers();
      return {
        exportDate: new Date().toISOString(),
        data: { customers, branches, receipts, payments, users: users.map(u => ({ ...u, password: undefined })) }
      };
    }),
    importCustomers: systemAdminProcedure.input(z.object({ customers: z.array(z.object({ customerNumber: z.string(), name: z.string(), phone: z.string().optional() })) })).mutation(async ({ input, ctx }) => {
      let imported = 0;
      let failed = 0;
      for (const c of input.customers) {
        try {
          const existing = await db.getCustomerByNumber(c.customerNumber);
          if (!existing) {
            await db.createCustomer({ customerNumber: c.customerNumber, name: c.name, phone: c.phone || '', createdBy: ctx.systemUser.id, updatedBy: ctx.systemUser.id });
            imported++;
          } else {
            failed++;
          }
        } catch { failed++; }
      }
      return { imported, failed, total: input.customers.length };
    }),
  }),
});

export type AppRouter = typeof appRouter;
