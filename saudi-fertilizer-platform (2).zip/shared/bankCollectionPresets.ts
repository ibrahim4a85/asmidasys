export type BankCollectionDatePreset = 'today' | 'yesterday' | 'last_week' | 'custom' | 'financial_period';

function formatLocalDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getBankCollectionDateRange(preset: BankCollectionDatePreset, customStartDate?: string, customEndDate?: string, now = new Date()) {
  const end = new Date(now);
  end.setHours(0, 0, 0, 0);

  if (preset === 'today') {
    const day = formatLocalDate(end);
    return { startDate: day, endDate: day };
  }
  if (preset === 'yesterday') {
    end.setDate(end.getDate() - 1);
    const day = formatLocalDate(end);
    return { startDate: day, endDate: day };
  }
  if (preset === 'last_week') {
    const start = new Date(end);
    start.setDate(start.getDate() - 6);
    return { startDate: formatLocalDate(start), endDate: formatLocalDate(end) };
  }
  if (preset === 'custom') return { startDate: customStartDate || undefined, endDate: customEndDate || undefined };
  return { startDate: undefined, endDate: undefined };
}
