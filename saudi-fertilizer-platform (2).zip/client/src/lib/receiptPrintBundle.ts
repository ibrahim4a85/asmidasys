import JSZip from 'jszip';

export type ReceiptPrintBundleItem = {
  serialNumber: string;
  attachmentUrl?: string | null;
};

export function getReceiptPrintArchiveName(count: number, includeAttachments: boolean) {
  return `سندات-قبض-محددة-${count}${includeAttachments ? '-مع-الإيصالات' : ''}.zip`;
}

export async function buildReceiptPrintBundle<T extends ReceiptPrintBundleItem>({
  receipts,
  includeAttachments,
  createPdf,
  createAttachmentPdf,
  fetchAttachment = fetch,
}: {
  receipts: T[];
  includeAttachments: boolean;
  createPdf: (receipt: T) => Blob | Promise<Blob>;
  createAttachmentPdf?: (receipt: T) => Blob | Promise<Blob>;
  fetchAttachment?: typeof fetch;
}) {
  const zip = new JSZip();
  for (const receipt of receipts) {
    const receiptPdf = await createPdf(receipt);
    zip.file(`${receipt.serialNumber}.pdf`, await receiptPdf.arrayBuffer());
    if (includeAttachments && receipt.attachmentUrl) {
      if (createAttachmentPdf) {
        const attachmentPdf = await createAttachmentPdf(receipt);
        zip.file(`${receipt.serialNumber}-ESAL.pdf`, await attachmentPdf.arrayBuffer());
        continue;
      }
      const response = await fetchAttachment(receipt.attachmentUrl);
      if (!response.ok) throw new Error(`تعذر جلب إيصال ${receipt.serialNumber}`);
      const extension = /\.pdf(?:[?#]|$)/i.test(receipt.attachmentUrl) ? '.pdf' : '.bin';
      zip.file(`${receipt.serialNumber}-ESAL${extension}`, await (await response.blob()).arrayBuffer());
    }
  }
  return {
    archive: await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } }),
    fileName: getReceiptPrintArchiveName(receipts.length, includeAttachments),
  };
}
