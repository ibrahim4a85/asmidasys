export const CONFIGURED_BRANCH_ORDER = [
  "الرياض",
  "بريدة",
  "الخرج",
  "جدة",
  "وادي الدواسر",
  "تبوك",
  "حائل",
  "الدمام",
  "نجران",
  "الجوف",
] as const;

const branchNameAliases = new Map<string, string>([["القصيم", "بريدة"]]);
const orderByNormalizedName = new Map(
  CONFIGURED_BRANCH_ORDER.map((name, index) => [normalizeBranchName(name), index]),
);
const arabicCollator = new Intl.Collator("ar", { sensitivity: "base", numeric: true });

function normalizeBranchName(name: string) {
  const normalized = name
    .trim()
    .replace(/^فرع\s+/, "")
    .replace(/\s+/g, " ")
    .toLocaleLowerCase("ar");

  return branchNameAliases.get(normalized) ?? normalized;
}

export function sortBranchesByConfiguredOrder<T extends { name: string }>(branches: T[]): T[] {
  return branches
    .map((branch, index) => ({ branch, index }))
    .sort((left, right) => {
      const leftOrder = orderByNormalizedName.get(normalizeBranchName(left.branch.name)) ?? Number.MAX_SAFE_INTEGER;
      const rightOrder = orderByNormalizedName.get(normalizeBranchName(right.branch.name)) ?? Number.MAX_SAFE_INTEGER;
      if (leftOrder !== rightOrder) return leftOrder - rightOrder;

      const nameComparison = arabicCollator.compare(left.branch.name, right.branch.name);
      return nameComparison === 0 ? left.index - right.index : nameComparison;
    })
    .map(({ branch }) => branch);
}

/** الرقم التشغيلي للفرع في الترتيب المعتمد، مع اعتبار «القصيم» مسمىً مكافئاً لبريدة. */
export function getConfiguredBranchNumber(branchName: string): number | null {
  const order = orderByNormalizedName.get(normalizeBranchName(branchName));
  return order === undefined ? null : order + 1;
}

export function getVoucherYearSuffix(date = new Date()): string {
  return new Intl.DateTimeFormat("en-US", {
    calendar: "gregory",
    timeZone: "Asia/Riyadh",
    year: "2-digit",
  }).format(date);
}

export function buildAnnualVoucherSerial(input: {
  branchName: string;
  sequence: number;
  kind: "receipt" | "payment";
  date?: Date;
}): string {
  const branchNumber = getConfiguredBranchNumber(input.branchName);
  if (!branchNumber) throw new Error(`لا يوجد رقم تشغيلي معتمد للفرع «${input.branchName}»`);
  const prefix = input.kind === "payment" ? "PY-" : "";
  return `${prefix}${branchNumber}-${getVoucherYearSuffix(input.date)}-${String(input.sequence).padStart(3, "0")}`;
}
