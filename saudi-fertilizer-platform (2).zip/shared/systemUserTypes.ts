export const SYSTEM_USER_TYPE_SETTINGS_KEY = 'system_user_type_definitions';

export type SystemUserTypeCategory = 'administration' | 'review' | 'operations' | 'management' | 'partner' | 'custom';

export type SystemUserTypeDefinition = {
  code: string;
  label: string;
  category: SystemUserTypeCategory;
  defaultPermissions: string[];
  isSystem: boolean;
  isActive: boolean;
};

export const SYSTEM_USER_TYPE_CATEGORIES: Array<{ id: SystemUserTypeCategory; label: string }> = [
  { id: 'administration', label: 'إدارة النظام' },
  { id: 'review', label: 'مراجعة وتعميد' },
  { id: 'operations', label: 'تشغيل ومبيعات' },
  { id: 'management', label: 'إدارة مالية ومبيعات' },
  { id: 'partner', label: 'شريك' },
  { id: 'custom', label: 'فئة مخصصة' },
];

export const DEFAULT_SYSTEM_USER_TYPES: SystemUserTypeDefinition[] = [
  { code: 'admin', label: 'مدير النظام', category: 'administration', defaultPermissions: ['*'], isSystem: true, isActive: true },
  { code: 'reviewer', label: 'مراجع', category: 'review', defaultPermissions: ['approvalReview'], isSystem: true, isActive: true },
  { code: 'reviewer_approver', label: 'مراجع معمد', category: 'review', defaultPermissions: ['approvalReview', 'approvalApprove'], isSystem: true, isActive: true },
  { code: 'delegate', label: 'مندوب', category: 'operations', defaultPermissions: ['approvalRequest'], isSystem: true, isActive: true },
  { code: 'sales_manager', label: 'مدير مبيعات', category: 'management', defaultPermissions: ['performanceReports'], isSystem: true, isActive: true },
  { code: 'finance_manager', label: 'مدير مالي', category: 'management', defaultPermissions: ['receipts', 'payments', 'reports'], isSystem: true, isActive: true },
  { code: 'authorized_partner', label: 'شريك مفوض', category: 'partner', defaultPermissions: ['dashboard', 'reports', 'approvalApprove'], isSystem: true, isActive: true },
];

const CODE_PATTERN = /^[a-z][a-z0-9_]{2,63}$/;

function normalizeDefinition(value: unknown): SystemUserTypeDefinition | null {
  if (!value || typeof value !== 'object') return null;
  const candidate = value as Partial<SystemUserTypeDefinition>;
  if (typeof candidate.code !== 'string' || !CODE_PATTERN.test(candidate.code)) return null;
  if (typeof candidate.label !== 'string' || !candidate.label.trim() || candidate.label.trim().length > 80) return null;
  if (!SYSTEM_USER_TYPE_CATEGORIES.some(category => category.id === candidate.category)) return null;
  if (!Array.isArray(candidate.defaultPermissions) || !candidate.defaultPermissions.every(permission => typeof permission === 'string' && permission.length <= 80)) return null;
  return {
    code: candidate.code,
    label: candidate.label.trim(),
    category: candidate.category as SystemUserTypeCategory,
    defaultPermissions: Array.from(new Set(candidate.defaultPermissions)),
    isSystem: Boolean(candidate.isSystem),
    isActive: candidate.isActive !== false,
  };
}

export function readSystemUserTypeDefinitions(serialized?: string | null): SystemUserTypeDefinition[] {
  if (!serialized) return DEFAULT_SYSTEM_USER_TYPES;
  try {
    const parsed = JSON.parse(serialized);
    if (!Array.isArray(parsed)) return DEFAULT_SYSTEM_USER_TYPES;
    const normalized = parsed.map(normalizeDefinition).filter((definition): definition is SystemUserTypeDefinition => Boolean(definition));
    const byCode = new Map(normalized.map(definition => [definition.code, definition]));
    const protectedDefinitions = DEFAULT_SYSTEM_USER_TYPES.map(defaultDefinition => {
      const override = byCode.get(defaultDefinition.code);
      return override ? { ...override, code: defaultDefinition.code, isSystem: true, isActive: defaultDefinition.code === 'admin' ? true : override.isActive } : defaultDefinition;
    });
    const customDefinitions = normalized.filter(definition => !DEFAULT_SYSTEM_USER_TYPES.some(defaultDefinition => defaultDefinition.code === definition.code) && !definition.isSystem);
    return [...protectedDefinitions, ...customDefinitions];
  } catch {
    return DEFAULT_SYSTEM_USER_TYPES;
  }
}

export function validateSystemUserTypeDefinitions(definitions: unknown): SystemUserTypeDefinition[] {
  if (!Array.isArray(definitions)) throw new Error('قائمة أنواع المستخدمين غير صالحة');
  const normalized = definitions.map(normalizeDefinition).filter((definition): definition is SystemUserTypeDefinition => Boolean(definition));
  if (normalized.length !== definitions.length) throw new Error('تحقق من رمز ومسميات وفئة أنواع المستخدمين');
  const codes = new Set<string>();
  for (const definition of normalized) {
    if (codes.has(definition.code)) throw new Error('لا يمكن تكرار رمز نوع المستخدم');
    codes.add(definition.code);
  }
  return readSystemUserTypeDefinitions(JSON.stringify(normalized));
}
