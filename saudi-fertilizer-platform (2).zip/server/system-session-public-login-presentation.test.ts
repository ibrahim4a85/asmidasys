import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const projectRoot = path.resolve(import.meta.dirname, '..');
const authContextSource = fs.readFileSync(path.join(projectRoot, 'client/src/contexts/AuthContext.tsx'), 'utf8');
const mainSource = fs.readFileSync(path.join(projectRoot, 'client/src/main.tsx'), 'utf8');

describe('فحص جلسة الإدارة في شاشة الدخول', () => {
  it('يعامل غياب جلسة الإدارة في المسار العام كحالة متوقعة لا كخطأ API ظاهر', () => {
    expect(authContextSource).toMatch(/systemAuth\.session\.useQuery\(undefined, \{[\s\S]*?meta: \{ suppressGlobalErrorLog: true \}/);
    expect(mainSource).toContain('event.query.meta?.suppressGlobalErrorLog === true');
    expect(mainSource).toContain('if (!suppressGlobalErrorLog) {');
    expect(mainSource).toContain('console.error("[API Query Error]", error);');
  });

  it('يبقي معالجة فشل الجلسة الفعلي في الموفر لحذف الحالة المخزنة فقط', () => {
    expect(authContextSource).toContain('if (systemSession.isError) {');
    expect(authContextSource).toContain("localStorage.removeItem('systemUser');");
  });
});
