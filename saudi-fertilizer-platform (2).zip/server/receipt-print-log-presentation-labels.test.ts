import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { getSystemLabel, readSystemLabelOverrides } from '../shared/systemLabelPresentation';

describe('receipt print log presentation labels', () => {
  const expectedLabels = {
    receipt_print_log_title: 'سجل طباعة السند',
    receipt_print_log_empty: 'لا يوجد سجل طباعة لهذا السند بعد.',
    receipt_print_log_with_attachment: 'السند مع الإيصال',
    receipt_print_log_receipt_only: 'السند فقط',
    receipt_print_log_system_user: 'مستخدم النظام',
  } as const;

  it('keeps print-log defaults and accepts administrator overrides', () => {
    for (const [id, label] of Object.entries(expectedLabels)) {
      expect(getSystemLabel(undefined, id as keyof typeof expectedLabels)).toBe(label);
    }

    const overrides = readSystemLabelOverrides({
      system_label_overrides: JSON.stringify({
        receipt_print_log_title: 'سجل مخرجات السند',
        receipt_print_log_empty: 'لا توجد عمليات طباعة مسجلة.',
        receipt_print_log_system_user: 'المستخدم الافتراضي',
      }),
    });

    expect(overrides.receipt_print_log_title).toBe('سجل مخرجات السند');
    expect(overrides.receipt_print_log_empty).toBe('لا توجد عمليات طباعة مسجلة.');
    expect(overrides.receipt_print_log_system_user).toBe('المستخدم الافتراضي');
  });

  it('uses labels only in the print-log dialog while preserving the print-log and receipt actions', () => {
    const source = readFileSync(new URL('../client/src/pages/ReceiptsPage.tsx', import.meta.url), 'utf8');

    expect(source).toContain("labelFor('receipt_print_log_title')");
    expect(source).toContain("labelFor('receipt_print_log_empty')");
    expect(source).toContain("labelFor('receipt_print_log_with_attachment')");
    expect(source).toContain("labelFor('receipt_print_log_receipt_only')");
    expect(source).toContain("labelFor('receipt_print_log_system_user')");
    expect(source).toContain("entry.printType === 'receipt_with_attachment'");
    expect(source).toContain('trpc.receiptPrintAudit.list.useQuery');
    expect(source).toContain('printAuditLog?.length');
    expect(source).toContain('setPrintAuditReceiptId(null)');
    expect(source).toContain('setPrintAuditReceiptId(r.id)');
    expect(source).toContain('handlePrint');
    expect(source).toContain('handlePrintWithAttachment');
    expect(source).toContain('downloadAttachment');
  });
});
