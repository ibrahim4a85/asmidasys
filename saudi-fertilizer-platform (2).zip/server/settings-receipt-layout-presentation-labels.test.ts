import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const settingsPage = readFileSync(fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url)), 'utf8');

describe('تسميات تخطيط نموذج سند القبض', () => {
  it('يوفر القيم الافتراضية ويسمح بتجاوزات العرض الإدارية', () => {
    expect(getSystemLabel(undefined, 'settings_receipt_layout_title')).toBe('تصميم شاشة إصدار سند القبض');
    expect(getSystemLabel(undefined, 'settings_receipt_layout_sections')).toBe('ترتيب وإظهار الأقسام');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ settings_receipt_layout_save: 'تطبيق تخطيط النموذج' }) },
      'settings_receipt_layout_save',
    )).toBe('تطبيق تخطيط النموذج');
  });

  it('يربط نصوص العرض فقط ويبقي التحقق والحفظ وبنية الأقسام كما هي', () => {
    expect(settingsPage).toContain("labelFor('settings_receipt_layout_title'");
    expect(settingsPage).toContain("labelFor('settings_receipt_layout_form_title_placeholder'");
    expect(settingsPage).toContain("labelFor('settings_receipt_layout_sections_description'");
    expect(settingsPage).toContain("labelFor('settings_receipt_layout_save'");
    expect(settingsPage).toContain("if (!sections.includes('customer') || !sections.includes('amount') || !sections.includes('payment'))");
    expect(settingsPage).toContain("{ key: 'receipt_form_sections', value: JSON.stringify(sections) }");
    expect(settingsPage).toContain('onClick={save}');
    expect(settingsPage).toContain('onCheckedChange={() => toggle(option.id)}');
  });
});
