import { describe, expect, it } from 'vitest';
import { DASHBOARD_SECTION_IDS, getDashboardPersonalSectionOrderKey, moveDashboardPersonalSection, parseDashboardPersonalSectionOrder } from '../shared/dashboardPersonalSectionOrder';

describe('الترتيب الشخصي لأقسام لوحة التحكم', () => {
  it('يتجاهل المعرفات غير المعتمدة والمكررة ويكمل الأقسام الناقصة', () => {
    expect(parseDashboardPersonalSectionOrder(['records', 'unknown', 'records', 'summary'])).toEqual(['records', 'summary', 'activity', 'bank']);
    expect(parseDashboardPersonalSectionOrder('invalid')).toEqual([...DASHBOARD_SECTION_IDS]);
  });

  it('يعيد ترتيب القسم بالسحب مع الحفاظ على بقية الترتيب', () => {
    expect(moveDashboardPersonalSection(DASHBOARD_SECTION_IDS, 'bank', 'activity')).toEqual(['summary', 'bank', 'activity', 'records']);
    expect(moveDashboardPersonalSection(DASHBOARD_SECTION_IDS, 'missing', 'activity')).toEqual([...DASHBOARD_SECTION_IDS]);
  });

  it('يبني مفتاح تخزين منفصلاً لكل مستخدم', () => {
    expect(getDashboardPersonalSectionOrderKey(101)).toBe('dashboard-section-order:101');
    expect(getDashboardPersonalSectionOrderKey('manager')).toBe('dashboard-section-order:manager');
  });
});
