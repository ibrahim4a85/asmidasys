ALTER TABLE `approval_requests` ADD `templateRequired` boolean DEFAULT false NOT NULL;
