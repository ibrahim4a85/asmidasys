ALTER TABLE `branch_targets` ADD `createdBy` int;--> statement-breakpoint
ALTER TABLE `branch_targets` ADD `updatedBy` int;--> statement-breakpoint
ALTER TABLE `branches` ADD `createdBy` int;--> statement-breakpoint
ALTER TABLE `branches` ADD `updatedBy` int;--> statement-breakpoint
ALTER TABLE `payments` ADD `createdBy` int;--> statement-breakpoint
ALTER TABLE `payments` ADD `updatedBy` int;--> statement-breakpoint
ALTER TABLE `receipts` ADD `createdBy` int;--> statement-breakpoint
ALTER TABLE `receipts` ADD `updatedBy` int;