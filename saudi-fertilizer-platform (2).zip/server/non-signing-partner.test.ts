import { describe, expect, it } from 'vitest';
import { applyNonSigningPartnerRestrictions } from './routers';

describe('تقييد الشريك غير المفوض', () => {
  it('يستبدل أي صلاحيات مرسلة بصلاحية التقارير فقط عند تعيين شريك فقط', () => {
    expect(applyNonSigningPartnerRestrictions({
      userType: 'authorized_partner',
      boardPosition: 'شريك فقط',
      userLevel: 'primary',
      permissions: { approvalDelegate: true, sidebar_users: true },
    })).toMatchObject({
      boardPosition: 'شريك فقط',
      userLevel: 'secondary',
      permissions: { sidebar_reports: true },
    });
  });

  it('يفرض التقييد عند تعديل شريك قائم حتى إن لم يرسل العميل نوع المستخدم مجدداً', () => {
    expect(applyNonSigningPartnerRestrictions({ permissions: { approvalRequest: true } }, {
      userType: 'authorized_partner',
      boardPosition: 'شريك فقط',
    })).toMatchObject({ permissions: { sidebar_reports: true } });
  });
});
