export type PrintSettingsSource = Partial<{
  print_header_text: string | null;
  print_footer_text: string | null;
  print_logo_position: string | null;
  print_logo_size: string | null;
  print_header_height: string | null;
  print_footer_height: string | null;
  print_accent_color: string | null;
  print_title_font_size: string | null;
  print_show_barcode: string | null;
  print_page_orientation: string | null;
  print_header_percent: string | null;
  print_footer_percent: string | null;
}>;

export type PrintLogoPosition = 'right' | 'center' | 'left';
export type PrintHeaderFlexDirection = 'row' | 'row-reverse' | 'column';
export type PrintPageOrientation = 'portrait' | 'landscape';

function clampNumericSetting(value: string | null | undefined, minimum: number, maximum: number, fallback: number) {
  const parsed = Number(value);
  const safeValue = Number.isFinite(parsed) ? parsed : fallback;
  return Math.min(maximum, Math.max(minimum, safeValue));
}

function safeAccentColor(value: string | null | undefined) {
  return /^#[0-9a-fA-F]{6}$/.test(value || '') ? value! : '#0f766e';
}

export function getPrintPresentation(settings: PrintSettingsSource | undefined, companyName?: string | null) {
  const selectedPosition = settings?.print_logo_position;
  const logoPosition: PrintLogoPosition = selectedPosition === 'left' || selectedPosition === 'center' || selectedPosition === 'right'
    ? selectedPosition
    : 'right';

  const headerFlexDirection: PrintHeaderFlexDirection = logoPosition === 'left' ? 'row-reverse' : logoPosition === 'center' ? 'column' : 'row';
  const pageOrientation: PrintPageOrientation = settings?.print_page_orientation === 'landscape' ? 'landscape' : 'portrait';

  return {
    logoSize: clampNumericSetting(settings?.print_logo_size, 40, 180, 80),
    headerHeight: clampNumericSetting(settings?.print_header_height, 60, 220, 92),
    footerHeight: clampNumericSetting(settings?.print_footer_height, 30, 160, 44),
    logoPosition,
    headerText: settings?.print_header_text?.trim() || companyName?.trim() || 'شركة الأسمدة المتحدة السعودية',
    footerText: settings?.print_footer_text?.trim() || '',
    headerFlexDirection,
    accentColor: safeAccentColor(settings?.print_accent_color),
    titleFontSize: clampNumericSetting(settings?.print_title_font_size, 18, 36, 24),
    showBarcode: settings?.print_show_barcode !== 'false',
    pageOrientation,
    headerPercent: clampNumericSetting(settings?.print_header_percent, 10, 25, 15),
    footerPercent: clampNumericSetting(settings?.print_footer_percent, 10, 25, 15),
  };
}
