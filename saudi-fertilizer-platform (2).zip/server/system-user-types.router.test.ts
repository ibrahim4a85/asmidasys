import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({
  createSystemUser: vi.fn(), getAllSystemUsers: vi.fn(), getSettings: vi.fn(), updateSetting: vi.fn(), updateSettings: vi.fn(),
}));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import type { TrpcContext } from './_core/context';
import { DEFAULT_SYSTEM_USER_TYPES, SYSTEM_USER_TYPE_SETTINGS_KEY } from '../shared/systemUserTypes';

function adminContext(): TrpcContext {
  return {
    user: null,
    systemUser: { id: 1, username: 'admin', fullName: 'مدير النظام', userType: 'admin', userLevel: 'primary', branchId: null, permissions: {} },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

const createInput = { username: 'inventory01', password: 'safe-password', fullName: 'مدير المخزون', userType: 'inventory_manager', userLevel: 'secondary' as const, branchId: null, permissions: {} };

describe('التحقق من أنواع المستخدمين في المسارات الإدارية', () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(db.getSettings).mockResolvedValue({} as never);
    vi.mocked(db.createSystemUser).mockResolvedValue({ success: true } as never);
    vi.mocked(db.updateSetting).mockResolvedValue({ success: true } as never);
  });

  it('يرفض إنشاء مستخدم بنوع غير مهيأ في الكتالوج', async () => {
    await expect(appRouter.createCaller(adminContext()).systemUsers.create(createInput)).rejects.toMatchObject({ code: 'BAD_REQUEST', message: 'نوع المستخدم غير معتمد أو غير نشط' });
    expect(db.createSystemUser).not.toHaveBeenCalled();
  });

  it('يرفض نوعاً مخصصاً غير نشط ويقبل النوع المخصص النشط', async () => {
    vi.mocked(db.getSettings).mockResolvedValue({
      [SYSTEM_USER_TYPE_SETTINGS_KEY]: JSON.stringify([...DEFAULT_SYSTEM_USER_TYPES, { code: 'inventory_manager', label: 'مدير المخزون', category: 'custom', defaultPermissions: [], isSystem: false, isActive: false }]),
    } as never);
    await expect(appRouter.createCaller(adminContext()).systemUsers.create(createInput)).rejects.toMatchObject({ code: 'BAD_REQUEST' });

    vi.mocked(db.getSettings).mockResolvedValue({
      [SYSTEM_USER_TYPE_SETTINGS_KEY]: JSON.stringify([...DEFAULT_SYSTEM_USER_TYPES, { code: 'inventory_manager', label: 'مدير المخزون', category: 'custom', defaultPermissions: ['reports'], isSystem: false, isActive: true }]),
    } as never);
    await appRouter.createCaller(adminContext()).systemUsers.create(createInput);
    expect(db.createSystemUser).toHaveBeenCalledWith(expect.objectContaining({ userType: 'inventory_manager', createdBy: 1, updatedBy: 1 }));
  });

  it('يتحقق من كتالوج الأنواع قبل حفظ إعداداته', async () => {
    await expect(appRouter.createCaller(adminContext()).settings.update({
      key: SYSTEM_USER_TYPE_SETTINGS_KEY,
      value: JSON.stringify([{ code: 'invalid code', label: 'غير صالح', category: 'custom', defaultPermissions: [], isSystem: false, isActive: true }]),
    })).rejects.toThrow('تحقق من رمز ومسميات وفئة أنواع المستخدمين');
    expect(db.updateSetting).not.toHaveBeenCalled();
  });
});
