import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { parse } from "cookie";
import { sdk } from "./sdk";
import { SYSTEM_SESSION_COOKIE, type SystemSessionUser, verifySystemSession } from "../systemSession";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  systemUser: SystemSessionUser | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let systemUser: SystemSessionUser | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  try {
    const rawCookies = opts.req.headers.cookie;
    const cookies = parse(Array.isArray(rawCookies) ? rawCookies.join(";") : rawCookies ?? "");
    const token = cookies[SYSTEM_SESSION_COOKIE];
    if (token) systemUser = await verifySystemSession(token);
  } catch {
    systemUser = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
    systemUser,
  };
}
