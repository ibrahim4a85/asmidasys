CREATE TABLE `partner_account_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`partnerId` int NOT NULL,
	`entryType` enum('withdrawal','entitlement','year_end_settlement') NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`entryDate` timestamp NOT NULL,
	`statement` text NOT NULL,
	`attachmentUrl` text,
	`attachmentName` varchar(255),
	`attachmentMimeType` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `partner_account_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_account_entry_unique` UNIQUE(`periodId`,`partnerId`,`entryDate`,`entryType`,`amount`)
);
--> statement-breakpoint
CREATE TABLE `partner_period_allocations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`partnerId` int NOT NULL,
	`sharePercentage` decimal(5,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int,
	`updatedBy` int,
	CONSTRAINT `partner_period_allocations_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_period_allocation_unique` UNIQUE(`periodId`,`partnerId`)
);
--> statement-breakpoint
CREATE TABLE `partner_period_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`openingProfitBalance` decimal(15,2) NOT NULL DEFAULT '0',
	`distributionDecisionUrl` text,
	`distributionDecisionName` varchar(255),
	`distributionDecisionMimeType` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int,
	`updatedBy` int,
	CONSTRAINT `partner_period_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_period_settings_period_unique` UNIQUE(`periodId`)
);
--> statement-breakpoint
CREATE TABLE `partners` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`systemUserId` int,
	`profileImageUrl` text,
	`profileImageName` varchar(255),
	`profileImageMimeType` varchar(100),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int,
	`updatedBy` int,
	CONSTRAINT `partners_id` PRIMARY KEY(`id`),
	CONSTRAINT `partners_system_user_unique` UNIQUE(`systemUserId`)
);
