import { describe, expect, it } from 'vitest';
import { hasSidebarAccess } from '../shared/sidebarPermissions';

describe('صلاحيات عناصر القائمة والوصول المباشر', () => {
  it('يحجب المسار عند تعطيل صلاحية العنصر صراحةً حتى لو كان المستخدم يملك صلاحية عمل أخرى', () => {
    expect(hasSidebarAccess({ item: 'customers', userType: 'accountant', permissions: { customersManage: true, sidebar_customers: false } })).toBe(false);
  });

  it('يعطي الشريك المفوض افتراضياً لوحة المعلومات والإشعارات والتعميد والتقارير فقط', () => {
    expect(hasSidebarAccess({ item: 'dashboard', userType: 'authorized_partner' })).toBe(true);
    expect(hasSidebarAccess({ item: 'delegates', userType: 'authorized_partner' })).toBe(true);
    expect(hasSidebarAccess({ item: 'reports', userType: 'authorized_partner' })).toBe(true);
    expect(hasSidebarAccess({ item: 'settings', userType: 'authorized_partner' })).toBe(false);
    expect(hasSidebarAccess({ item: 'customers', userType: 'authorized_partner' })).toBe(false);
  });

  it('يسمح للمدير دائماً ولو كانت صلاحيات القائمة المقيدة موجودة', () => {
    expect(hasSidebarAccess({ item: 'settings', isAdmin: true, userType: 'admin', permissions: { sidebar_settings: false } })).toBe(true);
  });

  it('يفتح صفحة التعميد لصاحب صلاحية الطلب حتى عند عدم منح عنصر القائمة بصورة منفصلة', () => {
    expect(hasSidebarAccess({ item: 'delegates', userType: 'delegate', permissions: { approvalRequest: true, sidebar_delegates: false } })).toBe(true);
  });
});
