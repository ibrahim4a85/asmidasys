import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { getSystemLabel, readSystemLabelOverrides } from '../shared/systemLabelPresentation';

describe('dashboard layout navigation accessibility label', () => {
  it('keeps the navigation-toggle default and accepts an administrator override', () => {
    expect(getSystemLabel(undefined, 'ui_toggle_navigation')).toBe('فتح قائمة التنقل');

    const overrides = readSystemLabelOverrides({
      system_label_overrides: JSON.stringify({
        ui_toggle_navigation: 'إظهار التنقل',
      }),
    });

    expect(overrides.ui_toggle_navigation).toBe('إظهار التنقل');
  });

  it('uses the label only for the dashboard toggle while preserving sidebar behavior and navigation structure', () => {
    const source = readFileSync(new URL('../client/src/components/DashboardLayout.tsx', import.meta.url), 'utf8');

    expect(source).toContain("aria-label={labelFor('ui_toggle_navigation')}");
    expect(source).toContain('const { state, toggleSidebar } = useSidebar();');
    expect(source).toContain('onClick={toggleSidebar}');
    expect(source).toContain('const menuItems = [');
    expect(source).toContain('onClick={() => setLocation(item.path)}');
    expect(source).toContain('const [isResizing, setIsResizing] = useState(false);');
  });
});
