import { describe, expect, it, vi } from 'vitest';
import { saveApprovalWorkflowWithDatabase } from './db';
import { systemSettings } from '../drizzle/schema';

function createWorkflowDatabase(members: Array<{ id: number; userType: string; boardPosition: string | null; isActive: boolean; permissions?: unknown }>, settings: Array<{ settingKey: string; settingValue: string }> = []) {
  const insertedWorkflows: unknown[] = [];
  const insertedApprovers: unknown[] = [];
  const tx = {
    select: vi.fn(() => ({ from: () => ({ where: () => ({ limit: async () => [] }) }) })),
    insert: vi.fn((table: unknown) => ({ values: async (values: unknown) => {
      if (insertedWorkflows.length === 0) { insertedWorkflows.push({ table, values }); return [{ insertId: 701 }]; }
      insertedApprovers.push({ table, values }); return [{ insertId: 702 }];
    } })),
  };
  return {
    insertedWorkflows,
    insertedApprovers,
    select: vi.fn(() => ({ from: (table: unknown) => table === systemSettings ? settings : ({ where: () => members }) })),
    transaction: async (callback: (transaction: typeof tx) => Promise<void>) => callback(tx),
  };
}

describe('تكامل حفظ دورة عضوي مجلس الإدارة', () => {
  it('يحفظ فعلياً مسار two_board_members عند اختيار رئيس وعضو مجلس إدارة مفوضين', async () => {
    const database = createWorkflowDatabase([
      { id: 51, userType: 'authorized_partner', boardPosition: 'رئيس مجلس الإدارة', isActive: true },
      { id: 52, userType: 'authorized_partner', boardPosition: 'عضو مجلس الإدارة', isActive: true },
    ]);

    await expect(saveApprovalWorkflowWithDatabase(database as any, { documentTypeId: 10, approvalMode: 'two_board_members', approverUserIds: [51, 52] })).resolves.toBeUndefined();
    expect(database.insertedWorkflows).toHaveLength(1);
    expect(database.insertedApprovers).toHaveLength(1);
  });

  it('يرفض حفظ المسار الفعلي عند إدراج شريك فقط بين الأعضاء', async () => {
    const database = createWorkflowDatabase([
      { id: 51, userType: 'authorized_partner', boardPosition: 'عضو مجلس الإدارة', isActive: true },
      { id: 53, userType: 'authorized_partner', boardPosition: 'شريك فقط', isActive: true },
    ]);

    await expect(saveApprovalWorkflowWithDatabase(database as any, { documentTypeId: 10, approvalMode: 'two_board_members', approverUserIds: [51, 53] })).rejects.toThrow('يقتصر هذا المسار على الشركاء المفوضين أعضاء مجلس الإدارة النشطين');
    expect(database.insertedWorkflows).toHaveLength(0);
  });

  it('يرفض مفوضاً نشطاً خارج قائمة المفوضين المعتمدة بعد حفظها', async () => {
    const database = createWorkflowDatabase([
      { id: 51, userType: 'authorized_partner', boardPosition: 'عضو مجلس الإدارة', isActive: true },
      { id: 52, userType: 'authorized_partner', boardPosition: 'عضو مجلس الإدارة', isActive: true },
    ], [{ settingKey: 'approval_approver_user_ids', settingValue: '[51]' }, { settingKey: 'approval_reviewer_user_ids', settingValue: '[]' }]);

    await expect(saveApprovalWorkflowWithDatabase(database as any, { documentTypeId: 10, approvalMode: 'any', approverUserIds: [51, 52] })).rejects.toThrow('يجب اختيار المفوضين من قائمة المفوضين المعتمدة فقط');
    expect(database.insertedWorkflows).toHaveLength(0);
  });
});
