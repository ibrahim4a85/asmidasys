import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const projectRoot = path.resolve(__dirname, '..');
const targetPage = fs.readFileSync(path.join(projectRoot, 'client', 'src', 'pages', 'TargetsPage.tsx'), 'utf8');

describe('عرض صفحة إدارة الأهداف والعمولات', () => {
  it('يعرض تبويبات عربية للأهداف الإدارية والمبيعات والعمولات مع السجل المتوافق', () => {
    expect(targetPage).toContain('dir="rtl"');
    expect(targetPage).toContain('أهداف إدارية');
    expect(targetPage).toContain('أهداف المبيعات');
    expect(targetPage).toContain('قواعد العمولات');
    expect(targetPage).toContain('المستهدفات السابقة');
  });

  it('يربط مرفق الإجراء بمكوّن السحب والإفلات والرفع المُدار فقط', () => {
    expect(targetPage).toContain("import { FileDropzone } from '@/components/FileDropzone'");
    expect(targetPage).toContain('files.uploadAdministrativeGoalAttachment.useMutation');
    expect(targetPage).toContain('goalManagement.administrative.addActionAttachment.useMutation');
    expect(targetPage).toContain('accept="application/pdf,image/png,image/jpeg,application/vnd.openxmlformats-officedocument.wordprocessingml.document"');
  });

  it('يوضح أن العمولات حالياً قواعد تخطيطية غير مرّحلة مالياً', () => {
    expect(targetPage).toContain('لا يتم هنا احتساب أو صرف أو ترحيل أي أثر مالي');
    expect(targetPage).toContain('تقدير غير مسجل');
  });
});
