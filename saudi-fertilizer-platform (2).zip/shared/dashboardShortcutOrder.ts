export type DashboardShortcutItem = { id: string };

export function parseDashboardShortcutIds(value: unknown, fallback: readonly string[]): string[] {
  if (!Array.isArray(value)) return [...fallback];
  const allowed = new Set(fallback);
  const seen = new Set<string>();
  const ordered = value.filter((id): id is string => {
    if (typeof id !== 'string' || !allowed.has(id) || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return ordered.length ? ordered : [...fallback];
}

export function moveDashboardShortcut(order: readonly string[], sourceId: string, targetId: string): string[] {
  const from = order.indexOf(sourceId);
  const to = order.indexOf(targetId);
  if (from < 0 || to < 0 || from === to) return [...order];
  const next = [...order];
  next.splice(from, 1);
  next.splice(to, 0, sourceId);
  return next;
}

export function orderDashboardShortcuts<T extends DashboardShortcutItem>(items: readonly T[], orderedIds: readonly string[]): T[] {
  const itemById = new Map(items.map(item => [item.id, item]));
  const seen = new Set<string>();
  const ordered = orderedIds.flatMap(id => {
    if (seen.has(id)) return [];
    const item = itemById.get(id);
    if (!item) return [];
    seen.add(id);
    return [item];
  });
  return ordered.length ? ordered : [...items];
}
