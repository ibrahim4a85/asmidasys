import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({ updateSettings: vi.fn() }));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import type { TrpcContext } from './_core/context';

function adminContext(): TrpcContext {
  return {
    user: null,
    systemUser: { id: 1, username: 'admin', fullName: 'مدير النظام', userType: 'admin', userLevel: 'primary', branchId: null, permissions: {} },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

describe('حفظ إعدادات عرض اسم الشركة', () => {
  beforeEach(() => vi.resetAllMocks());

  it('يحفظ حجم الخط والمساحة معاً في عملية خادم إدارية واحدة', async () => {
    vi.mocked(db.updateSettings).mockResolvedValue({ success: true } as never);

    await appRouter.createCaller(adminContext()).settings.updateMany({
      entries: [
        { key: 'sidebar_company_name_font_size', value: '18' },
        { key: 'sidebar_company_name_width', value: '210' },
      ],
    });

    expect(db.updateSettings).toHaveBeenCalledWith([
      { key: 'sidebar_company_name_font_size', value: '18' },
      { key: 'sidebar_company_name_width', value: '210' },
    ]);
  });
});
