import { getApprovalRequesterStatus } from './approvalRequestStatus';

describe('حالة متابعة طلب التعميد', () => {
  it('تعرض الإرسال والاعتماد المكتمل والاعتمادات المتبقية لطالب التعميد', () => {
    const status = getApprovalRequesterStatus({ status: 'sent', approvedCount: 1, requiredApprovals: 2, steps: [{ id: 1, status: 'approved', approverName: 'طارق مراد', boardPosition: 'رئيس مجلس الإدارة' }, { id: 2, status: 'pending', approverName: 'أحمد مراد', boardPosition: 'عضو مجلس الإدارة' }] });
    expect(status.lines).toContain('تمت المراجعة والإرسال إلى المفوضين.');
    expect(status.lines).toContain('تم التعميد من رئيس مجلس الإدارة: طارق مراد.');
    expect(status.lines).toContain('لم يكتمل التعميد؛ ما زال الطلب يحتاج إلى 1 من التعميدات اللازمة.');
  });
});
