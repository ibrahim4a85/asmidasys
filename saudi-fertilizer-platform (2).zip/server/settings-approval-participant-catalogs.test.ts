import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const settingsPage = readFileSync(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url), 'utf8');

describe('قوائم المراجعين والمفوضين المعتمدة في الإعدادات', () => {
  it('يحفظ قائمتي التعميد ويقيد محرر النوع بالكتالوجين', () => {
    expect(settingsPage).toContain('APPROVAL_REVIEWER_USER_IDS_SETTINGS_KEY');
    expect(settingsPage).toContain('APPROVAL_APPROVER_USER_IDS_SETTINGS_KEY');
    expect(settingsPage).toContain('readApprovalParticipantCatalogs(approvalSettings, users)');
    expect(settingsPage).toContain('reviewerCatalogUsers.map');
    expect(settingsPage).toContain('approverCatalogUsers.map');
    expect(settingsPage).toContain('اختر المراجعين والمفوضين من القوائم المعتمدة فقط');
  });
});
