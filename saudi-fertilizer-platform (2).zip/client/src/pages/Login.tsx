import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useSystemAuth } from '@/contexts/AuthContext';
import { trpc } from '@/lib/trpc';
import { Loader2, Lock, User, Building2, Moon, Sun } from 'lucide-react';
import { useLocation } from 'wouter';
import { getLoginPresentationText } from '@/lib/loginPresentation';
import { useTheme } from '@/contexts/ThemeContext';
import { useSystemLabels } from '@/hooks/useSystemLabels';

const defaultBackgrounds = [
  'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=80',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1920&q=80',
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1920&q=80',
];

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [resetRequested, setResetRequested] = useState(false);
  const [resetUsername, setResetUsername] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetNotice, setResetNotice] = useState('');
  const [resetError, setResetError] = useState('');
  const [bgIndex, setBgIndex] = useState(0);
  const { login, isAuthenticated } = useSystemAuth();
  const { colorMode, toggleColorMode } = useTheme();
  const { labelFor } = useSystemLabels();
  const [, setLocation] = useLocation();

  const loginMutation = trpc.systemAuth.login.useMutation();
  const requestResetMutation = trpc.systemAuth.requestPasswordReset.useMutation();
  const confirmResetMutation = trpc.systemAuth.confirmPasswordReset.useMutation();
  const { data: newsItems } = trpc.news.list.useQuery();
  const { data: backgrounds } = trpc.backgrounds.list.useQuery();
  const { data: company } = trpc.company.get.useQuery();
  const { data: settings } = trpc.settings.getAll.useQuery();

  const bgImages = backgrounds && backgrounds.length > 0
    ? backgrounds.map(b => b.imageUrl)
    : defaultBackgrounds;

  useEffect(() => {
    if (isAuthenticated) setLocation('/dashboard');
  }, [isAuthenticated, setLocation]);

  useEffect(() => {
    const interval = setInterval(() => {
      setBgIndex(prev => (prev + 1) % bgImages.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [bgImages.length]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await loginMutation.mutateAsync({ username, password });
      if (result.success && result.user) {
        await login();
        setLocation('/dashboard');
      } else {
        setError(result.error || labelFor('login_error_failed', 'فشل تسجيل الدخول'));
      }
    } catch (err) {
      setError(labelFor('login_error_connection', 'حدث خطأ في الاتصال بالخادم'));
    }
    setLoading(false);
  };

  const openRecovery = () => {
    setError('');
    setResetOpen(true);
    setResetRequested(false);
    setResetCode('');
    setNewPassword('');
    setConfirmPassword('');
    setResetError('');
    setResetNotice('');
  };

  const requestRecoveryCode = async (event: React.FormEvent) => {
    event.preventDefault();
    setResetError('');
    try {
      const result = await requestResetMutation.mutateAsync({ username: resetUsername.trim() });
      setResetNotice(result.message);
      setResetRequested(true);
    } catch {
      setResetNotice('إذا كانت بيانات الاسترداد مهيأة للحساب، فسيصل رمز إلى البريد المعتمد.');
      setResetRequested(true);
    }
  };

  const confirmRecovery = async (event: React.FormEvent) => {
    event.preventDefault();
    setResetError('');
    if (newPassword !== confirmPassword) { setResetError('كلمتا المرور غير متطابقتين'); return; }
    try {
      const result = await confirmResetMutation.mutateAsync({ username: resetUsername.trim(), code: resetCode.trim(), password: newPassword });
      if (!result.success) { setResetError(result.error); return; }
      setResetNotice('تم تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول.');
      setResetOpen(false);
      setPassword('');
      setError('');
    } catch (err: any) {
      setResetError(err?.message || 'تعذر التحقق من رمز الاسترداد');
    }
  };

  const newsSpeed = settings?.news_speed ? parseInt(settings.news_speed) : 50;
  const activeNews = newsItems?.filter(n => n.isActive) || [];
  const { subtitle: loginSubtitle, copyright: copyrightText } = getLoginPresentationText(settings, company?.companyName);
  const darkTogglePosition = settings?.login_dark_toggle_position || 'top-left';
  const darkToggleSize = settings?.login_dark_toggle_size || 'medium';
  const darkTogglePositionClass = {
    'top-left': 'left-4 top-4 sm:left-6 sm:top-6',
    'top-right': 'right-4 top-4 sm:right-6 sm:top-6',
    'bottom-left': 'bottom-4 left-4 sm:bottom-6 sm:left-6',
    'bottom-right': 'bottom-4 right-4 sm:bottom-6 sm:right-6',
  }[darkTogglePosition] || 'left-4 top-4 sm:left-6 sm:top-6';
  const darkToggleSizeClass = {
    small: 'h-8 px-2 text-xs',
    medium: 'h-10 px-3 text-sm',
    large: 'h-12 px-4 text-base',
  }[darkToggleSize] || 'h-10 px-3 text-sm';

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center">
      {/* Background Images */}
      {bgImages.map((bg, i) => (
        <div
          key={i}
          className="absolute inset-0 bg-cover bg-center transition-opacity duration-2000"
          style={{
            backgroundImage: `url(${bg})`,
            opacity: i === bgIndex ? 1 : 0,
            transition: 'opacity 2s ease-in-out',
          }}
        />
      ))}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />

      {/* News Ticker */}
      {activeNews.length > 0 && (
        <div className="absolute top-0 left-0 right-0 bg-primary/90 text-primary-foreground py-2 overflow-hidden z-20">
          <div
            className="news-ticker whitespace-nowrap text-sm font-medium"
            style={{ '--ticker-speed': `${newsSpeed}s` } as any}
          >
            {activeNews.map((item, i) => (
              <span key={i} className="mx-8">{item.content}</span>
            ))}
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={toggleColorMode}
        className={`absolute z-30 inline-flex items-center gap-2 rounded-xl border border-white/30 bg-black/25 font-medium text-white shadow-lg backdrop-blur-md transition hover:bg-black/40 focus:outline-none focus:ring-2 focus:ring-white/80 ${darkTogglePositionClass} ${darkToggleSizeClass}`}
        aria-label={colorMode === 'dark'
          ? labelFor('login_enable_light_mode', 'تفعيل الوضع الفاتح')
          : labelFor('login_enable_dark_mode', 'تفعيل الوضع الداكن')}
      >
        {colorMode === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        <span>{colorMode === 'dark'
          ? labelFor('login_light_mode', 'الوضع الفاتح')
          : labelFor('login_dark_mode', 'الوضع الداكن')}</span>
      </button>

      {/* Login Card */}
      <div className="relative z-10 w-full max-w-lg px-4">
        <Card className="mx-auto max-w-md border-0 bg-card/95 text-card-foreground shadow-2xl backdrop-blur-md">
          <CardHeader className="text-center pb-2 pt-8">
            <div className="flex justify-center mb-4">
              {company?.logoUrl ? (
                <img src={company.logoUrl} alt={labelFor('login_logo_alt', 'شعار الشركة')} className="h-20 w-20 object-contain" />
              ) : (
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-10 w-10 text-primary" />
                </div>
              )}
            </div>
            <h1 className="text-xl font-bold text-foreground">
              {company?.companyName || labelFor('login_default_company_name', 'شركة الأسمدة المتحدة السعودية')}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">{loginSubtitle}</p>
          </CardHeader>
          <CardContent className="px-8 pb-8">
            {!resetOpen ? <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium">{labelFor('login_username', 'اسم المستخدم')}</Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="username"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder={labelFor('login_username_placeholder', 'أدخل اسم المستخدم')}
                    className="pr-10 h-11"
                    autoComplete="username"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">{labelFor('login_password', 'كلمة المرور')}</Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={labelFor('login_password_placeholder', 'أدخل كلمة المرور')}
                    className="pr-10 h-11"
                    autoComplete="current-password"
                  />
                </div>
              </div>
              {error && (
                <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md text-center">
                  {error}
                </div>
              )}
              <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={loading}>
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : labelFor('login_submit', 'تسجيل الدخول')}
              </Button>
              <button type="button" onClick={openRecovery} className="w-full text-center text-sm font-medium text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">نسيت كلمة المرور؟</button>
            </form>
            : <div className="space-y-5" dir="rtl">
              <div className="space-y-1 text-center"><h2 className="font-bold text-foreground">استعادة كلمة المرور</h2><p className="text-sm text-muted-foreground">لا يظهر البريد المعتمد لحماية حسابات النظام.</p></div>
              {!resetRequested ? <form onSubmit={requestRecoveryCode} className="space-y-4"><div className="space-y-2"><Label htmlFor="reset-username">اسم المستخدم</Label><Input id="reset-username" value={resetUsername} onChange={event => setResetUsername(event.target.value)} autoComplete="username" placeholder="أدخل اسم المستخدم" required /></div>{resetError && <p className="rounded-md bg-destructive/10 p-3 text-center text-sm text-destructive">{resetError}</p>}<Button className="w-full" type="submit" disabled={requestResetMutation.isPending}>{requestResetMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : 'إرسال رمز الاسترداد'}</Button></form>
              : <form onSubmit={confirmRecovery} className="space-y-4"><p className="rounded-md bg-primary/10 p-3 text-center text-sm text-foreground">{resetNotice}</p><div className="space-y-2"><Label htmlFor="reset-code">رمز الاسترداد</Label><Input id="reset-code" inputMode="numeric" maxLength={6} value={resetCode} onChange={event => setResetCode(event.target.value.replace(/\D/g, ''))} placeholder="6 أرقام" required /></div><div className="space-y-2"><Label htmlFor="reset-password">كلمة المرور الجديدة</Label><Input id="reset-password" type="password" minLength={8} value={newPassword} onChange={event => setNewPassword(event.target.value)} autoComplete="new-password" placeholder="8 أحرف على الأقل" required /></div><div className="space-y-2"><Label htmlFor="reset-confirm-password">تأكيد كلمة المرور الجديدة</Label><Input id="reset-confirm-password" type="password" minLength={8} value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} autoComplete="new-password" required /></div>{resetError && <p className="rounded-md bg-destructive/10 p-3 text-center text-sm text-destructive">{resetError}</p>}<Button className="w-full" type="submit" disabled={confirmResetMutation.isPending}>{confirmResetMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : 'تعيين كلمة المرور'}</Button></form>}
              <button type="button" onClick={() => setResetOpen(false)} className="w-full text-center text-sm font-medium text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">العودة إلى تسجيل الدخول</button>
            </div>}
          </CardContent>
        </Card>
        <p className="mt-4 whitespace-nowrap text-center text-[8px] leading-4 text-white/70 sm:text-[11px] sm:leading-5">
          {copyrightText} <span className="mx-1 text-white/40">|</span> <span className="text-[8px] sm:text-[10px]">{labelFor('login_designer_credit', 'مصمم النظام - ابراهيم مقبل')}</span>
        </p>
      </div>
    </div>
  );
}
