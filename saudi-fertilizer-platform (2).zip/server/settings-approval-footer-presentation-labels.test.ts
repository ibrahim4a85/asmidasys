import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const settingsPage = readFileSync(fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url)), 'utf8');

describe('تسميات واجهة ختم التعميد على المرفقات', () => {
  it('يوفر القيم الافتراضية ويسمح بتجاوزات العرض الإدارية', () => {
    expect(getSystemLabel(undefined, 'settings_approval_footer')).toBe('ختم اعتماد المفوض على المرفق');
    expect(getSystemLabel(undefined, 'settings_approval_footer_status')).toBe('نص الحالة');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ settings_approval_save_footer: 'تطبيق إعدادات الختم' }) },
      'settings_approval_save_footer',
    )).toBe('تطبيق إعدادات الختم');
  });

  it('يربط نصوص العرض فقط ويبقي إعدادات الختم ومسار التعميد والمرفقات كما هي', () => {
    expect(settingsPage).toContain("labelFor('settings_approval_footer'");
    expect(settingsPage).toContain("labelFor('settings_approval_footer_helper'");
    expect(settingsPage).toContain("labelFor('settings_approval_footer_status'");
    expect(settingsPage).toContain("labelFor('settings_approval_save_footer'");
    expect(settingsPage).toContain('onClick={saveFooterSettings}');
    expect(settingsPage).toContain("{ key: 'approval_footer_enabled', value: footerEnabled ? 'true' : 'false' }");
    expect(settingsPage).toContain("{ key: 'approval_footer_label', value: footerLabel.trim() || 'تم التعميد' }");
    expect(settingsPage).toContain('saveWorkflow.mutate({ documentTypeId: Number(documentTypeId), reviewerUserIds, reviewerSequential, approverUserIds, approverSequential, requiredApprovals: required })');
  });
});
