import { describe, expect, it } from "vitest";
import { sortCustomerRows } from "../client/src/lib/customerTableSorting";

const customers = [
  { customerNumber: "10010", name: "شركة باء", branchId: 2, delegateId: 12, phone: "0502" },
  { customerNumber: "1002", name: "شركة ألف", branchId: 1, delegateId: 11, phone: "0501" },
  { customerNumber: "1001", name: "شركة جيم", branchId: 3, delegateId: 13, phone: null },
];
const branches = [{ id: 1, name: "الخبر" }, { id: 2, name: "الجبيل" }, { id: 3, name: "الرياض" }];
const delegates = [{ id: 11, fullName: "أحمد" }, { id: 12, fullName: "بدر" }, { id: 13, fullName: "خالد" }];

describe("فرز جدول العملاء", () => {
  it("يرتب أرقام العملاء رقمياً وليس كنصوص", () => {
    expect(sortCustomerRows(customers, "customerNumber", "asc").map((customer) => customer.customerNumber)).toEqual(["1001", "1002", "10010"]);
  });

  it("يدعم اتجاهي الفرز للنصوص والحقول المرتبطة", () => {
    expect(sortCustomerRows(customers, "name", "asc").map((customer) => customer.name)).toEqual(["شركة ألف", "شركة باء", "شركة جيم"]);
    expect(sortCustomerRows(customers, "branch", "desc", branches).map((customer) => customer.branchId)).toEqual([3, 1, 2]);
    expect(sortCustomerRows(customers, "delegate", "asc", branches, delegates).map((customer) => customer.delegateId)).toEqual([11, 12, 13]);
  });
});
