import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({
  createFullSystemBackup: vi.fn(),
  createBackupLog: vi.fn(),
  getBackupLogs: vi.fn(),
  verifySystemUserPassword: vi.fn(),
  restoreFullSystemBackup: vi.fn(),
}));

vi.mock('./storage', () => ({
  storageGetSignedUrl: vi.fn(),
  storagePut: vi.fn(),
}));

import { appRouter } from './routers';
import * as db from './db';
import * as storage from './storage';
import type { TrpcContext } from './_core/context';

function context(): TrpcContext {
  return {
    user: null,
    systemUser: { id: 9, username: 'admin', fullName: 'مدير النظام', userType: 'admin', userLevel: 'primary', branchId: null, permissions: {} },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

function emptyData() {
  return {
    users: [], systemUsers: [], systemSettings: [], companyProfile: [], regions: [], branches: [], financialPeriods: [], branchTargets: [],
    customers: [], inputLists: [], receipts: [], receiptInvoices: [], payments: [], performanceReports: [], delegates: [], documentTypes: [],
    approvalRequests: [], newsItems: [], loginBackgrounds: [], activityLog: [], internalNotifications: [], receiptDecisionAudit: [], backupLogs: [],
  };
}

describe('إجراءات النسخ الاحتياطي الكاملة', () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.unstubAllGlobals();
  });

  it('ينشئ تنزيل نسخة كاملة يضم بايتات المرفقات ويسجل العملية باسم المدير وعدد السجلات', async () => {
    const data = { ...emptyData(), customers: [{ id: 1, name: 'عميل اختبار' }], receipts: [{ attachmentUrl: '/manus-storage/receipts/slip.pdf' }] };
    vi.mocked(db.createFullSystemBackup).mockResolvedValue(data as never);
    vi.mocked(db.createBackupLog).mockResolvedValue(undefined as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://storage.example/slip.pdf');
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response('slip-bytes', { headers: { 'content-type': 'application/pdf' } })));

    const result = await appRouter.createCaller(context()).backups.downloadFull();

    expect(result.payload.version).toBe(2);
    expect(result.payload.files).toEqual([{ sourceUrl: '/manus-storage/receipts/slip.pdf', contentType: 'application/pdf', dataBase64: Buffer.from('slip-bytes').toString('base64') }]);
    expect(storage.storageGetSignedUrl).toHaveBeenCalledWith('receipts/slip.pdf');
    expect(db.createBackupLog).toHaveBeenCalledWith(expect.objectContaining({ operation: 'download', userId: 9, recordsCount: 2 }));
  });

  it('يرفض الاستيراد قبل لمس البيانات عند إدخال كلمة مرور خاطئة', async () => {
    vi.mocked(db.verifySystemUserPassword).mockResolvedValue(false);
    const caller = appRouter.createCaller(context());

    await expect(caller.backups.restoreFull({
      password: 'خاطئة', confirmation: 'استيراد النسخة الاحتياطية الكاملة', fileName: 'backup.json',
      payload: { format: 'asmidasys-full-system-backup', version: 2, exportedAt: '2026-08-19T00:00:00.000Z', files: [], data: emptyData() },
    })).rejects.toMatchObject({ code: 'FORBIDDEN' });
    expect(db.restoreFullSystemBackup).not.toHaveBeenCalled();
  });

  it('يستورد النسخة الصحيحة ويسجل نتيجة الاستيراد بعد تحقق كلمة المرور والتأكيد', async () => {
    vi.mocked(db.verifySystemUserPassword).mockResolvedValue(true);
    vi.mocked(db.restoreFullSystemBackup).mockResolvedValue(1 as never);
    vi.mocked(db.createBackupLog).mockResolvedValue(undefined as never);
    vi.mocked(storage.storagePut).mockResolvedValue({ key: 'restored-system-backup/slip_new.pdf', url: '/manus-storage/restored-system-backup/slip_new.pdf' });
    const caller = appRouter.createCaller(context());

    await expect(caller.backups.restoreFull({
      password: 'صحيحة', confirmation: 'استيراد النسخة الاحتياطية الكاملة', fileName: 'backup.json',
      payload: {
        format: 'asmidasys-full-system-backup', version: 2, exportedAt: '2026-08-19T00:00:00.000Z',
        files: [{ sourceUrl: '/manus-storage/receipts/slip.pdf', contentType: 'application/pdf', dataBase64: Buffer.from('slip-bytes').toString('base64') }],
        data: { ...emptyData(), customers: [{ id: 1 }], receipts: [{ attachmentUrl: '/manus-storage/receipts/slip.pdf' }] },
      },
    })).resolves.toEqual({ success: true, recordsCount: 2 });
    expect(db.restoreFullSystemBackup).toHaveBeenCalledTimes(1);
    expect(storage.storagePut).toHaveBeenCalledWith('restored-system-backup/slip.pdf', Buffer.from('slip-bytes'), 'application/pdf');
    expect(db.restoreFullSystemBackup).toHaveBeenCalledWith(expect.objectContaining({ receipts: [{ attachmentUrl: '/manus-storage/restored-system-backup/slip_new.pdf' }] }));
    expect(db.createBackupLog).toHaveBeenCalledWith(expect.objectContaining({ operation: 'restore', userId: 9, recordsCount: 2 }));
  });

  it('يعرض سجل النسخ الاحتياطية المحفوظ للمدير', async () => {
    vi.mocked(db.getBackupLogs).mockResolvedValue([{ id: 7, operation: 'download' }] as never);
    await expect(appRouter.createCaller(context()).backups.list()).resolves.toEqual([{ id: 7, operation: 'download' }]);
  });
});
