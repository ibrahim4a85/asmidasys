import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const settingsPage = readFileSync(fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url)), 'utf8');

describe('تسمية العرض الآمنة لمعاينة استيراد العملاء في الإعدادات', () => {
  it('يوفر قيمة افتراضية ويقبل تجاوز المدير لرأس عمود رقم العميل', () => {
    expect(getSystemLabel(undefined, 'settings_customer_import_preview_number_heading')).toBe('رقم العميل');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ settings_customer_import_preview_number_heading: 'رقم الحساب' }) },
      'settings_customer_import_preview_number_heading',
    )).toBe('رقم الحساب');
  });

  it('يربط رأس العمود المرئي فقط ويحافظ على تحليل الملف والمعاينة والاستيراد', () => {
    expect(settingsPage).toContain("labelFor('settings_customer_import_preview_number_heading', 'رقم العميل')");
    expect(settingsPage).toContain('const readCustomerFile = async');
    expect(settingsPage).toContain("XLSX.read(await file.arrayBuffer(), { type: 'array' })");
    expect(settingsPage).toContain("XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' })");
    expect(settingsPage).toContain('setPreview(parsed); setFileName(file.name);');
    expect(settingsPage).toContain('preview.slice(0, 10)');
    expect(settingsPage).toContain('importMutation.mutate({ customers: preview })');
  });
});
