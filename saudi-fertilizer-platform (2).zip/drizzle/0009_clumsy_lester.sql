CREATE TABLE `approval_request_steps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestId` int NOT NULL,
	`workflowId` int NOT NULL,
	`systemUserId` int NOT NULL,
	`stepOrder` int NOT NULL,
	`status` enum('pending','approved','rejected','skipped') NOT NULL DEFAULT 'pending',
	`note` text,
	`actedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `approval_request_steps_id` PRIMARY KEY(`id`),
	CONSTRAINT `approval_request_step_unique` UNIQUE(`requestId`,`systemUserId`)
);
--> statement-breakpoint
CREATE TABLE `approval_workflow_approvers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workflowId` int NOT NULL,
	`systemUserId` int NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `approval_workflow_approvers_id` PRIMARY KEY(`id`),
	CONSTRAINT `approval_workflow_approver_unique` UNIQUE(`workflowId`,`systemUserId`)
);
--> statement-breakpoint
CREATE TABLE `approval_workflows` (
	`id` int AUTO_INCREMENT NOT NULL,
	`documentTypeId` int NOT NULL,
	`approvalMode` enum('sequential','any','all') NOT NULL DEFAULT 'sequential',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `approval_workflows_id` PRIMARY KEY(`id`),
	CONSTRAINT `approval_workflows_documentTypeId_unique` UNIQUE(`documentTypeId`)
);
--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `workflowId` int;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `approvalMode` enum('sequential','any','all') DEFAULT 'sequential' NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `currentStepOrder` int DEFAULT 1 NOT NULL;