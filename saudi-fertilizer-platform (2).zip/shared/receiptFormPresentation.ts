export const receiptFormSectionOptions = [
  { id: 'customer', label: 'العميل' },
  { id: 'amount', label: 'المبلغ والتفقيط' },
  { id: 'payment', label: 'تفاصيل الدفع' },
  { id: 'invoices', label: 'تفاصيل الفواتير' },
  { id: 'attachment', label: 'إيصال التحويل' },
  { id: 'notes', label: 'الملاحظات' },
] as const;

export const receiptFormLabelOptions = [
  { id: 'customerSearch', label: 'بحث عن العميل' },
  { id: 'selectedCustomer', label: 'العميل المحدد' },
  { id: 'amount', label: 'المبلغ (ريال)' },
  { id: 'amountInWords', label: 'المبلغ كتابة (تفقيط)' },
  { id: 'paymentMethod', label: 'طريقة الدفع' },
  { id: 'bank', label: 'البنك' },
  { id: 'paymentFor', label: 'وذلك مقابل' },
  { id: 'invoices', label: 'تفاصيل الفواتير' },
  { id: 'attachment', label: 'إيصال العملية' },
  { id: 'notes', label: 'ملاحظات' },
] as const;

export type ReceiptFormSectionId = typeof receiptFormSectionOptions[number]['id'];
export type ReceiptFormLabelId = typeof receiptFormLabelOptions[number]['id'];
export type ReceiptCustomFieldType = 'text' | 'textarea' | 'number' | 'date' | 'select';
export type ReceiptCustomField = { id: string; label: string; type: ReceiptCustomFieldType; required: boolean; options: string[] };

export type ReceiptFormSettingsSource = Partial<{
  receipt_form_title: string | null;
  receipt_form_subtitle: string | null;
  receipt_form_sections: string | null;
  receipt_form_labels: string | null;
  receipt_form_custom_fields: string | null;
}>;

const defaultOrder = receiptFormSectionOptions.map(option => option.id);
const defaultLabels = Object.fromEntries(receiptFormLabelOptions.map(option => [option.id, option.label])) as Record<ReceiptFormLabelId, string>;

function isSectionId(value: unknown): value is ReceiptFormSectionId {
  return typeof value === 'string' && defaultOrder.includes(value as ReceiptFormSectionId);
}

function parseLabels(value: string | null | undefined): Record<ReceiptFormLabelId, string> {
  try {
    const parsed = JSON.parse(value || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return defaultLabels;
    return receiptFormLabelOptions.reduce((labels, field) => {
      const candidate = (parsed as Record<string, unknown>)[field.id];
      labels[field.id] = typeof candidate === 'string' && candidate.trim().length > 0 && candidate.trim().length <= 80 ? candidate.trim() : field.label;
      return labels;
    }, { ...defaultLabels });
  } catch { return defaultLabels; }
}

function parseCustomFields(value: string | null | undefined): ReceiptCustomField[] {
  try {
    const parsed = JSON.parse(value || '[]');
    if (!Array.isArray(parsed)) return [];
    const usedIds = new Set<string>();
    return parsed.slice(0, 8).flatMap((item): ReceiptCustomField[] => {
      if (!item || typeof item !== 'object') return [];
      const field = item as Record<string, unknown>;
      const id = typeof field.id === 'string' ? field.id.trim().toLowerCase() : '';
      const label = typeof field.label === 'string' ? field.label.trim() : '';
      const type = ['text', 'textarea', 'number', 'date', 'select'].includes(String(field.type)) ? field.type as ReceiptCustomFieldType : 'text';
      if (!/^[a-z][a-z0-9_]{1,39}$/.test(id) || !label || label.length > 80 || usedIds.has(id)) return [];
      usedIds.add(id);
      const options = Array.isArray(field.options) ? field.options.filter((option): option is string => typeof option === 'string').map(option => option.trim()).filter(Boolean).slice(0, 20) : [];
      return [{ id, label, type, required: field.required === true, options }];
    });
  } catch { return []; }
}

export function getReceiptFormPresentation(settings?: ReceiptFormSettingsSource) {
  let savedSections: ReceiptFormSectionId[] = [];
  try {
    const parsed = JSON.parse(settings?.receipt_form_sections || '[]');
    if (Array.isArray(parsed)) savedSections = parsed.filter(isSectionId);
  } catch {
    savedSections = [];
  }
  const sectionOrder = [...savedSections, ...defaultOrder.filter(id => !savedSections.includes(id))];
  return {
    title: settings?.receipt_form_title?.trim() || 'إصدار سند قبض جديد',
    subtitle: settings?.receipt_form_subtitle?.trim() || 'أدخل بيانات التحصيل ثم احفظ السند.',
    sectionOrder,
    labels: parseLabels(settings?.receipt_form_labels),
    customFields: parseCustomFields(settings?.receipt_form_custom_fields),
    isVisible: (id: ReceiptFormSectionId) => savedSections.length === 0 || savedSections.includes(id),
  };
}
