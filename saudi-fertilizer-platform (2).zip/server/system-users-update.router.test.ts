import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({ getAllSystemUsers: vi.fn(), getSettings: vi.fn(), updateSystemUser: vi.fn() }));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import type { TrpcContext } from './_core/context';

function adminContext(): TrpcContext {
  return {
    user: null,
    systemUser: { id: 1, username: 'admin', fullName: 'مدير النظام', userType: 'admin', userLevel: 'primary', branchId: null, permissions: {} },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

describe('تحديث بيانات مستخدم النظام', () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(db.getSettings).mockResolvedValue({} as never);
  });

  it('يقبل تحديث المستخدم دون كلمة مرور جديدة ويمنح الصلاحية الافتراضية عند غيابها', async () => {
    vi.mocked(db.getAllSystemUsers).mockResolvedValue([{ id: 10, username: '101', fullName: 'أحمد', userType: 'delegate', userLevel: 'secondary', branchId: 1, permissions: {}, isActive: true }] as never);
    vi.mocked(db.updateSystemUser).mockResolvedValue({ success: true } as never);

    await appRouter.createCaller(adminContext()).systemUsers.update({
      id: 10,
      data: { username: '101', fullName: 'أحمد حسانين', userType: 'delegate', userLevel: 'secondary', branchId: 1, permissions: { sidebar_receipts: true } },
    });

    expect(db.updateSystemUser).toHaveBeenCalledWith(10, expect.objectContaining({
      username: '101', fullName: 'أحمد حسانين', updatedBy: 1, permissions: expect.objectContaining({ approvalRequest: true }),
    }));
    expect(vi.mocked(db.updateSystemUser).mock.calls[0][1]).not.toHaveProperty('password');
  });
});
