import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const projectRoot = path.resolve(__dirname, '..');
const readClientFile = (...parts: string[]) => fs.readFileSync(path.join(projectRoot, 'client', 'src', ...parts), 'utf8');

describe('واجهة السحب والإفلات واستعادة كلمة المرور', () => {
  it('يوفر مكوّن الرفع منطقة قابلة للنقر والسحب ومعاينة وإزالة مع حدود النوع والحجم', () => {
    const source = readClientFile('components', 'FileDropzone.tsx');

    expect(source).toContain('onDragOver');
    expect(source).toContain('onDrop');
    expect(source).toContain('inputRef.current?.click()');
    expect(source).toContain('aria-label');
    expect(source).toContain('maxBytes');
    expect(source).toContain('onClear');
    expect(source).toContain('previewImage');
  });

  it('يستبدل روابط شعار الشركة وخلفيات الدخول ونموذج التعميد بمناطق رفع آمنة', () => {
    const source = readClientFile('pages', 'SettingsPage.tsx');

    expect(source).toContain('files.uploadCompanyLogo.useMutation');
    expect(source).toContain('files.uploadLoginBackground.useMutation');
    expect(source).toContain('files.uploadApprovalTemplate.useMutation');
    expect(source).toContain('<FileDropzone label="شعار الشركة"');
    expect(source).toContain('خلفية جديدة لشاشة الدخول');
    expect(source).toContain('نموذج النوع (PDF أو Word أو Excel)');
    expect(source).not.toContain('placeholder="https://example.com/logo.png"');
    expect(source).not.toContain('placeholder="رابط الصورة"');
  });

  it('يبقي مسار الاسترداد عاماً ولا يعرض البريد، ويطلب رمزاً وكلمة مرور مؤكدة', () => {
    const source = readClientFile('pages', 'Login.tsx');

    expect(source).toContain('systemAuth.requestPasswordReset.useMutation');
    expect(source).toContain('systemAuth.confirmPasswordReset.useMutation');
    expect(source).toContain('نسيت كلمة المرور؟');
    expect(source).toContain('رمز الاسترداد');
    expect(source).toContain('تأكيد كلمة المرور الجديدة');
    expect(source).toContain('لا يظهر البريد المعتمد لحماية حسابات النظام.');
    expect(source).not.toContain('recoveryEmail');
  });

  it('يوحّد مرفقات سندات القبض والتعميدات وحقوق الشركاء على مكوّن الرفع نفسه', () => {
    const receiptSource = readClientFile('pages', 'ReceiptsPage.tsx');
    const delegateSource = readClientFile('pages', 'DelegatesPage.tsx');
    const partnerSource = readClientFile('pages', 'PartnerRightsPage.tsx');

    expect(receiptSource).toContain("import { FileDropzone } from '@/components/FileDropzone'");
    expect(delegateSource).toContain("import { FileDropzone } from '@/components/FileDropzone'");
    expect(partnerSource).toContain("import { FileDropzone } from '@/components/FileDropzone'");
    expect(receiptSource).toContain('<FileDropzone');
    expect(delegateSource).toContain('<FileDropzone');
    expect(partnerSource).toContain('<FileDropzone');
  });
});
