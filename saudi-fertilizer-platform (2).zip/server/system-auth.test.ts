import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { getSessionCookieOptions } from "./_core/cookies";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    systemUser: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

function createSystemAdminContext(): TrpcContext {
  return {
    user: null,
    systemUser: {
      id: 1,
      username: "admin",
      fullName: "مدير النظام",
      userType: "admin",
      userLevel: "primary",
      branchId: null,
      permissions: {},
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("systemAuth.login", () => {
  it("uses proxy-aware cross-site cookie options for the management session", () => {
    const cookieOptions = getSessionCookieOptions({
      protocol: "http",
      headers: { "x-forwarded-proto": "https" },
    } as TrpcContext["req"]);

    expect(cookieOptions).toMatchObject({
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
    });
  });

  it("returns error for invalid credentials", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.systemAuth.login({
      username: "nonexistent_user_xyz",
      password: "wrong_password",
    });
    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
  });

  it("login procedure accepts username and password", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    // Test that the procedure exists and accepts the correct input shape
    const result = await caller.systemAuth.login({
      username: "admin",
      password: "admin123",
    });
    // Should either succeed or fail gracefully
    expect(result).toHaveProperty("success");
  });
});

describe("company.get", () => {
  it("returns company profile data", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.company.get();
    if (result) {
      expect(result).toHaveProperty("companyName");
    }
  });
});

describe("settings.getAll", () => {
  it("returns settings as key-value object", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.settings.getAll();
    expect(typeof result).toBe("object");
  });
});

describe("branches.list", () => {
  it("returns array of branches", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.branches.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("customers.list", () => {
  it("returns array of customers for an authenticated system administrator", async () => {
    const ctx = createSystemAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.customers.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("news.list", () => {
  it("returns array of news items", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.news.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("system administrator write permissions", () => {
  it("rejects changes made without a system-management session", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.settings.update({ key: "theme", value: "ocean" })).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("allows a system administrator to access protected management data", async () => {
    const caller = appRouter.createCaller(createSystemAdminContext());
    const backup = await caller.backup.exportData();

    expect(backup).toHaveProperty("data");
    expect(backup.data).toHaveProperty("customers");
  }, 15_000);
});
