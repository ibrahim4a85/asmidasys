import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { calculateAggregateSharePercentage, calculateEquityLineTotal, calculatePartnerAccountSummary, isValidShareTotal } from '../shared/partnerRights';
import { hasSidebarAccess } from '../shared/sidebarPermissions';

const projectRoot = resolve(__dirname, '..');
const router = readFileSync(resolve(projectRoot, 'server/routers.ts'), 'utf8');
const database = readFileSync(resolve(projectRoot, 'server/db.ts'), 'utf8');
const app = readFileSync(resolve(projectRoot, 'client/src/App.tsx'), 'utf8');
const appLayout = readFileSync(resolve(projectRoot, 'client/src/components/AppLayout.tsx'), 'utf8');
const usersManagement = readFileSync(resolve(projectRoot, 'client/src/pages/UsersManagement.tsx'), 'utf8');
const partnerRightsPage = readFileSync(resolve(projectRoot, 'client/src/pages/PartnerRightsPage.tsx'), 'utf8');

describe('حقوق الشركاء', () => {
  it('يحسب رصيد الشريك الافتتاحي والحركات والتسويات بحسب الاتجاه بصورة قابلة للتدقيق', () => {
    const summary = calculatePartnerAccountSummary({
      openingProfitBalance: '100000',
      sharePercentage: '25',
      entries: [
        { entryType: 'entitlement', amount: '5000' },
        { entryType: 'withdrawal', amount: '3000' },
        { entryType: 'year_end_settlement', amount: '1500', settlementDirection: 'credit' },
        { entryType: 'year_end_settlement', amount: '750', settlementDirection: 'debit' },
      ],
    });

    expect(summary).toEqual({
      openingBalance: 25000,
      entitlements: 5000,
      withdrawals: 3000,
      settlementCredits: 1500,
      settlementDebits: 750,
      closingBalance: 27750,
    });
  });

  it('يمنع تجاوز مجموع الحصص 100% ويقبل الحصص المكتملة', () => {
    expect(calculateAggregateSharePercentage([{ sharePercentage: '40' }, { sharePercentage: 60 }])).toBe(100);
    expect(isValidShareTotal(100)).toBe(true);
    expect(isValidShareTotal(100.01)).toBe(false);
  });

  it('يقصر تقرير الشريك المفوض على ملفه المرتبط ويفصل صلاحيات العرض والإضافة والتعديل والإدارة', () => {
    expect(router).toContain('const restrictedSystemUserId = ctx.systemUser.userType === "authorized_partner" ? ctx.systemUser.id : undefined;');
    expect(router).toContain('type PartnerRightsPermission = "partnerRightsView" | "partnerRightsCreateEntries" | "partnerRightsEditEntries" | "partnerRightsManage";');
    expect(router).toContain('requirePartnerRightsCapability(ctx.systemUser, "canCreateEntries"');
    expect(router).toContain('requirePartnerRightsCapability(ctx.systemUser, "canEditEntries"');
    expect(router).toContain('requirePartnerRightsCapability(ctx.systemUser, "canManage"');
    expect(router).toContain('uploadPartnerProfileImage: systemUserProcedure');
    expect(router).toContain('uploadPartnerRightsDocument: systemUserProcedure');
    expect(router).toContain('return { ...report, capabilities: getPartnerRightsCapabilities(ctx.systemUser)');
  });

  it('يفرض تقييد الحصص والمرفقات واتجاه التسوية على طبقة البيانات أيضاً', () => {
    expect(database).toContain('إجمالي حصص الشركاء لا يمكن أن يتجاوز 100%');
    expect(database).toContain('يلزم تحديد اتجاه تسوية نهاية العام');
    expect(database).toContain('entryType === "year_end_settlement" ? data.settlementDirection : null');
    expect(database).toContain('partnerAccountEntries, data.partnerAccountEntries || []');
  });

  it('يدعم عضوية تاريخية وبنود حقوق الملكية والتوزيعات الموثقة والمستندات السنوية دون إنشاء قيد حساب جارٍ تلقائياً', () => {
    expect(calculateEquityLineTotal({ capitalAmount: '1000', legalReserveAmount: '300', retainedEarningsAmount: '-50' })).toBe(1250);
    expect(database).toContain('getPartnerPeriodMemberships(periodId)');
    expect(database).toContain('getPartnerProfitDistributions(periodId)');
    expect(database).toContain('getPartnerPeriodDocuments(periodId)');
    expect(database).toContain('documentedDistributionTotal');
    expect(router).toContain('createHistoricalPeriod');
    expect(router).toContain('saveMembership');
    expect(router).toContain('saveDocumentedDistribution');
    expect(router).toContain('createPeriodDocument');
    expect(router).toContain('uploadPartnerRightsAnnualDocument');
    expect(router).toContain('partnerPeriodMemberships');
    expect(router).toContain('partnerProfitDistributions');
    expect(router).toContain('partnerPeriodDocuments');
  });

  it('يسجل الصفحة ضمن القائمة والمسار المحمي ويعرض إذنها ضمن إدارة المستخدمين', () => {
    expect(app).toContain('import PartnerRightsPage from "./pages/PartnerRightsPage"');
    expect(app).toContain('path="/partner-rights"');
    expect(app).toContain('item="partner-rights"');
    expect(appLayout).toContain("id: 'partner-rights'");
    expect(appLayout).toContain("label: 'حقوق الشركاء'");
    expect(usersManagement).toContain("['sidebar_partner-rights', 'حقوق الشركاء']");
  });

  it('يعرض حقوق الشركاء للشريك المفوض إذا كانت إعدادات القائمة القديمة لا تحتوي هذه الصلاحية، ويحترم الحجب الصريح', () => {
    expect(hasSidebarAccess({
      userType: 'authorized_partner',
      permissions: { sidebar_dashboard: true, sidebar_reports: true },
      item: 'partner-rights',
    })).toBe(true);
    expect(hasSidebarAccess({
      userType: 'authorized_partner',
      permissions: { 'sidebar_partner-rights': false },
      item: 'partner-rights',
    })).toBe(false);
    expect(appLayout).toContain("partnerRightsIsExplicitlyConfigured");
    expect(appLayout).toContain('min-h-0 flex-1 overflow-y-auto overscroll-contain py-2');
  });

  it('يتيح تحجيم القائمة الجانبية بالسحب على سطح المكتب ويحفظ التفضيل ضمن حدود آمنة', () => {
    expect(appLayout).toContain("sidebar-width-${user?.id || 'anonymous'}");
    expect(appLayout).toContain('window.localStorage.setItem(sidebarWidthStorageKey');
    expect(appLayout).toContain('Math.max(220, Math.min(560');
    expect(appLayout).toContain('window.innerWidth < 1024');
    expect(appLayout).toContain('aria-label="اسحب لتغيير عرض القائمة الجانبية"');
    expect(appLayout).toContain("'--sidebar-width': `${resolvedSidebarWidth}px`");
    expect(appLayout).toContain('overflow-y-auto overscroll-contain');
  });

  it('يعرض أدوات الشريك وحركات الحساب والتقرير السنوي وفق القدرات التي يعيدها الخادم', () => {
    expect(partnerRightsPage).toContain('trpc.partnerRights.updatePartner.useMutation');
    expect(partnerRightsPage).toContain('trpc.partnerRights.updateEntry.useMutation');
    expect(partnerRightsPage).toContain('trpc.partnerRights.createHistoricalPeriod.useMutation');
    expect(partnerRightsPage).toContain('trpc.partnerRights.saveMembership.useMutation');
    expect(partnerRightsPage).toContain('trpc.partnerRights.saveDocumentedDistribution.useMutation');
    expect(partnerRightsPage).toContain('trpc.partnerRights.createPeriodDocument.useMutation');
    expect(partnerRightsPage).toContain('trpc.files.uploadPartnerRightsAnnualDocument.useMutation');
    expect(partnerRightsPage).toContain('const capabilities = overview?.capabilities');
    expect(partnerRightsPage).toContain('const canManage = capabilities.canManage;');
    expect(partnerRightsPage).toContain('trpc.partnerRights.entryCatalog.useQuery');
    expect(partnerRightsPage).toContain("entryForm.id ? 'تعديل حركة الحساب الجاري'");
    expect(partnerRightsPage).toContain("partnerForm.id ? 'تعديل ملف الشريك'");
    expect(partnerRightsPage).toContain("setTab('entry')");
    expect(partnerRightsPage).toContain('لا تنشئ تلقائياً استحقاقاً أو مسحوباً أو تسوية');
    expect(partnerRightsPage).toContain('لا تتم إضافة أي شريك تلقائياً إلى فترة سابقة');
  });
});
