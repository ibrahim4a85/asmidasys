// تحويل الأرقام إلى كلمات عربية (تفقيط)
const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
const tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];

function convertGroup(num: number): string {
  if (num === 0) return '';
  if (num < 20) return ones[num];
  if (num < 100) {
    const ten = Math.floor(num / 10);
    const one = num % 10;
    if (one === 0) return tens[ten];
    return ones[one] + ' و' + tens[ten];
  }
  const hundred = Math.floor(num / 100);
  const remainder = num % 100;
  if (remainder === 0) return hundreds[hundred];
  return hundreds[hundred] + ' و' + convertGroup(remainder);
}

export function numberToArabicWords(amount: number): string {
  if (amount === 0) return 'صفر ريال';
  
  const intPart = Math.floor(amount);
  const decPart = Math.round((amount - intPart) * 100);
  
  let result = 'فقط ';
  
  if (intPart >= 1000000) {
    const millions = Math.floor(intPart / 1000000);
    if (millions === 1) result += 'مليون';
    else if (millions === 2) result += 'مليونان';
    else if (millions <= 10) result += convertGroup(millions) + ' ملايين';
    else result += convertGroup(millions) + ' مليون';
    const remainder = intPart % 1000000;
    if (remainder > 0) result += ' و';
    else { result += ' ريال'; }
    if (remainder > 0) {
      result += numberToArabicWordsHelper(remainder);
    }
  } else {
    result += numberToArabicWordsHelper(intPart);
  }
  
  if (decPart > 0) {
    result += ' و' + convertGroup(decPart) + ' هللة';
  }
  
  return result + ' .';
}

function numberToArabicWordsHelper(num: number): string {
  if (num === 0) return '';
  let result = '';
  
  if (num >= 1000) {
    const thousands = Math.floor(num / 1000);
    if (thousands === 1) result += 'ألف';
    else if (thousands === 2) result += 'ألفان';
    else if (thousands <= 10) result += convertGroup(thousands) + ' آلاف';
    else result += convertGroup(thousands) + ' ألف';
    const remainder = num % 1000;
    if (remainder > 0) result += ' و' + convertGroup(remainder);
    result += ' ريال';
  } else {
    result += convertGroup(num) + ' ريال';
  }
  
  return result;
}

