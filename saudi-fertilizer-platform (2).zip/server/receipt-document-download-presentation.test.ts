import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'client/src/pages/ReceiptsPage.tsx'), 'utf8');

describe('تنزيل سند القبض مع الإيصال', () => {
  it('ينشئ PDF السند من مصدر موحد يحمّل الشعار ويولّد رمز QR', () => {
    expect(source).toContain('const createReceiptPdfBlob = async');
    expect(source).toContain('fetch(company.logoUrl)');
    expect(source).toContain('QRCode.toDataURL(qrValue');
    expect(source).toContain('printPresentation.showBarcode');
  });

  it('يعرض السند في تخطيط رأسي موحد يضع الشعار وQR في الرأس ويوازن جدول البيانات', () => {
    expect(source).toContain('const isPortrait = printPresentation.pageOrientation === \'portrait\'');
    expect(source).toContain('canvas.width = isPortrait ? 1240 : 1754');
    expect(source).toContain('canvas.height = isPortrait ? 1754 : 1240');
    expect(source).toContain("orientation: printPresentation.pageOrientation");
    expect(source).toContain('const headerBoundary = Math.round(canvas.height * (printPresentation.headerPercent / 100))');
    expect(source).toContain('const footerTop = canvas.height - Math.round(canvas.height * (printPresentation.footerPercent / 100))');
    expect(source).toContain('const contentTop = headerBoundary');
    expect(source).toContain('const contentBottom = footerTop');
    expect(source).toContain('const contentHeight = contentBottom - contentTop');
    expect(source).toContain('const contentInset = Math.max(24, Math.round(contentHeight * 0.02))');
    expect(source).toContain('contentBottom - Math.max(96, Math.round(contentHeight * 0.08))');
    expect(source).toContain("const companyName = (printPresentation.headerText || company?.companyName || 'شركة الأسمدة المتحدة السعودية').replace(/\\s+/g, ' ').trim()");
    expect(source).toContain("context.direction = 'rtl'");
    expect(source).toContain('const companyTitleMaxWidth = canvas.width - (isPortrait ? 340 : 560)');
    expect(source).toContain('while (context.measureText(companyName).width > companyTitleMaxWidth && companyTitleFontSize > 24)');
    expect(source).toContain("context.fillText(companyName, canvas.width / 2, 82)");
    expect(source).toContain("context.fillText(company?.address || 'المملكة العربية السعودية', canvas.width / 2, 120)");
    expect(source).toContain("context.fillText(labelFor('receipt_print_title', 'سند قبض'), canvas.width / 2, headerBoundary - 28)");
    expect(source).toContain('context.drawImage(qr, qrX, 32, qrSize, qrSize)');
    expect(source).toContain('const tableWidth = canvas.width - (pageInset * 2)');
    expect(source).toContain("const customerIdentity = [customer?.name || '-', customerStatement].filter(Boolean).join('\\n')");
    expect(source).toContain("right: [labelFor('field_customer_name', 'اسم العميل'), customerIdentity]");
    expect(source).toContain("context.fillText(labelFor('receipt_print_received_from', 'استلمنا من المكرم'), canvas.width - pageInset, top + 26)");
    expect(source).not.toContain("context.fillText(customer?.name || '-', canvas.width - pageInset - 24");
    expect(source).toContain("const rowHeight = isCustomerRow ? 86 : isLongRow ? 88 : 64");
    expect(source).toContain("context.fillText(labelFor('receipt_print_recipient', 'المستلم'), canvas.width / 2, signatureTop + 38)");
  });

  it('يبقي نافذة المعاينة وملف PDF رأسيين بتمرير داخلي فعلي', () => {
    expect(source).toContain("const companyName = (headerText || company?.companyName || 'شركة الأسمدة المتحدة السعودية').replace(/\\s+/g, ' ').trim()");
    expect(source).toContain('const detailRows = [');
    expect(source).toContain("rightValue: customerIdentity");
    expect(source).toContain('whitespace-pre-line border border-slate-300');
    expect(source).toContain('w-full min-w-0 bg-white');
    expect(source).toContain('block w-full whitespace-nowrap font-bold leading-8 tracking-[-0.04em]');
    expect(source).toContain('QRCodeSVG value={qrData} size={68}');
    expect(source).toContain('w-[19%] border border-slate-300 bg-slate-100');
    expect(source).toContain('flex flex-col gap-3');
    expect(source).toContain('min-w-0 self-end text-right');
    expect(source).toContain("width: 'min(34rem, calc(100vw - 2rem))'");
    expect(source).toContain("height: '72dvh'");
    expect(source).toContain('min-h-0 flex-1 overflow-x-hidden overflow-y-scroll overscroll-contain bg-muted p-3');
    expect(source).toContain("scrollbarGutter: 'stable'");
    expect(source).toContain('aria-label="منطقة تمرير معاينة سند القبض"');
    expect(source).toContain('data-receipt-preview-scroll');
    expect(source).not.toContain('border-2 inline-block px-8 py-2 rounded-lg');
  });

  it('يفتح الطباعة الفردية من ملف PDF الموحد بعد اكتمال الشعار وQR، لا من نسخة DOM قد تطبع الصور فارغة', () => {
    expect(source).toContain("const handlePrint = async (receipt: any, printType: 'receipt' | 'receipt_with_attachment' = 'receipt')");
    expect(source).toContain("const receiptPdf = await createReceiptPdfBlob(receipt)");
    expect(source).toContain('printWindow.location.replace(receiptPdfUrl)');
    expect(source).toContain('downloadBlob(receiptPdf, `${receipt.serialNumber}.pdf`)');
    expect(source).not.toContain('<body>${printContent.innerHTML}</body>');
  });

  it('يبني المعاينة والطباعة من السند الكامل ويستخدم نفس البيان والمبلغ كتابة واسم الرأس', () => {
    expect(source).toContain('receipt = await utils.receipts.getById.fetch({ id: receipt.id }) || receipt');
    expect(source).toContain("receipt.amountInWords || numberToArabicWords(Number(receipt.amount))");
    expect(source).toContain("...(receipt.notes ? [{ right: [labelFor('field_notes', 'ملاحظات'), receipt.notes]");
    expect(source).toContain('const openReceiptPreview = async (receipt: any) =>');
    expect(source).toContain('onClick={() => void downloadReceiptDocument(r)}');
    expect(source).toContain('utils.receipts.getById.fetch({ id: receiptId })');
  });

  it('يجهز ملفي السند المنفرد والإيصال قبل النقر ثم ينزلهما كملفي PDF متتاليين', () => {
    expect(source).toContain('const preparedReceiptDocumentsRef = useRef(new Map<number, { receiptPdf: Blob; attachmentPdf: Blob }>())');
    expect(source).toContain('const prepareReceiptAndAttachment = async');
    expect(source).toContain('const [receiptPdf, attachmentPdf] = await Promise.all([createReceiptPdfBlob(receipt), createAttachmentPdfBlob(receipt)])');
    expect(source).toContain('preparedReceiptDocumentsRef.current.set(receipt.id, documents)');
    expect(source).toContain('downloadBlob(documents.receiptPdf, `${receipt.serialNumber}.pdf`)');
    expect(source).toContain('downloadBlob(documents.attachmentPdf, `${receipt.serialNumber}-ESAL.pdf`)');
    expect(source).toContain("toast.success('تم إرسال سند القبض ثم إيصال التحويل كملفي PDF متتاليين')");
    expect(source).toContain('const isSingleReceiptDownloadPrepared = !singleReceiptWithAttachmentNeedsPreparation');
    expect(source).toContain('disabled={selectedReceipts.length === 0 || (Boolean(singleSelectedReceipt) && !isSingleReceiptDownloadPrepared)}');
    expect(source).toContain("aria-label={isPreparingSingleReceiptDownload ? 'يتم تجهيز ملفي PDF للتنزيل'");
    expect(source).toContain('createAttachmentPdf: createAttachmentPdfBlob');
  });

  it('يعالج إجراء «طباعة السند مع الإيصال» بملفي PDF المجهزين ولا يفتح رابط المرفق الخام', () => {
    expect(source).toContain("recordPrintMutation.mutate({ receiptId: receipt.id, printType: 'receipt_with_attachment' })");
    expect(source).toContain('void downloadReceiptAndAttachment(receipt)');
    expect(source).not.toContain("window.open(receipt.attachmentUrl, '_blank', 'noopener,noreferrer')");
  });

  it('يعفي النقد من الإيصال ويبدل تسمية البنك إلى بنك الإيداع في النموذج والمعاينة وPDF', () => {
    expect(source).toContain('function isCashPaymentMethod(');
    expect(source).toContain("return isCash ? 'سيتم الإيداع في' : defaultLabel");
    expect(source).toContain('const attachmentRequired = !isCashPayment');
    expect(source).toContain('setAttachmentFile(null)');
    expect(source).toContain('سيتم الإيداع في: {selectedBank?.name || \'اختر البنك\'}');
    expect(source).toContain('paymentMethod={paymentMethods.find(p => p.id === previewReceipt.paymentMethodId)}');
    expect(source).toContain('isCashPaymentMethod(paymentMethodRecord)');
  });
});
