import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const projectRoot = resolve(__dirname, '..');
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), 'utf8');

describe('تسميات العرض في ملف PDF للتقارير', () => {
  it('يوفر القاموس القيم الافتراضية ويتقبل تجاوز المدير للنصوص الثابتة في PDF', () => {
    const settings = {
      system_label_overrides: JSON.stringify({
        report_pdf_title: 'ملخص التقرير',
        report_pdf_column_customer: 'اسم العميل',
        report_print_logo_alt: 'هوية التقارير',
        report_export_empty: 'لا توجد سجلات جاهزة للتصدير',
      }),
    };

    expect(getSystemLabel(null, 'report_pdf_title')).toBe('Report');
    expect(getSystemLabel(null, 'report_pdf_period')).toBe('Period');
    expect(getSystemLabel(null, 'report_pdf_total_amount')).toBe('Total Amount');
    expect(getSystemLabel(null, 'report_pdf_column_payment_method')).toBe('Payment Method');
    expect(getSystemLabel(null, 'report_print_logo_alt')).toBe('شعار الشركة');
    expect(getSystemLabel(null, 'report_export_empty')).toBe('لا توجد بيانات للتصدير');
    expect(getSystemLabel(settings, 'report_pdf_title')).toBe('ملخص التقرير');
    expect(getSystemLabel(settings, 'report_pdf_column_customer')).toBe('اسم العميل');
    expect(getSystemLabel(settings, 'report_print_logo_alt')).toBe('هوية التقارير');
    expect(getSystemLabel(settings, 'report_export_empty')).toBe('لا توجد سجلات جاهزة للتصدير');
  });

  it('يربط النصوص المرئية بالقاموس مع حماية بيانات التقرير واسم الملف والتنزيل', () => {
    const reportsPage = readProjectFile('client/src/pages/ReportsPage.tsx');

    expect(reportsPage).toContain("labelFor('report_pdf_title', 'Report')");
    expect(reportsPage).toContain("labelFor('report_pdf_total_receipts', 'Total Receipts')");
    expect(reportsPage).toContain("labelFor('report_pdf_column_payment_method', 'Payment Method')");
    expect(reportsPage).toContain("labelFor('report_print_logo_alt', 'شعار الشركة')");
    expect(reportsPage).toContain("labelFor('report_export_empty', 'لا توجد بيانات للتصدير')");
    expect(reportsPage).toContain('if (filteredReceipts.length === 0)');
    expect(reportsPage).toContain('toast.error(labelFor(\'report_export_empty\', \'لا توجد بيانات للتصدير\'));');
    expect(reportsPage).toContain('return;');
    expect(reportsPage).toContain('r.serialNumber');
    expect(reportsPage).toContain('parseFloat(r.amount).toLocaleString()');
    expect(reportsPage).toContain('const fileName = `report_${reportType}_${new Date().toISOString().slice(0, 10)}.pdf`;');
    expect(reportsPage).toContain('doc.save(fileName);');
  });
});
