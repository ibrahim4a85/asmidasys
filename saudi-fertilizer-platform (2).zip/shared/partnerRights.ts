export type PartnerAccountEntryKind = "withdrawal" | "entitlement" | "year_end_settlement";
export type SettlementDirection = "credit" | "debit" | null | undefined;
export const partnerEquityLineTypes = ["opening_balance", "capital", "legal_reserve", "retained_earnings", "profit_distribution", "net_income", "actuarial_remeasurement", "custom"] as const;
export type PartnerEquityLineType = (typeof partnerEquityLineTypes)[number];
export const partnerPeriodDocumentTypes = ["distribution_minutes", "year_end_settlement", "financial_statements", "custom"] as const;
export type PartnerPeriodDocumentType = (typeof partnerPeriodDocumentTypes)[number];

export type PartnerAccountMovement = {
  entryType: PartnerAccountEntryKind;
  amount: string | number;
  settlementDirection?: SettlementDirection;
};

export function toPartnerMoney(value: string | number | null | undefined) {
  const numeric = typeof value === "number" ? value : Number(value || 0);
  return Number.isFinite(numeric) ? numeric : 0;
}

export function calculatePartnerOpeningBalance(openingProfitBalance: string | number | null | undefined, sharePercentage: string | number | null | undefined) {
  return toPartnerMoney(openingProfitBalance) * (toPartnerMoney(sharePercentage) / 100);
}

export function calculatePartnerAccountSummary(input: {
  openingProfitBalance: string | number | null | undefined;
  sharePercentage: string | number | null | undefined;
  entries: PartnerAccountMovement[];
}) {
  const openingBalance = calculatePartnerOpeningBalance(input.openingProfitBalance, input.sharePercentage);
  let entitlements = 0;
  let withdrawals = 0;
  let settlementCredits = 0;
  let settlementDebits = 0;

  for (const entry of input.entries) {
    const amount = toPartnerMoney(entry.amount);
    if (entry.entryType === "entitlement") entitlements += amount;
    if (entry.entryType === "withdrawal") withdrawals += amount;
    if (entry.entryType === "year_end_settlement") {
      if (entry.settlementDirection === "debit") settlementDebits += amount;
      else settlementCredits += amount;
    }
  }

  const closingBalance = openingBalance + entitlements + settlementCredits - withdrawals - settlementDebits;
  return { openingBalance, entitlements, withdrawals, settlementCredits, settlementDebits, closingBalance };
}

export function calculateAggregateSharePercentage(allocations: Array<{ sharePercentage: string | number | null | undefined }>) {
  return allocations.reduce((total, allocation) => total + toPartnerMoney(allocation.sharePercentage), 0);
}

export function isValidShareTotal(total: number) {
  return total >= 0 && total <= 100 + 0.000001;
}

export function calculateEquityLineTotal(input: {
  capitalAmount: string | number | null | undefined;
  legalReserveAmount: string | number | null | undefined;
  retainedEarningsAmount: string | number | null | undefined;
}) {
  return toPartnerMoney(input.capitalAmount) + toPartnerMoney(input.legalReserveAmount) + toPartnerMoney(input.retainedEarningsAmount);
}
