import { describe, expect, it } from 'vitest';
import JSZip from 'jszip';
import { PDFDocument } from 'pdf-lib';
import { getApprovalTemplateOutputName, stampApprovalTemplate } from './approvalTemplates';

describe('نماذج التعميدات المرقمة', () => {
  it('يسمي النموذج المحمّل برقم التعميد وصيغته', () => {
    expect(getApprovalTemplateOutputName('RA101-001', 'application/pdf')).toBe('RA101-001-form.pdf');
    expect(getApprovalTemplateOutputName('RA101-001', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')).toBe('RA101-001-form.docx');
  });

  it('يختم نموذج PDF برقم التعميد في الصفحة الأولى', async () => {
    const source = await PDFDocument.create();
    source.addPage([400, 600]);
    const stamped = await stampApprovalTemplate({
      file: Buffer.from(await source.save()),
      mimeType: 'application/pdf',
      approvalNumber: 'RA101-001',
    });
    const parsed = await PDFDocument.load(stamped);
    expect(parsed.getPageCount()).toBe(1);
    expect(stamped.byteLength).toBeGreaterThan(0);
  });

  it('يضيف رقم التعميد بمحاذاة يسارية إلى نموذج Word', async () => {
    const source = new JSZip();
    source.file('word/document.xml', '<w:document><w:body><w:p><w:r><w:t>نموذج</w:t></w:r></w:p></w:body></w:document>');
    const stamped = await stampApprovalTemplate({
      file: Buffer.from(await source.generateAsync({ type: 'nodebuffer' })),
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      approvalNumber: 'RA101-001',
    });
    const result = await JSZip.loadAsync(stamped);
    const xml = await result.file('word/document.xml')?.async('string');
    expect(xml).toContain('RA101-001');
    expect(xml).toContain('<w:jc w:val="left"/>');
  });
});
