CREATE TABLE `backup_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`operation` enum('download','restore') NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`recordsCount` int NOT NULL DEFAULT 0,
	`status` enum('success','failed') NOT NULL DEFAULT 'success',
	`details` text,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backup_logs_id` PRIMARY KEY(`id`)
);
