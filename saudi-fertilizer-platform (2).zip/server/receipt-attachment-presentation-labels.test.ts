import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const receiptsPagePath = fileURLToPath(new URL('../client/src/pages/ReceiptsPage.tsx', import.meta.url));

describe('تسميات وصول إيصال التحويل في سجل سندات القبض', () => {
  it('تعيد القيم الافتراضية وتقبل تجاوز المدير لتسميات الوصول المرئية', () => {
    expect(getSystemLabel({}, 'receipts_attachment_preview')).toBe('معاينة الإيصال');
    expect(getSystemLabel({}, 'receipts_attachment_download')).toBe('تنزيل الإيصال');
    expect(getSystemLabel({}, 'receipts_attachment_requires_approval')).toBe('يتطلب صلاحية اعتماد');
    expect(getSystemLabel({}, 'receipts_attachment_missing')).toBe('لا يوجد');
    expect(getSystemLabel({}, 'receipts_table_status')).toBe('الحالة');
    expect(getSystemLabel({}, 'receipts_attachment_preview_dialog_title')).toBe('معاينة إيصال التحويل');
    expect(getSystemLabel({}, 'receipts_preview_dialog_title')).toBe('معاينة سند القبض');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ receipts_attachment_preview: 'استعراض المستند المرفق' }) }, 'receipts_attachment_preview')).toBe('استعراض المستند المرفق');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ receipts_table_status: 'وضع السند' }) }, 'receipts_table_status')).toBe('وضع السند');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ receipts_preview_dialog_title: 'استعراض السند' }) }, 'receipts_preview_dialog_title')).toBe('استعراض السند');
  });

  it('يحافظ على الصلاحية والمعاينة والتنزيل بعد نقلها إلى اختصارات السند الملونة', () => {
    const source = readFileSync(receiptsPagePath, 'utf8');
    expect(source).toContain("labelFor('receipts_table_status', 'الحالة')");
    expect(source).toContain("labelFor('receipts_attachment_preview_dialog_title', 'معاينة إيصال التحويل')");
    expect(source).toContain("labelFor('receipts_preview_dialog_title', 'معاينة سند القبض')");
    expect(source).toContain('aria-label={`اختصارات سند ${r.serialNumber}`}');
    expect(source).toContain('r.attachmentUrl && canApprove');
    expect(source).toContain('title="معاينة الإيصال"');
    expect(source).toContain("title={r.attachmentUrl ? 'تحميل السند مع الإيصال' : 'لا يوجد إيصال مرفق'}");
    expect(source).toContain('setAttachmentPreviewReceipt(r)');
    expect(source).toContain('downloadReceiptAndAttachment(r)');
    expect(source).toContain('attachmentPreviewReceipt?.serialNumber');
    expect(source).toContain('setPreviewReceipt(null)');
    expect(source).toContain('<PrintableReceipt');
    expect(source).toContain('statusLabel(r.status)');
    expect(source).toContain("openReceiptDecision(r, 'approved')");
    expect(source).toContain('setDeleteReceipt(r)');
  });
});
