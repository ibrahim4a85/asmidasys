import { describe, expect, it } from 'vitest';
import { filterPerformanceReports, summarizePerformanceReports } from '../shared/performanceReportSummary';

describe('تصفية وإجماليات تقارير الأداء', () => {
  const reports = [
    { id: 1, branchId: 1, reportDate: '2026-08-01', salesInvoicesCount: 2, salesInvoicesValue: 200, returnsInvoicesCount: 1, returnsInvoicesValue: 20, netSalesValue: 180, receiptsCount: 1, collectionsValue: 90 },
    { id: 2, branchId: 1, reportDate: '2026-08-03', salesInvoicesCount: 3, salesInvoicesValue: 300, returnsInvoicesCount: 0, returnsInvoicesValue: 0, netSalesValue: 300, receiptsCount: 2, collectionsValue: 120 },
    { id: 3, branchId: 2, reportDate: '2026-08-03', salesInvoicesCount: 5, salesInvoicesValue: 500, returnsInvoicesCount: 2, returnsInvoicesValue: 50, netSalesValue: 450, receiptsCount: 3, collectionsValue: 400 },
  ];

  it('يصفي بالتاريخ والفرع ويرتب اليوم الأحدث أولاً', () => {
    expect(filterPerformanceReports(reports, { branchId: '1', startDate: '2026-08-02', endDate: '2026-08-03' }).map(report => report.id)).toEqual([2]);
    expect(filterPerformanceReports(reports, { day: '2026-08-03' }).map(report => report.id)).toEqual([2, 3]);
  });

  it('يحسب إجماليات المبيعات والمرتجعات والمتحصلات لصف الإجمالي', () => {
    expect(summarizePerformanceReports(reports)).toMatchObject({ salesCount: 10, salesValue: 1000, returnsCount: 3, returnsValue: 70, netSales: 930, receiptsCount: 6, collectionsValue: 610 });
  });
});
