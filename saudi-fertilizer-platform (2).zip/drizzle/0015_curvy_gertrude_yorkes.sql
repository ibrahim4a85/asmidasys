CREATE TABLE `approval_request_reviewer_steps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestId` int NOT NULL,
	`workflowId` int NOT NULL,
	`systemUserId` int NOT NULL,
	`stepOrder` int NOT NULL,
	`status` enum('pending','approved','rejected','skipped') NOT NULL DEFAULT 'pending',
	`note` text,
	`actedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `approval_request_reviewer_steps_id` PRIMARY KEY(`id`),
	CONSTRAINT `approval_request_reviewer_step_unique` UNIQUE(`requestId`,`systemUserId`)
);
--> statement-breakpoint
CREATE TABLE `approval_workflow_reviewers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workflowId` int NOT NULL,
	`systemUserId` int NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `approval_workflow_reviewers_id` PRIMARY KEY(`id`),
	CONSTRAINT `approval_workflow_reviewer_unique` UNIQUE(`workflowId`,`systemUserId`)
);
--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewerSequential` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `requiredReviews` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewedCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `currentReviewStepOrder` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `approverSequential` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `reviewerSequential` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `requiredReviews` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `approverSequential` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `document_types` ADD `templateRequirement` enum('optional','required') DEFAULT 'optional' NOT NULL;--> statement-breakpoint
ALTER TABLE `document_types` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;