import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Pencil, Trash2, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { DeleteConfirmationDialog } from '@/components/DeleteConfirmationDialog';
import { useSystemLabels } from '@/hooks/useSystemLabels';
import { readSystemUserTypeDefinitions } from '@shared/systemUserTypes';

const sidebarPermissionLabels = [
  ['sidebar_dashboard', 'لوحة التحكم'], ['sidebar_notifications', 'سجل الإشعارات'], ['sidebar_settings', 'إعدادات النظام'],
  ['sidebar_users', 'إدارة المستخدمين'], ['sidebar_receipts', 'سندات القبض'], ['sidebar_payments', 'سندات الصرف'],
  ['sidebar_customers', 'إدارة العملاء'], ['sidebar_targets', 'إدارة الأهداف'], ['sidebar_performance-reports', 'تقارير الأداء'],
  ['sidebar_delegates', 'التعميدات'], ['sidebar_reports', 'التقارير'], ['sidebar_partner-rights', 'حقوق الشركاء'],
] as const;
const standardSidebarPermissions = Object.fromEntries(sidebarPermissionLabels.map(([key]) => [key, true]));
const partnerSidebarPermissions = Object.fromEntries(sidebarPermissionLabels.map(([key]) => [key, ['sidebar_dashboard', 'sidebar_notifications', 'sidebar_delegates', 'sidebar_reports', 'sidebar_partner-rights'].includes(key)]));
const reportsOnlySidebarPermissions = Object.fromEntries(sidebarPermissionLabels.map(([key]) => [key, key === 'sidebar_reports']));
const emptyPermissions: Record<string, boolean> = {
  customersManage: false, targetsManage: false, goalsView: false, goalsManage: false, goalsReview: false, goalsExecute: false, commissionsManage: false,
  receiptsApprove: false, dataDelete: false, approvalRequest: true, approvalDelegate: false,
  partnerRightsView: false, partnerRightsCreateEntries: false, partnerRightsEditEntries: false, partnerRightsManage: false,
  ...standardSidebarPermissions,
};

export default function UsersManagement() {
  const { isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const [open, setOpen] = useState(false);
  const [editUser, setEditUser] = useState<any>(null);
  const [deleteUser, setDeleteUser] = useState<any>(null);
  const [form, setForm] = useState({ username: '', password: '', fullName: '', userType: 'delegate' as any, userLevel: 'secondary' as any, branchId: null as number | null, phone: '', email: '', boardPosition: '', permissions: emptyPermissions });

  const { data: users, refetch } = trpc.systemUsers.list.useQuery();
  const { data: branches } = trpc.branches.list.useQuery();
  const { data: settings } = trpc.settings.getAll.useQuery();
  const createMutation = trpc.systemUsers.create.useMutation({ onSuccess: () => { refetch(); setOpen(false); resetForm(); toast.success('تم إضافة المستخدم بنجاح'); }, onError: error => toast.error(error.message || 'تعذر إضافة المستخدم') });
  const updateMutation = trpc.systemUsers.update.useMutation({ onSuccess: () => { refetch(); setOpen(false); resetForm(); toast.success('تم تحديث المستخدم بنجاح'); }, onError: error => toast.error(error.message || 'تعذر تحديث المستخدم') });
  const deleteMutation = trpc.systemUsers.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف المستخدم'); } });

  const resetForm = () => { setForm({ username: '', password: '', fullName: '', userType: 'delegate', userLevel: 'secondary', branchId: null, phone: '', email: '', boardPosition: '', permissions: emptyPermissions }); setEditUser(null); };

  const handleSubmit = () => {
    if (!form.username || !form.fullName) { toast.error('يرجى ملء الحقول المطلوبة'); return; }
    if (editUser) {
      const { password, ...dataWithoutPassword } = form;
      updateMutation.mutate({ id: editUser.id, data: password.trim() ? form : dataWithoutPassword });
    } else {
      if (!form.password) { toast.error('يرجى إدخال كلمة المرور'); return; }
      createMutation.mutate(form as any);
    }
  };

  const handleEdit = (u: any) => {
    setEditUser(u);
    setForm({ username: u.username, password: '', fullName: u.fullName, userType: u.userType, userLevel: u.userLevel, branchId: u.branchId, phone: u.phone || '', email: u.email || '', boardPosition: u.boardPosition || '', permissions: { ...emptyPermissions, ...(u.permissions || {}) } });
    setOpen(true);
  };

  const userTypeDefinitions = readSystemUserTypeDefinitions(settings?.system_user_type_definitions);
  const legacyTypeLabels: Record<string, string> = {
    accountant: labelFor('user_type_accountant', 'محاسب (نوع قديم)'),
    branch_supervisor: labelFor('user_type_branch_supervisor', 'مشرف فرع (نوع قديم)'),
  };
  const typeLabels: Record<string, string> = {
    ...Object.fromEntries(userTypeDefinitions.map(definition => [definition.code, definition.label])),
    ...legacyTypeLabels,
  };
  const selectableUserTypes = userTypeDefinitions.filter(definition => definition.isActive || definition.code === form.userType);
  const userLevelLabels: Record<string, string> = {
    primary: labelFor('user_level_primary', 'رئيسي'),
    secondary: labelFor('user_level_secondary', 'فرعي'),
  };
  const boardPositionLabels: Record<string, string> = {
    'رئيس مجلس الإدارة': labelFor('users_board_position_chair', 'رئيس مجلس الإدارة'),
    'عضو مجلس الإدارة': labelFor('users_board_position_member', 'عضو مجلس الإدارة'),
    'شريك فقط': labelFor('users_board_position_partner_only', 'شريك فقط'),
  };
  const sidebarPermissionText = (key: string, fallback: string) => labelFor(`nav_${key.replace(/^sidebar_/, '').replace('-', '_')}` as any, fallback);

  if (!isAdmin) return <div className="text-center py-20 text-muted-foreground">{labelFor('users_access_denied', 'ليس لديك صلاحية الوصول لهذه الصفحة')}</div>;

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">{labelFor('nav_users', 'إدارة المستخدمين')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{labelFor('users_page_subtitle', 'إضافة وإدارة مستخدمي النظام وصلاحياتهم')}</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
          <DialogTrigger asChild>
            <Button><UserPlus className="h-4 w-4 ml-2" />{labelFor('users_add', 'إضافة مستخدم')}</Button>
          </DialogTrigger>
          <DialogContent className="flex max-h-[92dvh] max-w-[calc(100%-1rem)] flex-col overflow-hidden p-0 sm:max-w-lg" dir="rtl">
            <DialogHeader className="shrink-0 border-b px-4 py-3 sm:px-6 sm:py-4"><DialogTitle>{editUser ? labelFor('users_edit', 'تعديل مستخدم') : labelFor('users_add_new', 'إضافة مستخدم جديد')}</DialogTitle></DialogHeader>
            <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3 sm:px-6 sm:py-4">
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>{labelFor('field_name', 'الاسم')} *</Label>
                <Input value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_username', 'اسم المستخدم')} *</Label>
                <Input value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>{editUser ? `${labelFor('field_password', 'كلمة المرور')} ${labelFor('users_new_password_suffix', 'الجديدة')}` : `${labelFor('field_password', 'كلمة المرور')} *`}</Label>
                <Input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_user_type', 'نوع المستخدم')}</Label>
                <Select value={form.userType} onValueChange={v => setForm({ ...form, userType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {selectableUserTypes.map(definition => <SelectItem key={definition.code} value={definition.code}>{definition.label}{!definition.isActive ? ' (غير نشط)' : ''}</SelectItem>)}
                    {!userTypeDefinitions.some(definition => definition.code === form.userType) && <SelectItem value={form.userType}>{typeLabels[form.userType] || `نوع قديم: ${form.userType}`}</SelectItem>}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_user_level', 'المستوى')}</Label>
                <Select value={form.userLevel} onValueChange={v => setForm({ ...form, userLevel: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="primary">{userLevelLabels.primary}</SelectItem>
                    <SelectItem value="secondary">{userLevelLabels.secondary}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_branch', 'الفرع')}</Label>
                <Select value={form.branchId?.toString() || ''} onValueChange={v => setForm({ ...form, branchId: v ? parseInt(v) : null })}>
                  <SelectTrigger><SelectValue placeholder={labelFor('users_select_branch', 'اختر الفرع')} /></SelectTrigger>
                  <SelectContent>
                    {branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_phone', 'رقم الهاتف')}</Label>
                <Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_email', 'البريد الإلكتروني')}</Label>
                <Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
              </div>
              {form.userType === 'authorized_partner' && (
                <div className="col-span-full space-y-2 sm:col-span-2">
                  <Label>{labelFor('users_partner_position', 'منصب الشريك / عضو مجلس الإدارة')}</Label>
                  <Select value={form.boardPosition || '__none__'} onValueChange={v => setForm({ ...form, boardPosition: v === '__none__' ? '' : v, permissions: v === 'شريك فقط' ? { ...form.permissions, ...reportsOnlySidebarPermissions, approvalRequest: false, approvalDelegate: false } : { ...form.permissions, ...partnerSidebarPermissions, approvalDelegate: v !== '__none__' } })}>
                  <SelectTrigger><SelectValue placeholder={labelFor('users_select_position', 'اختر المنصب')} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="رئيس مجلس الإدارة">{boardPositionLabels['رئيس مجلس الإدارة']}</SelectItem>
                    <SelectItem value="عضو مجلس الإدارة">{boardPositionLabels['عضو مجلس الإدارة']}</SelectItem>
                    <SelectItem value="شريك فقط">{boardPositionLabels['شريك فقط']}</SelectItem>
                      <SelectItem value="__none__">{labelFor('users_no_position', 'بدون منصب')}</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">{labelFor('users_non_signing_partner_hint', 'لا يُحتسب «شريك فقط» ضمن موافقتي مجلس الإدارة الإلزاميتين.')}</p>
                </div>
              )}
            </div>
            <div className="mt-5 rounded-xl border bg-muted/30 p-4">
              <p className="text-sm font-semibold">{labelFor('users_extra_permissions', 'صلاحيات إضافية')}</p>
              <p className="mt-1 text-xs text-muted-foreground">{labelFor('users_permissions_hint', 'تظل الأدوات الحساسة مقصورة على المدير، ما لم تُمنح الصلاحية أدناه صراحةً.')}</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {([
                  ['customersManage', 'users_permission_customers_manage', 'إدارة العملاء'],
                  ['targetsManage', 'users_permission_targets_manage', 'إدارة الأهداف'],
                  ['goalsView', 'users_permission_goals_view', 'عرض الأهداف'],
                  ['goalsManage', 'users_permission_goals_manage', 'إدارة الأهداف المتقدمة'],
                  ['goalsReview', 'users_permission_goals_review', 'مراجعة الأهداف والإجراءات'],
                  ['goalsExecute', 'users_permission_goals_execute', 'تنفيذ الإجراءات المسندة'],
                  ['commissionsManage', 'users_permission_commissions_manage', 'إدارة قواعد العمولات'],
                  ['receiptsApprove', 'users_permission_receipts_approve', 'اعتماد سندات القبض'],
                  ['dataDelete', 'users_permission_data_delete', 'حذف البيانات الانتقائي'],
                  ['approvalRequest', 'users_permission_approval_request', 'طلب تعميد المستندات'],
                  ['approvalDelegate', 'users_permission_approval_delegate', 'التفويض بالتعميد'],
                ] as const).map(([key, labelId, fallback]) => <label key={key} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm">
                  <Checkbox checked={form.permissions[key]} onCheckedChange={(checked) => setForm(current => ({ ...current, permissions: { ...current.permissions, [key]: checked === true } }))} />
                  <span>{labelFor(labelId, fallback)}</span>
                </label>)}
              </div>
            </div>
            <div className="mt-4 rounded-xl border border-primary/20 bg-primary/[0.03] p-4">
              <p className="text-sm font-semibold text-primary">حقوق الشركاء</p>
              <p className="mt-1 text-xs text-muted-foreground">عرض التقرير منفصل عن إضافة وتعديل حركات الحساب وإدارة ملفات الشركاء وحصصهم. الشريك المفوض يحصل على العرض فقط افتراضياً.</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {([
                  ['partnerRightsView', 'عرض تقرير حقوق الشركاء'],
                  ['partnerRightsCreateEntries', 'إضافة سجلات الشركاء'],
                  ['partnerRightsEditEntries', 'تعديل وحذف سجلات الشركاء'],
                  ['partnerRightsManage', 'إدارة الشركاء والحصص والمرفقات'],
                ] as const).map(([key, label]) => <label key={key} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm">
                  <Checkbox checked={Boolean(form.permissions[key])} onCheckedChange={(checked) => setForm(current => ({ ...current, permissions: { ...current.permissions, [key]: checked === true } }))} />
                  <span>{label}</span>
                </label>)}
              </div>
            </div>
            <div className="mt-4 rounded-xl border bg-muted/30 p-4">
              <p className="text-sm font-semibold">{labelFor('users_sidebar_visibility', 'إظهار عناصر القائمة الجانبية')}</p>
              <p className="mt-1 text-xs text-muted-foreground">{labelFor('users_sidebar_visibility_hint', 'يتحكم المدير في ظهور كل صفحة للمستخدم، مع بقاء القيود الإجرائية الأخرى مطبقة.')}</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {sidebarPermissionLabels.map(([key, label]) => <label key={key} className="flex cursor-pointer items-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm">
                  <Checkbox checked={Boolean(form.permissions[key])} onCheckedChange={(checked) => setForm(current => ({ ...current, permissions: { ...current.permissions, [key]: checked === true } }))} />
                  <span>{sidebarPermissionText(key, label)}</span>
                </label>)}
              </div>
            </div>
            </div>
            <div className="flex shrink-0 flex-col-reverse gap-2 border-t bg-background px-4 py-3 sm:flex-row sm:justify-end sm:px-6 sm:py-4">
              <Button className="w-full sm:w-auto" variant="outline" onClick={() => { setOpen(false); resetForm(); }}>{labelFor('action_cancel', 'إلغاء')}</Button>
              <Button className="w-full sm:w-auto" onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>{(createMutation.isPending || updateMutation.isPending) ? labelFor('users_saving', 'جارٍ الحفظ...') : editUser ? labelFor('users_update', 'تحديث') : labelFor('action_add', 'إضافة')}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="overflow-x-auto p-0">
          <Table className="min-w-[720px]">
            <TableHeader>
              <TableRow>
                <TableHead>{labelFor('field_name', 'الاسم')}</TableHead>
                <TableHead>{labelFor('field_username', 'اسم المستخدم')}</TableHead>
                <TableHead>{labelFor('field_user_type', 'نوع المستخدم')}</TableHead>
                <TableHead>{labelFor('field_user_level', 'المستوى')}</TableHead>
                <TableHead>{labelFor('field_branch', 'الفرع')}</TableHead>
                <TableHead>{labelFor('field_status', 'الحالة')}</TableHead>
                <TableHead>{labelFor('field_actions', 'إجراءات')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users?.map(u => (
                <TableRow key={u.id}>
                  <TableCell className="font-medium">{u.fullName}</TableCell>
                  <TableCell>{u.username}</TableCell>
                  <TableCell><Badge variant="secondary">{typeLabels[u.userType] || `نوع قديم: ${u.userType}`}</Badge></TableCell>
                  <TableCell>{userLevelLabels[u.userLevel] || u.userLevel}</TableCell>
                  <TableCell>{branches?.find(b => b.id === u.branchId)?.name || '-'}</TableCell>
                  <TableCell><Badge variant={u.isActive ? 'default' : 'destructive'}>{u.isActive ? labelFor('users_active', 'نشط') : labelFor('users_disabled', 'معطل')}</Badge></TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(u)}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setDeleteUser(u)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <DeleteConfirmationDialog
        open={Boolean(deleteUser)}
        onOpenChange={open => !open && setDeleteUser(null)}
        title="تأكيد حذف المستخدم"
        itemName={deleteUser?.fullName || ''}
        details={[
          `اسم المستخدم: ${deleteUser?.username || '-'}`,
          `النوع: ${typeLabels[deleteUser?.userType] || (deleteUser?.userType ? `نوع قديم: ${deleteUser.userType}` : '-')}`,
          `الفرع: ${branches?.find(branch => branch.id === deleteUser?.branchId)?.name || '-'}`,
        ]}
        isPending={deleteMutation.isPending}
        onConfirm={() => { if (deleteUser) deleteMutation.mutate({ id: deleteUser.id }); setDeleteUser(null); }}
      />
    </div>
  );
}
