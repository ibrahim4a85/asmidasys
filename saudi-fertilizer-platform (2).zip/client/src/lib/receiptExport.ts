import { getReceiptStatement } from '@shared/receiptPresentation';

type IdentifiedName = { id: number; name?: string; fullName?: string };
type CustomerExportRecord = IdentifiedName & { customerNumber?: string };

export type ReceiptExportSource = {
  id: number;
  serialNumber: string;
  createdAt: Date | string | number;
  branchId?: number | null;
  userId?: number | null;
  customerId?: number | null;
  amount: string | number;
  paymentMethodId?: number | null;
  paymentForId?: number | null;
  invoices?: unknown[] | null;
  status: 'draft' | 'issued' | 'approved' | 'rejected';
};

export type ReceiptExportLookups = {
  branches?: IdentifiedName[];
  users?: IdentifiedName[];
  customers?: CustomerExportRecord[];
  paymentMethods?: IdentifiedName[];
  paymentFors?: IdentifiedName[];
};

export function receiptExportStatusLabel(status: ReceiptExportSource['status']) {
  return status === 'approved' ? 'معتمد' : status === 'issued' ? 'تم الإصدار' : status === 'rejected' ? 'مرفوض' : 'مسودة';
}

export function buildReceiptExportRows(receipts: ReceiptExportSource[], lookups: ReceiptExportLookups = {}) {
  return receipts.map(receipt => ({
    'الرقم التسلسلي': receipt.serialNumber,
    'التاريخ': new Date(receipt.createdAt).toLocaleDateString('ar-SA'),
    'الفرع': lookups.branches?.find(branch => branch.id === receipt.branchId)?.name || '-',
    'المندوب': lookups.users?.find(systemUser => systemUser.id === receipt.userId)?.fullName || '-',
    'رقم العميل': lookups.customers?.find(customer => customer.id === receipt.customerId)?.customerNumber || '-',
    'العميل': lookups.customers?.find(customer => customer.id === receipt.customerId)?.name || '-',
    'المبلغ': Number(receipt.amount).toLocaleString('ar-SA'),
    'طريقة الدفع': lookups.paymentMethods?.find(method => method.id === receipt.paymentMethodId)?.name || '-',
    'البيان': getReceiptStatement(
      receipt.invoices as any,
      lookups.paymentFors?.find(paymentFor => paymentFor.id === receipt.paymentForId)?.name,
    ).join(' | '),
    'الحالة': receiptExportStatusLabel(receipt.status),
  }));
}
