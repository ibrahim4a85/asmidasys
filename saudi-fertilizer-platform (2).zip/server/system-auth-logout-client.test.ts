import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const projectRoot = path.resolve(import.meta.dirname, '..');
const authContextPath = path.join(projectRoot, 'client/src/contexts/AuthContext.tsx');
const appLayoutPath = path.join(projectRoot, 'client/src/components/AppLayout.tsx');

describe('system administration logout client flow', () => {
  it('clears the local authenticated state before resetting the cached session', () => {
    const source = fs.readFileSync(authContextPath, 'utf8');

    expect(source).toContain('const [hasLoggedOut, setHasLoggedOut] = useState(false);');
    expect(source).toContain('const user = hasLoggedOut ? null');
    expect(source).toContain('setHasLoggedOut(true);');
    expect(source).toContain('await systemLogout.mutateAsync();');
    expect(source).toContain('await utils.systemAuth.session.reset();');
  });

  it('ينتظر إنهاء الخروج ويمنع التكرار قبل العودة إلى المسار العام', () => {
    const source = fs.readFileSync(appLayoutPath, 'utf8');

    expect(source).toContain('const [isLoggingOut, setIsLoggingOut] = useState(false);');
    expect(source).toContain('const handleLogout = async () => {');
    expect(source).toContain('if (isLoggingOut) return;');
    expect(source).toContain('await logout();');
    expect(source).toContain('disabled={isLoggingOut}');
    expect(source).toContain("setLocation('/');");
  });
});
