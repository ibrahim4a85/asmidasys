type CustomerExportSource = {
  id: number;
  customerNumber: string;
  name: string;
  branchId?: number | null;
  delegateId?: number | null;
  phone?: string | null;
};

type NamedLookup = { id: number; name?: string; fullName?: string };

export function selectCustomersForExport<T extends { id: number }>(customers: T[], selectedIds: number[]) {
  return selectedIds.length > 0
    ? customers.filter(customer => selectedIds.includes(customer.id))
    : customers;
}

export function buildCustomerExportRows(customers: CustomerExportSource[], branches: NamedLookup[] = [], delegates: NamedLookup[] = []) {
  return customers.map(customer => ({
    'رقم العميل': customer.customerNumber,
    'اسم العميل': customer.name,
    'الفرع': branches.find(branch => branch.id === customer.branchId)?.name || '',
    'المندوب': delegates.find(delegate => delegate.id === customer.delegateId)?.fullName || '',
    'الهاتف': customer.phone || '',
  }));
}
