import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { readSystemLabelOverrides } from '../shared/systemLabelPresentation';

const settingsPagePath = fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url));

describe('تسميات العرض لقوائم الإدخال', () => {
  it('تعرض عناوين وحقول قوائم الإدخال من القاموس المركزي', () => {
    const source = readFileSync(settingsPagePath, 'utf8');
    const defaults = readSystemLabelOverrides({});
    const expectedLabels = {
      settings_input_lists_title: 'قوائم الإدخال الشجرية',
      settings_input_lists_description: 'تظهر الجذور الثلاثة في النظام، ويمكن بناء فروع داخل كل قائمة. عنصر الدفع النقدي وحده يضبط بلا إلزام لإرفاق الإيصال.',
      settings_input_lists_main_list: 'القائمة الرئيسية',
      settings_input_lists_parent_item: 'العنصر الأب',
      settings_input_lists_item_name: 'اسم الفرع أو العنصر',
      settings_input_lists_sort_order: 'ترتيب العرض',
      settings_input_lists_empty: 'لا توجد عناصر بعد.',
      settings_input_lists_add_branch: 'إضافة فرع',
    } as const;

    for (const [id, label] of Object.entries(expectedLabels)) {
      expect(defaults[id as keyof typeof defaults]).toBe(label);
      expect(source).toContain(`labelFor('${id}'`);
    }

    const overridden = readSystemLabelOverrides({
      system_label_overrides: JSON.stringify({ settings_input_lists_add_branch: 'إضافة قسم فرعي' }),
    });
    expect(overridden.settings_input_lists_add_branch).toBe('إضافة قسم فرعي');
  });

  it('يبقي حذف القائمة ومنطق الحفظ خارج تخصيص العرض', () => {
    const source = readFileSync(settingsPagePath, 'utf8');

    expect(source).toContain("title={labelFor('settings_input_lists_add_branch', 'إضافة فرع')}");
    expect(source).toContain('setForm({ ...blankList, listType, parentId: String(item.id) }); setOpen(true);');
    expect(source).toContain('title="حذف"');
    expect(source).toContain("deleteItem) deleteMutation.mutate({ id: deleteItem.id })");
    expect(source).toContain("editing ? updateMutation.mutate({ id: editing.id, data }) : createMutation.mutate");
  });
});
