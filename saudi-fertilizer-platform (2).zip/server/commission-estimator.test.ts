import { describe, expect, it } from 'vitest';
import { estimateCommission } from '../shared/commissionEstimator';

const riyadh2026Tiers = [
  { minAchievementPercent: 0, maxAchievementPercent: 79.999, payoutMultiplier: 0, isEligible: false },
  { minAchievementPercent: 80, maxAchievementPercent: 89.999, payoutMultiplier: 0.9, isEligible: true },
  { minAchievementPercent: 90, maxAchievementPercent: 99.999, payoutMultiplier: 1, isEligible: true },
  { minAchievementPercent: 100, payoutMultiplier: 1, additionalCommissionRate: 0.25, fixedBonusAmount: 5000, isEligible: true },
];

describe('حساب محاكاة العمولات', () => {
  it('يطبق العمولة الكاملة عند تحقيق 90% من مستهدف 4 ملايين', () => {
    const result = estimateCommission({ targetValue: 4_000_000, actualValue: 3_600_000, baseCommissionRate: 1, minimumPayoutAmount: 1, tiers: riyadh2026Tiers });
    expect(result).toMatchObject({ achievementPercent: 90, baseAmount: 36000, estimatedPayoutAmount: 36000, eligible: true, isEstimateOnly: true });
  });

  it('يخصم 10% من العمولة في شريحة 80% إلى أقل من 90%', () => {
    const result = estimateCommission({ targetValue: 4_000_000, actualValue: 3_400_000, baseCommissionRate: 1, minimumPayoutAmount: 1, tiers: riyadh2026Tiers });
    expect(result).toMatchObject({ achievementPercent: 85, baseAmount: 34000, multiplierAmount: 30600, estimatedPayoutAmount: 30600, eligible: true });
  });

  it('لا يقدّر صرفاً تحت 80% عندما تكون الشريحة غير مؤهلة', () => {
    const result = estimateCommission({ targetValue: 4_000_000, actualValue: 3_160_000, baseCommissionRate: 1, minimumPayoutAmount: 1, tiers: riyadh2026Tiers });
    expect(result).toMatchObject({ achievementPercent: 79, estimatedPayoutAmount: 0, eligible: false, reason: 'tier_not_eligible' });
  });

  it('يضيف الحافز الثابت والنسبة الإضافية بعد تجاوز 100%', () => {
    const result = estimateCommission({ targetValue: 4_000_000, actualValue: 4_400_000, baseCommissionRate: 1, minimumPayoutAmount: 1, tiers: riyadh2026Tiers });
    expect(result).toMatchObject({ achievementPercent: 110, baseAmount: 44000, additionalAmount: 11000, fixedBonusAmount: 5000, estimatedPayoutAmount: 60000, eligible: true });
  });

  it('يصف النتيجة كتقدير فقط ولا يتجاوز حد الصرف الأدنى', () => {
    const result = estimateCommission({ targetValue: 100_000, actualValue: 90_000, baseCommissionRate: 1, minimumPayoutAmount: 1000 });
    expect(result).toMatchObject({ estimatedPayoutAmount: 0, eligible: false, reason: 'below_minimum_payout', isEstimateOnly: true });
  });
});
