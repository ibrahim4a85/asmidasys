import { Bell, CheckCheck, FileText } from 'lucide-react';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { getNotificationTargetPath, getReceiptIdFromNotification } from '@shared/receiptPresentation';
import { useSystemLabels } from '@/hooks/useSystemLabels';

export default function NotificationsPage() {
  const { isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const { data: notifications = [] } = trpc.notifications.list.useQuery({ unreadOnly: false });
  const markRead = trpc.notifications.markRead.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });
  const markAllRead = trpc.notifications.markAllRead.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });
  const unreadCount = notifications.filter(notification => !notification.isRead).length;

  const openNotification = (notification: any) => {
    if (!notification.isRead) markRead.mutate({ id: notification.id });
    setLocation(getNotificationTargetPath(notification));
  };

  return (
    <div className="mx-auto max-w-5xl space-y-5" dir="rtl">
      <Card className="overflow-hidden border-primary/15 bg-gradient-to-l from-primary/10 via-card to-card">
        <CardHeader className="flex flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Bell className="h-5 w-5" /></span>
            <div><CardTitle>{labelFor('nav_notifications', 'سجل الإشعارات')}</CardTitle><p className="mt-1 text-sm text-muted-foreground">{labelFor('notifications_subtitle', 'اضغط على إشعار السند لفتحه ومعاينته مباشرة.')}</p></div>
          </div>
          {isAdmin && unreadCount > 0 && <Button variant="outline" size="sm" onClick={() => markAllRead.mutate()}><CheckCheck className="ml-1 h-4 w-4" />{labelFor('notifications_mark_all_read', 'تعليم الكل كمقروء')}</Button>}
        </CardHeader>
      </Card>
      <Card>
        <CardContent className="p-0">
          {notifications.length === 0 ? (
            <div className="px-6 py-16 text-center text-sm text-muted-foreground">{labelFor('notifications_empty', 'لا توجد إشعارات مسجلة حالياً.')}</div>
          ) : notifications.map(notification => {
            const receiptId = getReceiptIdFromNotification(notification);
            return <button key={notification.id} onClick={() => openNotification(notification)} className={cn('flex w-full items-start gap-3 border-b border-border/70 px-5 py-4 text-right transition-colors hover:bg-muted/60 last:border-0', !notification.isRead && 'bg-primary/5')}>
              <span className={cn('mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg', receiptId ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground')}><FileText className="h-4 w-4" /></span>
              <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-foreground">{notification.title}</span><span className="mt-1 block text-sm leading-6 text-muted-foreground">{notification.message}</span><span className="mt-2 block text-xs text-muted-foreground">{new Date(notification.createdAt).toLocaleString('ar-SA')}{receiptId ? ` · ${labelFor('notifications_open_receipt', 'اضغط لفتح السند')}` : ''}</span></span>
              {!notification.isRead && <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-primary" />}
            </button>;
          })}
        </CardContent>
      </Card>
    </div>
  );
}
