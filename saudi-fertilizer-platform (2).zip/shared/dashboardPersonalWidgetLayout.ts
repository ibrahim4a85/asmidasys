export const DASHBOARD_WIDGET_GROUPS = {
  summary: ['receipts_total', 'payments_total', 'pending_receipts', 'approved_receipts'],
  activity: ['collections_trend', 'quick_actions'],
  records: ['recent_receipts', 'top_branches'],
  bank: ['bank_collections'],
} as const;

export type DashboardWidgetGroup = keyof typeof DASHBOARD_WIDGET_GROUPS;
export type DashboardPersonalWidgetLayout = Record<DashboardWidgetGroup, { order: string[]; spans: Record<string, number>; hidden: string[] }>;

const WIDGET_SPAN_MIN = 1;
const WIDGET_SPAN_MAX = 4;
const DASHBOARD_WIDGET_DEFAULT_SPANS: Record<DashboardWidgetGroup, Record<string, number>> = {
  summary: { receipts_total: 1, payments_total: 1, pending_receipts: 1, approved_receipts: 1 },
  activity: { collections_trend: 3, quick_actions: 1 },
  records: { recent_receipts: 2, top_branches: 2 },
  bank: { bank_collections: 4 },
};

export function getDashboardPersonalWidgetLayoutKey(userId: number | string): string {
  return `dashboard-widget-layout:${userId}`;
}

function normalizeGroup(value: unknown, fallback: readonly string[]) {
  const stored = value && typeof value === 'object' ? value as { order?: unknown; spans?: unknown; hidden?: unknown } : {};
  const seen = new Set<string>();
  const order = Array.isArray(stored.order)
    ? stored.order.filter((id): id is string => typeof id === 'string' && fallback.includes(id) && !seen.has(id) && !!seen.add(id))
    : [];
  const spansSource = stored.spans && typeof stored.spans === 'object' ? stored.spans as Record<string, unknown> : {};
  const spans = Object.fromEntries(fallback.map(id => {
    const rawSpan = Number(spansSource[id]);
    const defaults = DASHBOARD_WIDGET_DEFAULT_SPANS as Record<string, Record<string, number>>;
    const span = Number.isFinite(rawSpan) ? Math.min(WIDGET_SPAN_MAX, Math.max(WIDGET_SPAN_MIN, Math.round(rawSpan))) : (defaults[Object.keys(DASHBOARD_WIDGET_GROUPS).find(group => DASHBOARD_WIDGET_GROUPS[group as DashboardWidgetGroup] === fallback) || 'summary']?.[id] || 1);
    return [id, span];
  }));
  const hiddenSeen = new Set<string>();
  const hidden = Array.isArray(stored.hidden)
    ? stored.hidden.filter((id): id is string => typeof id === 'string' && fallback.includes(id) && !hiddenSeen.has(id) && !!hiddenSeen.add(id))
    : [];
  return { order: [...order, ...fallback.filter(id => !seen.has(id))], spans, hidden };
}

export function parseDashboardPersonalWidgetLayout(value: unknown): DashboardPersonalWidgetLayout {
  const source = value && typeof value === 'object' ? value as Record<string, unknown> : {};
  return Object.fromEntries(Object.entries(DASHBOARD_WIDGET_GROUPS).map(([group, widgets]) => [group, normalizeGroup(source[group], widgets)])) as DashboardPersonalWidgetLayout;
}

export function moveDashboardPersonalWidget(layout: DashboardPersonalWidgetLayout, group: DashboardWidgetGroup, sourceId: string, targetId: string): DashboardPersonalWidgetLayout {
  const current = layout[group];
  const from = current.order.indexOf(sourceId);
  const to = current.order.indexOf(targetId);
  if (from < 0 || to < 0 || from === to) return layout;
  const order = [...current.order];
  order.splice(from, 1);
  order.splice(to, 0, sourceId);
  return { ...layout, [group]: { ...current, order } };
}

export function resizeDashboardPersonalWidget(layout: DashboardPersonalWidgetLayout, group: DashboardWidgetGroup, id: string, delta: -1 | 1, maxSpan = WIDGET_SPAN_MAX): DashboardPersonalWidgetLayout {
  if (!DASHBOARD_WIDGET_GROUPS[group].includes(id as never)) return layout;
  const current = layout[group];
  const span = Math.min(Math.min(WIDGET_SPAN_MAX, maxSpan), Math.max(WIDGET_SPAN_MIN, (current.spans[id] || 1) + delta));
  return { ...layout, [group]: { ...current, spans: { ...current.spans, [id]: span } } };
}

export function isDashboardPersonalWidgetHidden(layout: DashboardPersonalWidgetLayout, group: DashboardWidgetGroup, id: string): boolean {
  return layout[group].hidden.includes(id);
}

export function hideDashboardPersonalWidget(layout: DashboardPersonalWidgetLayout, group: DashboardWidgetGroup, id: string): DashboardPersonalWidgetLayout {
  if (!DASHBOARD_WIDGET_GROUPS[group].includes(id as never) || isDashboardPersonalWidgetHidden(layout, group, id)) return layout;
  const current = layout[group];
  return { ...layout, [group]: { ...current, hidden: [...current.hidden, id] } };
}

export function showDashboardPersonalWidget(layout: DashboardPersonalWidgetLayout, group: DashboardWidgetGroup, id: string): DashboardPersonalWidgetLayout {
  if (!DASHBOARD_WIDGET_GROUPS[group].includes(id as never) || !isDashboardPersonalWidgetHidden(layout, group, id)) return layout;
  const current = layout[group];
  return { ...layout, [group]: { ...current, hidden: current.hidden.filter(hiddenId => hiddenId !== id) } };
}
