import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const settingsPage = readFileSync(fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url)), 'utf8');

describe('تسميات محرر الحقول الوصفية لسند القبض', () => {
  it('يوفر قيم العرض الافتراضية ويسمح بتجاوزها إدارياً', () => {
    expect(getSystemLabel(undefined, 'settings_receipt_custom_fields_title')).toBe('الحقول الوصفية المخصصة');
    expect(getSystemLabel(undefined, 'settings_receipt_custom_field_input_type')).toBe('نوع الإدخال');
    expect(getSystemLabel(undefined, 'settings_receipt_custom_field_type_select')).toBe('قائمة خيارات');
    expect(getSystemLabel(undefined, 'settings_receipt_custom_field_options_placeholder')).toBe('مثال: خيار أول, خيار ثان');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ settings_receipt_custom_fields_empty: 'لا توجد حقول وصفية' }) },
      'settings_receipt_custom_fields_empty',
    )).toBe('لا توجد حقول وصفية');
  });

  it('يربط نصوص العرض فقط ويبقي إجراءات الحقول والتحقق كما هي', () => {
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_fields_title'");
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_field_name'");
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_field_input_type'");
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_field_options'");
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_field_options_placeholder'");
    expect(settingsPage).toContain("labelFor('settings_receipt_custom_fields_empty'");
    expect(settingsPage).toContain('onClick={addField}');
    expect(settingsPage).toContain('onClick={save}');
    expect(settingsPage).toContain("/^[a-z][a-z0-9_]{1,39}$/");
  });
});
