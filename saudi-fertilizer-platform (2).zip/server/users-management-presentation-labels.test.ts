import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const usersManagementPage = readFileSync(fileURLToPath(new URL('../client/src/pages/UsersManagement.tsx', import.meta.url)), 'utf8');

describe('تسميات العرض الآمنة في إدارة المستخدمين', () => {
  it('يوفر قيماً افتراضية ويقبل تجاوزاً إدارياً لتسميات العرض', () => {
    expect(getSystemLabel(undefined, 'user_level_primary')).toBe('رئيسي');
    expect(getSystemLabel(undefined, 'users_board_position_partner_only')).toBe('شريك فقط');
    expect(getSystemLabel(undefined, 'users_permission_receipts_approve')).toBe('اعتماد سندات القبض');
    expect(getSystemLabel(undefined, 'users_access_denied')).toBe('ليس لديك صلاحية الوصول لهذه الصفحة');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ users_permission_approval_delegate: 'تفويض الطلبات' }) },
      'users_permission_approval_delegate',
    )).toBe('تفويض الطلبات');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ users_access_denied: 'وصول المستخدمين محجوب' }) },
      'users_access_denied',
    )).toBe('وصول المستخدمين محجوب');
  });

  it('يربط النصوص المرئية فقط ويحافظ على القيم الداخلية وكلمات المرور والحذف', () => {
    expect(usersManagementPage).toContain("labelFor('user_level_primary'");
    expect(usersManagementPage).toContain("labelFor('users_board_position_chair'");
    expect(usersManagementPage).toContain("labelFor('users_access_denied', 'ليس لديك صلاحية الوصول لهذه الصفحة')");
    expect(usersManagementPage).toContain("'users_permission_receipts_approve'");
    expect(usersManagementPage).toContain('if (!isAdmin) return');
    expect(usersManagementPage).toContain("labelFor('action_cancel', 'إلغاء')");
    expect(usersManagementPage).toContain('readSystemUserTypeDefinitions(settings?.system_user_type_definitions)');
    expect(usersManagementPage).toContain('selectableUserTypes.map(definition => <SelectItem key={definition.code} value={definition.code}>');
    expect(usersManagementPage).toContain('definition.isActive || definition.code === form.userType');
    expect(usersManagementPage).toContain('نوع قديم: ${form.userType}');
    expect(usersManagementPage).toContain('value="primary"');
    expect(usersManagementPage).toContain('value="رئيس مجلس الإدارة"');
    expect(usersManagementPage).toContain('password.trim() ? form : dataWithoutPassword');
    expect(usersManagementPage).toContain('setDeleteUser(u)');
    expect(usersManagementPage).toContain('deleteMutation.mutate({ id: deleteUser.id })');
  });
});
