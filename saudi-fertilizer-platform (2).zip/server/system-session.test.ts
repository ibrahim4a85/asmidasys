import { describe, expect, it } from "vitest";
import { createSystemSession, verifySystemSession } from "./systemSession";

describe("system administrator session", () => {
  it("signs and verifies the administrator identity without exposing credentials", async () => {
    const token = await createSystemSession({
      id: 42,
      username: "admin-test",
      fullName: "مدير اختبار",
      userType: "admin",
      userLevel: "primary",
      branchId: null,
      permissions: { manageAll: true },
    });

    const session = await verifySystemSession(token);

    expect(session).toMatchObject({
      id: 42,
      username: "admin-test",
      userType: "admin",
      userLevel: "primary",
    });
    expect(token).not.toContain("admin123");
  });

  it("rejects an invalid session token", async () => {
    await expect(verifySystemSession("not-a-valid-token")).resolves.toBeNull();
  });
});
