import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({
  getApprovalWorkflows: vi.fn(), getApprovalRequests: vi.fn(), getSettings: vi.fn(), saveApprovalWorkflow: vi.fn(), createApprovalRequestFromWorkflow: vi.fn(), decideApprovalRequestStep: vi.fn(), attachApprovalDraft: vi.fn(), updateApprovalRequest: vi.fn(), deleteApprovalHistory: vi.fn(),
}));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));
vi.mock('./approvalTemplates', () => ({ stampApprovalTemplate: vi.fn(), stampApprovalDecisionFooter: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import * as storage from './storage';
import * as approvalTemplates from './approvalTemplates';
import type { TrpcContext } from './_core/context';

function context(permissions: Record<string, boolean> = {}, user: Partial<TrpcContext['systemUser']> = {}): TrpcContext {
  return {
    user: null,
    systemUser: { id: 17, username: 'delegate', fullName: 'مستخدم اختبار', userType: 'user', userLevel: 'secondary', branchId: 1, permissions, ...user },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

describe('دورة تعميد المستندات', () => {
  beforeEach(() => vi.resetAllMocks());

  it('يسمح لصاحب صلاحية طلب التعميد بإنشاء الطلب ويثبت هويته تلقائياً', async () => {
    vi.mocked(db.createApprovalRequestFromWorkflow).mockResolvedValue({ id: 4 } as never);
    await expect(appRouter.createCaller(context({ approvalRequest: true })).approvals.create({ documentTypeId: 3, title: 'طلب تعميد عقد' })).resolves.toEqual({ id: 4 });
    expect(db.createApprovalRequestFromWorkflow).toHaveBeenCalledWith(expect.objectContaining({ documentTypeId: 3, requestedBy: 17 }));
  });

  it('يمنع المستخدم الذي لا يحمل صلاحية طلب التعميد', async () => {
    await expect(appRouter.createCaller(context()).approvals.create({ documentTypeId: 3, title: 'طلب تعميد' })).rejects.toMatchObject({ code: 'FORBIDDEN' });
  });

  it('يسمح لصاحب صلاحية التفويض باتخاذ قرار الخطوة الموكلة إليه فقط', async () => {
    vi.mocked(db.decideApprovalRequestStep).mockResolvedValue({ id: 4, status: 'rejected' } as never);
    await expect(appRouter.createCaller(context({ approvalDelegate: true })).approvals.decide({ requestId: 4, decision: 'rejected', note: 'تحتاج استكمال بيانات' })).resolves.toEqual({ id: 4, status: 'rejected' });
    expect(db.decideApprovalRequestStep).toHaveBeenCalledWith(expect.objectContaining({ requestId: 4, systemUserId: 17, decision: 'rejected', note: 'تحتاج استكمال بيانات' }));
  });

  it('يسمح للمفوض المعيّن في نوع الطلب باتخاذ قراره دون اشتراط صلاحية تفويض عامة إضافية', async () => {
    vi.mocked(db.decideApprovalRequestStep).mockResolvedValue({ id: 7, status: 'rejected' } as never);

    await expect(appRouter.createCaller(context()).approvals.decide({ requestId: 7, decision: 'rejected' })).resolves.toEqual({ id: 7, status: 'rejected' });
    expect(db.decideApprovalRequestStep).toHaveBeenCalledWith(expect.objectContaining({ requestId: 7, systemUserId: 17 }));
  });

  it('يختم مرفق طلب التعميد المعتمد بتذييل المفوضين ويحفظ النسخة الجديدة', async () => {
    vi.mocked(db.decideApprovalRequestStep).mockResolvedValue({ id: 4, status: 'approved' } as never);
    vi.mocked(db.getSettings).mockResolvedValue({ approval_footer_enabled: 'true', approval_footer_height: '66', approval_footer_font_size: '8', approval_footer_color: '#0f5132', approval_footer_label: 'تم التعميد' } as never);
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{
      id: 4, requestedBy: 10, approvalNumber: 'RA101-001', attachmentUrl: '/manus-storage/approval-attachments/10/form.pdf', attachmentName: 'RA101-001-form.pdf',
      steps: [{ status: 'approved', actedAt: new Date('2026-08-24T10:00:00Z'), approverName: 'أحمد المفوض' }],
    }] as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://signed.example/form.pdf' as never);
    vi.mocked(approvalTemplates.stampApprovalDecisionFooter).mockResolvedValue(Buffer.from('signed-footer') as never);
    vi.mocked(storage.storagePut).mockResolvedValue({ url: '/manus-storage/approval-attachments/10/signed.pdf' } as never);
    vi.mocked(db.updateApprovalRequest).mockResolvedValue({ id: 4 } as never);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, arrayBuffer: vi.fn().mockResolvedValue(new Uint8Array([1, 2, 3]).buffer) }));

    await expect(appRouter.createCaller(context({ approvalDelegate: true })).approvals.decide({ requestId: 4, decision: 'approved', note: 'تمت المراجعة' })).resolves.toEqual({ id: 4, status: 'approved' });

    expect(approvalTemplates.stampApprovalDecisionFooter).toHaveBeenCalledWith(expect.objectContaining({
      mimeType: 'application/pdf',
      signatures: [expect.objectContaining({ name: 'أحمد المفوض' })],
      options: expect.objectContaining({ label: 'تم التعميد', height: 66 }),
    }));
    expect(db.updateApprovalRequest).toHaveBeenCalledWith(4, { attachmentUrl: '/manus-storage/approval-attachments/10/signed.pdf' });
  });

  it('يتيح للمراجع تنزيل النموذج المرفق قبل اعتماد المراجعة', async () => {
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{
      id: 4, requestedBy: 10, reviewerUserId: 17, approvalNumber: 'RA101-001', attachmentUrl: '/manus-storage/approval-attachments/10/form.pdf', attachmentName: 'RA101-001-form.pdf', steps: [{ systemUserId: 18 }],
    }] as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://signed.example/reviewer-form.pdf' as never);

    await expect(appRouter.createCaller(context()).approvals.downloadAttachment({ requestId: 4 })).resolves.toEqual({
      url: 'https://signed.example/reviewer-form.pdf', fileName: 'RA101-001-form.pdf',
    });
    expect(storage.storageGetSignedUrl).toHaveBeenCalledWith('approval-attachments/10/form.pdf');
  });

  it('يتيح لأي مراجع معيّن في قائمة مراجعي النوع تنزيل المرفق دون الاقتصار على المراجع الأول', async () => {
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{
      id: 9, requestedBy: 10, approvalNumber: 'RA101-002', attachmentUrl: '/manus-storage/approval-attachments/10/form.pdf', attachmentName: 'RA101-002-form.pdf', reviewerSteps: [{ systemUserId: 17 }], steps: [{ systemUserId: 18 }],
    }] as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://signed.example/reviewer-two.pdf' as never);

    await expect(appRouter.createCaller(context()).approvals.downloadAttachment({ requestId: 9 })).resolves.toEqual({
      url: 'https://signed.example/reviewer-two.pdf', fileName: 'RA101-002-form.pdf',
    });
  });

  it('يتيح للمفوض المعيّن تنزيل النموذج المرفق قبل قرار التعميد', async () => {
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{
      id: 4, requestedBy: 10, reviewerUserId: 11, approvalNumber: 'RA101-001', attachmentUrl: '/manus-storage/approval-attachments/10/form.pdf', attachmentName: 'RA101-001-form.pdf', steps: [{ systemUserId: 17 }],
    }] as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://signed.example/approver-form.pdf' as never);

    await expect(appRouter.createCaller(context({ approvalDelegate: true })).approvals.downloadAttachment({ requestId: 4 })).resolves.toEqual({
      url: 'https://signed.example/approver-form.pdf', fileName: 'RA101-001-form.pdf',
    });
  });

  it('يمنع غير المشاركين في الدورة من الوصول إلى مرفق طلب التعميد', async () => {
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{
      id: 4, requestedBy: 10, reviewerUserId: 11, approvalNumber: 'RA101-001', attachmentUrl: '/manus-storage/approval-attachments/10/form.pdf', attachmentName: 'RA101-001-form.pdf', steps: [{ systemUserId: 18 }],
    }] as never);

    await expect(appRouter.createCaller(context()).approvals.downloadAttachment({ requestId: 4 })).rejects.toMatchObject({ code: 'FORBIDDEN' });
    expect(storage.storageGetSignedUrl).not.toHaveBeenCalled();
  });

  it('يعيد حفظ مرفق PDF مختوماً برقم التعميد قبل إرفاقه بالمسودة', async () => {
    vi.mocked(db.getApprovalRequests).mockResolvedValue([{ id: 4, requestedBy: 17, approvalNumber: 'RA101-001' }] as never);
    vi.mocked(storage.storageGetSignedUrl).mockResolvedValue('https://signed.example/source.pdf' as never);
    vi.mocked(approvalTemplates.stampApprovalTemplate).mockResolvedValue(Buffer.from('stamped-pdf') as never);
    vi.mocked(storage.storagePut).mockResolvedValue({ url: '/manus-storage/approval-attachments/17/stamped.pdf' } as never);
    vi.mocked(db.attachApprovalDraft).mockResolvedValue({ id: 4, attachmentName: 'RA101-001-form.pdf' } as never);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      arrayBuffer: vi.fn().mockResolvedValue(new Uint8Array([1, 2, 3]).buffer),
    }));

    await expect(appRouter.createCaller(context({ approvalRequest: true })).approvals.attachDraft({
      requestId: 4,
      attachmentUrl: '/manus-storage/approval-attachments/17/form.pdf',
      attachmentName: 'form.pdf',
    })).resolves.toEqual({ id: 4, attachmentName: 'RA101-001-form.pdf' });

    expect(approvalTemplates.stampApprovalTemplate).toHaveBeenCalledWith(expect.objectContaining({
      approvalNumber: 'RA101-001',
      mimeType: 'application/pdf',
    }));
    expect(storage.storagePut).toHaveBeenCalledWith(
      expect.stringContaining('RA101-001-form.pdf'),
      Buffer.from('stamped-pdf'),
      'application/pdf',
    );
    expect(db.attachApprovalDraft).toHaveBeenCalledWith(expect.objectContaining({
      attachmentName: 'RA101-001-form.pdf',
      requesterId: 17,
    }));
  });

  it('يقصر حذف سجل طلبات التعميد على مدير النظام مع عبارة تأكيد خادمية ثابتة', async () => {
    vi.mocked(db.deleteApprovalHistory).mockResolvedValue({ requests: 2, reviewerSteps: 3, approverSteps: 4, notifications: 5 } as never);

    await expect(appRouter.createCaller(context()).approvals.purgeHistory({ confirmation: 'حذف سجل طلبات التعميد' })).rejects.toMatchObject({ code: 'FORBIDDEN' });
    await expect(appRouter.createCaller(context({}, { userType: 'admin', userLevel: 'primary' })).approvals.purgeHistory({ confirmation: 'حذف سجل طلبات التعميد' })).resolves.toEqual({ requests: 2, reviewerSteps: 3, approverSteps: 4, notifications: 5 });
    expect(db.deleteApprovalHistory).toHaveBeenCalledTimes(1);
  });
});
