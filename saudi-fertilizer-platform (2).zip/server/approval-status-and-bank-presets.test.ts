import { describe, expect, it } from 'vitest';
import { getApprovalRequesterStatus } from '../shared/approvalRequestStatus';
import { getBankCollectionDateRange } from '../shared/bankCollectionPresets';
import { applySecondaryUserApprovalRequestDefault } from '../shared/systemUserDefaults';

describe('الصلاحية الافتراضية وحالة التعميد وفلاتر المتحصلات', () => {
  it('يمنح المستخدم الفرعي صلاحية طلب التعميد افتراضياً ويحافظ على الإلغاء الصريح من المدير', () => {
    expect(applySecondaryUserApprovalRequestDefault({ userLevel: 'secondary', userType: 'delegate', permissions: { sidebar_delegates: true } })).toMatchObject({ permissions: { approvalRequest: true } });
    expect(applySecondaryUserApprovalRequestDefault({ userLevel: 'secondary', userType: 'delegate', permissions: { approvalRequest: false } })).toMatchObject({ permissions: { approvalRequest: false } });
  });

  it('يعرض لطالب التعميد الاعتماد المكتمل والاعتماد المتبقي بصورة مفهومة', () => {
    const status = getApprovalRequesterStatus({ status: 'sent', approvedCount: 1, requiredApprovals: 2, steps: [{ id: 1, status: 'approved', approverName: 'طارق مراد', boardPosition: 'رئيس مجلس الإدارة' }, { id: 2, status: 'pending', approverName: 'أحمد مراد', boardPosition: 'عضو مجلس الإدارة' }] });
    expect(status.lines).toContain('تمت المراجعة والإرسال إلى المفوضين.');
    expect(status.lines).toContain('تم التعميد من رئيس مجلس الإدارة: طارق مراد.');
    expect(status.lines).toContain('لم يكتمل التعميد؛ ما زال الطلب يحتاج إلى 1 من التعميدات اللازمة.');
  });

  it('يحسب اليوم والأمس وآخر أسبوع والفترة المخصصة للتقرير البنكي', () => {
    const now = new Date(2026, 7, 20, 12, 0, 0);
    expect(getBankCollectionDateRange('today', undefined, undefined, now)).toEqual({ startDate: '2026-08-20', endDate: '2026-08-20' });
    expect(getBankCollectionDateRange('yesterday', undefined, undefined, now)).toEqual({ startDate: '2026-08-19', endDate: '2026-08-19' });
    expect(getBankCollectionDateRange('last_week', undefined, undefined, now)).toEqual({ startDate: '2026-08-14', endDate: '2026-08-20' });
    expect(getBankCollectionDateRange('custom', '2026-08-01', '2026-08-15', now)).toEqual({ startDate: '2026-08-01', endDate: '2026-08-15' });
  });
});
