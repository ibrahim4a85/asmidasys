CREATE TABLE `performance_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`branchId` int NOT NULL,
	`reportDate` date NOT NULL,
	`salesInvoicesCount` int NOT NULL DEFAULT 0,
	`salesInvoicesValue` decimal(15,2) NOT NULL DEFAULT '0',
	`returnsInvoicesCount` int NOT NULL DEFAULT 0,
	`returnsInvoicesValue` decimal(15,2) NOT NULL DEFAULT '0',
	`netSalesValue` decimal(15,2) NOT NULL DEFAULT '0',
	`receiptsCount` int NOT NULL DEFAULT 0,
	`collectionsValue` decimal(15,2) NOT NULL DEFAULT '0',
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `performance_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `performance_reports_branch_date_unique` UNIQUE(`branchId`,`reportDate`)
);
