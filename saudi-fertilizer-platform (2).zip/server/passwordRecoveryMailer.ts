import nodemailer from "nodemailer";

const SMTP_HOST = "smtp.gmail.com";
const SMTP_PORT = 465;

function getSmtpConfiguration() {
  const user = process.env.GMAIL_SMTP_USER?.trim();
  const pass = process.env.GMAIL_SMTP_APP_PASSWORD?.trim();
  if (!user || !pass) throw new Error("خدمة إرسال رمز الاسترداد غير مهيأة");
  return { user, pass };
}

export async function sendPasswordRecoveryCode(input: { to: string; code: string }) {
  const { user, pass } = getSmtpConfiguration();
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: true,
    auth: { user, pass },
  });

  await transporter.sendMail({
    from: `منصة شركة الأسمدة المتحدة السعودية <${user}>`,
    to: input.to,
    subject: "رمز استعادة كلمة مرور الإدارة",
    text: `رمز استعادة كلمة مرور الإدارة هو: ${input.code}\n\nالرمز صالح لمدة 10 دقائق فقط. لا تشاركه مع أي شخص. إذا لم تطلب الاستعادة، تجاهل هذه الرسالة.`,
    html: `<div dir="rtl" style="font-family:Arial,sans-serif;line-height:1.8"><h2>رمز استعادة كلمة مرور الإدارة</h2><p>استخدم الرمز التالي لإعادة تعيين كلمة المرور:</p><p style="font-size:28px;font-weight:700;letter-spacing:6px">${input.code}</p><p>الرمز صالح لمدة <strong>10 دقائق</strong> فقط. لا تشاركه مع أي شخص.</p><p>إذا لم تطلب الاستعادة، يمكنك تجاهل هذه الرسالة.</p></div>`,
  });
}
