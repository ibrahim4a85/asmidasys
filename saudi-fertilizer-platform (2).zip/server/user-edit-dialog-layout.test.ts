import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('نافذة تعديل المستخدم', () => {
  it('تحتوي على منطقة تمرير داخلية وتبقي تذييل الحفظ والإلغاء ثابتاً', () => {
    const source = readFileSync(new URL('../client/src/pages/UsersManagement.tsx', import.meta.url), 'utf8');
    expect(source).toContain('max-h-[92dvh]');
    expect(source).toContain('min-h-0 flex-1 overflow-y-auto');
    expect(source).toContain('flex shrink-0 flex-col-reverse gap-2 border-t');
    expect(source).toContain('grid grid-cols-1 gap-4 sm:grid-cols-2');
  });
});
