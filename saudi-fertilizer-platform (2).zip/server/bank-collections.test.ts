import { describe, expect, it } from 'vitest';
import { summarizeBankCollections } from '../shared/bankCollections';

describe('تجميع المتحصلات البنكية', () => {
  it('يجمع المتحصلات اليومية لكل بنك ويحسب الإجماليات دون فقد بيانات الصفوف', () => {
    const result = summarizeBankCollections([
      { day: '2026-08-18', bankId: 1, bankName: 'الراجحي', totalAmount: '1500.50', receiptCount: 2 },
      { day: '2026-08-18', bankId: 2, bankName: 'الأهلي', totalAmount: '500', receiptCount: 1 },
      { day: '2026-08-18', bankId: 1, bankName: 'الراجحي', totalAmount: '250', receiptCount: 1 },
    ]);

    expect(result.totalAmount).toBe(2250.5);
    expect(result.totalReceipts).toBe(4);
    expect(result.banks).toEqual(['الأهلي', 'الراجحي']);
    expect(result.daily).toEqual([{ day: '2026-08-18', total: 2250.5, الأهلي: 500, الراجحي: 1750.5 }]);
  });
});
