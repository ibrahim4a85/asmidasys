import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

describe('delegates status presentation terminology', () => {
  it('provides Arabic defaults and accepts administrator overrides for display-only status labels', () => {
    expect(getSystemLabel({}, 'delegates_status_draft')).toBe('مسودة بانتظار النموذج');
    expect(getSystemLabel({}, 'delegates_status_review_pending')).toBe('بانتظار المراجع');
    expect(getSystemLabel({}, 'delegates_status_sent')).toBe('مرسل للمفوضين');
    expect(getSystemLabel({}, 'delegates_status_approved')).toBe('مكتمل الاعتماد');
    expect(getSystemLabel({}, 'delegates_status_rejected')).toBe('مرفوض');

    const settings = {
      system_label_overrides: JSON.stringify({
        delegates_status_review_pending: 'قيد المراجعة',
        delegates_status_approved: 'اكتمل المسار',
      }),
    };

    expect(getSystemLabel(settings, 'delegates_status_review_pending')).toBe('قيد المراجعة');
    expect(getSystemLabel(settings, 'delegates_status_approved')).toBe('اكتمل المسار');
  });

  it('uses labels only for badges while preserving canonical status codes and color mapping', () => {
    const source = readFileSync(new URL('../client/src/pages/DelegatesPage.tsx', import.meta.url), 'utf8');

    expect(source).toContain("draft: labelFor('delegates_status_draft', 'مسودة بانتظار النموذج')");
    expect(source).toContain("review_pending: labelFor('delegates_status_review_pending', 'بانتظار المراجع')");
    expect(source).toContain("sent: labelFor('delegates_status_sent', 'مرسل للمفوضين')");
    expect(source).toContain("approved: labelFor('delegates_status_approved', 'مكتمل الاعتماد')");
    expect(source).toContain("rejected: labelFor('delegates_status_rejected', 'مرفوض')");
    expect(source).toContain("request.status === 'review_pending'");
    expect(source).toContain("request.status === 'sent'");
    expect(source).toContain("statusColors[request.status]");
  });
});

