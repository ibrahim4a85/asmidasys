import tls from 'node:tls';
import { afterEach, describe, expect, it } from 'vitest';

const SMTP_HOST = 'smtp.gmail.com';
const SMTP_PORT = 465;

function waitForResponse(socket: tls.TLSSocket, expectedCode: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('انتهت مهلة اتصال Gmail SMTP')), 12_000);
    const onData = (chunk: Buffer) => {
      const response = chunk.toString('utf8');
      const code = Number(response.slice(0, 3));
      if (code !== expectedCode) {
        cleanup();
        reject(new Error(`استجابة Gmail SMTP غير متوقعة: ${response.replace(/\s+/g, ' ').trim()}`));
        return;
      }
      cleanup();
      resolve(response);
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      clearTimeout(timer);
      socket.off('data', onData);
      socket.off('error', onError);
    };
    socket.once('data', onData);
    socket.once('error', onError);
  });
}

describe('تهيئة Gmail SMTP', () => {
  let socket: tls.TLSSocket | undefined;

  afterEach(() => socket?.destroy());

  it('يتحقق من بيانات حساب Gmail للتوثيق دون إرسال بريد', async () => {
    const user = process.env.GMAIL_SMTP_USER?.trim();
    const appPassword = process.env.GMAIL_SMTP_APP_PASSWORD?.replace(/\s+/g, '');

    expect(user, 'يلزم توفير عنوان Gmail للإرسال').toMatch(/^[^\s@]+@gmail\.com$/i);
    expect(appPassword, 'يلزم توفير كلمة مرور تطبيقات Gmail').toMatch(/^.{16,}$/);

    socket = tls.connect({ host: SMTP_HOST, port: SMTP_PORT, servername: SMTP_HOST });
    await waitForResponse(socket, 220);
    socket.write('EHLO asmidasys.com\r\n');
    await waitForResponse(socket, 250);
    socket.write('AUTH LOGIN\r\n');
    await waitForResponse(socket, 334);
    socket.write(`${Buffer.from(user!, 'utf8').toString('base64')}\r\n`);
    await waitForResponse(socket, 334);
    socket.write(`${Buffer.from(appPassword!, 'utf8').toString('base64')}\r\n`);
    await waitForResponse(socket, 235);
  }, 25_000);
});
