import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { getSystemLabel, readSystemLabelOverrides } from '../shared/systemLabelPresentation';

describe('receipt print presentation labels', () => {
  const expectedLabels = {
    receipt_print_title: 'سند قبض',
    receipt_print_logo_alt: 'شعار الشركة',
    receipt_print_barcode_alt: 'باركود سند القبض',
    field_receipt_number: 'رقم السند',
    field_customer_name: 'اسم العميل',
    field_payment_for: 'وذلك مقابل',
    field_invoice_details: 'تفاصيل الفواتير',
    receipt_print_received_from: 'استلمنا من المكرم',
    receipt_print_recipient: 'المستلم',
  } as const;

  it('keeps printable receipt defaults and accepts administrator overrides', () => {
    for (const [id, label] of Object.entries(expectedLabels)) {
      expect(getSystemLabel(undefined, id as keyof typeof expectedLabels)).toBe(label);
    }

    const overrides = readSystemLabelOverrides({
      system_label_overrides: JSON.stringify({
        receipt_print_title: 'إيصال التحصيل',
        receipt_print_received_from: 'استلمنا من الشركة',
        receipt_print_recipient: 'مستلم التحصيل',
        receipt_print_logo_alt: 'شعار تحصيل الشركة',
        receipt_print_barcode_alt: 'رمز التحصيل',
      }),
    });

    expect(overrides.receipt_print_title).toBe('إيصال التحصيل');
    expect(overrides.receipt_print_received_from).toBe('استلمنا من الشركة');
    expect(overrides.receipt_print_recipient).toBe('مستلم التحصيل');
    expect(overrides.receipt_print_logo_alt).toBe('شعار تحصيل الشركة');
    expect(overrides.receipt_print_barcode_alt).toBe('رمز التحصيل');
  });

  it('uses labels only in the printable template while preserving receipt values and print actions', () => {
    const source = readFileSync(new URL('../client/src/pages/ReceiptsPage.tsx', import.meta.url), 'utf8');
    const printableTemplate = source.slice(source.indexOf('function PrintableReceipt'), source.indexOf('function readFileAsDataUrl'));

    expect(printableTemplate).toContain("useSystemLabels()");
    expect(printableTemplate).toContain("labelFor('receipt_print_title', 'سند قبض')");
    expect(printableTemplate).toContain("labelFor('receipt_print_logo_alt', 'شعار الشركة')");
    expect(printableTemplate).toContain("labelFor('receipt_print_barcode_alt', 'باركود سند القبض')");
    expect(printableTemplate).toContain("labelFor('field_payment_for', 'وذلك مقابل')");
    expect(printableTemplate).toContain("labelFor('receipt_print_recipient', 'المستلم')");
    expect(printableTemplate).toContain("receipt.status === 'approved'");
    expect(printableTemplate).toContain('receipt.serialNumber');
    expect(printableTemplate).toContain('getReceiptStatement(');
    expect(printableTemplate).toContain("labelFor('receipt_print_received_from', 'استلمنا من المكرم')");
    expect(printableTemplate).toContain("const customerStatement = String(receipt.customerStatement || '').trim()");
    expect(printableTemplate).toContain("const customerIdentity = [customer?.name || '-', customerStatement].filter(Boolean).join('\\n')");
    expect(printableTemplate).toContain('rightValue: customerIdentity');
    expect(printableTemplate).not.toContain('rounded-lg border border-slate-200 bg-slate-50');
    expect(printableTemplate).not.toContain('window.open(');
    expect(printableTemplate).not.toContain('pdf.save(');
    expect(source).toContain('link.download = fileName');
  });

  it('يحفظ ويعرض بيان العميل الاختياري ويطبق قالب PDF الرأسي على السند والتقارير', () => {
    const receiptSource = readFileSync(new URL('../client/src/pages/ReceiptsPage.tsx', import.meta.url), 'utf8');
    const reportsSource = readFileSync(new URL('../client/src/pages/ReportsPage.tsx', import.meta.url), 'utf8');

    expect(receiptSource).toContain('customerStatement: form.customerStatement.trim() || undefined');
    expect(receiptSource).toContain('receipt-customer-statement');
    expect(receiptSource).toContain("orientation: printPresentation.pageOrientation");
    expect(receiptSource).toContain('printPresentation.headerPercent');
    expect(receiptSource).toContain('printPresentation.footerPercent');
    expect(receiptSource).toContain('text-sm font-extrabold');
    expect(receiptSource).toContain('h-6 border-emerald-300');
    expect(receiptSource).toContain('h-6 border-rose-300');
    expect(reportsSource).toContain("orientation: printPresentation.pageOrientation");
    expect(reportsSource).toContain('footerStart');
  });
});
