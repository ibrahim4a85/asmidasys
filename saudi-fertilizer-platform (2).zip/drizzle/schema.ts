import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, bigint, decimal, boolean, json, date, uniqueIndex, index } from "drizzle-orm/mysql-core";

// ==================== المستخدمين ====================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

// نظام المصادقة المخصص
export const systemUsers = mysqlTable("system_users", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  fullName: varchar("fullName", { length: 255 }).notNull(),
  userType: varchar("userType", { length: 64 }).default("delegate").notNull(),
  boardPosition: varchar("boardPosition", { length: 255 }),
  userLevel: mysqlEnum("userLevel", ["primary", "secondary"]).default("secondary").notNull(),
  branchId: int("branchId"),
  isActive: boolean("isActive").default(true).notNull(),
  permissions: json("permissions"),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn"),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// رموز مؤقتة لاستعادة كلمات مرور نظام الإدارة. لا تُخزن الرموز الخام مطلقاً ولا تدخل النسخ الاحتياطية.
export const passwordResetCodes = mysqlTable("password_reset_codes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  recoveryEmail: varchar("recoveryEmail", { length: 320 }).notNull(),
  codeHash: varchar("codeHash", { length: 128 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  attempts: int("attempts").default(0).notNull(),
  consumedAt: timestamp("consumedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("password_reset_codes_user_unique").on(table.userId),
  uniqueIndex("password_reset_codes_hash_unique").on(table.codeHash),
]);

// ==================== إعدادات النظام ====================
export const systemSettings = mysqlTable("system_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
  settingValue: text("settingValue"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ==================== ملف تعريف الشركة ====================
export const companyProfile = mysqlTable("company_profile", {
  id: int("id").autoincrement().primaryKey(),
  companyName: varchar("companyName", { length: 255 }).notNull(),
  address: text("address"),
  commercialRegister: varchar("commercialRegister", { length: 50 }),
  taxNumber: varchar("taxNumber", { length: 50 }),
  logoUrl: text("logoUrl"),
  phone: varchar("phone", { length: 20 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ==================== المناطق ====================
export const regions = mysqlTable("regions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== الفروع ====================
export const branches = mysqlTable("branches", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  address: text("address"),
  regionId: int("regionId"),
  receiptSerial: varchar("receiptSerial", { length: 20 }).notNull(),
  paymentSerial: varchar("paymentSerial", { length: 20 }),
  currentReceiptNumber: int("currentReceiptNumber").default(0).notNull(),
  currentPaymentNumber: int("currentPaymentNumber").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// ==================== الفترات المالية ====================
export const financialPeriods = mysqlTable("financial_periods", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  isActive: boolean("isActive").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== حقوق الشركاء ====================
// يحتفظ هذا القسم بالمراجع والوصف فقط؛ أما بايتات الصور والمستندات فتظل في التخزين الكائني.
export const partners = mysqlTable("partners", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  systemUserId: int("systemUserId"),
  profileImageUrl: text("profileImageUrl"),
  profileImageName: varchar("profileImageName", { length: 255 }),
  profileImageMimeType: varchar("profileImageMimeType", { length: 100 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
}, (table) => [
  uniqueIndex("partners_system_user_unique").on(table.systemUserId),
]);

// بيانات قرار توزيع الأرباح والرصيد المرحّل تُسجّل مرة واحدة لكل فترة مالية.
export const partnerPeriodSettings = mysqlTable("partner_period_settings", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  openingProfitBalance: decimal("openingProfitBalance", { precision: 15, scale: 2 }).default("0").notNull(),
  distributionDecisionUrl: text("distributionDecisionUrl"),
  distributionDecisionName: varchar("distributionDecisionName", { length: 255 }),
  distributionDecisionMimeType: varchar("distributionDecisionMimeType", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
}, (table) => [
  uniqueIndex("partner_period_settings_period_unique").on(table.periodId),
]);

// حصة كل شريك ضمن فترة مالية محددة؛ يمنع الفهرس وجود حصتين للشريك نفسه في الفترة.
export const partnerPeriodAllocations = mysqlTable("partner_period_allocations", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  partnerId: int("partnerId").notNull(),
  sharePercentage: decimal("sharePercentage", { precision: 5, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
}, (table) => [
  uniqueIndex("partner_period_allocation_unique").on(table.periodId, table.partnerId),
]);

// لا تحمل هذه الحركة إشارة سالبة؛ يحدد نوعها أثرها المحاسبي على الحساب الجاري.
export const partnerAccountEntries = mysqlTable("partner_account_entries", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  partnerId: int("partnerId").notNull(),
  entryType: mysqlEnum("entryType", ["withdrawal", "entitlement", "year_end_settlement"]).notNull(),
  settlementDirection: mysqlEnum("settlementDirection", ["credit", "debit"]),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  entryDate: timestamp("entryDate").notNull(),
  statement: text("statement").notNull(),
  attachmentUrl: text("attachmentUrl"),
  attachmentName: varchar("attachmentName", { length: 255 }),
  attachmentMimeType: varchar("attachmentMimeType", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("partner_account_entry_unique").on(table.periodId, table.partnerId, table.entryDate, table.entryType, table.amount),
]);

// عضوية الشركاء التاريخية مستقلة عن حالة الشريك الحالية، حتى تبقى تقارير السنوات السابقة دقيقة.
export const partnerPeriodMemberships = mysqlTable("partner_period_memberships", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  partnerId: int("partnerId").notNull(),
  isIncluded: boolean("isIncluded").default(true).notNull(),
  shareUnits: decimal("shareUnits", { precision: 15, scale: 2 }),
  nominalShareValue: decimal("nominalShareValue", { precision: 15, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("partner_period_membership_unique").on(table.periodId, table.partnerId),
]);

// سطور قابلة للتخصيص لقائمة التغير في حقوق الشركاء؛ الإجمالي يحسب في العرض ولا ينشئ أي قيد.
export const partnerPeriodEquityLines = mysqlTable("partner_period_equity_lines", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  lineType: mysqlEnum("lineType", ["opening_balance", "capital", "legal_reserve", "retained_earnings", "profit_distribution", "net_income", "actuarial_remeasurement", "custom"]).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  capitalAmount: decimal("capitalAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  legalReserveAmount: decimal("legalReserveAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  retainedEarningsAmount: decimal("retainedEarningsAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  notes: text("notes"),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("partner_period_equity_line_sort_unique").on(table.periodId, table.sortOrder),
]);

// تفصيل توثيقي لتوزيعات الأرباح بحسب الشريك والفترة؛ لا ينشئ حركة حساب جارٍ أو اعتماداً تلقائياً.
export const partnerProfitDistributions = mysqlTable("partner_profit_distributions", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  partnerId: int("partnerId").notNull(),
  distributionAmount: decimal("distributionAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  distributionDate: timestamp("distributionDate"),
  statement: text("statement"),
  attachmentKey: text("attachmentKey"),
  attachmentUrl: text("attachmentUrl"),
  attachmentName: varchar("attachmentName", { length: 255 }),
  attachmentMimeType: varchar("attachmentMimeType", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("partner_profit_distribution_unique").on(table.periodId, table.partnerId),
]);

// فهرس مرفقات سنوي متعدد لمحاضر التوزيع والتسويات والقوائم المالية والمستندات المخصصة.
export const partnerPeriodDocuments = mysqlTable("partner_period_documents", {
  id: int("id").autoincrement().primaryKey(),
  periodId: int("periodId").notNull(),
  documentType: mysqlEnum("documentType", ["distribution_minutes", "year_end_settlement", "financial_statements", "custom"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  attachmentKey: text("attachmentKey"),
  attachmentUrl: text("attachmentUrl").notNull(),
  attachmentName: varchar("attachmentName", { length: 255 }).notNull(),
  attachmentMimeType: varchar("attachmentMimeType", { length: 100 }).notNull(),
  notes: text("notes"),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("partner_period_document_sort_unique").on(table.periodId, table.sortOrder),
]);

// ==================== المستهدفات ====================
export const branchTargets = mysqlTable("branch_targets", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  periodId: int("periodId").notNull(),
  targetType: mysqlEnum("targetType", ["sales", "collections", "custom"]).notNull(),
  targetName: varchar("targetName", { length: 255 }),
  targetValue: decimal("targetValue", { precision: 15, scale: 2 }).notNull(),
  currentValue: decimal("currentValue", { precision: 15, scale: 2 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// ==================== إدارة الأهداف والعمولات ====================
export const goalTypes = mysqlTable("goal_types", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["administrative", "sales"]).notNull(),
  description: text("description"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  uniqueIndex("goal_type_category_name_unique").on(table.category, table.name),
]);

export const administrativeGoals = mysqlTable("administrative_goals", {
  id: int("id").autoincrement().primaryKey(),
  goalTypeId: int("goalTypeId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["planned", "in_progress", "completed", "closed"]).default("planned").notNull(),
  startDate: date("startDate"),
  expectedEndDate: date("expectedEndDate"),
  expectedDurationMonths: int("expectedDurationMonths"),
  completionPercent: decimal("completionPercent", { precision: 5, scale: 2 }).default("0").notNull(),
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  index("administrative_goals_type_idx").on(table.goalTypeId),
  index("administrative_goals_status_idx").on(table.status),
]);

export const administrativeGoalReviewers = mysqlTable("administrative_goal_reviewers", {
  id: int("id").autoincrement().primaryKey(),
  goalId: int("goalId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  createdBy: int("createdBy").notNull(),
}, (table) => [
  uniqueIndex("administrative_goal_reviewer_unique").on(table.goalId, table.userId),
  index("administrative_goal_reviewer_user_idx").on(table.userId),
]);

export const administrativeGoalActions = mysqlTable("administrative_goal_actions", {
  id: int("id").autoincrement().primaryKey(),
  goalId: int("goalId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  sortOrder: int("sortOrder").default(0).notNull(),
  status: mysqlEnum("status", ["planned", "in_progress", "completed", "closed"]).default("planned").notNull(),
  plannedStartDate: date("plannedStartDate"),
  plannedEndDate: date("plannedEndDate"),
  proposedAssigneeUserId: int("proposedAssigneeUserId"),
  assigneeUserId: int("assigneeUserId"),
  completionPercent: decimal("completionPercent", { precision: 5, scale: 2 }).default("0").notNull(),
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  index("administrative_goal_action_goal_idx").on(table.goalId),
  index("administrative_goal_action_assignee_idx").on(table.assigneeUserId),
]);

export const administrativeGoalActionAttachments = mysqlTable("administrative_goal_action_attachments", {
  id: int("id").autoincrement().primaryKey(),
  actionId: int("actionId").notNull(),
  attachmentUrl: text("attachmentUrl").notNull(),
  attachmentName: varchar("attachmentName", { length: 255 }).notNull(),
  attachmentMimeType: varchar("attachmentMimeType", { length: 100 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  createdBy: int("createdBy").notNull(),
}, (table) => [index("administrative_goal_attachment_action_idx").on(table.actionId)]);

export const salesGoalPlans = mysqlTable("sales_goal_plans", {
  id: int("id").autoincrement().primaryKey(),
  goalTypeId: int("goalTypeId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  periodId: int("periodId").notNull(),
  scopeType: mysqlEnum("scopeType", ["company", "branch", "user"]).default("branch").notNull(),
  branchId: int("branchId"),
  userId: int("userId"),
  status: mysqlEnum("status", ["draft", "active", "closed"]).default("draft").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  index("sales_goal_plan_period_idx").on(table.periodId),
  index("sales_goal_plan_branch_idx").on(table.branchId),
  index("sales_goal_plan_user_idx").on(table.userId),
]);

export const salesGoalMetrics = mysqlTable("sales_goal_metrics", {
  id: int("id").autoincrement().primaryKey(),
  salesGoalPlanId: int("salesGoalPlanId").notNull(),
  metricType: mysqlEnum("metricType", ["sales", "collections", "new_customers", "custom"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  targetValue: decimal("targetValue", { precision: 15, scale: 2 }).notNull(),
  currentValue: decimal("currentValue", { precision: 15, scale: 2 }).default("0").notNull(),
  dataSource: mysqlEnum("dataSource", ["manual", "performance_reports", "approved_receipts"]).default("manual").notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [index("sales_goal_metric_plan_idx").on(table.salesGoalPlanId)]);

export const commissionPlans = mysqlTable("commission_plans", {
  id: int("id").autoincrement().primaryKey(),
  salesGoalPlanId: int("salesGoalPlanId").notNull(),
  salesGoalMetricId: int("salesGoalMetricId"),
  name: varchar("name", { length: 255 }).notNull(),
  baseCommissionRate: decimal("baseCommissionRate", { precision: 7, scale: 4 }).notNull(),
  minimumPayoutAmount: decimal("minimumPayoutAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [
  index("commission_plan_sales_goal_idx").on(table.salesGoalPlanId),
  index("commission_plan_metric_idx").on(table.salesGoalMetricId),
]);

export const commissionTiers = mysqlTable("commission_tiers", {
  id: int("id").autoincrement().primaryKey(),
  commissionPlanId: int("commissionPlanId").notNull(),
  minAchievementPercent: decimal("minAchievementPercent", { precision: 7, scale: 2 }).notNull(),
  maxAchievementPercent: decimal("maxAchievementPercent", { precision: 7, scale: 2 }),
  payoutMultiplier: decimal("payoutMultiplier", { precision: 7, scale: 4 }).default("1").notNull(),
  additionalCommissionRate: decimal("additionalCommissionRate", { precision: 7, scale: 4 }).default("0").notNull(),
  fixedBonusAmount: decimal("fixedBonusAmount", { precision: 15, scale: 2 }).default("0").notNull(),
  isEligible: boolean("isEligible").default(true).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
}, (table) => [index("commission_tier_plan_idx").on(table.commissionPlanId)]);

// ==================== العملاء ====================
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  customerNumber: varchar("customerNumber", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  branchId: int("branchId"),
  delegateId: int("delegateId"),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// ==================== قوائم الإدخال ====================
export const inputLists = mysqlTable("input_lists", {
  id: int("id").autoincrement().primaryKey(),
  listType: mysqlEnum("listType", ["payment_method", "bank", "payment_for"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  parentId: int("parentId"),
  requiresAttachment: boolean("requiresAttachment").default(true).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== سندات القبض ====================
export const receipts = mysqlTable("receipts", {
  id: int("id").autoincrement().primaryKey(),
  serialNumber: varchar("serialNumber", { length: 50 }).notNull(),
  branchId: int("branchId").notNull(),
  userId: int("userId").notNull(),
  customerId: int("customerId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  amountInWords: text("amountInWords"),
  paymentMethodId: int("paymentMethodId"),
  bankId: int("bankId"),
  paymentForId: int("paymentForId"),
  customerStatement: text("customerStatement"),
  attachmentUrl: text("attachmentUrl"),
  qrCode: text("qrCode"),
  status: mysqlEnum("status", ["draft", "issued", "approved", "rejected"]).default("draft").notNull(),
  notes: text("notes"),
  customFields: text("customFields"),
  periodId: int("periodId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// ==================== فواتير سندات القبض ====================
export const receiptInvoices = mysqlTable("receipt_invoices", {
  id: int("id").autoincrement().primaryKey(),
  receiptId: int("receiptId").notNull(),
  invoiceNumber: varchar("invoiceNumber", { length: 50 }).notNull(),
  invoiceAmount: decimal("invoiceAmount", { precision: 15, scale: 2 }).notNull(),
});

// ==================== إشعارات النظام الداخلية ====================
export const internalNotifications = mysqlTable("internal_notifications", {
  id: int("id").autoincrement().primaryKey(),
  recipientUserId: int("recipientUserId").notNull(),
  notificationType: varchar("notificationType", { length: 64 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  receiptId: int("receiptId"),
  approvalRequestId: int("approvalRequestId"),
  isRead: boolean("isRead").default(false).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== سجل قرارات سندات القبض ====================
export const receiptDecisionAudit = mysqlTable("receipt_decision_audit", {
  id: int("id").autoincrement().primaryKey(),
  receiptId: int("receiptId").notNull(),
  decision: mysqlEnum("decision", ["approved", "rejected"]).notNull(),
  previousStatus: varchar("previousStatus", { length: 32 }).notNull(),
  nextStatus: varchar("nextStatus", { length: 32 }).notNull(),
  decidedBy: int("decidedBy").notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== سندات الصرف ====================
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  serialNumber: varchar("serialNumber", { length: 50 }).notNull(),
  branchId: int("branchId").notNull(),
  userId: int("userId").notNull(),
  beneficiary: varchar("beneficiary", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  amountInWords: text("amountInWords"),
  expenseCategory: varchar("expenseCategory", { length: 255 }),
  paymentMethodId: int("paymentMethodId"),
  bankId: int("bankId"),
  description: text("description"),
  attachmentUrl: text("attachmentUrl"),
  status: mysqlEnum("status", ["draft", "approved", "rejected"]).default("draft").notNull(),
  notes: text("notes"),
  periodId: int("periodId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
});

// ==================== تقارير الأداء اليومية ====================
export const performanceReports = mysqlTable("performance_reports", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  reportDate: date("reportDate").notNull(),
  salesInvoicesCount: int("salesInvoicesCount").default(0).notNull(),
  salesInvoicesValue: decimal("salesInvoicesValue", { precision: 15, scale: 2 }).default("0").notNull(),
  returnsInvoicesCount: int("returnsInvoicesCount").default(0).notNull(),
  returnsInvoicesValue: decimal("returnsInvoicesValue", { precision: 15, scale: 2 }).default("0").notNull(),
  netSalesValue: decimal("netSalesValue", { precision: 15, scale: 2 }).default("0").notNull(),
  receiptsCount: int("receiptsCount").default(0).notNull(),
  collectionsValue: decimal("collectionsValue", { precision: 15, scale: 2 }).default("0").notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  uniqueIndex("performance_reports_branch_date_unique").on(table.branchId, table.reportDate),
]);

// ==================== المفوضين ====================
export const delegates = mysqlTable("delegates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  position: varchar("position", { length: 255 }),
  username: varchar("username", { length: 64 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== أنواع النماذج ====================
export const documentTypes = mysqlTable("document_types", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  templateRequirement: mysqlEnum("templateRequirement", ["optional", "required"]).default("optional").notNull(),
  templateUrl: text("templateUrl"),
  templateName: varchar("templateName", { length: 255 }),
  templateMimeType: varchar("templateMimeType", { length: 100 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ==================== مسارات تعميد المستندات ====================
export const approvalWorkflows = mysqlTable("approval_workflows", {
  id: int("id").autoincrement().primaryKey(),
  documentTypeId: int("documentTypeId").notNull().unique(),
  reviewerUserId: int("reviewerUserId"),
  reviewerSequential: boolean("reviewerSequential").default(false).notNull(),
  requiredReviews: int("requiredReviews").default(0).notNull(),
  approvalMode: mysqlEnum("approvalMode", ["sequential", "any", "all", "two_board_members"]).default("sequential").notNull(),
  approverSequential: boolean("approverSequential").default(false).notNull(),
  requiredApprovals: int("requiredApprovals").default(1).notNull(),
  boardMembersOnly: boolean("boardMembersOnly").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const approvalWorkflowReviewers = mysqlTable("approval_workflow_reviewers", {
  id: int("id").autoincrement().primaryKey(),
  workflowId: int("workflowId").notNull(),
  systemUserId: int("systemUserId").notNull(),
  sortOrder: int("sortOrder").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("approval_workflow_reviewer_unique").on(table.workflowId, table.systemUserId),
]);

export const approvalWorkflowApprovers = mysqlTable("approval_workflow_approvers", {
  id: int("id").autoincrement().primaryKey(),
  workflowId: int("workflowId").notNull(),
  systemUserId: int("systemUserId").notNull(),
  sortOrder: int("sortOrder").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("approval_workflow_approver_unique").on(table.workflowId, table.systemUserId),
]);

// ==================== طلبات التعميد ====================
export const approvalRequests = mysqlTable("approval_requests", {
  id: int("id").autoincrement().primaryKey(),
  documentTypeId: int("documentTypeId"),
  requestedBy: int("requestedBy").notNull(),
  approvalNumber: varchar("approvalNumber", { length: 80 }).unique(),
  requesterName: varchar("requesterName", { length: 255 }),
  requesterPosition: varchar("requesterPosition", { length: 255 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  attachmentUrl: text("attachmentUrl"),
  attachmentName: varchar("attachmentName", { length: 255 }),
  templateRequired: boolean("templateRequired").default(false).notNull(),
  status: mysqlEnum("status", ["pending", "draft", "review_pending", "sent", "approved", "rejected", "postponed"]).default("draft").notNull(),
  delegateId: int("delegateId"),
  workflowId: int("workflowId"),
  reviewerUserId: int("reviewerUserId"),
  reviewerSequential: boolean("reviewerSequential").default(false).notNull(),
  requiredReviews: int("requiredReviews").default(0).notNull(),
  reviewedCount: int("reviewedCount").default(0).notNull(),
  currentReviewStepOrder: int("currentReviewStepOrder").default(1).notNull(),
  reviewStatus: varchar("reviewStatus", { length: 32 }).default("not_started").notNull(),
  reviewNote: text("reviewNote"),
  reviewedAt: timestamp("reviewedAt"),
  submittedAt: timestamp("submittedAt"),
  approvalMode: mysqlEnum("approvalMode", ["sequential", "any", "all", "two_board_members"]).default("sequential").notNull(),
  approverSequential: boolean("approverSequential").default(false).notNull(),
  requiredApprovals: int("requiredApprovals").default(1).notNull(),
  approvedCount: int("approvedCount").default(0).notNull(),
  currentStepOrder: int("currentStepOrder").default(1).notNull(),
  approvalNote: text("approvalNote"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const approvalRequestReviewerSteps = mysqlTable("approval_request_reviewer_steps", {
  id: int("id").autoincrement().primaryKey(),
  requestId: int("requestId").notNull(),
  workflowId: int("workflowId").notNull(),
  systemUserId: int("systemUserId").notNull(),
  stepOrder: int("stepOrder").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "skipped"]).default("pending").notNull(),
  note: text("note"),
  actedAt: timestamp("actedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("approval_request_reviewer_step_unique").on(table.requestId, table.systemUserId),
]);

export const approvalRequestSteps = mysqlTable("approval_request_steps", {
  id: int("id").autoincrement().primaryKey(),
  requestId: int("requestId").notNull(),
  workflowId: int("workflowId").notNull(),
  systemUserId: int("systemUserId").notNull(),
  stepOrder: int("stepOrder").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "skipped"]).default("pending").notNull(),
  note: text("note"),
  actedAt: timestamp("actedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("approval_request_step_unique").on(table.requestId, table.systemUserId),
]);

// ==================== الشريط الإخباري ====================
export const newsItems = mysqlTable("news_items", {
  id: int("id").autoincrement().primaryKey(),
  content: text("content").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0),
  speed: int("speed").default(50),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== خلفيات تسجيل الدخول ====================
export const loginBackgrounds = mysqlTable("login_backgrounds", {
  id: int("id").autoincrement().primaryKey(),
  imageUrl: text("imageUrl").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== سجل النشاطات ====================
export const activityLog = mysqlTable("activity_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ==================== سجل النسخ الاحتياطية ====================
export const backupLogs = mysqlTable("backup_logs", {
  id: int("id").autoincrement().primaryKey(),
  operation: mysqlEnum("operation", ["download", "restore"]).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  recordsCount: int("recordsCount").default(0).notNull(),
  status: mysqlEnum("status", ["success", "failed"]).default("success").notNull(),
  details: text("details"),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type SystemUser = typeof systemUsers.$inferSelect;
export type InsertSystemUser = typeof systemUsers.$inferInsert;
export type Branch = typeof branches.$inferSelect;
export type Customer = typeof customers.$inferSelect;
export type Receipt = typeof receipts.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type PerformanceReport = typeof performanceReports.$inferSelect;
export type FinancialPeriod = typeof financialPeriods.$inferSelect;
export type Partner = typeof partners.$inferSelect;
export type PartnerPeriodSetting = typeof partnerPeriodSettings.$inferSelect;
export type PartnerPeriodAllocation = typeof partnerPeriodAllocations.$inferSelect;
export type PartnerAccountEntry = typeof partnerAccountEntries.$inferSelect;
export type PartnerPeriodMembership = typeof partnerPeriodMemberships.$inferSelect;
export type PartnerPeriodEquityLine = typeof partnerPeriodEquityLines.$inferSelect;
export type PartnerProfitDistribution = typeof partnerProfitDistributions.$inferSelect;
export type PartnerPeriodDocument = typeof partnerPeriodDocuments.$inferSelect;
export type BranchTarget = typeof branchTargets.$inferSelect;
export type Delegate = typeof delegates.$inferSelect;
export type ApprovalRequest = typeof approvalRequests.$inferSelect;
export type ApprovalWorkflow = typeof approvalWorkflows.$inferSelect;
export type BackupLog = typeof backupLogs.$inferSelect;
