import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const customersPage = readFileSync(fileURLToPath(new URL('../client/src/pages/CustomersPage.tsx', import.meta.url)), 'utf8');

describe('تسميات العرض الآمنة في لوحة استيراد العملاء', () => {
  it('يوفر قيماً افتراضية ويقبل تجاوزاً إدارياً لعنوان ووصف اللوحة', () => {
    expect(getSystemLabel(undefined, 'customers_import_file_title')).toBe('رفع ملف Excel للعملاء');
    expect(getSystemLabel(undefined, 'customers_import_file_description')).toBe('يجب أن يحتوي الملف على أعمدة: رقم العميل، الاسم، الهاتف (اختياري) - يدعم xlsx, xls, csv');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ customers_import_file_title: 'استيراد قائمة العملاء' }) },
      'customers_import_file_title',
    )).toBe('استيراد قائمة العملاء');
  });

  it('يربط النصوص الوصفية فقط ويحافظ على قراءة الملف والتحقق والاستيراد', () => {
    expect(customersPage).toContain("labelFor('customers_import_file_title'");
    expect(customersPage).toContain("labelFor('customers_import_file_description'");
    expect(customersPage).toContain('accept=".xlsx,.xls,.csv"');
    expect(customersPage).toContain('await file.arrayBuffer()');
    expect(customersPage).toContain("XLSX.read(buffer, { type: 'array' })");
    expect(customersPage).toContain("XLSX.utils.sheet_to_json(sheet, { header: 1 })");
    expect(customersPage).toContain("if (rows.length < 2)");
    expect(customersPage).toContain("header.findIndex((h: string) => h.includes('رقم')");
    expect(customersPage).toContain('await createMutation.mutateAsync({ customerNumber, name, phone } as any)');
  });
});
