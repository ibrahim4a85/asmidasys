import { applySecondaryUserApprovalRequestDefault } from './systemUserDefaults';

describe('الصلاحية الافتراضية لطلب التعميد', () => {
  it('يمنح المستخدم الفرعي صلاحية طلب التعميد عند عدم تحديدها', () => {
    expect(applySecondaryUserApprovalRequestDefault({ userLevel: 'secondary', userType: 'delegate', permissions: { sidebar_delegates: true } })).toMatchObject({ permissions: { approvalRequest: true } });
  });

  it('يحافظ على إلغاء مدير النظام الصريح للصلاحية', () => {
    expect(applySecondaryUserApprovalRequestDefault({ userLevel: 'secondary', userType: 'delegate', permissions: { approvalRequest: false } })).toMatchObject({ permissions: { approvalRequest: false } });
  });

  it('لا يمنح شريكاً غير مفوض صلاحية طلب التعميد', () => {
    expect(applySecondaryUserApprovalRequestDefault({ userLevel: 'secondary', userType: 'authorized_partner', boardPosition: 'شريك فقط', permissions: {} })).toEqual({ userLevel: 'secondary', userType: 'authorized_partner', boardPosition: 'شريك فقط', permissions: {} });
  });
});
