import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({ getBankCollectionsByPeriod: vi.fn() }));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import type { TrpcContext } from './_core/context';

function context(): TrpcContext {
  return {
    user: null,
    systemUser: { id: 31, username: 'partner', fullName: 'شريك مفوض', userType: 'authorized_partner', userLevel: 'primary', branchId: null, permissions: { sidebar_dashboard: true } },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

describe('إجراء تقرير المتحصلات البنكية', () => {
  beforeEach(() => vi.resetAllMocks());

  it('يمرر الفترة والتاريخين المحددين إلى طبقة البيانات ويرجع التجميع كما هو', async () => {
    const report = [{ day: '2026-08-18', bankId: 1, bankName: 'الراجحي', totalAmount: '1500', receiptCount: 2 }];
    vi.mocked(db.getBankCollectionsByPeriod).mockResolvedValue(report as never);
    await expect(appRouter.createCaller(context()).reports.bankCollections({ periodId: 8, startDate: '2026-08-01', endDate: '2026-08-18' })).resolves.toEqual(report);
    expect(db.getBankCollectionsByPeriod).toHaveBeenCalledWith({ periodId: 8, startDate: '2026-08-01', endDate: '2026-08-18' });
  });

  it('يرفض التواريخ غير المعيارية قبل تنفيذ الاستعلام', async () => {
    await expect(appRouter.createCaller(context()).reports.bankCollections({ startDate: '18/08/2026' })).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    expect(db.getBankCollectionsByPeriod).not.toHaveBeenCalled();
  });
});
