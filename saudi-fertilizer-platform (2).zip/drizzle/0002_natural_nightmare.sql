ALTER TABLE `customers` ADD `createdBy` int;--> statement-breakpoint
ALTER TABLE `customers` ADD `updatedBy` int;