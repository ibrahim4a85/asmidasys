export type PdfLogoFormat = "PNG" | "JPEG" | "WEBP";

export function getPdfLogoFormat(mimeType?: string): PdfLogoFormat | null {
  const normalized = mimeType?.toLowerCase().split(";")[0].trim();
  if (normalized === "image/png") return "PNG";
  if (normalized === "image/jpeg" || normalized === "image/jpg") return "JPEG";
  if (normalized === "image/webp") return "WEBP";
  return null;
}
