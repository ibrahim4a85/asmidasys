export type DirectReceiptDownload = {
  type: 'receipt' | 'attachment';
  fileName: string;
  mode: 'direct';
  opensPreview: false;
  sequence: 1 | 2;
};

export function getSeparateReceiptDownloadPlan(serialNumber: string, attachmentUrl?: string | null): DirectReceiptDownload[] {
  if (!attachmentUrl) return [];

  return [
    { type: 'receipt', fileName: `${serialNumber}.pdf`, mode: 'direct', opensPreview: false, sequence: 1 },
    { type: 'attachment', fileName: `${serialNumber}-ESAL.pdf`, mode: 'direct', opensPreview: false, sequence: 2 },
  ];
}
