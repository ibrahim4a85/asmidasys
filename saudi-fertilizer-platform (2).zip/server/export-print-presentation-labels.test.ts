import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const projectRoot = resolve(__dirname, '..');
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), 'utf8');

describe('تسميات العرض المطبوعة للتصدير', () => {
  it('يوفر القاموس قيماً افتراضية ويتقبل تجاوز المدير لعناوين التصدير المطبوعة', () => {
    const settings = {
      system_label_overrides: JSON.stringify({
        receipts_export_print_title: 'كشف تحصيلات القبض',
        customers_export_print_all_scope: 'قاعدة العملاء',
        customers_export_empty_message: 'لا توجد سجلات قابلة للتصدير',
      }),
    };

    expect(getSystemLabel(null, 'receipts_export_print_title')).toBe('تقرير سندات القبض');
    expect(getSystemLabel(null, 'receipts_export_print_count')).toBe('عدد السندات');
    expect(getSystemLabel(null, 'receipts_export_print_date')).toBe('تاريخ التصدير');
    expect(getSystemLabel(null, 'customers_export_print_title')).toBe('تقرير العملاء');
    expect(getSystemLabel(null, 'customers_export_print_selected_scope')).toBe('المحدد');
    expect(getSystemLabel(null, 'customers_export_empty_message')).toBe('لا توجد بيانات قابلة للتصدير');
    expect(getSystemLabel(settings, 'receipts_export_print_title')).toBe('كشف تحصيلات القبض');
    expect(getSystemLabel(settings, 'customers_export_print_all_scope')).toBe('قاعدة العملاء');
    expect(getSystemLabel(settings, 'customers_export_empty_message')).toBe('لا توجد سجلات قابلة للتصدير');
  });

  it('يربط القوالب المطبوعة بالقاموس مع حماية التوليد والتنزيل وأسماء الملفات', () => {
    const receiptsPage = readProjectFile('client/src/pages/ReceiptsPage.tsx');
    const customersPage = readProjectFile('client/src/pages/CustomersPage.tsx');

    expect(receiptsPage).toContain("labelFor('receipts_export_print_title')");
    expect(receiptsPage).toContain("labelFor('receipts_export_print_count')");
    expect(receiptsPage).toContain("labelFor('receipts_export_print_date')");
    expect(receiptsPage).toContain("XLSX.utils.book_append_sheet(workbook, worksheet, 'سندات القبض');");
    expect(receiptsPage).toContain("XLSX.writeFile(workbook, `سندات-القبض-${new Date().toISOString().slice(0, 10)}.xlsx`);");

    expect(customersPage).toContain("labelFor('customers_export_print_title')");
    expect(customersPage).toContain("labelFor('customers_export_print_selected_scope')");
    expect(customersPage).toContain("labelFor('customers_export_print_all_scope')");
    expect(customersPage).toContain("if (!rows.length) { toast.error(labelFor('customers_export_empty_message', 'لا توجد بيانات قابلة للتصدير')); return; }");
    expect(customersPage).toContain("const scope = selected.length > 0 ? `المحدد-${selected.length}` : 'كل-العملاء';");
    expect(customersPage).toContain("XLSX.writeFile(workbook, `العملاء-${scope}.xlsx`);");
    expect(customersPage).toContain('window.open(\'\', \'_blank\', \'noopener,noreferrer\')');
  });
});
