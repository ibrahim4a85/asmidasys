import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { getSystemLabel, readSystemLabelOverrides } from '../shared/systemLabelPresentation';

describe('app layout navigation accessibility label', () => {
  it('keeps the navigation-toggle default and accepts an administrator override', () => {
    expect(getSystemLabel(undefined, 'ui_toggle_navigation')).toBe('فتح قائمة التنقل');

    const overrides = readSystemLabelOverrides({
      system_label_overrides: JSON.stringify({
        ui_toggle_navigation: 'إظهار التنقل',
      }),
    });

    expect(overrides.ui_toggle_navigation).toBe('إظهار التنقل');
  });

  it('uses the label for the mobile control while preserving navigation state and structure', () => {
    const source = readFileSync(new URL('../client/src/components/AppLayout.tsx', import.meta.url), 'utf8');

    expect(source).toContain("aria-label={labelFor('ui_toggle_navigation')}");
    expect(source).toContain('onClick={() => setMobileOpen(true)}');
    expect(source).toContain('const [mobileOpen, setMobileOpen]');
    expect(source).toContain('const navItems: NavItem[]');
    expect(source).toContain('const sortedNavItems');
    expect(source).toContain('hasSidebarAccess');
  });
});
