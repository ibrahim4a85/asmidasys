import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({ createGoalType: vi.fn(), getCommissionPlanById: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import type { TrpcContext } from './_core/context';

function context(permissions: Record<string, boolean> = {}): TrpcContext {
  return {
    user: null,
    systemUser: { id: 61, username: 'goals-user', fullName: 'مستخدم الأهداف', userType: 'manager', userLevel: 'primary', branchId: null, permissions },
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

describe('موجّه إدارة الأهداف والعمولات', () => {
  beforeEach(() => vi.resetAllMocks());

  it('يرفض إدارة أنواع الأهداف دون صلاحية الإدارة الدقيقة', async () => {
    await expect(appRouter.createCaller(context({ goalsView: true })).goalManagement.goalTypes.create({ name: 'تشغيلي', category: 'administrative' }))
      .rejects.toMatchObject({ code: 'FORBIDDEN' });
    expect(db.createGoalType).not.toHaveBeenCalled();
  });

  it('يبقي صلاحية المستهدفات القديمة متوافقة مع إدارة أنواع الأهداف الجديدة', async () => {
    vi.mocked(db.createGoalType).mockResolvedValue({ id: 7 } as never);
    await appRouter.createCaller(context({ targetsManage: true })).goalManagement.goalTypes.create({ name: 'تشغيلي', category: 'administrative' });
    expect(db.createGoalType).toHaveBeenCalledWith(expect.objectContaining({ name: 'تشغيلي', category: 'administrative', createdBy: 61, updatedBy: 61 }));
  });

  it('يرفض مدخل نوع هدف غير معتمد قبل تنفيذ عملية حفظ', async () => {
    await expect(appRouter.createCaller(context({ goalsManage: true })).goalManagement.goalTypes.create({ name: 'غير صالح', category: 'other' as never }))
      .rejects.toMatchObject({ code: 'BAD_REQUEST' });
    expect(db.createGoalType).not.toHaveBeenCalled();
  });

  it('يرفض شرائح العمولة ذات النطاق المعكوس قبل الوصول لبيانات الخطط', async () => {
    vi.mocked(db.getCommissionPlanById).mockResolvedValue({ id: 1 } as never);
    await expect(appRouter.createCaller(context({ commissionsManage: true })).goalManagement.commissions.replaceTiers({
      commissionPlanId: 1,
      tiers: [{ minAchievementPercent: 90, maxAchievementPercent: 80, payoutMultiplier: 1, additionalCommissionRate: 0, fixedBonusAmount: 0, isEligible: true }],
    })).rejects.toMatchObject({ code: 'BAD_REQUEST' });
  });
});
