import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const projectRoot = resolve(__dirname, '..');
const receiptsPage = readFileSync(resolve(projectRoot, 'client/src/pages/ReceiptsPage.tsx'), 'utf8');

describe('أدوات سجل سندات القبض', () => {
  it('يعرض اختصارات أدوات السجل الأيقونية في صف علامات التبويب من دون رأس سجل زائد', () => {
    expect(receiptsPage).toContain('علامات تبويب وإجراءات سندات القبض');
    expect(receiptsPage).toContain('id="receipt-record-tools"');
    expect(receiptsPage).toContain('اختصارات أدوات سجل السندات');
    expect(receiptsPage).toContain('size="icon"');
    expect(receiptsPage).toContain('ms-auto flex items-center gap-1');
    expect(receiptsPage).not.toContain("labelFor('receipts_export_hint'");
    expect(receiptsPage).not.toContain('const [receiptToolsExpanded, setReceiptToolsExpanded] = useState(false);');
    expect(receiptsPage).not.toContain("'أدوات السجل'");
  });

  it('يدعم الفرز المحلي للتاريخ والبنك وطريقة الدفع مع مؤشر وصول واضح', () => {
    expect(receiptsPage).toContain("'date' | 'bank' | 'paymentMethod'");
    expect(receiptsPage).toContain("toggleReceiptSort('date')");
    expect(receiptsPage).toContain("toggleReceiptSort('bank')");
    expect(receiptsPage).toContain("toggleReceiptSort('paymentMethod')");
    expect(receiptsPage).toContain("localeCompare(String(rightValue), 'ar-SA'");
    expect(receiptsPage).toContain('aria-sort={receiptSortKey === \'date\'');
  });

  it('يعرض البيان ويحجم جميع الأعمدة مع حفظ التفضيل ويقدم اختصارات السند المطلوبة وفق المرفق والحالة والصلاحية', () => {
    expect(receiptsPage).toContain("labelFor('receipts_table_invoices', 'البيان')");
    expect(receiptsPage).toContain('const receiptColumnDefaults');
    expect(receiptsPage).toContain('const [receiptColumnWidths, setReceiptColumnWidths]');
    expect(receiptsPage).toContain('const startReceiptColumnResize');
    expect(receiptsPage).toContain('const resizeHandle');
    expect(receiptsPage).toContain('receipts-column-widths-${user?.id || \'anonymous\'}');
    expect(receiptsPage).toContain("resizeHandle('serial', 'الرقم')");
    expect(receiptsPage).toContain("resizeHandle('actions', 'الإجراءات')");
    expect(receiptsPage).toContain('window.localStorage.setItem(receiptColumnStorageKey');
    expect(receiptsPage).not.toContain('setAmountColumnWidth');
    expect(receiptsPage).toContain("setView('list'); setFiltersExpanded(true);");
    expect(receiptsPage).toContain('aria-label={`اسحب لتغيير عرض عمود ${label}`}');
    expect(receiptsPage).toContain("event.key === 'ArrowLeft'");
    expect(receiptsPage).toContain("event.key === 'ArrowRight'");
    expect(receiptsPage).toContain('معاينة الإيصال');
    expect(receiptsPage).toContain('تحميل السند');
    expect(receiptsPage).toContain('تحميل السند مع الإيصال');
    expect(receiptsPage).toContain('اعتماد السند');
    expect(receiptsPage).toContain('رفض السند');
    expect(receiptsPage).toContain('تعديل السند');
    expect(receiptsPage).toContain('سجل الطباعة');
    expect(receiptsPage).toContain('setAttachmentPreviewReceipt(r)');
    expect(receiptsPage).toContain('downloadReceiptDocument(r)');
    expect(receiptsPage).toContain('downloadReceiptAndAttachment(r)');
    expect(receiptsPage).toContain("canApprove && r.status === 'issued'");
    expect(receiptsPage).toContain('openReceiptDecision(r, \'approved\')');
    expect(receiptsPage).toContain('openReceiptDecision(r, \'rejected\')');
    expect(receiptsPage).toContain('h-6 border-emerald-300 px-1.5 text-[9px] text-emerald-700');
    expect(receiptsPage).toContain('h-6 border-rose-300 px-1.5 text-[9px] text-rose-700');
    expect(receiptsPage).toContain('text-sm font-extrabold leading-5 tabular-nums text-foreground');
    expect(receiptsPage).toContain('flex min-w-max flex-nowrap justify-center gap-1 overflow-x-auto');
    expect(receiptsPage).not.toContain("labelFor('receipts_table_attachment'");
    expect(receiptsPage).toContain('handleEditReceipt(r)');
    expect(receiptsPage).toContain('setPrintAuditReceiptId(r.id)');
  });
});
