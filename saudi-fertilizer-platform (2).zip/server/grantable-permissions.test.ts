import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getCustomerByNumber: vi.fn(),
  createCustomer: vi.fn(),
  createBranchTarget: vi.fn(),
}));

import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function managementContext(permissions: Record<string, boolean> = {}): TrpcContext {
  return {
    user: null,
    systemUser: {
      id: 71,
      username: "operations-user",
      fullName: "مستخدم العمليات",
      userType: "accountant",
      userLevel: "primary",
      branchId: 3,
      permissions,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

describe("الصلاحيات القابلة للمنح للعملاء والأهداف", () => {
  beforeEach(() => vi.resetAllMocks());

  it("يرفض إنشاء عميل عندما لا توجد صلاحية إدارة العملاء", async () => {
    const caller = appRouter.createCaller(managementContext());

    await expect(caller.customers.create({ customerNumber: "C-100", name: "عميل اختبار" }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("يسمح لصاحب صلاحية إدارة العملاء بإنشاء العميل مع تتبع منفذ العملية", async () => {
    vi.mocked(db.getCustomerByNumber).mockResolvedValue(null);
    vi.mocked(db.createCustomer).mockResolvedValue({ id: 101 } as never);
    const caller = appRouter.createCaller(managementContext({ customersManage: true }));

    await caller.customers.create({ customerNumber: "C-100", name: "عميل اختبار", branchId: 3 });

    expect(db.createCustomer).toHaveBeenCalledWith(expect.objectContaining({
      customerNumber: "C-100",
      name: "عميل اختبار",
      createdBy: 71,
      updatedBy: 71,
    }));
  });

  it("يرفض إنشاء مستهدف عند غياب صلاحية إدارة الأهداف", async () => {
    const caller = appRouter.createCaller(managementContext({ customersManage: true }));

    await expect(caller.targets.create({ branchId: 3, periodId: 1, targetType: "collections", targetValue: "50000" }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("يسمح لصاحب صلاحية إدارة الأهداف بإنشاء مستهدف", async () => {
    vi.mocked(db.createBranchTarget).mockResolvedValue({ id: 201 } as never);
    const caller = appRouter.createCaller(managementContext({ targetsManage: true }));

    await caller.targets.create({ branchId: 3, periodId: 1, targetType: "collections", targetValue: "50000" });

    expect(db.createBranchTarget).toHaveBeenCalledWith({
      branchId: 3,
      periodId: 1,
      targetType: "collections",
      targetValue: "50000",
    });
  });
});
