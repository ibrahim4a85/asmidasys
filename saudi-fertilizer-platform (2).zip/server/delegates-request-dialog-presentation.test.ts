import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('delegates request dialog presentation', () => {
  it('keeps the request dialog RTL, visually grouped, responsive, and independent from approval decisions', () => {
    const source = readFileSync(new URL('../client/src/pages/DelegatesPage.tsx', import.meta.url), 'utf8');

    expect(source).toContain('border-2 border-primary/30 bg-gradient-to-b');
    expect(source).toContain('dir="rtl"');
    expect(source).toContain('max-h-[92dvh]');
    expect(source).toContain('rounded-xl border border-sky-200');
    expect(source).toContain('rounded-xl border border-violet-200');
    expect(source).toContain('rounded-xl border border-amber-300');
    expect(source).toContain('rounded-xl border border-emerald-200');
    expect(source).toContain('flex flex-col gap-2 border-t');
    expect(source).toContain("createDraftMutation.mutate({ documentTypeId: Number(documentTypeId), description: description || undefined })");
    expect(source).toContain('attachSelectedFile');
    expect(source).toContain("submitDraftMutation.mutate({ requestId: draft.id })");
  });
});
