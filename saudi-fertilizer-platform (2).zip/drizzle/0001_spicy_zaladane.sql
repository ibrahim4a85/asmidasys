CREATE TABLE `activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `approval_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`documentTypeId` int,
	`requestedBy` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`attachmentUrl` text,
	`status` enum('pending','sent','approved','rejected','postponed') NOT NULL DEFAULT 'pending',
	`delegateId` int,
	`approvalNote` text,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `approval_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `branch_targets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`branchId` int NOT NULL,
	`periodId` int NOT NULL,
	`targetType` enum('sales','collections','custom') NOT NULL,
	`targetName` varchar(255),
	`targetValue` decimal(15,2) NOT NULL,
	`currentValue` decimal(15,2) DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `branch_targets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `branches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`address` text,
	`regionId` int,
	`receiptSerial` varchar(20) NOT NULL,
	`paymentSerial` varchar(20),
	`currentReceiptNumber` int NOT NULL DEFAULT 0,
	`currentPaymentNumber` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `branches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `company_profile` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyName` varchar(255) NOT NULL,
	`address` text,
	`commercialRegister` varchar(50),
	`taxNumber` varchar(50),
	`logoUrl` text,
	`phone` varchar(20),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `company_profile_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerNumber` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`branchId` int,
	`delegateId` int,
	`phone` varchar(20),
	`email` varchar(320),
	`address` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_customerNumber_unique` UNIQUE(`customerNumber`)
);
--> statement-breakpoint
CREATE TABLE `delegates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`position` varchar(255),
	`username` varchar(64) NOT NULL,
	`password` varchar(255) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `delegates_id` PRIMARY KEY(`id`),
	CONSTRAINT `delegates_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `document_types` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `document_types_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `financial_periods` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`isActive` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `financial_periods_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `input_lists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`listType` enum('payment_method','bank','payment_for') NOT NULL,
	`name` varchar(255) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `input_lists_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `login_backgrounds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`imageUrl` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `login_backgrounds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `news_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`content` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`sortOrder` int DEFAULT 0,
	`speed` int DEFAULT 50,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `news_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serialNumber` varchar(50) NOT NULL,
	`branchId` int NOT NULL,
	`userId` int NOT NULL,
	`beneficiary` varchar(255) NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`amountInWords` text,
	`expenseCategory` varchar(255),
	`paymentMethodId` int,
	`bankId` int,
	`description` text,
	`attachmentUrl` text,
	`status` enum('draft','approved','rejected') NOT NULL DEFAULT 'draft',
	`notes` text,
	`periodId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipt_invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`receiptId` int NOT NULL,
	`invoiceNumber` varchar(50) NOT NULL,
	`invoiceAmount` decimal(15,2) NOT NULL,
	CONSTRAINT `receipt_invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serialNumber` varchar(50) NOT NULL,
	`branchId` int NOT NULL,
	`userId` int NOT NULL,
	`customerId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`amountInWords` text,
	`paymentMethodId` int,
	`bankId` int,
	`paymentForId` int,
	`attachmentUrl` text,
	`qrCode` text,
	`status` enum('draft','approved','rejected') NOT NULL DEFAULT 'draft',
	`notes` text,
	`periodId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receipts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `regions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `regions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `system_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`settingKey` varchar(100) NOT NULL,
	`settingValue` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `system_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `system_settings_settingKey_unique` UNIQUE(`settingKey`)
);
--> statement-breakpoint
CREATE TABLE `system_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(64) NOT NULL,
	`password` varchar(255) NOT NULL,
	`fullName` varchar(255) NOT NULL,
	`userType` enum('admin','accountant','delegate','branch_supervisor') NOT NULL DEFAULT 'delegate',
	`userLevel` enum('primary','secondary') NOT NULL DEFAULT 'secondary',
	`branchId` int,
	`isActive` boolean NOT NULL DEFAULT true,
	`permissions` json,
	`phone` varchar(20),
	`email` varchar(320),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp,
	CONSTRAINT `system_users_id` PRIMARY KEY(`id`),
	CONSTRAINT `system_users_username_unique` UNIQUE(`username`)
);
