import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

describe("إصدار ملفات واجهة الإنتاج", () => {
  it("يضع أصول الإنتاج في مسار إصدار مستقل لتفادي إعادة استخدام حزمة مخزنة قديمة", () => {
    const configPath = path.resolve(import.meta.dirname, "..", "vite.config.ts");
    const config = fs.readFileSync(configPath, "utf8");

    expect(config).toContain('assetsDir: "assets-r20260901-1"');
  });
});
