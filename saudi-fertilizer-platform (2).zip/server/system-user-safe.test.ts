import { describe, expect, it } from 'vitest';
import { toSafeSystemUser } from '../shared/systemUserSafe';

describe('إخفاء البيانات الحساسة للمستخدم النظامي', () => {
  it('يحذف كلمة المرور من أي سجل يعاد إلى واجهة الإدارة مع إبقاء الحقول الآمنة', () => {
    const safeUser = toSafeSystemUser({ id: 4, username: 'partner', fullName: 'شريك مفوض', password: 'secret-value', userType: 'authorized_partner' });
    expect(safeUser).toEqual({ id: 4, username: 'partner', fullName: 'شريك مفوض', userType: 'authorized_partner' });
    expect('password' in safeUser).toBe(false);
  });
});
