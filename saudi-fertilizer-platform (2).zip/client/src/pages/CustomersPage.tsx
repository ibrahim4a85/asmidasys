import { useMemo, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowDown, ArrowDownUp, ArrowUp, Plus, Pencil, Trash2, Upload, Search, FileSpreadsheet, FileText } from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { sortCustomerRows, type CustomerSortDirection, type CustomerSortKey } from '@/lib/customerTableSorting';
import { buildCustomerExportRows, selectCustomersForExport } from '../lib/customerExport';
import { DeleteConfirmationDialog } from '@/components/DeleteConfirmationDialog';
import { useSystemLabels } from '@/hooks/useSystemLabels';

function escapeCustomerExportHtml(value: unknown) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export default function CustomersPage() {
  const { isAdmin, user } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const canManageCustomers = isAdmin || user?.permissions?.customersManage === true;
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [editCustomer, setEditCustomer] = useState<any>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const [sortKey, setSortKey] = useState<CustomerSortKey>('customerNumber');
  const [sortDirection, setSortDirection] = useState<CustomerSortDirection>('asc');
  const [deleteTarget, setDeleteTarget] = useState<any>(null);
  const [form, setForm] = useState({ customerNumber: '', name: '', branchId: null as number | null, delegateId: null as number | null, phone: '' });

  const { data: customers, refetch } = trpc.customers.list.useQuery({ search });
  const { data: branches } = trpc.branches.list.useQuery();
  const { data: systemUsers } = trpc.systemUsers.list.useQuery();
  const createMutation = trpc.customers.create.useMutation({ onSuccess: () => { refetch(); setOpen(false); resetForm(); toast.success('تم إضافة العميل'); } });
  const updateMutation = trpc.customers.update.useMutation({ onSuccess: () => { refetch(); setOpen(false); resetForm(); toast.success('تم تحديث العميل'); } });
  const deleteMutation = trpc.customers.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف العميل'); } });
  const deleteManyMutation = trpc.customers.deleteMany.useMutation({ onSuccess: () => { refetch(); setSelected([]); toast.success('تم حذف العملاء المحددين'); } });

  const resetForm = () => { setForm({ customerNumber: '', name: '', branchId: null, delegateId: null, phone: '' }); setEditCustomer(null); };
  const delegates = systemUsers?.filter(u => u.userType === 'delegate') || [];
  const sortedCustomers = useMemo(
    () => sortCustomerRows(customers || [], sortKey, sortDirection, branches || [], delegates),
    [branches, customers, delegates, sortDirection, sortKey],
  );

  const toggleSort = (key: CustomerSortKey) => {
    if (sortKey === key) {
      setSortDirection((current) => current === 'asc' ? 'desc' : 'asc');
      return;
    }
    setSortKey(key);
    setSortDirection('asc');
  };

  const SortableHeader = ({ label, column }: { label: string; column: CustomerSortKey }) => {
    const isActive = sortKey === column;
    const Icon = isActive ? (sortDirection === 'asc' ? ArrowUp : ArrowDown) : ArrowDownUp;
    return (
      <TableHead className="p-0">
        <button
          type="button"
          onClick={() => toggleSort(column)}
          className={`flex w-full items-center justify-between gap-2 px-3 py-3 text-right font-medium transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${isActive ? 'text-primary' : ''}`}
          aria-label={`فرز حسب ${label}${isActive ? (sortDirection === 'asc' ? ' تصاعدياً' : ' تنازلياً') : ''}`}
        >
          <span>{label}</span>
          <Icon className={`h-3.5 w-3.5 flex-none ${isActive ? 'opacity-100' : 'opacity-45'}`} aria-hidden="true" />
        </button>
      </TableHead>
    );
  };

  const handleSubmit = () => {
    if (!form.customerNumber || !form.name) { toast.error('يرجى ملء الحقول المطلوبة'); return; }
    // Prevent duplicate customer number
    const duplicate = customers?.find(c => c.customerNumber === form.customerNumber && c.id !== editCustomer?.id);
    if (duplicate) { toast.error('رقم العميل مستخدم بالفعل، يرجى اختيار رقم آخر'); return; }
    if (editCustomer) {
      updateMutation.mutate({ id: editCustomer.id, data: form });
    } else {
      createMutation.mutate(form as any);
    }
  };

  const handleEdit = (c: any) => {
    setEditCustomer(c);
    setForm({ customerNumber: c.customerNumber, name: c.name, branchId: c.branchId, delegateId: c.delegateId, phone: c.phone || '' });
    setOpen(true);
  };

  const exportCustomers = (format: 'xlsx' | 'pdf') => {
    const rows = buildCustomerExportRows(
      selectCustomersForExport(sortedCustomers, selected) as any,
      branches || [],
      delegates,
    );
    if (!rows.length) { toast.error(labelFor('customers_export_empty_message', 'لا توجد بيانات قابلة للتصدير')); return; }
    const scope = selected.length > 0 ? `المحدد-${selected.length}` : 'كل-العملاء';
    if (format === 'xlsx') {
      const worksheet = XLSX.utils.json_to_sheet(rows);
      worksheet['!rtl'] = true;
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'العملاء');
      XLSX.writeFile(workbook, `العملاء-${scope}.xlsx`);
      return;
    }
    const rowsHtml = rows.map(row => `<tr>${Object.values(row).map(value => `<td>${String(value || '-')}</td>`).join('')}</tr>`).join('');
    const exportTitle = escapeCustomerExportHtml(labelFor('customers_export_print_title'));
    const exportScope = selected.length > 0
      ? `${escapeCustomerExportHtml(labelFor('customers_export_print_selected_scope'))} (${selected.length})`
      : escapeCustomerExportHtml(labelFor('customers_export_print_all_scope'));
    const printWindow = window.open('', '_blank', 'noopener,noreferrer');
    if (!printWindow) { toast.error('تعذر فتح نافذة التصدير'); return; }
    printWindow.document.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"/><title>${exportTitle}</title><style>body{font-family:Arial,sans-serif;padding:28px;direction:rtl}h1{color:#0f766e;font-size:20px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #cbd5e1;padding:8px;text-align:right}th{background:#ecfdf5}@media print{body{padding:0}}</style></head><body><h1>${exportTitle} — ${exportScope}</h1><table><thead><tr>${Object.keys(rows[0]).map(header => `<th>${header}</th>`).join('')}</tr></thead><tbody>${rowsHtml}</tbody></table><script>window.onload=()=>window.print()</script></body></html>`);
    printWindow.document.close();
  };

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">{labelFor('nav_customers', 'إدارة العملاء')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{labelFor('customers_page_subtitle', 'إضافة وإدارة بيانات العملاء')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {canManageCustomers && selected.length > 0 && (
            <Button variant="destructive" onClick={() => setDeleteTarget({ type: 'many', count: selected.length })}>
              <Trash2 className="h-4 w-4 ml-1" />حذف المحدد ({selected.length})
            </Button>
          )}
          {canManageCustomers && <>
            <Button variant="outline" onClick={() => exportCustomers('xlsx')}><FileSpreadsheet className="h-4 w-4 ml-2" />Excel {selected.length > 0 ? `(${selected.length})` : 'الكل'}</Button>
            <Button variant="outline" onClick={() => exportCustomers('pdf')}><FileText className="h-4 w-4 ml-2" />PDF {selected.length > 0 ? `(${selected.length})` : 'الكل'}</Button>
          </>}
          <Dialog open={open} onOpenChange={v => { setOpen(v); if (!v) resetForm(); }}>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-2" />{labelFor('customers_add', 'إضافة عميل')}</Button></DialogTrigger>
            <DialogContent className="max-w-[calc(100%-1rem)] sm:max-w-lg">
              <DialogHeader><DialogTitle>{editCustomer ? labelFor('customers_edit', 'تعديل عميل') : labelFor('customers_add_new', 'إضافة عميل جديد')}</DialogTitle></DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2"><Label>{labelFor('field_customer_number', 'رقم العميل')} *</Label><Input value={form.customerNumber} onChange={e => setForm({ ...form, customerNumber: e.target.value })} /></div>
                  <div className="space-y-2"><Label>{labelFor('field_name', 'الاسم')} *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>{labelFor('field_branch', 'الفرع')}</Label>
                    <Select value={form.branchId?.toString() || ''} onValueChange={v => setForm({ ...form, branchId: v ? parseInt(v) : null })}>
                      <SelectTrigger><SelectValue placeholder={labelFor('action_select', 'اختر')} /></SelectTrigger>
                      <SelectContent>{branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>{labelFor('field_delegate', 'المندوب')}</Label>
                    <Select value={form.delegateId?.toString() || ''} onValueChange={v => setForm({ ...form, delegateId: v ? parseInt(v) : null })}>
                      <SelectTrigger><SelectValue placeholder={labelFor('action_select', 'اختر')} /></SelectTrigger>
                      <SelectContent>{delegates.map(d => <SelectItem key={d.id} value={d.id.toString()}>{d.fullName}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2"><Label>{labelFor('field_phone', 'رقم الهاتف')}</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
                <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                  <Button className="w-full sm:w-auto" variant="outline" onClick={() => { setOpen(false); resetForm(); }}>{labelFor('customers_cancel', 'إلغاء')}</Button>
                  <Button className="w-full sm:w-auto" onClick={handleSubmit}>{editCustomer ? labelFor('action_update', 'تحديث') : labelFor('action_add', 'إضافة')}</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder={`${labelFor('field_search', 'بحث')} عن ${labelFor('field_customer', 'العملاء')}...`} value={search} onChange={e => setSearch(e.target.value)} className="pr-10" />
      </div>

      {/* Excel Upload */}
      {canManageCustomers && (
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:gap-4">
              <Upload className="h-5 w-5 text-muted-foreground" />
              <div className="flex-1">
                <p className="text-sm font-medium">{labelFor('customers_import_file_title', 'رفع ملف Excel للعملاء')}</p>
                <p className="text-xs text-muted-foreground">{labelFor('customers_import_file_description', 'يجب أن يحتوي الملف على أعمدة: رقم العميل، الاسم، الهاتف (اختياري) - يدعم xlsx, xls, csv')}</p>
              </div>
              <Input type="file" accept=".xlsx,.xls,.csv" className="w-full sm:w-60" id="excel-upload" onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                try {
                  const buffer = await file.arrayBuffer();
                  const workbook = XLSX.read(buffer, { type: 'array' });
                  const sheet = workbook.Sheets[workbook.SheetNames[0]];
                  const rows: any[] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
                  if (rows.length < 2) { toast.error('الملف فارغ أو لا يحتوي بيانات'); return; }
                  // Validate header
                  const header = rows[0].map((h: any) => String(h).trim().toLowerCase());
                  const numIdx = header.findIndex((h: string) => h.includes('رقم') || h.includes('number') || h.includes('num') || h === 'id');
                  const nameIdx = header.findIndex((h: string) => h.includes('اسم') || h.includes('name'));
                  const phoneIdx = header.findIndex((h: string) => h.includes('هاتف') || h.includes('phone') || h.includes('جوال'));
                  if (numIdx === -1 || nameIdx === -1) { toast.error('لم يتم العثور على أعمدة "رقم العميل" و"الاسم" في الملف'); return; }
                  let imported = 0;
                  let failed = 0;
                  for (let i = 1; i < rows.length; i++) {
                    const row = rows[i];
                    const customerNumber = String(row[numIdx] || '').trim();
                    const name = String(row[nameIdx] || '').trim();
                    const phone = phoneIdx >= 0 ? String(row[phoneIdx] || '').trim() : '';
                    if (customerNumber && name) {
                      try {
                        await createMutation.mutateAsync({ customerNumber, name, phone } as any);
                        imported++;
                      } catch { failed++; }
                    } else {
                      failed++;
                    }
                  }
                  toast.success(`تم استيراد ${imported} عميل بنجاح${failed > 0 ? ` (${failed} سجل فشل أو مكرر)` : ''}`);
                  refetch();
                } catch { toast.error('خطأ في قراءة الملف'); }
                e.target.value = '';
              }} />
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                {canManageCustomers && <TableHead className="w-10"><Checkbox checked={sortedCustomers.length > 0 && selected.length === sortedCustomers.length} onCheckedChange={v => setSelected(v ? sortedCustomers.map(c => c.id) : [])} /></TableHead>}
                <SortableHeader label={labelFor('field_customer_number', 'رقم العميل')} column="customerNumber" />
                <SortableHeader label={labelFor('field_name', 'الاسم')} column="name" />
                <SortableHeader label={labelFor('field_branch', 'الفرع')} column="branch" />
                <SortableHeader label={labelFor('field_delegate', 'المندوب')} column="delegate" />
                <SortableHeader label={labelFor('field_phone', 'رقم الهاتف')} column="phone" />
                <TableHead>{labelFor('field_actions', 'إجراءات')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedCustomers.map(c => (
                <TableRow key={c.id}>
                  {canManageCustomers && <TableCell><Checkbox checked={selected.includes(c.id)} onCheckedChange={v => setSelected(v ? [...selected, c.id] : selected.filter(id => id !== c.id))} /></TableCell>}
                  <TableCell className="font-mono">{c.customerNumber}</TableCell>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell>{branches?.find(b => b.id === c.branchId)?.name || '-'}</TableCell>
                  <TableCell>{delegates.find(d => d.id === c.delegateId)?.fullName || '-'}</TableCell>
                  <TableCell>{c.phone || '-'}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(c)}><Pencil className="h-4 w-4" /></Button>
                      {canManageCustomers && <Button variant="ghost" size="icon" className="text-destructive" onClick={() => setDeleteTarget({ type: 'one', customer: c })}><Trash2 className="h-4 w-4" /></Button>}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {(!customers || customers.length === 0) && (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">{labelFor('customers_empty', 'لا يوجد عملاء')}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <DeleteConfirmationDialog
        open={Boolean(deleteTarget)}
        onOpenChange={open => !open && setDeleteTarget(null)}
        title={deleteTarget?.type === 'many' ? 'تأكيد حذف العملاء المحددين' : 'تأكيد حذف العميل'}
        itemName={deleteTarget?.type === 'many' ? `${deleteTarget.count} عميل محدد` : deleteTarget?.customer?.name || ''}
        details={deleteTarget?.type === 'many'
          ? [`عدد السجلات: ${deleteTarget.count}`, 'سيُحذف كل العملاء المحددين وارتباطاتهم المسموح حذفها.']
          : [`رقم العميل: ${deleteTarget?.customer?.customerNumber || '-'}`, `الفرع: ${branches?.find(branch => branch.id === deleteTarget?.customer?.branchId)?.name || '-'}`, `المندوب: ${delegates.find(delegate => delegate.id === deleteTarget?.customer?.delegateId)?.fullName || '-'}`]}
        isPending={deleteMutation.isPending || deleteManyMutation.isPending}
        onConfirm={() => {
          if (deleteTarget?.type === 'many') deleteManyMutation.mutate({ ids: selected });
          else if (deleteTarget?.customer) deleteMutation.mutate({ id: deleteTarget.customer.id });
          setDeleteTarget(null);
        }}
      />
    </div>
  );
}
