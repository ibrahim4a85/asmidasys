import { useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import { getSystemLabel, type SystemLabelId } from '@shared/systemLabelPresentation';

/**
 * Returns the administrator-managed terminology with stable fallbacks.
 * Each consuming screen keeps a visible default while the settings query loads.
 */
export function useSystemLabels() {
  const { data: settings = {} } = trpc.settings.getAll.useQuery();
  const labelFor = useCallback(
    (id: SystemLabelId, fallback?: string) => getSystemLabel(settings, id, fallback),
    [settings],
  );

  return { settings, labelFor };
}
