import JSZip from "jszip";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";

function escapeXml(value: string) {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[character] || character);
}

export function getApprovalTemplateOutputName(approvalNumber: string, mimeType: string) {
  return `${approvalNumber}-form.${mimeType === "application/pdf" ? "pdf" : "docx"}`;
}

export async function stampApprovalTemplate(input: { file: Buffer; mimeType: string; approvalNumber: string }) {
  if (input.mimeType === "application/pdf") {
    const document = await PDFDocument.load(input.file);
    const font = await document.embedFont(StandardFonts.HelveticaBold);
    const firstPage = document.getPages()[0];
    firstPage.drawText(input.approvalNumber, {
      x: 22,
      y: firstPage.getHeight() - 28,
      size: 11,
      font,
      color: rgb(0.05, 0.16, 0.38),
    });
    return Buffer.from(await document.save());
  }

  if (input.mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
    const archive = await JSZip.loadAsync(input.file);
    const documentXml = await archive.file("word/document.xml")?.async("string");
    if (!documentXml) throw new Error("تعذر قراءة محتوى نموذج Word");
    const numberParagraph = `<w:p><w:pPr><w:jc w:val="left"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>${escapeXml(input.approvalNumber)}</w:t></w:r></w:p>`;
    archive.file("word/document.xml", documentXml.replace(/<w:body[^>]*>/, `$&${numberParagraph}`));
    return Buffer.from(await archive.generateAsync({ type: "nodebuffer" }));
  }

  throw new Error("صيغة نموذج التعميد غير مدعومة للختم التلقائي");
}

export type ApprovalFooterSignature = {
  name: string;
  actedAt: Date | string;
};

export type ApprovalFooterOptions = {
  enabled?: boolean;
  height?: number;
  fontSize?: number;
  color?: string;
  label?: string;
};

function parseFooterColor(value?: string) {
  const normalized = (value || "#0f5132").replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) return rgb(0.06, 0.32, 0.2);
  return rgb(
    Number.parseInt(normalized.slice(0, 2), 16) / 255,
    Number.parseInt(normalized.slice(2, 4), 16) / 255,
    Number.parseInt(normalized.slice(4, 6), 16) / 255,
  );
}

function signatureDate(value: Date | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "-" : date.toLocaleString("ar-SA", { dateStyle: "short", timeStyle: "short" });
}

/**
 * يختم ملف المرفق بخانات اعتماد ثابتة في تذييل الصفحة الأخيرة. لا يقبل سوى
 * الاعتمادات الناجحة التي حفظتها دورة التعميد، وتبقى الخانات الأربع جزءاً من
 * قالب ثابت قابل للضبط من الإعدادات بدلاً من إدخال محتوى تنفيذي حر.
 */
export async function stampApprovalDecisionFooter(input: {
  file: Buffer;
  mimeType: string;
  signatures: ApprovalFooterSignature[];
  options?: ApprovalFooterOptions;
}) {
  if (input.options?.enabled === false || !input.signatures.length) return input.file;
  const signatures = input.signatures.slice(0, 4);
  const label = input.options?.label?.trim() || "تم التعميد";
  const fontSize = Math.min(14, Math.max(7, Number(input.options?.fontSize || 8)));
  const footerHeight = Math.min(120, Math.max(48, Number(input.options?.height || 66)));

  if (input.mimeType === "application/pdf") {
    const document = await PDFDocument.load(input.file);
    const page = document.getPages().at(-1);
    if (!page) throw new Error("تعذر قراءة صفحات المرفق");
    const regular = await document.embedFont(StandardFonts.Helvetica);
    const bold = await document.embedFont(StandardFonts.HelveticaBold);
    const width = page.getWidth();
    const footerY = 0;
    const slotWidth = width / 4;
    page.drawRectangle({ x: 0, y: footerY, width, height: footerHeight, color: rgb(1, 1, 1), borderColor: parseFooterColor(input.options?.color), borderWidth: 0.6 });
    for (let index = 1; index < 4; index += 1) page.drawLine({ start: { x: slotWidth * index, y: footerY }, end: { x: slotWidth * index, y: footerY + footerHeight }, color: parseFooterColor(input.options?.color), thickness: 0.4 });
    signatures.forEach((signature, index) => {
      const center = (slotWidth * index) + (slotWidth / 2);
      const color = parseFooterColor(input.options?.color);
      const lines = [label, signature.name, signatureDate(signature.actedAt)];
      lines.forEach((line, lineIndex) => {
        const font = lineIndex === 0 ? bold : regular;
        const measured = font.widthOfTextAtSize(line, fontSize);
        page.drawText(line, { x: center - (measured / 2), y: footerY + footerHeight - 18 - (lineIndex * (fontSize + 5)), size: fontSize, font, color });
      });
    });
    return Buffer.from(await document.save());
  }

  if (input.mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
    const archive = await JSZip.loadAsync(input.file);
    const documentXml = await archive.file("word/document.xml")?.async("string");
    if (!documentXml) throw new Error("تعذر قراءة محتوى نموذج Word");
    const cells = Array.from({ length: 4 }, (_, index) => {
      const signature = signatures[index];
      const content = signature
        ? `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>${escapeXml(label)}</w:t></w:r></w:p><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>${escapeXml(signature.name)}</w:t></w:r></w:p><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>${escapeXml(signatureDate(signature.actedAt))}</w:t></w:r></w:p>`
        : `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t> </w:t></w:r></w:p>`;
      return `<w:tc><w:tcPr><w:tcW w:w="2250" w:type="dxa"/></w:tcPr>${content}</w:tc>`;
    }).join("");
    const footerTable = `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:jc w:val="center"/></w:tblPr><w:tblGrid><w:gridCol w:w="2250"/><w:gridCol w:w="2250"/><w:gridCol w:w="2250"/><w:gridCol w:w="2250"/></w:tblGrid><w:tr>${cells}</w:tr></w:tbl>`;
    archive.file("word/document.xml", documentXml.replace(/<w:sectPr[\s\S]*?<\/w:sectPr>/, `${footerTable}$&`));
    return Buffer.from(await archive.generateAsync({ type: "nodebuffer" }));
  }

  throw new Error("صيغة مرفق التعميد غير مدعومة لختم قرار التعميد");
}
