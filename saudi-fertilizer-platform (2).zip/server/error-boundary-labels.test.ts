import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

describe('error boundary terminology', () => {
  it('uses Arabic fallbacks and accepts administrator overrides for error-screen presentation', () => {
    expect(getSystemLabel({}, 'error_boundary_title')).toBe('تعذر تحميل هذه الصفحة');
    expect(getSystemLabel({}, 'error_boundary_reload')).toBe('إعادة تحميل الصفحة');

    const settings = {
      system_label_overrides: JSON.stringify({
        error_boundary_title: 'توقفت الصفحة مؤقتاً',
        error_boundary_reload: 'أعد المحاولة',
      }),
    };

    expect(getSystemLabel(settings, 'error_boundary_title')).toBe('توقفت الصفحة مؤقتاً');
    expect(getSystemLabel(settings, 'error_boundary_reload')).toBe('أعد المحاولة');
  });

  it('keeps a static outer boundary for provider failures and hides technical error details', () => {
    const appSource = readFileSync(new URL('../client/src/App.tsx', import.meta.url), 'utf8');
    const boundarySource = readFileSync(new URL('../client/src/components/ErrorBoundary.tsx', import.meta.url), 'utf8');

    expect(appSource).toContain('function ManagedErrorBoundary');
    expect(appSource).toContain("title={labelFor('error_boundary_title')}");
    expect(appSource).toContain("reloadLabel={labelFor('error_boundary_reload')}");
    expect(appSource).toMatch(/<ErrorBoundary>\s*<ThemeProvider/);
    expect(appSource).toMatch(/<AuthProvider>\s*<ManagedErrorBoundary>/);
    expect(boundarySource).toContain('window.location.reload()');
    expect(boundarySource).not.toContain('error?.stack');
    expect(boundarySource).not.toContain('<pre');
  });
});

