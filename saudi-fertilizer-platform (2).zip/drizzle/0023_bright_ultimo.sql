CREATE TABLE `partner_period_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`documentType` enum('distribution_minutes','year_end_settlement','financial_statements','custom') NOT NULL,
	`title` varchar(255) NOT NULL,
	`attachmentKey` text,
	`attachmentUrl` text NOT NULL,
	`attachmentName` varchar(255) NOT NULL,
	`attachmentMimeType` varchar(100) NOT NULL,
	`notes` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `partner_period_documents_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_period_document_sort_unique` UNIQUE(`periodId`,`sortOrder`)
);
--> statement-breakpoint
CREATE TABLE `partner_period_equity_lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`lineType` enum('opening_balance','capital','legal_reserve','retained_earnings','profit_distribution','net_income','actuarial_remeasurement','custom') NOT NULL,
	`label` varchar(255) NOT NULL,
	`capitalAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`legalReserveAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`retainedEarningsAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`notes` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `partner_period_equity_lines_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_period_equity_line_sort_unique` UNIQUE(`periodId`,`sortOrder`)
);
--> statement-breakpoint
CREATE TABLE `partner_period_memberships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`partnerId` int NOT NULL,
	`isIncluded` boolean NOT NULL DEFAULT true,
	`shareUnits` decimal(15,2),
	`nominalShareValue` decimal(15,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `partner_period_memberships_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_period_membership_unique` UNIQUE(`periodId`,`partnerId`)
);
--> statement-breakpoint
CREATE TABLE `partner_profit_distributions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`periodId` int NOT NULL,
	`partnerId` int NOT NULL,
	`distributionAmount` decimal(15,2) NOT NULL DEFAULT '0',
	`distributionDate` timestamp,
	`statement` text,
	`attachmentKey` text,
	`attachmentUrl` text,
	`attachmentName` varchar(255),
	`attachmentMimeType` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int NOT NULL,
	CONSTRAINT `partner_profit_distributions_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_profit_distribution_unique` UNIQUE(`periodId`,`partnerId`)
);
