import { useEffect, useMemo, useState, type DragEvent, type ReactNode } from 'react';
import { useSystemAuth } from '@/contexts/AuthContext';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, ArrowDown, ArrowLeft, ArrowUp, ArrowUpLeft, BarChart3, CalendarDays, CheckCircle2, CircleDollarSign, CreditCard, Eye, EyeOff, FilePlus2, FileText, GripVertical, Landmark, RotateCcw, Search, ShieldCheck, TrendingUp, UserRoundPlus, Users } from 'lucide-react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { summarizeBankCollections } from '@shared/bankCollections';
import { getBankCollectionDateRange, type BankCollectionDatePreset } from '../../../shared/bankCollectionPresets';
import { getSystemLabel } from '@shared/systemLabelPresentation';
import { orderDashboardShortcuts, parseDashboardShortcutIds } from '@shared/dashboardShortcutOrder';
import { DASHBOARD_SECTION_IDS, getDashboardPersonalSectionOrderKey, moveDashboardPersonalSection, parseDashboardPersonalSectionOrder } from '@shared/dashboardPersonalSectionOrder';
import { DASHBOARD_WIDGET_GROUPS, getDashboardPersonalWidgetLayoutKey, hideDashboardPersonalWidget, isDashboardPersonalWidgetHidden, moveDashboardPersonalWidget, parseDashboardPersonalWidgetLayout, resizeDashboardPersonalWidget, showDashboardPersonalWidget, type DashboardPersonalWidgetLayout, type DashboardWidgetGroup } from '@shared/dashboardPersonalWidgetLayout';
import { useLocation } from 'wouter';

const COLORS = ['#38bdf8', '#34d399', '#a78bfa', '#fbbf24', '#fb7185', '#22d3ee'];
const formatMoney = (value: number) => `${value.toLocaleString('ar-SA', { maximumFractionDigits: 0 })} ر.س`;
type BranchCollectionPreset = Exclude<BankCollectionDatePreset, 'financial_period'>;
type DashboardWidgetOrdering = {
  editMode: boolean;
  dragged: { group: DashboardWidgetGroup; id: string } | null;
  getOrder: (group: DashboardWidgetGroup, id: string) => number;
  getSpan: (group: DashboardWidgetGroup, id: string) => number;
  onDragStart: (event: DragEvent<HTMLElement>, group: DashboardWidgetGroup, id: string) => void;
  onDragOver: (event: DragEvent<HTMLElement>) => void;
  onDrop: (event: DragEvent<HTMLElement>, group: DashboardWidgetGroup, id: string) => void;
  onDragEnd: () => void;
  onMoveByStep: (group: DashboardWidgetGroup, id: string, direction: -1 | 1) => void;
  onResize: (group: DashboardWidgetGroup, id: string, delta: -1 | 1, maxSpan?: number) => void;
  isHidden: (group: DashboardWidgetGroup, id: string) => boolean;
  onHide: (group: DashboardWidgetGroup, id: string) => void;
  onShow: (group: DashboardWidgetGroup, id: string) => void;
};

type HiddenDashboardWidget = { group: DashboardWidgetGroup; id: string; label: string };

function getLocalDateKey(value: unknown) {
  const date = new Date(String(value || ''));
  if (Number.isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export default function Dashboard() {
  const { user } = useSystemAuth();
  const [, setLocation] = useLocation();
  const { data: receipts = [] } = trpc.receipts.list.useQuery({});
  const { data: payments = [] } = trpc.payments.list.useQuery({});
  const { data: customers = [] } = trpc.customers.list.useQuery({});
  const { data: branches = [] } = trpc.branches.list.useQuery();
  const { data: activePeriod } = trpc.periods.active.useQuery();
  const { data: periods = [] } = trpc.periods.list.useQuery();
  const { data: inputLists = [] } = trpc.inputLists.list.useQuery();
  const { data: settings = {} } = trpc.settings.getAll.useQuery();
  const [periodFilter, setPeriodFilter] = useState<string>('active');
  const [datePreset, setDatePreset] = useState<BankCollectionDatePreset>('today');
  const [bankFilter, setBankFilter] = useState<string>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [branchCollectionPreset, setBranchCollectionPreset] = useState<BranchCollectionPreset>('today');
  const [branchCollectionStartDate, setBranchCollectionStartDate] = useState('');
  const [branchCollectionEndDate, setBranchCollectionEndDate] = useState('');
  const [isSectionOrdering, setIsSectionOrdering] = useState(false);
  const [personalSectionOrder, setPersonalSectionOrder] = useState<string[] | null>(null);
  const [draggedSectionId, setDraggedSectionId] = useState<string | null>(null);
  const [personalWidgetLayout, setPersonalWidgetLayout] = useState<DashboardPersonalWidgetLayout | null>(null);
  const [draggedWidget, setDraggedWidget] = useState<{ group: DashboardWidgetGroup; id: string } | null>(null);

  const dateRange = useMemo(() => getBankCollectionDateRange(datePreset, startDate, endDate), [datePreset, endDate, startDate]);
  const bankCollectionInput = useMemo(() => ({
    periodId: datePreset === 'financial_period' ? (periodFilter === 'active' ? activePeriod?.id : periodFilter === 'all' ? undefined : Number(periodFilter)) : undefined,
    bankId: bankFilter === 'all' ? undefined : Number(bankFilter),
    startDate: dateRange.startDate,
    endDate: dateRange.endDate,
  }), [activePeriod?.id, bankFilter, datePreset, dateRange.endDate, dateRange.startDate, periodFilter]);
  const { data: bankCollections = [], isLoading: isBankCollectionsLoading } = trpc.reports.bankCollections.useQuery(bankCollectionInput);
  const bankSummary = useMemo(() => summarizeBankCollections(bankCollections), [bankCollections]);
  const branchCollectionRange = useMemo(() => getBankCollectionDateRange(branchCollectionPreset, branchCollectionStartDate, branchCollectionEndDate), [branchCollectionEndDate, branchCollectionPreset, branchCollectionStartDate]);

  const totalReceipts = useMemo(() => receipts.reduce((sum, receipt) => sum + parseFloat(receipt.amount || '0'), 0), [receipts]);
  const totalPayments = useMemo(() => payments.reduce((sum, payment) => sum + parseFloat(payment.amount || '0'), 0), [payments]);
  const issuedReceipts = receipts.filter(receipt => receipt.status === 'issued').length;
  const approvedReceipts = receipts.filter(receipt => receipt.status === 'approved').length;
  const labelFor = (id: Parameters<typeof getSystemLabel>[1], fallback: string) => getSystemLabel(settings, id, fallback);
  const dashboardTitle = settings.dashboard_title || `${labelFor('dashboard_welcome_prefix', 'مرحباً،')} ${user?.fullName || ''}`;
  const dashboardSubtitle = settings.dashboard_subtitle || (activePeriod ? `${labelFor('dashboard_active_financial_period', 'الفترة المالية النشطة')}: ${activePeriod.name}` : labelFor('dashboard_operations_subtitle', 'متابعة العمليات المالية والاعتمادات من مركز واحد'));

  const selectedShortcutIds = useMemo(() => {
    const fallback = ['receipts', 'approvals', 'performance', 'customers'];
    try { return parseDashboardShortcutIds(JSON.parse(settings.dashboard_shortcuts || JSON.stringify(fallback)), fallback); } catch { return fallback; }
  }, [settings.dashboard_shortcuts]);
  const dashboardSectionOrder = useMemo(() => {
    const fallback = ['summary', 'activity', 'records', 'bank'];
    try {
      const stored = JSON.parse(settings.dashboard_section_order || JSON.stringify(fallback));
      const valid = Array.isArray(stored) ? stored.filter((id): id is string => fallback.includes(id)) : [];
      return valid.length ? [...valid, ...fallback.filter(id => !valid.includes(id))] : fallback;
    } catch { return fallback; }
  }, [settings.dashboard_section_order]);
  useEffect(() => {
    if (!user?.id) {
      setPersonalSectionOrder(null);
      setPersonalWidgetLayout(null);
      return;
    }
    try {
      const storedOrder = window.localStorage.getItem(getDashboardPersonalSectionOrderKey(user.id));
      setPersonalSectionOrder(storedOrder ? parseDashboardPersonalSectionOrder(JSON.parse(storedOrder)) : null);
      const storedWidgetLayout = window.localStorage.getItem(getDashboardPersonalWidgetLayoutKey(user.id));
      setPersonalWidgetLayout(storedWidgetLayout ? parseDashboardPersonalWidgetLayout(JSON.parse(storedWidgetLayout)) : null);
    } catch {
      setPersonalSectionOrder(null);
      setPersonalWidgetLayout(null);
    }
  }, [user?.id]);

  const effectiveDashboardSectionOrder = personalSectionOrder || dashboardSectionOrder;
  const sectionOrder = (id: string) => Math.max(0, effectiveDashboardSectionOrder.indexOf(id));
  const savePersonalSectionOrder = (nextOrder: readonly string[]) => {
    if (!user?.id) return;
    const normalizedOrder = parseDashboardPersonalSectionOrder(nextOrder);
    setPersonalSectionOrder(normalizedOrder);
    try {
      window.localStorage.setItem(getDashboardPersonalSectionOrderKey(user.id), JSON.stringify(normalizedOrder));
    } catch {
      // يظل الترتيب فعالاً في الجلسة الحالية إذا لم يتوفر تخزين المتصفح.
    }
  };
  const movePersonalSection = (sourceId: string, targetId: string) => {
    savePersonalSectionOrder(moveDashboardPersonalSection(effectiveDashboardSectionOrder, sourceId, targetId));
  };
  const movePersonalSectionByStep = (sourceId: string, direction: -1 | 1) => {
    const currentIndex = effectiveDashboardSectionOrder.indexOf(sourceId);
    const targetId = effectiveDashboardSectionOrder[currentIndex + direction];
    if (targetId) movePersonalSection(sourceId, targetId);
  };
  const resetPersonalSectionOrder = () => {
    if (user?.id) {
      try {
        window.localStorage.removeItem(getDashboardPersonalSectionOrderKey(user.id));
        window.localStorage.removeItem(getDashboardPersonalWidgetLayoutKey(user.id));
      } catch { /* لا يمنع إعادة الضبط داخل الجلسة. */ }
    }
    setPersonalSectionOrder(null);
    setPersonalWidgetLayout(null);
    setDraggedSectionId(null);
    setDraggedWidget(null);
  };
  const effectiveWidgetLayout = personalWidgetLayout || parseDashboardPersonalWidgetLayout(null);
  const savePersonalWidgetLayout = (nextLayout: DashboardPersonalWidgetLayout) => {
    if (!user?.id) return;
    setPersonalWidgetLayout(nextLayout);
    try { window.localStorage.setItem(getDashboardPersonalWidgetLayoutKey(user.id), JSON.stringify(nextLayout)); } catch { /* تبقى التفضيلات نشطة في الجلسة. */ }
  };
  const dashboardWidgetLabels: Record<DashboardWidgetGroup, Record<string, string>> = {
    summary: {
      receipts_total: labelFor('dashboard_total_receipts', 'إجمالي المقبوضات'),
      payments_total: labelFor('dashboard_expenses', 'المصروفات'),
      pending_receipts: labelFor('dashboard_pending_receipts', 'سندات بانتظار الاعتماد'),
      approved_receipts: labelFor('dashboard_approved_receipts', 'السندات المعتمدة'),
    },
    activity: {
      collections_trend: labelFor('dashboard_collections_trend', 'اتجاه المتحصلات'),
      quick_actions: labelFor('dashboard_shortcuts', 'إجراءات سريعة'),
    },
    records: {
      recent_receipts: labelFor('dashboard_recent_receipts', 'آخر سندات القبض'),
      top_branches: labelFor('dashboard_top_branches', 'الفروع الأعلى تحصيلاً'),
    },
    bank: { bank_collections: labelFor('dashboard_bank_collections', 'المتحصلات البنكية') },
  };
  const hiddenDashboardWidgets: HiddenDashboardWidget[] = (Object.entries(DASHBOARD_WIDGET_GROUPS) as Array<[DashboardWidgetGroup, readonly string[]]>).flatMap(([group, ids]) =>
    ids.filter(id => effectiveWidgetLayout[group].hidden.includes(id)).map(id => ({ group, id, label: dashboardWidgetLabels[group][id] || id })),
  );
  const widgetOrdering: DashboardWidgetOrdering = {
    editMode: isSectionOrdering,
    dragged: draggedWidget,
    getOrder: (group, id) => Math.max(0, effectiveWidgetLayout[group].order.indexOf(id)),
    getSpan: (group, id) => effectiveWidgetLayout[group].spans[id] || 1,
    onDragStart: (event, group, id) => {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('application/x-dashboard-widget', JSON.stringify({ group, id }));
      setDraggedWidget({ group, id });
    },
    onDragOver: event => event.preventDefault(),
    onDrop: (event, targetGroup, targetId) => {
      event.preventDefault();
      try {
        const raw = event.dataTransfer.getData('application/x-dashboard-widget');
        const source = raw ? JSON.parse(raw) as { group?: DashboardWidgetGroup; id?: string } : draggedWidget;
        if (source?.group === targetGroup && source.id) savePersonalWidgetLayout(moveDashboardPersonalWidget(effectiveWidgetLayout, targetGroup, source.id, targetId));
      } finally {
        setDraggedWidget(null);
      }
    },
    onDragEnd: () => setDraggedWidget(null),
    onMoveByStep: (group, id, direction) => {
      const order = effectiveWidgetLayout[group].order;
      const targetId = order[order.indexOf(id) + direction];
      if (targetId) savePersonalWidgetLayout(moveDashboardPersonalWidget(effectiveWidgetLayout, group, id, targetId));
    },
    onResize: (group, id, delta, maxSpan) => savePersonalWidgetLayout(resizeDashboardPersonalWidget(effectiveWidgetLayout, group, id, delta, maxSpan)),
    isHidden: (group, id) => isDashboardPersonalWidgetHidden(effectiveWidgetLayout, group, id),
    onHide: (group, id) => savePersonalWidgetLayout(hideDashboardPersonalWidget(effectiveWidgetLayout, group, id)),
    onShow: (group, id) => savePersonalWidgetLayout(showDashboardPersonalWidget(effectiveWidgetLayout, group, id)),
  };
  const sectionOrdering: DashboardSectionOrdering = {
    editMode: isSectionOrdering,
    draggedId: draggedSectionId,
    onDragStart: (event, id) => {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', id);
      setDraggedSectionId(id);
    },
    onDragOver: (event) => event.preventDefault(),
    onDrop: (event, targetId) => {
      event.preventDefault();
      const sourceId = event.dataTransfer.getData('text/plain') || draggedSectionId;
      if (sourceId) movePersonalSection(sourceId, targetId);
      setDraggedSectionId(null);
    },
    onDragEnd: () => setDraggedSectionId(null),
    onMoveByStep: movePersonalSectionByStep,
  };
  const shortcutDefinitions = [
    { id: 'receipts', title: labelFor('nav_receipts', 'إصدار سند قبض'), icon: FilePlus2, path: '/receipts', tone: 'bg-sky-500/15 text-sky-300 border-sky-400/20' },
    { id: 'approvals', title: labelFor('nav_delegates', 'طلبات التعميد'), icon: ShieldCheck, path: '/delegates', tone: 'bg-violet-500/15 text-violet-300 border-violet-400/20' },
    { id: 'performance', title: labelFor('nav_performance_reports', 'تقارير الأداء'), icon: BarChart3, path: '/performance-reports', tone: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/20' },
    { id: 'customers', title: labelFor('nav_customers', 'إدارة العملاء'), icon: UserRoundPlus, path: '/customers', tone: 'bg-amber-500/15 text-amber-300 border-amber-400/20' },
  ];
  const shortcuts = orderDashboardShortcuts(shortcutDefinitions, selectedShortcutIds);

  const branchCollectionReceipts = useMemo(() => receipts.filter(receipt => {
    const receiptDate = getLocalDateKey(receipt.createdAt);
    if (!receiptDate) return false;
    if (branchCollectionRange.startDate && receiptDate < branchCollectionRange.startDate) return false;
    if (branchCollectionRange.endDate && receiptDate > branchCollectionRange.endDate) return false;
    return true;
  }), [branchCollectionRange.endDate, branchCollectionRange.startDate, receipts]);
  const receiptsByBranch = useMemo(() => branches.map(branch => ({
    name: branch.name,
    value: branchCollectionReceipts.filter(receipt => receipt.branchId === branch.id).reduce((sum, receipt) => sum + parseFloat(receipt.amount || '0'), 0),
    count: branchCollectionReceipts.filter(receipt => receipt.branchId === branch.id).length,
  })).sort((left, right) => right.value - left.value), [branchCollectionReceipts, branches]);

  const weeklyTrend = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, index) => {
      const date = new Date();
      date.setHours(0, 0, 0, 0);
      date.setDate(date.getDate() - (6 - index));
      return date;
    });
    return days.map(date => {
      const key = date.toISOString().slice(0, 10);
      const amount = receipts.filter(receipt => String(receipt.createdAt || '').slice(0, 10) === key).reduce((sum, receipt) => sum + parseFloat(receipt.amount || '0'), 0);
      return { day: date.toLocaleDateString('ar-SA', { weekday: 'short' }), amount };
    });
  }, [receipts]);

  const customerById = useMemo(() => new Map(customers.map(customer => [customer.id, customer])), [customers]);
  const branchById = useMemo(() => new Map(branches.map(branch => [branch.id, branch])), [branches]);
  const latestReceipts = useMemo(() => [...receipts]
    .sort((left: any, right: any) => new Date(right.createdAt || 0).getTime() - new Date(left.createdAt || 0).getTime())
    .map(receipt => {
      const customer = customerById.get(receipt.customerId);
      const branch = branchById.get(receipt.branchId);
      return {
        ...receipt,
        branchName: branch?.name || '',
        customerNumber: customer?.customerNumber || '',
        customerName: customer?.name || '',
      };
    }), [branchById, customerById, receipts]);
  const stats = [
    { title: labelFor('dashboard_total_receipts', 'إجمالي المقبوضات'), value: formatMoney(totalReceipts), detail: `${receipts.length.toLocaleString('ar-SA')} ${labelFor('dashboard_receipts_count', 'سند قبض')}`, icon: CircleDollarSign, accent: 'from-sky-500 to-cyan-400' },
    { title: labelFor('dashboard_expenses', 'المصروفات'), value: formatMoney(totalPayments), detail: labelFor('dashboard_current_period', 'ضمن الفترة الحالية'), icon: CreditCard, accent: 'from-rose-500 to-pink-400' },
    { title: labelFor('dashboard_pending_receipts', 'سندات بانتظار الاعتماد'), value: issuedReceipts.toLocaleString('ar-SA'), detail: labelFor('dashboard_requires_decision', 'تحتاج قراراً إدارياً'), icon: ShieldCheck, accent: 'from-violet-500 to-fuchsia-400' },
    { title: labelFor('dashboard_approved_receipts', 'السندات المعتمدة'), value: approvedReceipts.toLocaleString('ar-SA'), detail: `${customers.length.toLocaleString('ar-SA')} ${labelFor('dashboard_registered_customers', 'عميل مسجل')}`, icon: CheckCircle2, accent: 'from-emerald-500 to-teal-400' },
  ];

  const isModernLayout = settings.interface_style === 'modern';
  if (!isModernLayout) {
    return <ClassicDashboard
      title={dashboardTitle}
      subtitle={dashboardSubtitle}
      dashboardSectionOrder={effectiveDashboardSectionOrder}
      sectionOrdering={sectionOrdering}
      widgetOrdering={widgetOrdering}
      isSectionOrdering={isSectionOrdering}
      onToggleSectionOrdering={() => setIsSectionOrdering(current => !current)}
      onResetSectionOrder={resetPersonalSectionOrder}
      stats={stats}
      shortcuts={shortcuts}
      weeklyTrend={weeklyTrend}
      latestReceipts={latestReceipts}
      receiptsByBranch={receiptsByBranch}
      branchCollectionPreset={branchCollectionPreset}
      setBranchCollectionPreset={setBranchCollectionPreset}
      branchCollectionStartDate={branchCollectionStartDate}
      setBranchCollectionStartDate={setBranchCollectionStartDate}
      branchCollectionEndDate={branchCollectionEndDate}
      setBranchCollectionEndDate={setBranchCollectionEndDate}
      dashboardLabel={labelFor('dashboard_title', 'لوحة المعلومات')}
      shortcutsLabel={labelFor('dashboard_shortcuts', 'اختصارات سريعة')}
      recentReceiptsLabel={labelFor('dashboard_recent_receipts', 'آخر سندات القبض')}
      topBranchesLabel={labelFor('dashboard_top_branches', 'الفروع الأعلى تحصيلاً')}
      hiddenWidgets={hiddenDashboardWidgets}
      labels={{
        todayDate: labelFor('dashboard_today_date', 'تاريخ اليوم'),
        collectionsTrend: labelFor('dashboard_collections_trend', 'اتجاه المتحصلات'),
        viewRecords: labelFor('dashboard_view_records', 'عرض السجل'),
        customerFallback: labelFor('dashboard_customer_fallback', 'عميل'),
        noReceipts: labelFor('dashboard_no_receipts', 'لا توجد سندات قبض مسجلة حتى الآن.'),
        branch: {
          description: labelFor('dashboard_branches_description', 'مرتب فورياً حسب قيمة سندات القبض ضمن الفترة المختارة'),
          period: labelFor('dashboard_collection_period', 'فترة التحصيل'),
          today: labelFor('dashboard_preset_today', 'اليوم'),
          yesterday: labelFor('dashboard_preset_yesterday', 'الأمس'),
          lastWeek: labelFor('dashboard_preset_last_week', 'أسبوع سابق'),
          custom: labelFor('dashboard_preset_custom', 'فترة مخصصة'),
          receiptCount: labelFor('dashboard_branch_receipt_count', 'سند'),
          noBranches: labelFor('dashboard_no_branches', 'لا توجد فروع مضافة بعد.'),
          noReceipts: labelFor('dashboard_no_branch_receipts', 'لا توجد سندات قبض في الفترة المختارة.'),
          fromDate: labelFor('dashboard_branch_from_date', 'من تاريخ تحصيل الفروع'),
          toDate: labelFor('dashboard_branch_to_date', 'إلى تاريخ تحصيل الفروع'),
        },
      }}
	      onNavigate={setLocation}
    />;
  }

  return (
    <div className="rtl-page flex flex-col gap-5 pb-8" dir="rtl">
      <section className="relative overflow-hidden rounded-[1.75rem] bg-[#0b1220] px-5 py-6 text-white shadow-2xl shadow-slate-950/15 sm:px-7 sm:py-8">
        <div className="absolute inset-0 opacity-80" style={{ backgroundImage: 'radial-gradient(circle at 14% 18%, rgba(56,189,248,.22), transparent 28%), radial-gradient(circle at 83% 105%, rgba(16,185,129,.24), transparent 32%)' }} />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-sky-200"><Activity className="h-3.5 w-3.5" />{labelFor('dashboard_operations_center', 'مركز العمليات المالية')}</div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{dashboardTitle}</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300">{dashboardSubtitle}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <DashboardSectionOrderControls active={isSectionOrdering} onToggle={() => setIsSectionOrdering(current => !current)} onReset={resetPersonalSectionOrder} />
            <div className="rounded-2xl border border-white/10 bg-white/[.06] px-4 py-3 text-right backdrop-blur"><p className="text-[11px] text-slate-400">{labelFor('dashboard_net_flow', 'صافي التدفق')}</p><p className="mt-1 font-bold text-emerald-300">{formatMoney(totalReceipts - totalPayments)}</p></div>
            <div className="rounded-2xl border border-white/10 bg-white/[.06] px-4 py-3 text-right backdrop-blur"><p className="text-[11px] text-slate-400">{labelFor('dashboard_today_date', 'تاريخ اليوم')}</p><p className="mt-1 text-sm font-bold text-slate-100">{new Date().toLocaleDateString('ar-SA', { day: 'numeric', month: 'short' })}</p></div>
          </div>
        </div>
        {isSectionOrdering && <p role="status" className="mt-4 text-xs font-medium text-sky-200">وضع تخصيص العناصر مفعّل: اسحب أي إطار لإعادة ترتيبه، واستخدم أزرار التكبير والتصغير أو الأسهم لتخصيص حجمه وموقعه.</p>}
      </section>

      <DashboardSectionContainer id="summary" order={sectionOrder('summary')} ordering={sectionOrdering} className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          const widgetId = ['receipts_total', 'payments_total', 'pending_receipts', 'approved_receipts'][index];
          return <DashboardWidgetFrame key={stat.title} group="summary" id={widgetId} ordering={widgetOrdering}><Card className="group h-full overflow-hidden border-border/70 bg-card shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg">
            <CardContent className="relative p-5">
              <div className={`absolute inset-y-0 right-0 w-1 bg-gradient-to-b ${stat.accent}`} />
              <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-semibold text-muted-foreground">{stat.title}</p><p className="mt-2 text-2xl font-bold tracking-tight text-card-foreground">{stat.value}</p><p className="mt-2 text-xs text-muted-foreground">{stat.detail}</p></div><div className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${stat.accent} text-white shadow-md`}><Icon className="h-5 w-5" /></div></div>
            </CardContent>
          </Card></DashboardWidgetFrame>;
        })}
      </DashboardSectionContainer>

      <DashboardSectionContainer id="activity" order={sectionOrder('activity')} ordering={sectionOrdering} className="grid grid-cols-1 gap-5 xl:grid-cols-4">
        <DashboardWidgetFrame group="activity" id="collections_trend" ordering={widgetOrdering}><Card className="h-full overflow-hidden border-border/70 shadow-sm">
          <CardHeader className="border-b bg-muted/25 px-5 py-4 sm:px-6"><div className="flex items-center justify-between"><div><CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="h-5 w-5 text-primary" />{labelFor('dashboard_collections_trend', 'اتجاه المتحصلات')}</CardTitle><p className="mt-1 text-xs text-muted-foreground">{labelFor('dashboard_collections_trend_description', 'قيمة سندات القبض المسجلة خلال آخر سبعة أيام')}</p></div><div className="rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary">{labelFor('dashboard_last_seven_days', 'آخر 7 أيام')}</div></div></CardHeader>
          <CardContent className="p-4 sm:p-6">
            <ResponsiveContainer width="100%" height={245}>
              <AreaChart data={weeklyTrend} margin={{ top: 10, right: 4, left: 0, bottom: 0 }}><defs><linearGradient id="dashboardTrendFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.35} /><stop offset="100%" stopColor="#0ea5e9" stopOpacity={0.01} /></linearGradient></defs><CartesianGrid vertical={false} strokeDasharray="3 3" stroke="currentColor" className="text-border" /><XAxis axisLine={false} tickLine={false} dataKey="day" fontSize={11} /><YAxis axisLine={false} tickLine={false} width={40} fontSize={10} tickFormatter={(value) => value >= 1000 ? `${Math.round(value / 1000)}k` : value} /><Tooltip formatter={(value: number) => formatMoney(value)} contentStyle={{ direction: 'rtl', borderRadius: 12, border: '1px solid hsl(var(--border))' }} /><Area type="monotone" dataKey="amount" stroke="#0ea5e9" strokeWidth={3} fill="url(#dashboardTrendFill)" /></AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card></DashboardWidgetFrame>

        <DashboardWidgetFrame group="activity" id="quick_actions" ordering={widgetOrdering}><Card className="h-full overflow-hidden border-0 bg-[#111c2e] text-slate-100 shadow-lg">
          <CardHeader className="border-b border-white/10 px-5 py-4"><CardTitle className="flex items-center gap-2 text-base text-white"><CalendarDays className="h-5 w-5 text-emerald-300" />{labelFor('dashboard_shortcuts', 'إجراءات سريعة')}</CardTitle><p className="mt-1 text-xs leading-5 text-slate-400">{labelFor('dashboard_shortcuts_description', 'الدخول المباشر إلى أكثر المهام استخداماً')}</p></CardHeader>
          <CardContent className="grid gap-2 p-3">
            {shortcuts.map(shortcut => { const Icon = shortcut.icon; return <button key={shortcut.id} onClick={() => setLocation(shortcut.path)} className="group flex items-center justify-between rounded-xl border border-white/5 bg-white/[.035] p-3 text-right transition hover:bg-white/[.08]"><span className="flex items-center gap-3"><span className={`flex h-9 w-9 items-center justify-center rounded-lg border ${shortcut.tone}`}><Icon className="h-4 w-4" /></span><span className="text-sm font-bold text-slate-100">{shortcut.title}</span></span><ArrowLeft className="h-4 w-4 text-slate-500 transition-transform group-hover:-translate-x-1 group-hover:text-slate-200" /></button>; })}
          </CardContent>
        </Card></DashboardWidgetFrame>
      </DashboardSectionContainer>

      <DashboardSectionContainer id="records" order={sectionOrder('records')} ordering={sectionOrdering} className="grid grid-cols-1 gap-5 xl:grid-cols-4">
        <DashboardWidgetFrame group="records" id="recent_receipts" ordering={widgetOrdering}>
          <RecentReceiptsCard
            receipts={latestReceipts}
            title={labelFor('dashboard_recent_receipts', 'آخر سندات القبض')}
            description={labelFor('dashboard_recent_receipts_description', 'أحدث العمليات المسجلة في النظام')}
            viewRecordsLabel={labelFor('dashboard_view_records', 'عرض السجل')}
            customerFallback={labelFor('dashboard_customer_fallback', 'عميل')}
            noReceiptsLabel={labelFor('dashboard_no_receipts', 'لا توجد سندات قبض مسجلة حتى الآن.')}
            noMatchesLabel="لا توجد سندات مطابقة لاسم العميل أو رقمه."
            onNavigate={setLocation}
            formatAmount={receipt => formatMoney(parseFloat(receipt.amount || '0'))}
            statusText={receipt => `${receipt.status === 'approved' ? labelFor('status_approved', 'معتمد') : receipt.status === 'issued' ? labelFor('dashboard_waiting_approval', 'بانتظار الاعتماد') : labelFor('status_draft', 'مسودة')} · ${new Date(receipt.createdAt || Date.now()).toLocaleDateString('ar-SA')}`}
            modern
          />
        </DashboardWidgetFrame>
        <DashboardWidgetFrame group="records" id="top_branches" ordering={widgetOrdering}><BranchCollectionsCard receiptsByBranch={receiptsByBranch} preset={branchCollectionPreset} setPreset={setBranchCollectionPreset} startDate={branchCollectionStartDate} setStartDate={setBranchCollectionStartDate} endDate={branchCollectionEndDate} setEndDate={setBranchCollectionEndDate} title={labelFor('dashboard_top_branches', 'الفروع الأعلى تحصيلاً')} labels={{ description: labelFor('dashboard_branches_description', 'مرتب فورياً حسب قيمة سندات القبض ضمن الفترة المختارة'), period: labelFor('dashboard_collection_period', 'فترة التحصيل'), today: labelFor('dashboard_preset_today', 'اليوم'), yesterday: labelFor('dashboard_preset_yesterday', 'الأمس'), lastWeek: labelFor('dashboard_preset_last_week', 'أسبوع سابق'), custom: labelFor('dashboard_preset_custom', 'فترة مخصصة'), receiptCount: labelFor('dashboard_branch_receipt_count', 'سند'), noBranches: labelFor('dashboard_no_branches', 'لا توجد فروع مضافة بعد.'), noReceipts: labelFor('dashboard_no_branch_receipts', 'لا توجد سندات قبض في الفترة المختارة.'), fromDate: labelFor('dashboard_branch_from_date', 'من تاريخ تحصيل الفروع'), toDate: labelFor('dashboard_branch_to_date', 'إلى تاريخ تحصيل الفروع') }} modern /></DashboardWidgetFrame>
      </DashboardSectionContainer>

      <DashboardSectionContainer id="bank" order={sectionOrder('bank')} ordering={sectionOrdering}>
        <DashboardWidgetFrame group="bank" id="bank_collections" ordering={widgetOrdering}>
        <Card className="border-border/70 shadow-sm"><CardHeader className="flex flex-col gap-4 border-b bg-muted/20 px-5 py-4 lg:flex-row lg:items-center lg:justify-between"><div><CardTitle className="flex items-center gap-2 text-base"><Landmark className="h-5 w-5 text-primary" />{labelFor('dashboard_bank_collections', 'المتحصلات البنكية')}</CardTitle><p className="mt-1 text-xs text-muted-foreground">{labelFor('dashboard_bank_collections_description', 'ملخص المعتمد حسب البنك والفترة المختارة')}</p></div><div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-3 lg:w-auto"><select aria-label={labelFor('dashboard_collection_period', 'فترة التحصيل')} value={datePreset} onChange={event => setDatePreset(event.target.value as BankCollectionDatePreset)} className="h-9 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option value="today">{labelFor('dashboard_preset_today', 'اليوم')}</option><option value="yesterday">{labelFor('dashboard_preset_yesterday', 'الأمس')}</option><option value="last_week">{labelFor('dashboard_last_seven_days', 'آخر أسبوع')}</option><option value="custom">{labelFor('dashboard_preset_custom', 'فترة مخصصة')}</option><option value="financial_period">{labelFor('field_period', 'فترة مالية')}</option></select>{datePreset === 'financial_period' ? <select aria-label={labelFor('field_period', 'الفترة المالية')} value={periodFilter} onChange={event => setPeriodFilter(event.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option value="active">{labelFor('report_all_periods', 'الفترة النشطة')}</option><option value="all">{labelFor('report_all_periods', 'كل الفترات')}</option>{periods.map(period => <option key={period.id} value={period.id}>{period.name}</option>)}</select> : datePreset === 'custom' ? <div className="flex gap-2"><input aria-label={labelFor('field_from_date', 'من تاريخ')} type="date" value={startDate} onChange={event => setStartDate(event.target.value)} className="h-9 w-full rounded-md border border-input bg-background px-2 text-xs" /><input aria-label={labelFor('field_to_date', 'إلى تاريخ')} type="date" value={endDate} onChange={event => setEndDate(event.target.value)} className="h-9 w-full rounded-md border border-input bg-background px-2 text-xs" /></div> : <div className="flex h-9 items-center rounded-md border border-dashed px-3 text-xs text-muted-foreground">{dateRange.startDate} إلى {dateRange.endDate}</div>}<select aria-label={labelFor('field_bank', 'البنك')} value={bankFilter} onChange={event => setBankFilter(event.target.value)} className="h-9 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option value="all">{labelFor('dashboard_all_banks', 'كل البنوك')}</option>{inputLists.filter(item => item.listType === 'bank' && item.isActive).map(bank => <option key={bank.id} value={bank.id}>{bank.name}</option>)}</select></div></CardHeader><CardContent className="p-5"><div className="mb-5 grid gap-3 sm:grid-cols-2"><div className="rounded-xl bg-emerald-50 p-4 text-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-200"><p className="text-xs font-semibold">{labelFor('dashboard_total_bank_collections', 'إجمالي المتحصلات البنكية')}</p><p className="mt-1 text-xl font-bold">{formatMoney(bankSummary.totalAmount)}</p></div><div className="rounded-xl bg-sky-50 p-4 text-sky-900 dark:bg-sky-950/30 dark:text-sky-200"><p className="text-xs font-semibold">{labelFor('dashboard_approved_receipts_count', 'عدد السندات المعتمدة')}</p><p className="mt-1 text-xl font-bold">{bankSummary.totalReceipts.toLocaleString('ar-SA')}</p></div></div>{isBankCollectionsLoading ? <div className="h-52 animate-pulse rounded-xl bg-muted" /> : bankSummary.daily.length ? <ResponsiveContainer width="100%" height={235}><BarChart data={bankSummary.daily} margin={{ top: 6, right: 0, left: 0, bottom: 0 }}><CartesianGrid vertical={false} strokeDasharray="3 3" className="text-border" /><XAxis dataKey="day" fontSize={11} tickFormatter={value => new Date(`${value}T00:00:00`).toLocaleDateString('ar-SA', { month: 'numeric', day: 'numeric' })} /><YAxis fontSize={11} /><Tooltip formatter={(value: number) => formatMoney(value)} />{bankSummary.banks.map((bank, index) => <Bar key={bank} dataKey={bank} stackId="banks" fill={COLORS[index % COLORS.length]} radius={index === bankSummary.banks.length - 1 ? [5, 5, 0, 0] : 0} />)}</BarChart></ResponsiveContainer> : <div className="flex h-44 flex-col items-center justify-center gap-2 rounded-xl border border-dashed text-center text-muted-foreground"><Landmark className="h-7 w-7 opacity-50" /><p className="text-sm">{labelFor('dashboard_no_bank_collections', 'لا توجد متحصلات بنكية ضمن التصفية المختارة.')}</p></div>}</CardContent></Card>
        </DashboardWidgetFrame>
      </DashboardSectionContainer>
      <HiddenDashboardWidgetsRail widgets={hiddenDashboardWidgets} onShow={widgetOrdering.onShow} />
    </div>
  );
}

function BranchCollectionsCard({
  receiptsByBranch,
  preset,
  setPreset,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  title,
  labels,
  modern = false,
}: {
  receiptsByBranch: Array<{ name: string; value: number; count: number }>;
  preset: BranchCollectionPreset;
  setPreset: (value: BranchCollectionPreset) => void;
  startDate: string;
  setStartDate: (value: string) => void;
  endDate: string;
  setEndDate: (value: string) => void;
  title: string;
  labels: { description: string; period: string; today: string; yesterday: string; lastWeek: string; custom: string; receiptCount: string; noBranches: string; noReceipts: string; fromDate: string; toDate: string };
  modern?: boolean;
}) {
  const range = getBankCollectionDateRange(preset, startDate, endDate);
  const label = preset === 'today' ? labels.today : preset === 'yesterday' ? labels.yesterday : preset === 'last_week' ? labels.lastWeek : labels.custom;
  return <Card className={`overflow-hidden border-border shadow-sm ${modern ? 'border-border/70' : ''}`}><CardHeader className="gap-3 border-b bg-muted/20 px-5 py-4"><div><CardTitle className="flex items-center gap-2 text-base"><Users className="h-5 w-5 text-primary" />{title}</CardTitle><p className="mt-1 text-xs text-muted-foreground">{labels.description}</p></div><div className="grid gap-2 sm:grid-cols-2"><select aria-label={labels.period} value={preset} onChange={event => setPreset(event.target.value as BranchCollectionPreset)} className="h-9 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option value="today">{labels.today}</option><option value="yesterday">{labels.yesterday}</option><option value="last_week">{labels.lastWeek}</option><option value="custom">{labels.custom}</option></select>{preset === 'custom' ? <div className="grid grid-cols-2 gap-2"><input aria-label={labels.fromDate} type="date" value={startDate} onChange={event => setStartDate(event.target.value)} className="h-9 min-w-0 rounded-md border border-input bg-background px-2 text-xs" /><input aria-label={labels.toDate} type="date" value={endDate} onChange={event => setEndDate(event.target.value)} className="h-9 min-w-0 rounded-md border border-input bg-background px-2 text-xs" /></div> : <div className="flex h-9 items-center rounded-md border border-dashed px-3 text-xs text-muted-foreground">{label}: {range.startDate}</div>}</div></CardHeader><CardContent className="space-y-4 p-5">{receiptsByBranch.slice(0, 5).map((branch, index) => <div key={branch.name}><div className="mb-2 flex items-center justify-between gap-3 text-sm"><span className="flex min-w-0 items-center gap-2 font-medium text-card-foreground"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-bold text-primary">{index + 1}</span><span className="truncate">{branch.name}</span></span><span className="shrink-0 font-bold text-card-foreground">{formatMoney(branch.value)}</span></div><div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className={`h-full rounded-full ${modern ? 'bg-gradient-to-l from-primary to-sky-400' : 'bg-primary'}`} style={{ width: `${Math.max(4, (branch.value / Math.max(receiptsByBranch[0]?.value || 1, 1)) * 100)}%` }} /></div><p className="mt-1 text-[11px] text-muted-foreground">{branch.count.toLocaleString('ar-SA')} {labels.receiptCount}</p></div>)}{!receiptsByBranch.length && <p className="py-8 text-center text-sm text-muted-foreground">{labels.noBranches}</p>} {receiptsByBranch.length > 0 && receiptsByBranch.every(branch => branch.count === 0) && <p className="py-4 text-center text-sm text-muted-foreground">{labels.noReceipts}</p>}</CardContent></Card>;
}

type DashboardSectionOrdering = {
  editMode: boolean;
  draggedId: string | null;
  onDragStart: (event: DragEvent<HTMLElement>, id: string) => void;
  onDragOver: (event: DragEvent<HTMLElement>) => void;
  onDrop: (event: DragEvent<HTMLElement>, targetId: string) => void;
  onDragEnd: () => void;
  onMoveByStep: (id: string, direction: -1 | 1) => void;
};

function DashboardSectionOrderControls({ active, onToggle, onReset }: { active: boolean; onToggle: () => void; onReset: () => void }) {
  return <div className="flex items-center gap-1 rounded-xl border border-border/70 bg-card/80 p-1 shadow-sm backdrop-blur" aria-label="إدارة ترتيب عناصر لوحة التحكم">
    <button type="button" aria-pressed={active} onClick={onToggle} className={`inline-flex h-9 items-center gap-2 rounded-lg px-2.5 text-xs font-bold transition ${active ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} title="إعادة ترتيب لوحة التحكم"><GripVertical className="h-4 w-4" /><span className="hidden sm:inline">ترتيب العناصر</span></button>
    {active && <button type="button" onClick={onReset} className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-muted hover:text-foreground" title="استعادة ترتيب لوحة التحكم الافتراضي" aria-label="استعادة ترتيب لوحة التحكم الافتراضي"><RotateCcw className="h-4 w-4" /></button>}
  </div>;
}

function DashboardSectionContainer({ id, order, ordering, className = '', children }: { id: string; order: number; ordering: DashboardSectionOrdering; className?: string; children: ReactNode }) {
  const position = ordering.editMode ? Math.max(0, DASHBOARD_SECTION_IDS.indexOf(id as (typeof DASHBOARD_SECTION_IDS)[number])) : -1;
  return <section
    style={{ order }}
    draggable={ordering.editMode}
    onDragStart={event => ordering.onDragStart(event, id)}
    onDragOver={ordering.onDragOver}
    onDrop={event => ordering.onDrop(event, id)}
    onDragEnd={ordering.onDragEnd}
    className={`relative min-w-0 transition ${ordering.editMode ? 'rounded-2xl border-2 border-dashed border-primary/45 bg-primary/[0.025] p-2 shadow-sm' : ''} ${ordering.draggedId === id ? 'opacity-55' : ''}`}
    aria-label={ordering.editMode ? 'قسم قابل لإعادة الترتيب في لوحة التحكم' : undefined}
  >
    {ordering.editMode && <div className="mb-2 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-primary/10 px-2 py-1.5 text-xs font-bold text-primary"><span className="inline-flex items-center gap-1.5"><GripVertical className="h-4 w-4" />اسحب لترتيب هذا القسم</span><span className="flex items-center gap-1"><button type="button" onClick={() => ordering.onMoveByStep(id, -1)} disabled={position <= 0} className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-background text-foreground shadow-sm transition hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40" aria-label="نقل القسم للأعلى"><ArrowUp className="h-3.5 w-3.5" /></button><button type="button" onClick={() => ordering.onMoveByStep(id, 1)} disabled={position >= DASHBOARD_SECTION_IDS.length - 1} className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-background text-foreground shadow-sm transition hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40" aria-label="نقل القسم للأسفل"><ArrowDown className="h-3.5 w-3.5" /></button></span></div>}
    <div className={className}>{children}</div>
  </section>;
}

function DashboardWidgetFrame({ group, id, ordering, maxSpan = 4, children }: { group: DashboardWidgetGroup; id: string; ordering: DashboardWidgetOrdering; maxSpan?: number; children: ReactNode }) {
  if (ordering.isHidden(group, id)) return null;
  const position = ordering.getOrder(group, id);
  const span = Math.min(ordering.getSpan(group, id), maxSpan);
  const isDragged = ordering.dragged?.group === group && ordering.dragged.id === id;
  return <div
    style={{ order: position, gridColumn: `span ${span} / span ${span}` }}
    draggable={ordering.editMode}
    onDragStart={event => ordering.onDragStart(event, group, id)}
    onDragOver={ordering.onDragOver}
    onDrop={event => ordering.onDrop(event, group, id)}
    onDragEnd={ordering.onDragEnd}
    className={`relative min-w-0 ${ordering.editMode ? 'rounded-2xl border-2 border-dashed border-primary/50 bg-primary/[0.025] p-1.5' : ''} ${isDragged ? 'opacity-55' : ''}`}
    aria-label={ordering.editMode ? 'إطار قابل للنقل وتغيير الحجم في لوحة التحكم' : undefined}
  >
    <button type="button" onPointerDown={event => event.stopPropagation()} onClick={event => { event.stopPropagation(); ordering.onHide(group, id); }} className="absolute left-2 top-2 z-20 inline-flex h-7 w-7 items-center justify-center rounded-lg border border-border/80 bg-card/95 text-muted-foreground shadow-sm transition hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-300" title="إخفاء هذا العنصر" aria-label="إخفاء هذا العنصر من لوحة التحكم"><EyeOff className="h-3.5 w-3.5" /></button>
    {ordering.editMode && <div className="flex items-center justify-between gap-2 rounded-xl bg-primary/10 px-2 py-1 text-xs font-bold text-primary"><span className="inline-flex items-center gap-1"><GripVertical className="h-3.5 w-3.5" />تخصيص الإطار</span><span className="flex items-center gap-1"><button type="button" onClick={() => ordering.onMoveByStep(group, id, -1)} disabled={position <= 0} className="h-6 min-w-6 rounded bg-background px-1 text-foreground shadow-sm disabled:opacity-35" aria-label="نقل الإطار للخلف">→</button><button type="button" onClick={() => ordering.onMoveByStep(group, id, 1)} className="h-6 min-w-6 rounded bg-background px-1 text-foreground shadow-sm" aria-label="نقل الإطار للأمام">←</button><button type="button" onClick={() => ordering.onResize(group, id, -1, maxSpan)} disabled={span <= 1} className="h-6 min-w-6 rounded bg-background px-1 text-foreground shadow-sm disabled:opacity-35" aria-label="تصغير الإطار">−</button><button type="button" onClick={() => ordering.onResize(group, id, 1, maxSpan)} disabled={span >= maxSpan} className="h-6 min-w-6 rounded bg-background px-1 text-foreground shadow-sm disabled:opacity-35" aria-label="تكبير الإطار">+</button></span></div>}
    {children}
  </div>;
}

function ClassicDashboard({
  title,
  subtitle,
  dashboardSectionOrder,
  stats,
  shortcuts,
  weeklyTrend,
  latestReceipts,
  receiptsByBranch,
  branchCollectionPreset,
  setBranchCollectionPreset,
  branchCollectionStartDate,
  setBranchCollectionStartDate,
  branchCollectionEndDate,
  setBranchCollectionEndDate,
  dashboardLabel,
  shortcutsLabel,
  recentReceiptsLabel,
  topBranchesLabel,
  labels,
  onNavigate,
  sectionOrdering,
  widgetOrdering,
  isSectionOrdering,
  onToggleSectionOrdering,
  onResetSectionOrder,
  hiddenWidgets,
}: {
  title: string;
  subtitle: string;
  dashboardSectionOrder: string[];
  stats: Array<{ title: string; value: string; detail: string; icon: typeof CircleDollarSign; accent: string }>;
  shortcuts: Array<{ id: string; title: string; icon: typeof FilePlus2; path: string; tone: string }>;
  weeklyTrend: Array<{ day: string; amount: number }>;
  latestReceipts: any[];
  receiptsByBranch: Array<{ name: string; value: number; count: number }>;
  branchCollectionPreset: BranchCollectionPreset;
  setBranchCollectionPreset: (value: BranchCollectionPreset) => void;
  branchCollectionStartDate: string;
  setBranchCollectionStartDate: (value: string) => void;
  branchCollectionEndDate: string;
  setBranchCollectionEndDate: (value: string) => void;
  dashboardLabel: string;
  shortcutsLabel: string;
  recentReceiptsLabel: string;
  topBranchesLabel: string;
  labels: {
    todayDate: string;
    collectionsTrend: string;
    viewRecords: string;
    customerFallback: string;
    noReceipts: string;
    branch: { description: string; period: string; today: string; yesterday: string; lastWeek: string; custom: string; receiptCount: string; noBranches: string; noReceipts: string; fromDate: string; toDate: string };
  };
  onNavigate: (path: string) => void;
  sectionOrdering: DashboardSectionOrdering;
  widgetOrdering: DashboardWidgetOrdering;
  isSectionOrdering: boolean;
  onToggleSectionOrdering: () => void;
  onResetSectionOrder: () => void;
  hiddenWidgets: HiddenDashboardWidget[];
}) {
  const sectionOrder = (id: string) => Math.max(0, dashboardSectionOrder.indexOf(id));
  return <div className="rtl-page flex flex-col gap-5 pb-8" dir="rtl">
    <section style={{ order: -1 }} className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div><p className="mb-2 text-xs font-bold text-primary">{dashboardLabel}</p><h1 className="text-2xl font-bold text-card-foreground sm:text-3xl">{title}</h1><p className="mt-2 max-w-2xl text-sm text-muted-foreground">{subtitle}</p></div>
        <div className="flex flex-wrap items-center gap-2"><DashboardSectionOrderControls active={isSectionOrdering} onToggle={onToggleSectionOrdering} onReset={onResetSectionOrder} /><div className="rounded-xl border bg-muted/30 px-4 py-3 text-right"><p className="text-xs text-muted-foreground">{labels.todayDate}</p><p className="mt-1 text-sm font-bold text-card-foreground">{new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p></div></div>
      </div>
      {isSectionOrdering && <p role="status" className="mt-4 text-xs font-medium text-primary">وضع تخصيص العناصر مفعّل: اسحب أي إطار لإعادة ترتيبه، واستخدم أزرار التكبير والتصغير أو الأسهم لتخصيص حجمه وموقعه.</p>}
    </section>

    <DashboardSectionContainer id="summary" order={sectionOrder('summary')} ordering={sectionOrdering} className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map((stat, index) => { const Icon = stat.icon; const widgetId = ['receipts_total', 'payments_total', 'pending_receipts', 'approved_receipts'][index]; return <DashboardWidgetFrame key={stat.title} group="summary" id={widgetId} ordering={widgetOrdering}><Card className="h-full border-border bg-card shadow-sm"><CardContent className="p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold text-muted-foreground">{stat.title}</p><p className="mt-3 text-2xl font-bold text-card-foreground">{stat.value}</p><p className="mt-2 text-xs text-muted-foreground">{stat.detail}</p></div><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary"><Icon className="h-5 w-5" /></span></div></CardContent></Card></DashboardWidgetFrame>; })}
    </DashboardSectionContainer>

    <DashboardSectionContainer id="activity" order={sectionOrder('activity')} ordering={sectionOrdering} className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1.7fr)_minmax(280px,.75fr)]">
      <DashboardWidgetFrame group="activity" id="collections_trend" ordering={widgetOrdering}><Card className="h-full border-border shadow-sm"><CardHeader className="border-b bg-muted/20"><CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="h-5 w-5 text-primary" />{labels.collectionsTrend}</CardTitle></CardHeader><CardContent className="p-4 sm:p-6"><ResponsiveContainer width="100%" height={260}><AreaChart data={weeklyTrend}><defs><linearGradient id="classicDashboardTrend" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={.28} /><stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={.02} /></linearGradient></defs><CartesianGrid vertical={false} strokeDasharray="3 3" className="text-border" /><XAxis dataKey="day" fontSize={11} /><YAxis fontSize={10} /><Tooltip formatter={(value: number) => formatMoney(value)} /><Area type="monotone" dataKey="amount" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#classicDashboardTrend)" /></AreaChart></ResponsiveContainer></CardContent></Card></DashboardWidgetFrame>
      <DashboardWidgetFrame group="activity" id="quick_actions" ordering={widgetOrdering}><Card className="h-full border-border shadow-sm"><CardHeader className="border-b bg-muted/20"><CardTitle className="flex items-center gap-2 text-base"><CalendarDays className="h-5 w-5 text-primary" />{shortcutsLabel}</CardTitle></CardHeader><CardContent className="grid gap-2 p-3">{shortcuts.map(shortcut => { const Icon = shortcut.icon; return <button key={shortcut.id} onClick={() => onNavigate(shortcut.path)} className="flex items-center justify-between rounded-lg border bg-background p-3 text-right transition hover:border-primary/50 hover:bg-primary/5"><span className="flex items-center gap-3"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary"><Icon className="h-4 w-4" /></span><span className="text-sm font-bold text-card-foreground">{shortcut.title}</span></span><ArrowLeft className="h-4 w-4 text-muted-foreground" /></button>; })}</CardContent></Card></DashboardWidgetFrame>
    </DashboardSectionContainer>

    <DashboardSectionContainer id="records" order={sectionOrder('records')} ordering={sectionOrdering} className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(280px,1fr)]">
      <DashboardWidgetFrame group="records" id="recent_receipts" ordering={widgetOrdering}>
        <RecentReceiptsCard
          receipts={latestReceipts}
          title={recentReceiptsLabel}
          viewRecordsLabel={labels.viewRecords}
          customerFallback={labels.customerFallback}
          noReceiptsLabel={labels.noReceipts}
          noMatchesLabel="لا توجد سندات مطابقة لاسم العميل أو رقمه."
          onNavigate={onNavigate}
          formatAmount={receipt => formatMoney(Number(receipt.amount || 0))}
        />
      </DashboardWidgetFrame>
      <DashboardWidgetFrame group="records" id="top_branches" ordering={widgetOrdering}><BranchCollectionsCard receiptsByBranch={receiptsByBranch} preset={branchCollectionPreset} setPreset={setBranchCollectionPreset} startDate={branchCollectionStartDate} setStartDate={setBranchCollectionStartDate} endDate={branchCollectionEndDate} setEndDate={setBranchCollectionEndDate} title={topBranchesLabel} labels={labels.branch} /></DashboardWidgetFrame>
    </DashboardSectionContainer>
    <HiddenDashboardWidgetsRail widgets={hiddenWidgets} onShow={widgetOrdering.onShow} />
  </div>;
}

function RecentReceiptsCard({
  receipts,
  title,
  description,
  viewRecordsLabel,
  customerFallback,
  noReceiptsLabel,
  noMatchesLabel,
  onNavigate,
  formatAmount,
  statusText,
  modern = false,
}: {
  receipts: any[];
  title: string;
  description?: string;
  viewRecordsLabel: string;
  customerFallback: string;
  noReceiptsLabel: string;
  noMatchesLabel: string;
  onNavigate: (path: string) => void;
  formatAmount: (receipt: any) => string;
  statusText?: (receipt: any) => string;
  modern?: boolean;
}) {
  const [searchValue, setSearchValue] = useState('');
  const normalizedSearch = searchValue.trim().toLocaleLowerCase();
  const visibleReceipts = useMemo(() => receipts
    .filter(receipt => !normalizedSearch || [receipt.customerName, receipt.customerNumber]
      .some(value => String(value || '').toLocaleLowerCase().includes(normalizedSearch)))
    .slice(0, 5), [normalizedSearch, receipts]);
  const emptyMessage = normalizedSearch ? noMatchesLabel : noReceiptsLabel;

  return <Card className={`h-full overflow-hidden shadow-sm ${modern ? 'border-border/70' : 'border-border'}`}>
    <CardHeader className={`border-b bg-muted/20 ${modern ? 'px-5 py-4' : ''}`}>
      <div className="flex flex-row items-start justify-between gap-3">
        <div className="min-w-0"><CardTitle className="flex items-center gap-2 text-base"><FileText className="h-5 w-5 text-primary" />{title}</CardTitle>{description && <p className="mt-1 text-xs text-muted-foreground">{description}</p>}</div>
        <button type="button" onClick={() => onNavigate('/receipts')} className="shrink-0 text-xs font-bold text-primary hover:underline">{viewRecordsLabel}</button>
      </div>
      <label className="relative mt-3 block" aria-label="البحث في آخر سندات القبض باسم العميل أو رقمه">
        <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          value={searchValue}
          onChange={event => setSearchValue(event.target.value)}
          placeholder="ابحث باسم العميل أو رقمه"
          className="h-9 w-full rounded-lg border border-input bg-background pr-9 pl-3 text-right text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
        />
      </label>
    </CardHeader>
    <CardContent className="p-0"><div className="divide-y">{visibleReceipts.length ? visibleReceipts.map(receipt => <button type="button" key={receipt.id} onClick={() => onNavigate(`/receipts?receiptId=${receipt.id}`)} className={`grid w-full grid-cols-[minmax(0,1fr)_auto] gap-3 px-5 py-3.5 text-right transition ${modern ? 'hover:bg-muted/45' : 'hover:bg-muted/35'}`}><div className="min-w-0"><p className="flex flex-wrap gap-x-3 gap-y-1 font-bold text-card-foreground"><span>رقم السند: {receipt.serialNumber || '-'}</span><span className="text-sm font-semibold text-primary">الفرع: {receipt.branchName || '-'}</span></p><p className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground"><span>رقم العميل: {receipt.customerNumber || '-'}</span><span>اسم العميل: {receipt.customerName || customerFallback}</span></p></div><div className="shrink-0 text-left"><p className="font-bold text-emerald-600 dark:text-emerald-400">{formatAmount(receipt)}</p>{statusText && <p className="mt-1 text-xs text-muted-foreground">{statusText(receipt)}</p>}</div></button>) : <div className="px-5 py-10 text-center text-sm text-muted-foreground">{emptyMessage}</div>}</div></CardContent>
  </Card>;
}

function HiddenDashboardWidgetsRail({ widgets, onShow }: { widgets: HiddenDashboardWidget[]; onShow: (group: DashboardWidgetGroup, id: string) => void }) {
  if (!widgets.length) return null;
  return <aside dir="rtl" className="group fixed left-2 top-1/2 z-50 max-w-[calc(100vw-1rem)] -translate-y-1/2" aria-label="العناصر المخفية من لوحة التحكم"><div className="rounded-2xl border border-primary/25 bg-card/95 p-1.5 shadow-lg backdrop-blur"><div className="flex items-center gap-2 px-2 py-1.5 text-xs font-bold text-primary"><Eye className="h-4 w-4" /><span className="max-w-0 overflow-hidden whitespace-nowrap opacity-0 transition-all duration-200 group-hover:max-w-32 group-hover:opacity-100">عناصر مخفية</span><span className="rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px]">{widgets.length}</span></div><div className="mt-1 space-y-1 border-t border-border/70 pt-1">{widgets.map(widget => <button key={`${widget.group}-${widget.id}`} type="button" onClick={() => onShow(widget.group, widget.id)} title={`إظهار ${widget.label}`} className="flex h-8 w-full items-center gap-2 rounded-lg px-2 text-right text-xs font-semibold text-muted-foreground transition hover:bg-primary/10 hover:text-primary"><Eye className="h-3.5 w-3.5 shrink-0" /><span className="max-w-0 overflow-hidden whitespace-nowrap opacity-0 transition-all duration-200 group-hover:max-w-40 group-hover:opacity-100">{widget.label}</span></button>)}</div></div></aside>;
}
