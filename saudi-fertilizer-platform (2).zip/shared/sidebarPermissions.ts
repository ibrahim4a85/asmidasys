export type SidebarItemId = 'dashboard' | 'notifications' | 'settings' | 'users' | 'receipts' | 'payments' | 'customers' | 'targets' | 'performance-reports' | 'delegates' | 'reports' | 'partner-rights';

export function hasSidebarAccess(input: {
  isAdmin?: boolean;
  userType?: string;
  permissions?: unknown;
  item: SidebarItemId;
}) {
  if (input.isAdmin) return true;
  const permissions = input.permissions;
  const canUseApprovals = Array.isArray(permissions)
    ? permissions.includes('approvalRequest') || permissions.includes('approvalDelegate')
    : Boolean((permissions as Record<string, boolean> | undefined)?.approvalRequest || (permissions as Record<string, boolean> | undefined)?.approvalDelegate);
  const canUseGoals = Array.isArray(permissions)
    ? ['targetsManage', 'goalsView', 'goalsManage', 'goalsReview', 'goalsExecute', 'commissionsManage'].some(permission => permissions.includes(permission))
    : ['targetsManage', 'goalsView', 'goalsManage', 'goalsReview', 'goalsExecute', 'commissionsManage'].some(permission => Boolean((permissions as Record<string, boolean> | undefined)?.[permission]));
  if (input.item === 'delegates' && canUseApprovals) return true;
  if (input.item === 'targets' && !canUseGoals) return false;
  const configured = !Array.isArray(permissions) && Boolean(permissions && Object.keys(permissions as Record<string, unknown>).some(key => key.startsWith('sidebar_')));
  const partnerRightsIsExplicitlyConfigured = !Array.isArray(permissions)
    && Boolean(permissions && Object.prototype.hasOwnProperty.call(permissions as Record<string, unknown>, 'sidebar_partner-rights'));
  // تُضاف هذه الصفحة إلى الشركاء المفوضين افتراضياً. أما إذا ضبط المدير
  // صلاحيتها صراحةً لهذا المستخدم فتظل القيمة الصريحة هي الحاكمة.
  if (input.item === 'partner-rights' && input.userType === 'authorized_partner' && !partnerRightsIsExplicitlyConfigured) return true;
  if (configured) return Boolean((permissions as Record<string, boolean>)[`sidebar_${input.item}`]);
  const partnerDefaults: SidebarItemId[] = ['dashboard', 'notifications', 'delegates', 'reports', 'partner-rights'];
  if (input.userType === 'authorized_partner') return partnerDefaults.includes(input.item);
  return input.item !== 'users' && input.item !== 'settings';
}
