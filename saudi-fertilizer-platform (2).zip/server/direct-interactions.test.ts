import { describe, expect, it } from 'vitest';
import { getDeleteConfirmationContent } from '../client/src/lib/deleteConfirmation';
import { getSeparateReceiptDownloadPlan } from '../client/src/lib/directDownload';

describe('تفاعلات الحذف والتنزيل المباشر', () => {
  it('يجهز نافذة تأكيد تعرض اسم العنصر وتفاصيله قبل الحذف', () => {
    const content = getDeleteConfirmationContent({
      itemName: 'العميل: مؤسسة الربيع',
      details: ['رقم العميل: 101', 'الفرع: الرياض'],
      scope: 'عميل واحد فقط',
    });

    expect(content.prefix).toBe('أنت على وشك حذف ');
    expect(content.itemName).toBe('العميل: مؤسسة الربيع');
    expect(content.suffix).toContain('لا يمكن التراجع');
    expect(content.scopeLabel).toBe('نطاق الحذف: عميل واحد فقط');
    expect(content.hasDetails).toBe(true);
    expect(content.details).toEqual(['رقم العميل: 101', 'الفرع: الرياض']);
  });

  it('يخفي صندوق التفاصيل عندما لا تتوفر تفاصيل إضافية للعنصر', () => {
    const content = getDeleteConfirmationContent({ itemName: 'سند قبض 3-26-001' });
    expect(content.scopeLabel).toBe('نطاق الحذف: عنصر واحد');
    expect(content.hasDetails).toBe(false);
    expect(content.details).toEqual([]);
  });

  it('ينشئ خطتي تنزيل منفصلتين ومباشرتين للسند والإيصال', () => {
    expect(getSeparateReceiptDownloadPlan('3-26-001', 'https://files.example/receipt.pdf')).toEqual([
      { type: 'receipt', fileName: '3-26-001.pdf', mode: 'direct', opensPreview: false, sequence: 1 },
      { type: 'attachment', fileName: '3-26-001-ESAL.pdf', mode: 'direct', opensPreview: false, sequence: 2 },
    ]);
  });

  it('يمنع أي مسار معاينة ويحدد ترتيب التنزيل المباشر للسند ثم الإيصال', () => {
    const plan = getSeparateReceiptDownloadPlan('3-26-001', 'https://files.example/receipt.pdf');
    expect(plan.every(item => item.mode === 'direct' && item.opensPreview === false)).toBe(true);
    expect(plan.map(item => item.sequence)).toEqual([1, 2]);
    expect(plan.some(item => 'previewUrl' in item)).toBe(false);
  });

  it('لا يسمح بإنشاء تنزيل إيصال عندما يغيب المرفق', () => {
    expect(getSeparateReceiptDownloadPlan('3-26-001', null)).toEqual([]);
  });
});
