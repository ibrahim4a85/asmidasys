export type ApprovalRequestStatusStep = {
  id: number;
  approverName?: string | null;
  boardPosition?: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'skipped' | string;
};

export type ApprovalRequestStatusInput = {
  status: 'sent' | 'approved' | 'rejected' | string;
  approvedCount?: number | null;
  requiredApprovals?: number | null;
  steps?: ApprovalRequestStatusStep[] | null;
};

export function getApprovalRequesterStatus(input: ApprovalRequestStatusInput) {
  const steps = input.steps ?? [];
  const approvedSteps = steps.filter(step => step.status === 'approved');
  const required = Math.max(1, input.requiredApprovals ?? steps.filter(step => step.status !== 'skipped').length ?? 1);
  const remaining = Math.max(0, required - (input.approvedCount ?? approvedSteps.length));
  const lines: string[] = [];

  if (input.status === 'sent') {
    lines.push('تمت المراجعة والإرسال إلى المفوضين.');
  }
  for (const step of approvedSteps) {
    const role = step.boardPosition?.trim() || 'المفوض بالتعميد';
    const name = step.approverName?.trim() || 'مستخدم غير محدد';
    lines.push(`تم التعميد من ${role}: ${name}.`);
  }
  if (input.status === 'approved') {
    lines.push('اكتملت جميع التعميدات اللازمة واعتمد الطلب.');
  } else if (input.status === 'rejected') {
    lines.push('لم يكتمل التعميد لأن أحد المفوضين رفض الطلب.');
  } else if (remaining > 0) {
    lines.push(`لم يكتمل التعميد؛ ما زال الطلب يحتاج إلى ${remaining} من التعميدات اللازمة.`);
  }

  return { lines, remaining, required, approvedCount: input.approvedCount ?? approvedSteps.length };
}
