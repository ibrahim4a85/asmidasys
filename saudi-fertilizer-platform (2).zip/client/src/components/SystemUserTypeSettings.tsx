import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { trpc } from '@/lib/trpc';
import { SYSTEM_USER_TYPE_CATEGORIES, SYSTEM_USER_TYPE_SETTINGS_KEY, readSystemUserTypeDefinitions, validateSystemUserTypeDefinitions, type SystemUserTypeDefinition } from '@shared/systemUserTypes';

const PRESET_PERMISSIONS = [
  ['approvalRequest', 'طلب تعميد'],
  ['approvalReview', 'مراجعة طلبات التعميد'],
  ['approvalApprove', 'تعميد الطلبات'],
  ['customersManage', 'إدارة العملاء'],
  ['targetsManage', 'إدارة الأهداف'],
  ['goalsView', 'عرض الأهداف'],
  ['goalsManage', 'إدارة الأهداف المتقدمة'],
  ['goalsReview', 'مراجعة الأهداف والإجراءات'],
  ['goalsExecute', 'تنفيذ الإجراءات المسندة'],
  ['commissionsManage', 'إدارة قواعد العمولات'],
  ['receiptsApprove', 'اعتماد سندات القبض'],
  ['dataDelete', 'حذف البيانات الانتقائي'],
  ['reports', 'التقارير'],
  ['performanceReports', 'تقارير الأداء'],
] as const;

const emptyCustomType = (): SystemUserTypeDefinition => ({
  code: '', label: '', category: 'custom', defaultPermissions: [], isSystem: false, isActive: true,
});

export function SystemUserTypeSettings() {
  const { data: settings, refetch } = trpc.settings.getAll.useQuery();
  const utils = trpc.useUtils();
  const updateMutation = trpc.settings.updateMany.useMutation();
  const [definitions, setDefinitions] = useState<SystemUserTypeDefinition[]>([]);

  useEffect(() => {
    if (settings) setDefinitions(readSystemUserTypeDefinitions(settings[SYSTEM_USER_TYPE_SETTINGS_KEY]));
  }, [settings]);

  const updateDefinition = (index: number, patch: Partial<SystemUserTypeDefinition>) => {
    setDefinitions(current => current.map((definition, definitionIndex) => definitionIndex === index ? { ...definition, ...patch } : definition));
  };

  const togglePresetPermission = (index: number, permission: string, checked: boolean) => {
    const currentPermissions = definitions[index]?.defaultPermissions || [];
    updateDefinition(index, { defaultPermissions: checked ? Array.from(new Set([...currentPermissions, permission])) : currentPermissions.filter(item => item !== permission) });
  };

  const save = async () => {
    try {
      const validDefinitions = validateSystemUserTypeDefinitions(definitions);
      await updateMutation.mutateAsync({ entries: [{ key: SYSTEM_USER_TYPE_SETTINGS_KEY, value: JSON.stringify(validDefinitions) }] });
      setDefinitions(validDefinitions);
      await utils.settings.getAll.invalidate();
      await refetch();
      toast.success('تم حفظ أنواع المستخدمين. تبقى الصلاحيات الفعلية لكل حساب تحت تحكم مدير النظام.');
    } catch (error: any) {
      toast.error(error?.message || 'تعذر حفظ أنواع المستخدمين');
    }
  };

  return <Card><CardHeader><CardTitle>إدارة أنواع المستخدمين</CardTitle></CardHeader><CardContent className="space-y-5">
    <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm leading-6 text-muted-foreground">
      عدّل مسمى النوع وفئته وحالته، أو أضف أنواعاً مخصصة. إعدادات الصلاحيات أدناه هي <strong className="text-foreground">قوالب وصفية</strong> تساعد عند الإدارة فقط؛ لا تُمنح تلقائياً للحسابات الحالية ولا تتجاوز مربعات الصلاحيات الفعلية في شاشة إدارة المستخدمين. يظل «مدير النظام» نشطاً دائماً.
    </div>
    <div className="space-y-4">
      {definitions.map((definition, index) => <section key={`${definition.code}-${index}`} className="rounded-xl border bg-card p-4 shadow-sm">
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_12rem_auto] lg:items-end">
          <div className="space-y-2"><Label>رمز النوع</Label><Input value={definition.code} dir="ltr" disabled={definition.isSystem} placeholder="مثال: inventory_manager" onChange={event => updateDefinition(index, { code: event.target.value.trim().toLowerCase() })} /><p className="text-xs text-muted-foreground">للأنواع المخصصة: أحرف إنجليزية صغيرة وأرقام وشرطة سفلية فقط.</p></div>
          <div className="space-y-2"><Label>المسمى الظاهر</Label><Input value={definition.label} maxLength={80} placeholder="مثال: مدير المخزون" onChange={event => updateDefinition(index, { label: event.target.value })} /></div>
          <div className="space-y-2"><Label>الفئة</Label><Select value={definition.category} onValueChange={value => updateDefinition(index, { category: value as SystemUserTypeDefinition['category'] })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{SYSTEM_USER_TYPE_CATEGORIES.map(category => <SelectItem key={category.id} value={category.id}>{category.label}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex items-center gap-2 pb-2"><Switch checked={definition.isActive} disabled={definition.code === 'admin'} onCheckedChange={checked => updateDefinition(index, { isActive: checked })} /><span className="text-sm">{definition.isActive ? 'نشط' : 'غير نشط'}</span>{!definition.isSystem && <Button type="button" variant="ghost" size="icon" className="text-destructive" aria-label="حذف النوع" onClick={() => setDefinitions(current => current.filter((_, definitionIndex) => definitionIndex !== index))}><Trash2 className="h-4 w-4" /></Button>}</div>
        </div>
        <div className="mt-4 rounded-lg border bg-muted/20 p-3"><p className="text-sm font-medium">قالب الصلاحيات الوصفي</p><div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">{PRESET_PERMISSIONS.map(([permission, label]) => <label key={permission} className="flex cursor-pointer items-center gap-2 rounded-md border bg-background px-3 py-2 text-sm"><Checkbox checked={definition.defaultPermissions.includes(permission)} onCheckedChange={checked => togglePresetPermission(index, permission, checked === true)} /><span>{label}</span></label>)}</div></div>
      </section>)}
    </div>
    <div className="flex flex-col-reverse gap-3 border-t pt-4 sm:flex-row sm:justify-between"><Button type="button" variant="outline" onClick={() => setDefinitions(current => [...current, emptyCustomType()])}><Plus className="ml-1 h-4 w-4" />إضافة نوع مخصص</Button><Button type="button" onClick={save} disabled={!settings || updateMutation.isPending}>{updateMutation.isPending ? 'جارٍ الحفظ...' : 'حفظ أنواع المستخدمين'}</Button></div>
  </CardContent></Card>;
}
