import { describe, expect, it } from 'vitest';
import { buildReceiptExportRows } from '../client/src/lib/receiptExport';

const receipts = [
  { id: 1, serialNumber: 'RYD-0001', createdAt: '2026-08-18T00:00:00.000Z', branchId: 1, userId: 10, customerId: 100, amount: '1500', paymentMethodId: 2, paymentForId: 3, invoices: [{ invoiceNumber: '101', invoiceAmount: '1500' }], status: 'approved' as const },
  { id: 2, serialNumber: 'RYD-0002', createdAt: '2026-08-18T00:00:00.000Z', branchId: 1, userId: 10, customerId: 101, amount: '1600', paymentMethodId: 2, paymentForId: 3, invoices: [{ invoiceNumber: '102', invoiceAmount: '1600' }], status: 'issued' as const },
  { id: 3, serialNumber: 'RYD-0003', createdAt: '2026-08-19T00:00:00.000Z', branchId: 1, userId: 10, customerId: 101, amount: '700', paymentMethodId: 2, paymentForId: 4, invoices: [], status: 'issued' as const },
];

const lookups = {
  branches: [{ id: 1, name: 'الرياض' }],
  users: [{ id: 10, fullName: 'أحمد حسانين' }],
  customers: [{ id: 100, customerNumber: '100', name: 'العميل الأول' }, { id: 101, customerNumber: '101', name: 'العميل الثاني' }],
  paymentMethods: [{ id: 2, name: 'تحويل بنكي' }],
  paymentFors: [{ id: 3, name: 'دفعة من الحساب' }, { id: 4, name: 'سداد الرصيد' }],
};

describe('تجهيز صفوف تصدير سندات القبض', () => {
  it('يصدر السندات المحددة فقط عند تمريرها إلى التجهيز', () => {
    const rows = buildReceiptExportRows(receipts.filter(receipt => receipt.id === 2), lookups);

    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({
      'الرقم التسلسلي': 'RYD-0002',
      'العميل': 'العميل الثاني',
      'المندوب': 'أحمد حسانين',
      'الحالة': 'تم الإصدار',
      'البيان': expect.stringMatching(/^ف 102 - .+ ريال$/),
    });
  });

  it('يصدر جميع النتائج الظاهرة مع أسماء المراجع والحالة', () => {
    const rows = buildReceiptExportRows(receipts, lookups);

    expect(rows).toHaveLength(3);
    expect(rows.map(row => row['الرقم التسلسلي'])).toEqual(['RYD-0001', 'RYD-0002', 'RYD-0003']);
    expect(rows[0]).toMatchObject({ 'الفرع': 'الرياض', 'طريقة الدفع': 'تحويل بنكي', 'الحالة': 'معتمد' });
    expect(rows[2]).toMatchObject({ 'البيان': 'سداد الرصيد' });
  });
});
