export const BOARD_MEMBER_POSITIONS = ['رئيس مجلس الإدارة', 'عضو مجلس الإدارة'] as const;
export const PARTNER_BOARD_POSITIONS = [...BOARD_MEMBER_POSITIONS, 'شريك فقط'] as const;

export function normalizeBoardPosition(position: string | null | undefined) {
  if (!position) return null;
  const normalized = position.trim();
  if (normalized === 'رئيس مجلس الادارة') return 'رئيس مجلس الإدارة';
  if (normalized === 'عضو مجلس الادارة') return 'عضو مجلس الإدارة';
  return normalized;
}

export function isBoardMemberPosition(position: string | null | undefined) {
  const normalized = normalizeBoardPosition(position);
  return normalized === 'رئيس مجلس الإدارة' || normalized === 'عضو مجلس الإدارة';
}
