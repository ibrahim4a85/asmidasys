import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';
import { useLocation } from 'wouter';
import { useSystemAuth } from '@/contexts/AuthContext';
import { trpc } from '@/lib/trpc';
import {
  LayoutDashboard, Users, FileText, CreditCard, UserCircle,
  Target, Settings, Shield, BarChart3, LogOut, Menu, X, Building2, ChevronLeft, ChevronDown, TrendingUp, Bell, CheckCheck, ArrowDown, ArrowUp, SlidersHorizontal, Moon, Sun, WalletCards
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { getNotificationTargetPath } from '@shared/receiptPresentation';
import { toast } from 'sonner';
import { getLoginPresentationText } from '../../../shared/loginPresentation';
import { getCompanyNameDisplaySettings } from '@shared/companyNameDisplaySettings';
import { useTheme } from '@/contexts/ThemeContext';
import { getSystemLabel, type SystemLabelId } from '@shared/systemLabelPresentation';
import { readSystemUserTypeDefinitions } from '@shared/systemUserTypes';

interface NavItem {
  id: string;
  label: string;
  icon: any;
  path: string;
  group: 'الرئيسية' | 'العمليات' | 'الإدارة' | 'التقارير' | 'النظام';
  adminOnly?: boolean;
  requiredPermission?: 'customersManage' | 'targetsManage' | 'dataDelete';
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard, path: '/dashboard', group: 'الرئيسية' },
  { id: 'notifications', label: 'سجل الإشعارات', icon: Bell, path: '/notifications', group: 'الرئيسية' },
  { id: 'receipts', label: 'سندات القبض', icon: FileText, path: '/receipts', group: 'العمليات' },
  { id: 'payments', label: 'سندات الصرف', icon: CreditCard, path: '/payments', group: 'العمليات' },
  { id: 'delegates', label: 'التعميدات', icon: Shield, path: '/delegates', group: 'العمليات' },
  { id: 'customers', label: 'إدارة العملاء', icon: UserCircle, path: '/customers', group: 'الإدارة', requiredPermission: 'customersManage' },
  { id: 'targets', label: 'إدارة الأهداف', icon: Target, path: '/targets', group: 'الإدارة', requiredPermission: 'targetsManage' },
  { id: 'users', label: 'إدارة المستخدمين', icon: Users, path: '/users', group: 'الإدارة', adminOnly: true },
  { id: 'performance-reports', label: 'تقارير الأداء', icon: TrendingUp, path: '/performance-reports', group: 'التقارير' },
  { id: 'reports', label: 'التقارير', icon: BarChart3, path: '/reports', group: 'التقارير' },
  { id: 'partner-rights', label: 'حقوق الشركاء', icon: WalletCards, path: '/partner-rights', group: 'التقارير' },
  { id: 'settings', label: 'إعدادات النظام', icon: Settings, path: '/settings', group: 'النظام', requiredPermission: 'dataDelete' },
];
const navGroupOrder: NavItem['group'][] = ['الرئيسية', 'العمليات', 'الإدارة', 'التقارير', 'النظام'];

export default function AppLayout({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [sidebarOrderOpen, setSidebarOrderOpen] = useState(false);
  const [draftSidebarOrder, setDraftSidebarOrder] = useState<string[]>([]);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [openNavGroups, setOpenNavGroups] = useState<Record<string, boolean>>({ الرئيسية: true, العمليات: true, الإدارة: true, التقارير: true, النظام: true });
  const { user, logout, isAdmin } = useSystemAuth();
  const [sidebarWidth, setSidebarWidth] = useState<number | null>(null);
  const [isSidebarResizing, setIsSidebarResizing] = useState(false);
  const sidebarResizeStartRef = useRef<{ startX: number; width: number } | null>(null);
  const { colorMode, toggleColorMode } = useTheme();
  const [location, setLocation] = useLocation();
  const { data: company } = trpc.company.get.useQuery();
  const { data: settings } = trpc.settings.getAll.useQuery();
  const { data: notifications = [] } = trpc.notifications.list.useQuery({ unreadOnly: false });
  const utils = trpc.useUtils();
  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => utils.notifications.list.invalidate(),
  });
  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => utils.notifications.list.invalidate(),
  });
  const saveSidebarOrder = trpc.settings.update.useMutation({
    onSuccess: () => {
      utils.settings.getAll.invalidate();
      setSidebarOrderOpen(false);
      toast.success(labelFor('ui_save_sidebar_order'));
    },
    onError: () => toast.error(`تعذر ${labelFor('ui_save_sidebar_order')}`),
  });
  const unreadCount = notifications.filter(notification => !notification.isRead).length;
  const { copyright: copyrightText } = getLoginPresentationText(settings, company?.companyName);
  const { fontSize: companyNameFontSize, width: companyNameWidth } = getCompanyNameDisplaySettings(settings);
  const interfaceStyle = settings?.interface_style === 'modern' ? 'modern' : 'classic';
  const labelFor = (id: SystemLabelId, fallback?: string) => getSystemLabel(settings, id, fallback);
  const expandedSidebarWidth = interfaceStyle === 'classic' ? 265 : Math.max(260, Math.min(545, companyNameWidth + 75));
  const resolvedSidebarWidth = sidebarWidth ?? expandedSidebarWidth;
  const sidebarWidthStorageKey = `app-sidebar-width-${user?.id || 'anonymous'}`;
  const systemUserType = (user as { userType?: string } | null)?.userType;
  const systemUserTypeLabel = readSystemUserTypeDefinitions(settings?.system_user_type_definitions).find(definition => definition.code === systemUserType)?.label
    || (systemUserType === 'accountant' ? labelFor('user_type_accountant', 'محاسب (نوع قديم)') : systemUserType === 'branch_supervisor' ? labelFor('user_type_branch_supervisor', 'مشرف فرع (نوع قديم)') : systemUserType || labelFor('user_type_delegate', 'مندوب'));
  const hasPermission = (permission?: NavItem['requiredPermission']) => {
    if (!permission || isAdmin) return true;
    if (Array.isArray(user?.permissions)) return user.permissions.includes(permission);
    return Boolean(user?.permissions?.[permission]);
  };
  const hasSidebarAccess = (item: NavItem) => {
    if (isAdmin) return true;
    if (item.adminOnly) return false;
    const permissions = user?.permissions;
    const canUseApprovals = Boolean(
      Array.isArray(permissions)
        ? permissions.includes('approvalRequest') || permissions.includes('approvalDelegate')
        : permissions?.approvalRequest || permissions?.approvalDelegate
    );
    const canUseGoals = Boolean(
      Array.isArray(permissions)
        ? ['targetsManage', 'goalsView', 'goalsManage', 'goalsReview', 'goalsExecute', 'commissionsManage'].some(permission => permissions.includes(permission))
        : ['targetsManage', 'goalsView', 'goalsManage', 'goalsReview', 'goalsExecute', 'commissionsManage'].some(permission => permissions?.[permission])
    );
    if (item.id === 'delegates' && canUseApprovals) return true;
    if (item.id === 'targets' && !canUseGoals) return false;
    const hasSidebarConfiguration = !Array.isArray(permissions) && Boolean(permissions && Object.keys(permissions).some(key => key.startsWith('sidebar_')));
    const partnerRightsIsExplicitlyConfigured = !Array.isArray(permissions)
      && Boolean(permissions && Object.prototype.hasOwnProperty.call(permissions, 'sidebar_partner-rights'));
    if (item.id === 'partner-rights' && systemUserType === 'authorized_partner' && !partnerRightsIsExplicitlyConfigured) return true;
    if (hasSidebarConfiguration) return Boolean((permissions as Record<string, boolean> | undefined)?.[`sidebar_${item.id}`]) && (item.id === 'targets' ? canUseGoals : hasPermission(item.requiredPermission));
    if (systemUserType === 'authorized_partner') return ['dashboard', 'notifications', 'delegates', 'reports', 'partner-rights'].includes(item.id);
    return item.id !== 'delegates' && (item.id === 'targets' ? canUseGoals : hasPermission(item.requiredPermission));
  };

  useEffect(() => {
    try {
      const order = settings?.sidebar_order ? JSON.parse(settings.sidebar_order) : [];
      setDraftSidebarOrder(Array.isArray(order) ? order : []);
    } catch {
      setDraftSidebarOrder([]);
    }
  }, [settings?.sidebar_order]);

  useEffect(() => {
    try {
      const storedWidth = Number(window.localStorage.getItem(sidebarWidthStorageKey));
      setSidebarWidth(Number.isFinite(storedWidth) && storedWidth >= 220 && storedWidth <= 560 ? storedWidth : null);
    } catch { setSidebarWidth(null); }
  }, [sidebarWidthStorageKey]);

  useEffect(() => {
    if (sidebarWidth === null) return;
    try { window.localStorage.setItem(sidebarWidthStorageKey, String(sidebarWidth)); } catch { /* مساحة التخزين اختيارية */ }
  }, [sidebarWidth, sidebarWidthStorageKey]);

  useEffect(() => {
    const move = (event: globalThis.PointerEvent) => {
      const start = sidebarResizeStartRef.current;
      if (!start) return;
      setSidebarWidth(Math.max(220, Math.min(560, Math.round(start.width + (start.startX - event.clientX)))));
    };
    const stop = () => { sidebarResizeStartRef.current = null; setIsSidebarResizing(false); };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
  }, []);

  const startSidebarResize = (event: ReactPointerEvent<HTMLButtonElement>) => {
    if (collapsed || window.innerWidth < 1024) return;
    event.preventDefault();
    sidebarResizeStartRef.current = { startX: event.clientX, width: resolvedSidebarWidth };
    event.currentTarget.setPointerCapture(event.pointerId);
    setIsSidebarResizing(true);
  };

  // Sort nav items based on settings
  const sortedNavItems = useMemo(() => {
    const filtered = navItems.filter(hasSidebarAccess);
    if (settings?.sidebar_order) {
      try {
        const order: string[] = JSON.parse(settings.sidebar_order);
        return [...filtered].sort((a, b) => {
          const aIdx = order.indexOf(a.id);
          const bIdx = order.indexOf(b.id);
          if (aIdx === -1 && bIdx === -1) return 0;
          if (aIdx === -1) return 1;
          if (bIdx === -1) return -1;
          return aIdx - bIdx;
        });
      } catch { return filtered; }
    }
    return filtered;
  }, [isAdmin, settings?.sidebar_order, user?.permissions, systemUserType]);

  const orderedNavItemsForEditor = useMemo(() => {
    const indexOf = (id: string) => {
      const index = draftSidebarOrder.indexOf(id);
      return index === -1 ? Number.MAX_SAFE_INTEGER : index;
    };
    return [...sortedNavItems].sort((a, b) => indexOf(a.id) - indexOf(b.id));
  }, [draftSidebarOrder, sortedNavItems]);

  const moveSidebarItem = (itemId: string, direction: -1 | 1) => {
    const ids = orderedNavItemsForEditor.map(item => item.id);
    const currentIndex = ids.indexOf(itemId);
    const nextIndex = currentIndex + direction;
    if (currentIndex < 0 || nextIndex < 0 || nextIndex >= ids.length) return;
    [ids[currentIndex], ids[nextIndex]] = [ids[nextIndex], ids[currentIndex]];
    setDraftSidebarOrder(ids);
  };

  const openNotification = (notification: any) => {
    if (!notification.isRead) markRead.mutate({ id: notification.id });
    setNotificationsOpen(false);
    setLocation(getNotificationTargetPath(notification));
  };

  const handleLogout = async () => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    try {
      await logout();
    } finally {
      setLocation('/');
      setIsLoggingOut(false);
    }
  };

  const renderNavItem = (item: NavItem) => {
    const Icon = item.icon;
    const isActive = location === item.path;
    const labelId = (item.id === 'performance-reports' ? 'nav_performance_reports' : `nav_${item.id}`) as SystemLabelId;
    return <button key={item.id} onClick={() => { setLocation(item.path); setMobileOpen(false); }} className={cn("w-full flex items-center gap-2 px-2.5 py-2.5 rounded-lg text-right text-sm font-medium transition-all duration-150", isActive ? "bg-gradient-to-r from-primary to-secondary text-sidebar-primary-foreground shadow-lg" : "text-sidebar-foreground hover:bg-sidebar-accent")}><Icon className="h-5 w-5 flex-shrink-0" />{!collapsed && <span>{labelFor(labelId, item.label)}</span>}</button>;
  };

  return (
    <div className="rtl-page min-h-screen flex bg-gradient-to-b from-background via-background to-muted/20" dir="rtl">
      {/* Mobile Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside style={collapsed ? undefined : { '--sidebar-width': `${resolvedSidebarWidth}px` } as any} className={cn(
        "fixed top-0 right-0 h-full min-h-0 overflow-hidden border-l border-sidebar-border/50 z-50 transition-all duration-300 flex flex-col shadow-xl",
        interfaceStyle === 'classic' ? "bg-sidebar" : "bg-gradient-to-b from-sidebar to-sidebar/95",
        collapsed ? "w-[70px]" : "w-[calc(100vw-1.25rem)] max-w-[22rem] lg:w-[var(--sidebar-width)] lg:max-w-none",
        mobileOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
      )}>
        {!collapsed && <button type="button" aria-label="اسحب لتغيير عرض القائمة الجانبية" onPointerDown={startSidebarResize} className={cn("absolute inset-y-0 left-0 z-20 hidden w-2 cursor-col-resize touch-none border-l border-transparent lg:block", isSidebarResizing ? "border-primary bg-primary/20" : "hover:border-primary/70 hover:bg-primary/10")}><span className="sr-only">مقبض تغيير عرض القائمة الجانبية</span></button>}
        {/* Header */}
        <div className="flex min-h-[110px] items-start gap-2 border-b border-sidebar-border px-3 py-3 text-right sm:min-h-[136px] sm:px-2.5 sm:py-4">
          {company?.logoUrl ? (
            <img src={company.logoUrl} alt={labelFor('login_logo_alt', 'شعار الشركة')} className="h-14 w-14 rounded-xl object-contain shadow-sm flex-shrink-0" />
          ) : (
            <div className="h-14 w-14 rounded-xl bg-sidebar-primary/10 flex items-center justify-center flex-shrink-0">
              <Building2 className="h-5 w-5 text-sidebar-primary" />
            </div>
          )}
          {!collapsed && (
            <div className="min-w-0 flex-1 overflow-visible pt-1 sm:pt-2">
              <h2 className="break-words font-bold leading-6 tracking-[-0.02em] text-sidebar-foreground sm:leading-7" style={{ fontSize: `${companyNameFontSize}px` }}>
                {company?.companyName || labelFor('login_default_company_name', 'شركة الأسمدة المتحدة السعودية')}
              </h2>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain py-2 [scrollbar-gutter:stable]">
          <nav className={cn("px-1.5", interfaceStyle === 'classic' ? 'space-y-1' : 'space-y-2')}>
            {interfaceStyle === 'classic' ? sortedNavItems.map(renderNavItem) : navGroupOrder.map(group => {
              const groupItems = sortedNavItems.filter(item => item.group === group);
              if (!groupItems.length) return null;
              const isOpen = openNavGroups[group] !== false;
              return <div key={group} className="space-y-1">
                {!collapsed && <button onClick={() => setOpenNavGroups(current => ({ ...current, [group]: !isOpen }))} className="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-[11px] font-bold tracking-wide text-sidebar-foreground/65 hover:bg-sidebar-accent"><span>{labelFor((group === 'الرئيسية' ? 'nav_group_home' : group === 'العمليات' ? 'nav_group_operations' : group === 'الإدارة' ? 'nav_group_management' : group === 'التقارير' ? 'nav_group_reports' : 'nav_group_system') as SystemLabelId, group)}</span><ChevronDown className={cn('h-3.5 w-3.5 transition-transform', !isOpen && '-rotate-90')} /></button>}
                {(isOpen || collapsed) && <div className="space-y-1">{groupItems.map(renderNavItem)}</div>}
              </div>;
            })}
          </nav>
          {isAdmin && !collapsed && (
            <div className="mx-2 mt-4 border-t border-sidebar-border/70 pt-3">
              <Button variant="ghost" size="sm" className="h-auto w-full justify-start gap-2 whitespace-normal text-right text-sidebar-foreground hover:bg-sidebar-accent" onClick={() => setSidebarOrderOpen(true)}>
                <SlidersHorizontal className="h-4 w-4" />{labelFor('ui_manage_sidebar_order')}
              </Button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-sidebar-border p-3">
          <div className={cn("flex items-center gap-2", collapsed && "justify-center")}>
            <div className="h-8 w-8 rounded-full bg-sidebar-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-bold text-sidebar-primary">{user?.fullName?.charAt(0)}</span>
            </div>
            {!collapsed && (
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-medium text-sidebar-foreground truncate">{user?.fullName}</p>
                <p className="text-[10px] text-muted-foreground">
                  {systemUserTypeLabel}
                </p>
              </div>
            )}
            {!collapsed && (
              <Button variant="ghost" size="icon" onClick={handleLogout} disabled={isLoggingOut} aria-label="تسجيل الخروج" title="تسجيل الخروج" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                <LogOut className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Collapse Toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -left-3 top-1/2 -translate-y-1/2 h-6 w-6 rounded-full bg-sidebar border border-sidebar-border flex items-center justify-center hover:bg-sidebar-accent transition-colors hidden lg:flex"
        >
          <ChevronLeft className={cn("h-3 w-3 text-sidebar-foreground transition-transform", collapsed && "rotate-180")} />
        </button>
      </aside>

      {/* Main Content */}
      <main style={collapsed ? undefined : { '--sidebar-width': `${resolvedSidebarWidth}px` } as any} className={cn(
        "min-w-0 flex-1 min-h-screen flex flex-col transition-all duration-300",
        collapsed ? "lg:mr-[70px]" : "lg:mr-[var(--sidebar-width)]"
      )}>
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border h-14 flex items-center px-4 gap-3" dir="rtl">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label={labelFor('ui_toggle_navigation')}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex-1" />
          <span className="text-xs text-muted-foreground hidden sm:block">
            {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
          <div className="flex items-center gap-2 relative">
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={toggleColorMode}
              aria-label={`${labelFor('ui_enable')} ${colorMode === 'dark' ? labelFor('ui_light_mode') : labelFor('ui_dark_mode')}`}
              title={colorMode === 'dark' ? labelFor('ui_light_mode') : labelFor('ui_dark_mode')}
            >
              {colorMode === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={() => setNotificationsOpen(open => !open)}
              aria-label={labelFor('ui_notifications')}
            >
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -left-1 min-w-4 h-4 rounded-full bg-destructive px-1 text-[9px] leading-4 text-destructive-foreground">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </Button>
            {notificationsOpen && (
              <div className="absolute right-0 top-11 z-50 w-[calc(100vw-1.5rem)] max-w-80 overflow-hidden rounded-xl border border-border bg-popover text-popover-foreground shadow-xl" dir="rtl">
                <div className="flex items-center justify-between border-b border-border px-3 py-2">
                  <div>
                    <p className="text-sm font-bold">{labelFor('ui_notifications')}</p>
                    <p className="text-[11px] text-muted-foreground">{labelFor('ui_notifications_description')}</p>
                  </div>
                  {unreadCount > 0 && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => markAllRead.mutate()}>
                      <CheckCheck className="ml-1 h-3.5 w-3.5" /> {labelFor('ui_mark_all_read')}
                    </Button>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="px-4 py-8 text-center text-xs text-muted-foreground">{labelFor('ui_notifications_empty')}</p>
                  ) : notifications.slice(0, 20).map(notification => (
                    <button
                      key={notification.id}
                      onClick={() => openNotification(notification)}
                      className={cn(
                        'w-full border-b border-border/60 px-4 py-3 text-right transition-colors hover:bg-muted/60',
                        !notification.isRead && 'bg-primary/5'
                      )}
                    >
                      <div className="flex items-start gap-2">
                        {!notification.isRead && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-primary" />}
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold">{notification.title}</p>
                          <p className="mt-1 text-[11px] leading-5 text-muted-foreground">{notification.message}</p>
                          <p className="mt-1 text-[10px] text-muted-foreground">{new Date(notification.createdAt).toLocaleString('ar-SA')}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 rounded-lg bg-muted/50 px-2 py-1.5 sm:px-3">
              <UserCircle className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground hidden sm:inline">{user?.fullName}</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-1 text-destructive hover:text-destructive">
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">{labelFor('ui_logout')}</span>
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <div className="min-w-0 flex-1 p-3 sm:p-4 md:p-6">
          {children}
        </div>
        <footer className="border-t border-border/70 bg-background/70 px-4 py-2.5 text-center text-[10px] text-muted-foreground" dir="rtl">
          <span>{copyrightText}</span>
          <span className="mx-2 text-border">|</span>
          <span>{labelFor('login_designer_credit')}</span>
        </footer>
      </main>
      <Dialog open={sidebarOrderOpen} onOpenChange={setSidebarOrderOpen}>
        <DialogContent dir="rtl" className="max-h-[92dvh] max-w-[calc(100%-1rem)] overflow-y-auto text-right sm:max-w-lg">
          <DialogHeader><DialogTitle>{labelFor('ui_sidebar_order_title')}</DialogTitle></DialogHeader>
          <p className="text-sm leading-6 text-muted-foreground">{labelFor('ui_sidebar_order_description')}</p>
          <div className="max-h-[52vh] space-y-2 overflow-y-auto py-2">
            {orderedNavItemsForEditor.map((item, index) => {
              const Icon = item.icon;
              return <div key={item.id} className="flex items-center gap-3 rounded-lg border bg-muted/30 px-3 py-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary"><Icon className="h-4 w-4" /></span>
                <span className="flex-1 text-sm font-medium">{labelFor((item.id === 'performance-reports' ? 'nav_performance_reports' : `nav_${item.id}`) as SystemLabelId, item.label)}</span>
                <span className="text-xs text-muted-foreground">{index + 1}</span>
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={index === 0} onClick={() => moveSidebarItem(item.id, -1)} title={labelFor('ui_move_up')}><ArrowUp className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={index === orderedNavItemsForEditor.length - 1} onClick={() => moveSidebarItem(item.id, 1)} title={labelFor('ui_move_down')}><ArrowDown className="h-4 w-4" /></Button>
              </div>;
            })}
          </div>
          <div className="flex flex-col-reverse justify-start gap-2 sm:flex-row">
            <Button className="w-full sm:w-auto" variant="outline" onClick={() => setSidebarOrderOpen(false)}>{labelFor('ui_cancel')}</Button>
            <Button className="w-full sm:w-auto" onClick={() => saveSidebarOrder.mutate({ key: 'sidebar_order', value: JSON.stringify(draftSidebarOrder) })} disabled={saveSidebarOrder.isPending}>{labelFor('ui_save_sidebar_order')}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
