import { describe, expect, it } from 'vitest';
import { getPrintPresentation } from '@shared/printPresentation';

describe('إعدادات تصميم المطبوعات', () => {
  it('يستخدم افتراضات واضحة عند غياب الإعدادات', () => {
    expect(getPrintPresentation(undefined, 'شركة الأسمدة المتحدة')).toMatchObject({
      logoSize: 80,
      headerHeight: 92,
      footerHeight: 44,
      logoPosition: 'right',
      headerText: 'شركة الأسمدة المتحدة',
      footerText: '',
      headerFlexDirection: 'row',
      accentColor: '#0f766e',
      titleFontSize: 24,
      showBarcode: true,
      pageOrientation: 'portrait',
      headerPercent: 15,
      footerPercent: 15,
    });
  });

  it('يطبق النصوص والقياسات والموضع المخصصين على مخرجات السند والتقرير', () => {
    expect(getPrintPresentation({
      print_header_text: 'رأس مخصص',
      print_footer_text: 'تذييل مخصص',
      print_logo_position: 'center',
      print_logo_size: '120',
      print_header_height: '150',
      print_footer_height: '70',
    })).toMatchObject({
      logoSize: 120,
      headerHeight: 150,
      footerHeight: 70,
      logoPosition: 'center',
      headerText: 'رأس مخصص',
      footerText: 'تذييل مخصص',
      headerFlexDirection: 'column',
      accentColor: '#0f766e',
      titleFontSize: 24,
      showBarcode: true,
      pageOrientation: 'portrait',
      headerPercent: 15,
      footerPercent: 15,
    });
  });

  it('يحمي التصميم من قيم الإعدادات غير الصالحة أو الخارجة عن الحدود', () => {
    expect(getPrintPresentation({
      print_logo_position: 'unknown',
      print_logo_size: '999',
      print_header_height: '5',
      print_footer_height: 'غير صالح',
    })).toMatchObject({
      logoSize: 180,
      headerHeight: 60,
      footerHeight: 44,
      logoPosition: 'right',
      headerFlexDirection: 'row',
    });
  });

  it('يحفظ خيارات اللون والعنوان والباركود ضمن حدود آمنة', () => {
    expect(getPrintPresentation({
      print_accent_color: '#1f4e79',
      print_title_font_size: '32',
      print_show_barcode: 'false',
    })).toMatchObject({
      accentColor: '#1f4e79',
      titleFontSize: 32,
      showBarcode: false,
    });
    expect(getPrintPresentation({ print_accent_color: 'invalid', print_title_font_size: '99' })).toMatchObject({
      accentColor: '#0f766e',
      titleFontSize: 36,
    });
  });

  it('يقبل تخصيص اتجاه الصفحة ونسبتي الرأس والتذييل ضمن حدود آمنة', () => {
    expect(getPrintPresentation({
      print_page_orientation: 'landscape',
      print_header_percent: '22',
      print_footer_percent: '12',
    })).toMatchObject({
      pageOrientation: 'landscape',
      headerPercent: 22,
      footerPercent: 12,
    });

    expect(getPrintPresentation({
      print_page_orientation: 'invalid',
      print_header_percent: '2',
      print_footer_percent: '90',
    })).toMatchObject({
      pageOrientation: 'portrait',
      headerPercent: 10,
      footerPercent: 25,
    });
  });
});
