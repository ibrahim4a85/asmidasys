import { type PointerEvent as ReactPointerEvent, useEffect, useMemo, useRef, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { FileDropzone } from '@/components/FileDropzone';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Plus, FileSpreadsheet, FileText, Filter, History, List, Printer, Trash2, Eye, Pencil, Download, FileDown, Loader2, MoreHorizontal, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { numberToArabicWords } from '@/lib/numberToArabicWords';
import QRCode from 'qrcode';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import { getReceiptDelegateName, getReceiptInvoiceSummary, getReceiptStatement } from '@shared/receiptPresentation';
import { getPrintPresentation } from '@shared/printPresentation';
import { buildReceiptExportRows } from '../lib/receiptExport';
import { DeleteConfirmationDialog } from '@/components/DeleteConfirmationDialog';
import { buildReceiptPrintBundle } from '../lib/receiptPrintBundle';
import { getReceiptFormPresentation } from '@shared/receiptFormPresentation';
import { useSystemLabels } from '@/hooks/useSystemLabels';

function isCashPaymentMethod(paymentMethod: { name?: unknown; requiresAttachment?: boolean } | null | undefined) {
  if (!paymentMethod) return false;
  if (paymentMethod.requiresAttachment === false) return true;
  const normalizedName = String(paymentMethod.name || '').trim().replace(/[ً-ْ]/g, '');
  return normalizedName === 'نقدا';
}

function getDepositBankLabel(isCash: boolean, defaultLabel: string) {
  return isCash ? 'سيتم الإيداع في' : defaultLabel;
}

function QRCodeSVG({ value, size = 100, alt }: { value: string; size?: number; alt: string }) {
  const [dataUrl, setDataUrl] = useState('');
  useEffect(() => {
    let mounted = true;
    QRCode.toDataURL(value, { width: size, margin: 1, errorCorrectionLevel: 'M' })
      .then(url => { if (mounted) setDataUrl(url); })
      .catch(() => { if (mounted) setDataUrl(''); });
    return () => { mounted = false; };
  }, [value, size]);
  return dataUrl ? <img src={dataUrl} alt={alt} width={size} height={size} className="border" /> : <div className="animate-pulse bg-muted" style={{ width: size, height: size }} />;
}

function getReceiptCustomFieldRows(receipt: any, settings?: Record<string, unknown>) {
  let values: Record<string, unknown> = {};
  try {
    const parsed = typeof receipt.customFields === 'string' ? JSON.parse(receipt.customFields) : receipt.customFields;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) values = parsed;
  } catch {
    values = {};
  }
  return getReceiptFormPresentation(settings).customFields
    .map(field => ({ label: field.label, value: values[field.id] }))
    .filter(row => typeof row.value === 'string' && row.value.trim().length > 0) as Array<{ label: string; value: string }>;
}

function PrintableReceipt({ receipt, customer, company, paymentMethod, bank, paymentFor, delegateName, printSettings }: any) {
  const { labelFor } = useSystemLabels();
  const qrData = JSON.stringify({
    serial: receipt.serialNumber,
    amount: receipt.amount,
    date: receipt.createdAt,
    customer: customer?.name,
  });
  const { logoSize, headerHeight, footerHeight, headerText, footerText, headerFlexDirection, accentColor, titleFontSize, showBarcode } = getPrintPresentation(printSettings, company?.companyName);
  const customFieldRows = getReceiptCustomFieldRows(receipt, printSettings);
  const statusLabel = receipt.status === 'approved'
    ? labelFor('status_approved', 'معتمد')
    : receipt.status === 'issued'
      ? labelFor('status_issued', 'تم الإصدار')
      : receipt.status === 'rejected'
        ? labelFor('status_rejected', 'مرفوض')
        : labelFor('status_draft', 'مسودة');

  const companyName = (headerText || company?.companyName || 'شركة الأسمدة المتحدة السعودية').replace(/\s+/g, ' ').trim();
  const statement = getReceiptStatement(receipt.invoices, paymentFor).join(' — ');
  const customerStatement = String(receipt.customerStatement || '').trim();
  const customerIdentity = [customer?.name || '-', customerStatement].filter(Boolean).join('\n');
  const paymentMethodName = typeof paymentMethod === 'string' ? paymentMethod : paymentMethod?.name || '-';
  const isCash = isCashPaymentMethod(paymentMethod);
  const detailRows = [
    { rightLabel: labelFor('field_customer_name', 'اسم العميل'), rightValue: customerIdentity, leftLabel: labelFor('field_customer_number', 'رقم العميل'), leftValue: customer?.customerNumber || '-' },
    { rightLabel: labelFor('field_amount', 'المبلغ'), rightValue: `${parseFloat(receipt.amount).toLocaleString('ar-SA')} ريال`, leftLabel: labelFor('field_amount_in_words', 'المبلغ كتابة'), leftValue: receipt.amountInWords || numberToArabicWords(parseFloat(receipt.amount)) },
    { rightLabel: labelFor('field_payment_method', 'طريقة الدفع'), rightValue: paymentMethodName, leftLabel: getDepositBankLabel(isCash, labelFor('field_bank', 'البنك')), leftValue: bank || '-' },
    { rightLabel: labelFor('field_payment_for', 'وذلك مقابل'), rightValue: paymentFor || '-', leftLabel: labelFor('receipts_table_invoices', 'البيان'), leftValue: statement },
    ...customFieldRows.map(row => ({ rightLabel: row.label, rightValue: String(row.value), leftLabel: '', leftValue: '' })),
    ...(receipt.notes ? [{ rightLabel: labelFor('field_notes', 'ملاحظات'), rightValue: receipt.notes, leftLabel: '', leftValue: '' }] : []),
  ];

  return (
    <div className="w-full min-w-0 bg-white px-4 py-5 text-slate-900 sm:px-6" dir="rtl" style={{ fontFamily: 'Cairo, sans-serif' }}>
      <header className="border-b-2 pb-4" style={{ borderColor: accentColor }}>
        <div className="flex flex-col gap-3" dir="rtl">
          <aside className="min-w-0 self-end text-right" dir="rtl">
            <div className="flex items-start justify-end gap-2">
              {company?.logoUrl && <img src={company.logoUrl} alt={labelFor('receipt_print_logo_alt', 'شعار الشركة')} className="shrink-0 object-contain" style={{ width: Math.min(68, logoSize), height: Math.min(68, logoSize) }} />}
              {showBarcode && <QRCodeSVG value={qrData} size={68} alt={labelFor('receipt_print_barcode_alt', 'باركود سند القبض')} />}
            </div>
            <div className="mt-2 space-y-0.5 text-[10px] leading-4 text-slate-700">
              <p><span className="font-bold">{labelFor('field_receipt_number', 'رقم السند')}:</span> <bdi dir="ltr">{receipt.serialNumber}</bdi></p>
              <p><span className="font-bold">{labelFor('field_date', 'التاريخ')}:</span> {new Date(receipt.createdAt).toLocaleDateString('ar-SA')}</p>
              <p><span className="font-bold">{labelFor('field_status', 'الحالة')}:</span> {statusLabel}</p>
            </div>
          </aside>
          <div className="min-w-0 text-center" dir="rtl">
            <h1
              className="block w-full whitespace-nowrap font-bold leading-8 tracking-[-0.04em]"
              style={{ color: accentColor, fontSize: `clamp(13px, 4.4vw, ${Math.min(20, Math.max(17, titleFontSize - 8))}px)`, whiteSpace: 'nowrap' }}
              title={companyName}
            >
              {companyName}
            </h1>
            <p className="mt-1 text-xs text-slate-600">{company?.address || 'المملكة العربية السعودية'}</p>
            <h2 className="mt-4 font-bold" style={{ color: accentColor, fontSize: Math.max(19, titleFontSize - 3) }}>{labelFor('receipt_print_title', 'سند قبض')}</h2>
            {receipt.status === 'draft' && <p className="mt-2 text-sm font-bold text-red-600">{labelFor('status_draft', 'مسودة')}</p>}
          </div>
        </div>
      </header>

      <p className="mt-4 text-right text-xs font-bold text-slate-600">
        {labelFor('receipt_print_received_from', 'استلمنا من المكرم')}
      </p>

      <table className="mt-2 w-full table-fixed border-collapse text-xs sm:text-sm">
        <tbody>
          {detailRows.map((row, index) => (
            <tr key={`${row.rightLabel}-${index}`} className="border border-slate-300">
              <th className="w-[19%] border border-slate-300 bg-slate-100 px-2 py-2 text-right font-semibold sm:px-3">{row.rightLabel}</th>
              <td className="w-[31%] whitespace-pre-line border border-slate-300 px-2 py-2 text-right leading-5 break-words sm:px-3 sm:leading-6">{row.rightValue}</td>
              <th className="w-[19%] border border-slate-300 bg-slate-100 px-2 py-2 text-right font-semibold sm:px-3">{row.leftLabel}</th>
              <td className="w-[31%] border border-slate-300 px-2 py-2 text-right leading-5 break-words sm:px-3 sm:leading-6">{row.leftValue}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-6 text-center text-sm">
        <div className="mx-auto w-44 border-b border-slate-400 pb-5" />
        <p className="mt-2 font-semibold">{labelFor('receipt_print_recipient', 'المستلم')}</p>
        <p className="mt-1 text-slate-600">{delegateName}</p>
      </div>
      {footerText && <div className="mt-6 border-t pt-3 text-center text-xs text-slate-600" style={{ minHeight: footerHeight, borderColor: accentColor }}>{footerText}</div>}
    </div>
  );
}

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('تعذر قراءة ملف إيصال التحويل'));
    reader.readAsDataURL(file);
  });
}

function escapeReceiptHtml(value: unknown) {
  return String(value ?? '-').replace(/[&<>'"]/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  }[character] || character));
}

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

function loadImage(url: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('تعذر تحميل الصورة المرفقة للتحويل إلى PDF'));
    image.src = url;
  });
}

const receiptColumnDefaults = {
  select: 4, serial: 11, date: 9, customer: 14, amount: 11,
  payment: 10, bank: 10, statement: 18, status: 13, actions: 20,
} as const;
type ReceiptColumnKey = keyof typeof receiptColumnDefaults;

function drawWrappedCanvasText(context: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
  const lines: string[] = [];
  for (const paragraph of String(text || '-').split(/\r?\n/)) {
    const words = paragraph.trim().split(/\s+/).filter(Boolean);
    if (!words.length) {
      lines.push('');
      continue;
    }
    let line = '';
    for (const word of words) {
      const nextLine = line ? `${line} ${word}` : word;
      if (line && context.measureText(nextLine).width > maxWidth) {
        lines.push(line);
        line = word;
      } else {
        line = nextLine;
      }
    }
    if (line) lines.push(line);
  }
  lines.forEach((currentLine, index) => context.fillText(currentLine, x, y + (index * lineHeight)));
  return Math.max(1, lines.length) * lineHeight;
}

export default function ReceiptsPage() {
  const { user, isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const [view, setView] = useState<'list' | 'create'>('list');
  const [form, setForm] = useState({ customerId: 0, customerStatement: '', amount: '', paymentMethodId: 0, bankId: 0, paymentForId: 0, notes: '' });
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, string>>({});
  const [customerSearch, setCustomerSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [invoices, setInvoices] = useState<{ invoiceNumber: string; invoiceAmount: string }[]>([]);
  const [previewReceipt, setPreviewReceipt] = useState<any>(null);
  const [attachmentPreviewReceipt, setAttachmentPreviewReceipt] = useState<any>(null);
  const [editingReceipt, setEditingReceipt] = useState<any>(null);
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const [filterPeriodId, setFilterPeriodId] = useState<number | null>(null);
  const [filterBranchId, setFilterBranchId] = useState<number | null>(null);
  const [filterUserId, setFilterUserId] = useState<number | null>(null);
  const [filterCustomerId, setFilterCustomerId] = useState<number | null>(null);
  const [filterStatus, setFilterStatus] = useState('');
  const [filterPaymentMethodId, setFilterPaymentMethodId] = useState<number | null>(null);
  const [filterSerialNumber, setFilterSerialNumber] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [filtersExpanded, setFiltersExpanded] = useState(false);
  const [receiptSortKey, setReceiptSortKey] = useState<'date' | 'bank' | 'paymentMethod'>('date');
  const [receiptSortDirection, setReceiptSortDirection] = useState<'asc' | 'desc'>('desc');
  const [receiptColumnWidths, setReceiptColumnWidths] = useState<Record<ReceiptColumnKey, number>>({ ...receiptColumnDefaults });
  const [resizingReceiptColumn, setResizingReceiptColumn] = useState<ReceiptColumnKey | null>(null);
  const [selectedReceipts, setSelectedReceipts] = useState<number[]>([]);
  const [preparedReceiptDownloadId, setPreparedReceiptDownloadId] = useState<number | null>(null);
  const [preparingReceiptDownloadId, setPreparingReceiptDownloadId] = useState<number | null>(null);
  const [auditReceiptId, setAuditReceiptId] = useState<number | null>(null);
  const [printAuditReceiptId, setPrintAuditReceiptId] = useState<number | null>(null);
  const [deleteReceipt, setDeleteReceipt] = useState<any>(null);
  const [decisionTarget, setDecisionTarget] = useState<{ receipt: any; decision: 'approved' | 'rejected' } | null>(null);
  const [decisionNote, setDecisionNote] = useState('');
  const [batchApprovalOpen, setBatchApprovalOpen] = useState(false);
  const receiptColumnResizeStartRef = useRef<{ column: ReceiptColumnKey; startX: number; width: number } | null>(null);
  const openedNotificationReceiptId = useRef<number | null>(null);
  const preparedReceiptDocumentsRef = useRef(new Map<number, { receiptPdf: Blob; attachmentPdf: Blob }>());
  const utils = trpc.useUtils();
  const canApprove = isAdmin || user?.userLevel === 'primary' || Boolean((user?.permissions as any)?.receiptsApprove);
  const listFilters = useMemo(() => ({
    ...(isAdmin ? {} : { userId: user?.id }),
    ...(filterPeriodId ? { periodId: filterPeriodId } : {}),
    ...(filterBranchId ? { branchId: filterBranchId } : {}),
    ...(filterUserId && canApprove ? { userId: filterUserId } : {}),
    ...(filterCustomerId ? { customerId: filterCustomerId } : {}),
    ...(filterStatus ? { status: filterStatus as 'draft' | 'issued' | 'approved' | 'rejected' } : {}),
    ...(filterPaymentMethodId ? { paymentMethodId: filterPaymentMethodId } : {}),
    ...(filterSerialNumber.trim() ? { serialNumber: filterSerialNumber.trim() } : {}),
    ...(filterStartDate ? { startDate: new Date(`${filterStartDate}T00:00:00`) } : {}),
    ...(filterEndDate ? { endDate: new Date(`${filterEndDate}T23:59:59.999`) } : {}),
  }), [canApprove, filterBranchId, filterCustomerId, filterEndDate, filterPaymentMethodId, filterPeriodId, filterSerialNumber, filterStartDate, filterStatus, filterUserId, isAdmin, user?.id]);

  const { data: receipts, refetch } = trpc.receipts.list.useQuery(listFilters);
  const { data: customers } = trpc.customers.list.useQuery({ search: customerSearch });
  const { data: allCustomers } = trpc.customers.list.useQuery({});
  const { data: inputLists } = trpc.inputLists.list.useQuery({});
  const { data: branches } = trpc.branches.list.useQuery();
  const { data: periods } = trpc.periods.list.useQuery();
  const { data: company } = trpc.company.get.useQuery();
  const { data: printSettings } = trpc.settings.getAll.useQuery();
  const { data: userDirectory } = trpc.systemUsers.directory.useQuery();
  const { data: auditLog } = trpc.receiptAudit.list.useQuery(
    auditReceiptId ? { receiptId: auditReceiptId } : undefined,
    { enabled: canApprove && auditReceiptId !== null },
  );
  const { data: printAuditLog } = trpc.receiptPrintAudit.list.useQuery(
    { receiptId: printAuditReceiptId ?? 0 },
    { enabled: printAuditReceiptId !== null },
  );
  const createMutation = trpc.receipts.create.useMutation();
  const updateMutation = trpc.receipts.update.useMutation();
  const decideMutation = trpc.receipts.decide.useMutation();
  const approveBatchMutation = trpc.receipts.approveBatch.useMutation();
  const addInvoiceMutation = trpc.receipts.addInvoice.useMutation();
  const uploadAttachmentMutation = trpc.files.uploadReceiptAttachment.useMutation();
  const deleteMutation = trpc.receipts.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف السند'); } });
  const recordPrintMutation = trpc.receiptPrintAudit.record.useMutation();

  const isLeafListItem = (item: any) => !(inputLists || []).some(child => child.parentId === item.id);
  const paymentMethods = inputLists?.filter(i => i.listType === 'payment_method' && i.isActive && isLeafListItem(i)) || [];
  const banks = inputLists?.filter(i => i.listType === 'bank' && i.isActive && isLeafListItem(i)) || [];
  const paymentFors = inputLists?.filter(i => i.listType === 'payment_for' && i.isActive && isLeafListItem(i)) || [];
  const receiptFormPresentation = getReceiptFormPresentation(printSettings);
  const receiptLabels = receiptFormPresentation.labels;

  useEffect(() => {
    if (editingReceipt || !inputLists?.length) return;
    const defaultPaymentMethodId = inputLists.find(item => item.listType === 'payment_method' && item.name.trim() === 'تحويل بنكي')?.id;
    const defaultBankId = inputLists.find(item => item.listType === 'bank' && item.name.trim() === 'الراجحي')?.id;
    const defaultPaymentForId = inputLists.find(item => item.listType === 'payment_for' && item.name.trim() === 'دفعة من الحساب')?.id;
    setForm(current => {
      const next = {
        ...current,
        paymentMethodId: current.paymentMethodId || defaultPaymentMethodId || 0,
        bankId: current.bankId || defaultBankId || 0,
        paymentForId: current.paymentForId || defaultPaymentForId || 0,
      };
      return next.paymentMethodId === current.paymentMethodId && next.bankId === current.bankId && next.paymentForId === current.paymentForId ? current : next;
    });
  }, [editingReceipt, inputLists]);

  useEffect(() => {
    const receiptId = Number(new URLSearchParams(window.location.search).get('receiptId'));
    if (!Number.isInteger(receiptId) || receiptId <= 0 || openedNotificationReceiptId.current === receiptId) return;

    utils.receipts.getById.fetch({ id: receiptId })
      .then(receipt => {
        const receiptFromList = receipts?.find(item => item.id === receiptId);
        if (!receipt && !receiptFromList) return;
        openedNotificationReceiptId.current = receiptId;
        setPreviewReceipt(receipt || receiptFromList);
      })
      .catch(() => {
        const receiptFromList = receipts?.find(item => item.id === receiptId);
        if (receiptFromList) {
          openedNotificationReceiptId.current = receiptId;
          setPreviewReceipt(receiptFromList);
          return;
        }
        toast.error('تعذر فتح سند القبض المرتبط بالإشعار');
      });
  }, [receipts, utils]);

  const resetForm = () => { setForm({ customerId: 0, customerStatement: '', amount: '', paymentMethodId: 0, bankId: 0, paymentForId: 0, notes: '' }); setCustomFieldValues({}); setSelectedCustomer(null); setCustomerSearch(''); setInvoices([]); setAttachmentFile(null); setEditingReceipt(null); };

  const amountInWords = form.amount ? numberToArabicWords(parseFloat(form.amount)) : '';
  const isPaymentForInvoices = paymentFors.find(p => p.id === form.paymentForId)?.name === 'سداد فواتير';
  const selectedPaymentMethod = paymentMethods.find(item => item.id === form.paymentMethodId);
  const selectedBank = banks.find(item => item.id === form.bankId);
  const isCashPayment = isCashPaymentMethod(selectedPaymentMethod);
  const attachmentRequired = !isCashPayment;
  const statusLabel = (status: string) => status === 'approved' ? 'معتمد' : status === 'issued' ? 'تم الإصدار' : status === 'rejected' ? 'مرفوض' : 'مسودة';
  const receiptStatement = (receipt: any) => getReceiptStatement(
    receipt.invoices,
    paymentFors.find(paymentFor => paymentFor.id === receipt.paymentForId)?.name,
  );
  const sortedReceipts = useMemo(() => [...(receipts || [])].sort((left, right) => {
    const leftValue = receiptSortKey === 'date'
      ? new Date(left.createdAt).getTime()
      : receiptSortKey === 'bank'
        ? banks.find(bank => bank.id === left.bankId)?.name || ''
        : paymentMethods.find(method => method.id === left.paymentMethodId)?.name || '';
    const rightValue = receiptSortKey === 'date'
      ? new Date(right.createdAt).getTime()
      : receiptSortKey === 'bank'
        ? banks.find(bank => bank.id === right.bankId)?.name || ''
        : paymentMethods.find(method => method.id === right.paymentMethodId)?.name || '';
    const comparison = typeof leftValue === 'number' && typeof rightValue === 'number'
      ? leftValue - rightValue
      : String(leftValue).localeCompare(String(rightValue), 'ar-SA', { sensitivity: 'base' });
    return receiptSortDirection === 'asc' ? comparison : -comparison;
  }), [banks, paymentMethods, receiptSortDirection, receiptSortKey, receipts]);
  const receiptColumnStorageKey = `receipts-column-widths-${user?.id || 'anonymous'}`;
  const toggleReceiptSort = (key: 'date' | 'bank' | 'paymentMethod') => {
    if (receiptSortKey === key) {
      setReceiptSortDirection(direction => direction === 'asc' ? 'desc' : 'asc');
      return;
    }
    setReceiptSortKey(key);
    setReceiptSortDirection(key === 'date' ? 'desc' : 'asc');
  };
  const receiptSortIndicator = (key: 'date' | 'bank' | 'paymentMethod') => receiptSortKey === key
    ? (receiptSortDirection === 'asc' ? '↑' : '↓')
    : '↕';
  const clampReceiptColumnWidth = (width: number) => Math.max(4, Math.min(30, Math.round(width * 10) / 10));
  const startReceiptColumnResize = (column: ReceiptColumnKey, event: ReactPointerEvent<HTMLButtonElement>) => {
    event.preventDefault();
    receiptColumnResizeStartRef.current = { column, startX: event.clientX, width: receiptColumnWidths[column] };
    event.currentTarget.setPointerCapture(event.pointerId);
    setResizingReceiptColumn(column);
  };
  const adjustReceiptColumnWidth = (column: ReceiptColumnKey, amount: number) => setReceiptColumnWidths(widths => ({ ...widths, [column]: clampReceiptColumnWidth(widths[column] + amount) }));
  const resizeHandle = (column: ReceiptColumnKey, label: string) => <button type="button" className={`absolute inset-y-0 left-0 z-10 w-3 cursor-col-resize touch-none border-l border-transparent focus-visible:border-primary focus-visible:outline-none ${resizingReceiptColumn === column ? 'border-primary bg-primary/15' : 'hover:border-primary/70 hover:bg-primary/10'}`} aria-label={`اسحب لتغيير عرض عمود ${label}`} onPointerDown={event => startReceiptColumnResize(column, event)} onKeyDown={event => { if (event.key === 'ArrowLeft') { event.preventDefault(); adjustReceiptColumnWidth(column, 1); } if (event.key === 'ArrowRight') { event.preventDefault(); adjustReceiptColumnWidth(column, -1); } }}><span className="sr-only">مقبض تغيير عرض عمود {label}</span></button>;
  const selectedReceiptRows = (selectedReceipts.length > 0
    ? sortedReceipts.filter(receipt => selectedReceipts.includes(receipt.id))
    : sortedReceipts);
  const explicitlySelectedReceiptRows = sortedReceipts.filter(receipt => selectedReceipts.includes(receipt.id));
  const singleSelectedReceipt = explicitlySelectedReceiptRows.length === 1 ? explicitlySelectedReceiptRows[0] : null;
  const singleReceiptWithAttachmentNeedsPreparation = Boolean(singleSelectedReceipt?.attachmentUrl);
  const isPreparingSingleReceiptDownload = Boolean(singleSelectedReceipt && preparingReceiptDownloadId === singleSelectedReceipt.id);
  const isSingleReceiptDownloadPrepared = !singleReceiptWithAttachmentNeedsPreparation
    || preparedReceiptDownloadId === singleSelectedReceipt?.id;
  const selectedIssuedReceiptRows = explicitlySelectedReceiptRows.filter(receipt => receipt.status === 'issued');
  const selectedRowsContainNonIssuedReceipt = explicitlySelectedReceiptRows.some(receipt => receipt.status !== 'issued');
  const allVisibleSelected = sortedReceipts.length > 0 && sortedReceipts.every(receipt => selectedReceipts.includes(receipt.id));

  useEffect(() => {
    const handlePointerMove = (event: PointerEvent) => {
      const resizeStart = receiptColumnResizeStartRef.current;
      if (!resizeStart) return;
      const viewportWidth = Math.max(window.innerWidth, 1);
      const nextWidth = resizeStart.width + ((resizeStart.startX - event.clientX) / viewportWidth) * 100;
      setReceiptColumnWidths(widths => ({ ...widths, [resizeStart.column]: clampReceiptColumnWidth(nextWidth) }));
    };
    const stopResize = () => {
      receiptColumnResizeStartRef.current = null;
      setResizingReceiptColumn(null);
    };
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', stopResize);
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', stopResize);
    };
  }, []);

  useEffect(() => {
    try {
      const stored = JSON.parse(window.localStorage.getItem(receiptColumnStorageKey) || 'null');
      if (!stored || typeof stored !== 'object') {
        setReceiptColumnWidths({ ...receiptColumnDefaults });
        return;
      }
      const next = { ...receiptColumnDefaults } as Record<ReceiptColumnKey, number>;
      for (const column of Object.keys(receiptColumnDefaults) as ReceiptColumnKey[]) {
        const value = Number((stored as Record<string, unknown>)[column]);
        if (Number.isFinite(value)) next[column] = clampReceiptColumnWidth(value);
      }
      setReceiptColumnWidths(next);
    } catch { setReceiptColumnWidths({ ...receiptColumnDefaults }); }
  }, [receiptColumnStorageKey]);

  useEffect(() => {
    try { window.localStorage.setItem(receiptColumnStorageKey, JSON.stringify(receiptColumnWidths)); } catch { /* التخزين محلي اختياري */ }
  }, [receiptColumnStorageKey, receiptColumnWidths]);

  const handleSaveReceipt = async (status: 'approved' | 'draft') => {
    if (!selectedCustomer || !form.amount || !form.paymentMethodId || !form.paymentForId) { toast.error('يرجى ملء البيانات المطلوبة'); return; }
    if (!editingReceipt && attachmentRequired && !attachmentFile) { toast.error('إيصال التحويل مطلوب قبل حفظ سند القبض'); return; }
    const validInvoices = invoices.filter(invoice => invoice.invoiceNumber.trim() && Number(invoice.invoiceAmount) > 0);
    if (isPaymentForInvoices && validInvoices.length === 0) { toast.error('أضف فاتورة واحدة صحيحة على الأقل'); return; }
    try {
      let attachmentUrl = editingReceipt?.attachmentUrl || undefined;
      if (attachmentFile) {
        attachmentUrl = (await uploadAttachmentMutation.mutateAsync({
          fileName: attachmentFile.name,
          dataUrl: await readFileAsDataUrl(attachmentFile),
        })).url;
      }
      const resolvedStatus: 'approved' | 'draft' | 'issued' = user?.userLevel === 'secondary' && status !== 'draft' ? 'issued' : status;
      const payload = {
        branchId: editingReceipt?.branchId || user?.branchId || branches?.[0]?.id || 1,
        userId: editingReceipt?.userId || user?.id || 1,
        customerId: selectedCustomer.id,
        customerStatement: form.customerStatement.trim() || undefined,
        amount: form.amount,
        amountInWords,
        paymentMethodId: form.paymentMethodId || undefined,
        bankId: form.bankId || undefined,
        paymentForId: form.paymentForId || undefined,
        attachmentUrl,
        notes: form.notes || undefined,
        customFields: customFieldValues,
        status: resolvedStatus,
        invoices: validInvoices,
      };
      if (editingReceipt) {
        await updateMutation.mutateAsync({ id: editingReceipt.id, data: payload });
        await refetch();
        setPreviewReceipt(await utils.receipts.getById.fetch({ id: editingReceipt.id }));
        toast.success('تم تعديل سند القبض بنجاح');
      } else {
        const result = await createMutation.mutateAsync(payload);
        const receiptId = Number((result as any)?.id);
        if (!receiptId) throw new Error('تعذر تحديد السند الذي تم إنشاؤه');
        await refetch();
        setPreviewReceipt(await utils.receipts.getById.fetch({ id: receiptId }));
        toast.success(isAdmin ? 'تم حفظ السند واعتماده وفتح المعاينة' : 'تم إصدار السند وإرساله للاعتماد');
      }
      setView('list');
      resetForm();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'تعذر حفظ سند القبض');
    }
  };

  const createAttachmentPdfBlob = async (receipt: any) => {
    if (!receipt.attachmentUrl) throw new Error('لا يمكن تنزيل الإيصال لأنه غير مرفق');
    const response = await fetch(receipt.attachmentUrl);
    if (!response.ok) throw new Error('تعذر جلب مرفق الإيصال');
    const attachment = await response.blob();
    if (attachment.type === 'application/pdf' || /\.pdf(?:[?#]|$)/i.test(receipt.attachmentUrl)) {
      return new Blob([attachment], { type: 'application/pdf' });
    }
    const imageUrl = URL.createObjectURL(attachment);
    try {
      const image = await loadImage(imageUrl);
      const pdf = new jsPDF({ orientation: image.width > image.height ? 'landscape' : 'portrait', unit: 'pt', format: 'a4', compress: true });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const scale = Math.min((pageWidth - 48) / image.width, (pageHeight - 48) / image.height);
      const width = image.width * scale;
      const height = image.height * scale;
      const canvas = document.createElement('canvas');
      canvas.width = image.width;
      canvas.height = image.height;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('تعذر تجهيز صورة الإيصال');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0);
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', (pageWidth - width) / 2, (pageHeight - height) / 2, width, height, undefined, 'FAST');
      return pdf.output('blob');
    } finally {
      URL.revokeObjectURL(imageUrl);
    }
  };

  const downloadAttachment = async (receipt: any) => {
    if (!canApprove) { toast.error('معاينة وتنزيل إيصالات التحويل متاحان للمدير أو لمن يملك صلاحية اعتماد السندات'); return; }
    try {
      downloadBlob(await createAttachmentPdfBlob(receipt), `${receipt.serialNumber}-ESAL.pdf`);
      toast.success('تم تنزيل إيصال التحويل بصيغة PDF');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'تعذر تنزيل إيصال التحويل بصيغة PDF');
    }
  };

  const createReceiptPdfBlob = async (receipt: any) => {
    try {
      // لا تعتمد على صف القائمة المختصر عند الطباعة؛ السند الكامل يتضمن الفواتير والحقول المخصصة والملاحظات نفسها المعروضة في المعاينة.
      receipt = await utils.receipts.getById.fetch({ id: receipt.id }) || receipt;
      const customer = allCustomers?.find(c => c.id === receipt.customerId);
      const paymentMethodRecord = paymentMethods.find(item => item.id === receipt.paymentMethodId);
      const paymentMethod = paymentMethodRecord?.name || '-';
      const bank = banks.find(item => item.id === receipt.bankId)?.name || '-';
      const paymentFor = paymentFors.find(item => item.id === receipt.paymentForId)?.name || '-';
      const statement = receiptStatement(receipt).join(' — ');
      const printPresentation = getPrintPresentation(printSettings, company?.companyName);
      const amount = `${Number(receipt.amount).toLocaleString('ar-SA')} ريال`;
      const customRows = getReceiptCustomFieldRows(receipt, printSettings);
      const customerStatement = String(receipt.customerStatement || '').trim();
      const customerIdentity = [customer?.name || '-', customerStatement].filter(Boolean).join('\n');
      const rows = [
        { right: [labelFor('field_customer_name', 'اسم العميل'), customerIdentity], left: [labelFor('field_customer_number', 'رقم العميل'), customer?.customerNumber || '-'] },
        { right: [labelFor('field_amount', 'المبلغ'), amount], left: [labelFor('field_amount_in_words', 'المبلغ كتابة'), receipt.amountInWords || numberToArabicWords(Number(receipt.amount))] },
        { right: [labelFor('field_payment_method', 'طريقة الدفع'), paymentMethod], left: [getDepositBankLabel(isCashPaymentMethod(paymentMethodRecord), labelFor('field_bank', 'البنك')), bank] },
        { right: [labelFor('field_payment_for', 'وذلك مقابل'), paymentFor], left: [labelFor('receipts_table_invoices', 'البيان'), statement] },
        ...customRows.map(row => ({ right: [row.label, row.value] as [string, string], left: undefined })),
        ...(receipt.notes ? [{ right: [labelFor('field_notes', 'ملاحظات'), receipt.notes] as [string, string], left: undefined }] : []),
      ] as Array<{ right: [string, string]; left?: [string, string] }>;
      const canvas = document.createElement('canvas');
      const isPortrait = printPresentation.pageOrientation === 'portrait';
      canvas.width = isPortrait ? 1240 : 1754;
      canvas.height = isPortrait ? 1754 : 1240;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('تعذر تجهيز ملف سند القبض');
      context.direction = 'rtl';
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      const pageInset = 60;
      const headerBoundary = Math.round(canvas.height * (printPresentation.headerPercent / 100));
      const footerTop = canvas.height - Math.round(canvas.height * (printPresentation.footerPercent / 100));
      const contentTop = headerBoundary;
      const contentBottom = footerTop;
      const contentHeight = contentBottom - contentTop;
      const logoSize = Math.min(isPortrait ? 108 : 132, Math.max(70, printPresentation.logoSize));
      const logoX = printPresentation.logoPosition === 'left'
        ? pageInset
        : printPresentation.logoPosition === 'center'
          ? (canvas.width - logoSize) / 2
          : canvas.width - logoSize - pageInset;
      const qrSize = Math.min(100, logoSize);
      const qrX = printPresentation.logoPosition === 'right' ? pageInset : canvas.width - qrSize - pageInset;
      if (company?.logoUrl) {
        try {
          const response = await fetch(company.logoUrl);
          if (!response.ok) throw new Error('تعذر تحميل الشعار');
          const logoUrl = URL.createObjectURL(await response.blob());
          try {
            const logo = await loadImage(logoUrl);
            context.drawImage(logo, logoX, 28, logoSize, logoSize);
          } finally {
            URL.revokeObjectURL(logoUrl);
          }
        } catch { /* يبقى السند قابلاً للتنزيل حتى إذا تعذر الوصول المؤقت للشعار */ }
      }
      if (printPresentation.showBarcode) {
        try {
          const qrValue = JSON.stringify({ serial: receipt.serialNumber, amount: receipt.amount, date: receipt.createdAt, customer: customer?.name });
          const qrUrl = await QRCode.toDataURL(qrValue, { width: 128, margin: 1, errorCorrectionLevel: 'M' });
          const qr = await loadImage(qrUrl);
          context.drawImage(qr, qrX, 32, qrSize, qrSize);
        } catch { /* يبقى السند قابلاً للتنزيل إذا تعذر توليد رمز QR */ }
      }
      const companyName = (printPresentation.headerText || company?.companyName || 'شركة الأسمدة المتحدة السعودية').replace(/\s+/g, ' ').trim();
      context.textAlign = 'center';
      context.fillStyle = printPresentation.accentColor;
      const companyTitleMaxWidth = canvas.width - (isPortrait ? 340 : 560);
      let companyTitleFontSize = isPortrait ? 38 : 48;
      context.font = `bold ${companyTitleFontSize}px Cairo, Arial, sans-serif`;
      while (context.measureText(companyName).width > companyTitleMaxWidth && companyTitleFontSize > 24) {
        companyTitleFontSize -= 2;
        context.font = `bold ${companyTitleFontSize}px Cairo, Arial, sans-serif`;
      }
      context.fillText(companyName, canvas.width / 2, 82);
      context.font = isPortrait ? '21px Cairo, Arial, sans-serif' : '25px Cairo, Arial, sans-serif';
      context.fillStyle = '#334155';
      context.fillText(company?.address || 'المملكة العربية السعودية', canvas.width / 2, 120);
      context.fillStyle = printPresentation.accentColor;
      context.textAlign = 'center';
      context.font = isPortrait ? 'bold 36px Cairo, Arial, sans-serif' : 'bold 44px Cairo, Arial, sans-serif';
      context.fillText(labelFor('receipt_print_title', 'سند قبض'), canvas.width / 2, headerBoundary - 28);
      context.textAlign = 'right';
      context.fillStyle = '#0f172a';
      context.font = isPortrait ? 'bold 19px Cairo, Arial, sans-serif' : 'bold 23px Cairo, Arial, sans-serif';
      const metaX = canvas.width - pageInset;
      const metaStart = Math.max(150, headerBoundary - 106);
      context.fillText(`${labelFor('field_receipt_number', 'رقم السند')}: \u200E${receipt.serialNumber}\u200E`, metaX, metaStart);
      context.fillText(`${labelFor('field_date', 'التاريخ')}: ${new Date(receipt.createdAt).toLocaleDateString('ar-SA')}`, metaX, metaStart + 28);
      context.fillText(`${labelFor('field_status', 'الحالة')}: ${statusLabel(receipt.status)}`, metaX, metaStart + 56);
      context.strokeStyle = printPresentation.accentColor;
      context.lineWidth = 5;
      context.beginPath();
      context.moveTo(pageInset, headerBoundary);
      context.lineTo(canvas.width - pageInset, headerBoundary);
      context.stroke();
      const contentInset = Math.max(24, Math.round(contentHeight * 0.02));
      let top = contentTop + contentInset;
      const tableX = pageInset;
      const tableWidth = canvas.width - (pageInset * 2);
      context.textAlign = 'right';
      context.fillStyle = '#475569';
      context.font = 'bold 18px Cairo, Arial, sans-serif';
      context.fillText(labelFor('receipt_print_received_from', 'استلمنا من المكرم'), canvas.width - pageInset, top + 26);
      top += 44;
      const halfWidth = tableWidth / 2;
      const leftValueWidth = halfWidth - 220;
      const rightStart = tableX + halfWidth;
      rows.forEach(({ right, left }) => {
        const isCustomerRow = right[0] === labelFor('field_customer_name', 'اسم العميل');
        const isLongRow = isCustomerRow || right[1].includes('\n') || right[0] === labelFor('receipts_table_invoices', 'البيان') || left?.[0] === labelFor('receipts_table_invoices', 'البيان');
        const rowHeight = isCustomerRow ? 86 : isLongRow ? 88 : 64;
        context.strokeStyle = '#cbd5e1';
        context.lineWidth = 2;
        context.strokeRect(tableX, top, tableWidth, rowHeight);
        context.fillStyle = '#f1f5f9';
        context.fillRect(rightStart + halfWidth - 220, top, 220, rowHeight);
        context.fillRect(tableX + leftValueWidth, top, 220, rowHeight);
        context.beginPath();
        context.moveTo(tableX + leftValueWidth, top);
        context.lineTo(tableX + leftValueWidth, top + rowHeight);
        context.moveTo(rightStart, top);
        context.lineTo(rightStart, top + rowHeight);
        context.moveTo(rightStart + halfWidth - 220, top);
        context.lineTo(rightStart + halfWidth - 220, top + rowHeight);
        context.stroke();
        context.textAlign = 'right';
        context.fillStyle = '#1e293b';
        context.font = 'bold 19px Cairo, Arial, sans-serif';
        context.fillText(right[0], canvas.width - 84, top + 40);
        context.font = '20px Cairo, Arial, sans-serif';
        drawWrappedCanvasText(context, String(right[1]), rightStart + halfWidth - 250, top + 38, halfWidth - 280, 26);
        if (left) {
          context.fillStyle = '#1e293b';
          context.font = 'bold 19px Cairo, Arial, sans-serif';
          context.fillText(left[0], tableX + leftValueWidth + 190, top + 40);
          context.font = '20px Cairo, Arial, sans-serif';
          drawWrappedCanvasText(context, String(left[1]), tableX + leftValueWidth - 28, top + 38, leftValueWidth - 48, 26);
        }
        top += rowHeight;
      });
      context.strokeStyle = printPresentation.accentColor;
      context.lineWidth = 2;
      const signatureTop = Math.min(top + Math.max(48, Math.round(contentHeight * 0.04)), contentBottom - Math.max(96, Math.round(contentHeight * 0.08)));
      context.beginPath();
      context.moveTo(canvas.width / 2 - 180, signatureTop);
      context.lineTo(canvas.width / 2 + 180, signatureTop);
      context.stroke();
      context.textAlign = 'center';
      context.fillStyle = '#1e293b';
      context.font = 'bold 20px Cairo, Arial, sans-serif';
      context.fillText(labelFor('receipt_print_recipient', 'المستلم'), canvas.width / 2, signatureTop + 38);
      context.font = '18px Cairo, Arial, sans-serif';
      context.fillText(getReceiptDelegateName(customer, userDirectory), canvas.width / 2, signatureTop + 66);
      context.strokeStyle = printPresentation.accentColor;
      context.lineWidth = 2;
      context.beginPath();
      context.moveTo(pageInset, contentBottom);
      context.lineTo(canvas.width - pageInset, contentBottom);
      context.stroke();
      if (printPresentation.footerText) {
        context.fillStyle = '#475569';
        context.font = '16px Cairo, Arial, sans-serif';
        context.fillText(printPresentation.footerText, canvas.width / 2, contentBottom + Math.min(42, Math.round((canvas.height - contentBottom) / 2)));
      }
      const pdf = new jsPDF({ orientation: printPresentation.pageOrientation, unit: 'px', format: [canvas.width, canvas.height], compress: true });
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, canvas.width, canvas.height, undefined, 'FAST');
      return pdf.output('blob');
    } catch (error) {
      throw error instanceof Error ? error : new Error('تعذر تجهيز سند القبض بصيغة PDF');
    }
  };

  const downloadReceiptDocument = async (receipt: any) => {
    try {
      downloadBlob(await createReceiptPdfBlob(receipt), `${receipt.serialNumber}.pdf`);
      toast.success('تم تنزيل سند القبض بصيغة PDF');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'تعذر تنزيل سند القبض بصيغة PDF');
    }
  };

  const prepareReceiptAndAttachment = async (receipt: any) => {
    if (!canApprove) {
      throw new Error('تنزيل إيصالات التحويل متاح للمدير أو لمن يملك صلاحية اعتماد السندات');
    }
    if (!receipt.attachmentUrl) {
      throw new Error('لا يمكن تنزيل الإيصال لأنه غير مرفق');
    }
    const cachedDocuments = preparedReceiptDocumentsRef.current.get(receipt.id);
    if (cachedDocuments) return cachedDocuments;
    setPreparingReceiptDownloadId(receipt.id);
    try {
      const [receiptPdf, attachmentPdf] = await Promise.all([createReceiptPdfBlob(receipt), createAttachmentPdfBlob(receipt)]);
      const documents = { receiptPdf, attachmentPdf };
      preparedReceiptDocumentsRef.current.set(receipt.id, documents);
      setPreparedReceiptDownloadId(receipt.id);
      return documents;
    } catch (error) {
      throw error instanceof Error ? error : new Error('تعذر تجهيز السند وإيصال التحويل بصيغة PDF');
    } finally {
      setPreparingReceiptDownloadId(currentId => currentId === receipt.id ? null : currentId);
    }
  };

  const downloadReceiptAndAttachment = (receipt: any) => {
    if (!canApprove) { toast.error('تنزيل إيصالات التحويل متاح للمدير أو لمن يملك صلاحية اعتماد السندات'); return; }
    if (!receipt.attachmentUrl) { toast.error('لا يمكن تنزيل الإيصال لأنه غير مرفق'); return; }
    const documents = preparedReceiptDocumentsRef.current.get(receipt.id);
    if (!documents) {
      void prepareReceiptAndAttachment(receipt)
        .then(() => toast.info('اكتمل تجهيز ملفي PDF. اضغط تنزيل السند مع الإيصال مرة أخرى لبدء التنزيلين.'))
        .catch(error => toast.error(error instanceof Error ? error.message : 'تعذر تجهيز السند وإيصال التحويل بصيغة PDF'));
      return;
    }
    downloadBlob(documents.receiptPdf, `${receipt.serialNumber}.pdf`);
    downloadBlob(documents.attachmentPdf, `${receipt.serialNumber}-ESAL.pdf`);
    toast.success('تم إرسال سند القبض ثم إيصال التحويل كملفي PDF متتاليين');
  };

  const createSelectedReceiptPdf = (receipt: any) => createReceiptPdfBlob(receipt);

  const printSelectedReceipts = async (includeAttachments: boolean) => {
    if (selectedReceipts.length === 0) { toast.error('حدّد سند قبض واحداً على الأقل للطباعة'); return; }
    if (selectedReceiptRows.length === 1) {
      if (includeAttachments) {
        downloadReceiptAndAttachment(selectedReceiptRows[0]);
      } else {
        await downloadReceiptDocument(selectedReceiptRows[0]);
      }
      return;
    }
    try {
      const { archive, fileName } = await buildReceiptPrintBundle({
        receipts: selectedReceiptRows,
        includeAttachments,
        createPdf: createSelectedReceiptPdf,
        createAttachmentPdf: createAttachmentPdfBlob,
      });
      downloadBlob(archive, fileName);
      toast.success(`تم تجهيز حزمة طباعة ${selectedReceiptRows.length} سند`);
    } catch (error) { toast.error(error instanceof Error ? error.message : 'تعذر تجهيز حزمة الطباعة'); }
  };

  const handleEditReceipt = (receipt: any) => {
    const customer = allCustomers?.find(c => c.id === receipt.customerId) || null;
    setEditingReceipt(receipt);
    setSelectedCustomer(customer);
    setCustomerSearch(customer?.name || '');
    setInvoices((receipt.invoices || []).map((invoice: any) => ({ invoiceNumber: invoice.invoiceNumber, invoiceAmount: String(invoice.invoiceAmount) })));
    try {
      const parsed = typeof receipt.customFields === 'string' ? JSON.parse(receipt.customFields) : receipt.customFields;
      setCustomFieldValues(parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? Object.fromEntries(Object.entries(parsed).filter(([, value]) => typeof value === 'string')) as Record<string, string> : {});
    } catch { setCustomFieldValues({}); }
    setForm({
      customerId: receipt.customerId,
      customerStatement: receipt.customerStatement || '',
      amount: String(receipt.amount || ''),
      paymentMethodId: receipt.paymentMethodId || 0,
      bankId: receipt.bankId || 0,
      paymentForId: receipt.paymentForId || 0,
      notes: receipt.notes || '',
    });
    setView('create');
  };

  const openReceiptDecision = (receipt: any, decision: 'approved' | 'rejected') => {
    if (receipt.status !== 'issued') {
      toast.error('يمكن اتخاذ القرار للسندات الصادرة فقط');
      return;
    }
    setDecisionNote('');
    setDecisionTarget({ receipt, decision });
  };

  const submitReceiptDecision = async () => {
    if (!decisionTarget) return;
    const note = decisionNote.trim();
    if (decisionTarget.decision === 'rejected' && !note) {
      toast.error('سبب الرفض مطلوب قبل رفض السند');
      return;
    }
    try {
      await decideMutation.mutateAsync({
        id: decisionTarget.receipt.id,
        decision: decisionTarget.decision,
        note: note || undefined,
      });
      await refetch();
      if (previewReceipt?.id === decisionTarget.receipt.id) setPreviewReceipt(await utils.receipts.getById.fetch({ id: decisionTarget.receipt.id }));
      toast.success(decisionTarget.decision === 'approved' ? 'تم اعتماد سند القبض' : 'تم رفض سند القبض');
      setDecisionTarget(null);
      setDecisionNote('');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'تعذر تحديث حالة السند');
    }
  };

  const submitBatchApproval = async () => {
    if (explicitlySelectedReceiptRows.length === 0) {
      toast.error('حدّد سند قبض واحداً على الأقل للاعتماد');
      return;
    }
    if (selectedRowsContainNonIssuedReceipt) {
      toast.error('الاعتماد الجماعي متاح للسندات الصادرة فقط؛ أزل السندات ذات الحالات الأخرى من التحديد');
      return;
    }
    const ids = selectedIssuedReceiptRows.map(receipt => receipt.id);
    try {
      await approveBatchMutation.mutateAsync({ ids });
      await refetch();
      if (previewReceipt && ids.includes(previewReceipt.id)) setPreviewReceipt(await utils.receipts.getById.fetch({ id: previewReceipt.id }));
      setSelectedReceipts([]);
      setBatchApprovalOpen(false);
      toast.success(`تم اعتماد ${ids.length} سند قبض وتسجيل القرارات في سجل التدقيق`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'تعذر اعتماد السندات المحددة');
    }
  };

  const toggleReceiptSelection = (receiptId: number, checked: boolean) => {
    setSelectedReceipts(previous => checked
      ? Array.from(new Set([...previous, receiptId]))
      : previous.filter(id => id !== receiptId));
    if (!checked) {
      setPreparedReceiptDownloadId(currentId => currentId === receiptId ? null : currentId);
      return;
    }
    const receipt = receipts?.find(row => row.id === receiptId);
    if (!receipt?.attachmentUrl) return;
    void prepareReceiptAndAttachment(receipt).catch(() => undefined);
  };

  const toggleAllVisibleReceipts = (checked: boolean) => {
    setSelectedReceipts(checked ? sortedReceipts.map(receipt => receipt.id) : []);
    setPreparedReceiptDownloadId(null);
  };

  const clearReceiptFilters = () => {
    setFilterPeriodId(null);
    setFilterBranchId(null);
    setFilterUserId(null);
    setFilterCustomerId(null);
    setFilterStatus('');
    setFilterPaymentMethodId(null);
    setFilterSerialNumber('');
    setFilterStartDate('');
    setFilterEndDate('');
    setSelectedReceipts([]);
    setPreparedReceiptDownloadId(null);
  };

  const exportReceipts = (format: 'xlsx' | 'pdf') => {
    if (selectedReceiptRows.length === 0) {
      toast.error('لا توجد سندات ضمن نطاق التصفية الحالي لتصديرها');
      return;
    }
    const rows = buildReceiptExportRows(selectedReceiptRows as any, {
      branches,
      users: userDirectory,
      customers: allCustomers,
      paymentMethods,
      paymentFors,
    });

    if (format === 'xlsx') {
      const worksheet = XLSX.utils.json_to_sheet(rows);
      worksheet['!rtl'] = true;
      worksheet['!cols'] = [
        { wch: 18 }, { wch: 14 }, { wch: 16 }, { wch: 22 }, { wch: 14 }, { wch: 32 }, { wch: 16 }, { wch: 20 }, { wch: 48 }, { wch: 14 },
      ];
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'سندات القبض');
      XLSX.writeFile(workbook, `سندات-القبض-${new Date().toISOString().slice(0, 10)}.xlsx`);
      toast.success(`تم تصدير ${rows.length} سند إلى Excel`);
      return;
    }

    const exportTitle = escapeReceiptHtml(labelFor('receipts_export_print_title'));
    const exportCountLabel = escapeReceiptHtml(labelFor('receipts_export_print_count'));
    const exportDateLabel = escapeReceiptHtml(labelFor('receipts_export_print_date'));
    const tableRows = rows.map(row => `<tr>${Object.values(row).map(value => `<td>${escapeReceiptHtml(value)}</td>`).join('')}</tr>`).join('');
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('تعذر فتح نافذة التصدير؛ يرجى السماح بالنوافذ المنبثقة ثم المحاولة');
      return;
    }
    printWindow.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${exportTitle}</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Tahoma,Arial,sans-serif;color:#172033;direction:rtl}h1{font-size:20px;margin:0 0 8px;color:#0f5f75}.meta{font-size:12px;color:#64748b;margin-bottom:16px}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #cbd5e1;padding:7px;text-align:right;vertical-align:top}th{background:#e0f2fe;color:#0c4a6e;font-weight:700}tr:nth-child(even){background:#f8fafc}</style></head><body><h1>${exportTitle}</h1><div class="meta">${exportCountLabel}: ${rows.length} — ${exportDateLabel}: ${new Date().toLocaleDateString('ar-SA')}</div><table><thead><tr>${Object.keys(rows[0]).map(key => `<th>${escapeReceiptHtml(key)}</th>`).join('')}</tr></thead><tbody>${tableRows}</tbody></table><script>window.onload=()=>window.print()</script></body></html>`);
    printWindow.document.close();
    toast.success('تم تجهيز التقرير للطباعة أو الحفظ بصيغة PDF');
  };

  const handlePrint = async (receipt: any, printType: 'receipt' | 'receipt_with_attachment' = 'receipt') => {
    recordPrintMutation.mutate({ receiptId: receipt.id, printType });
    const printWindow = window.open('', '_blank');
    try {
      const receiptPdf = await createReceiptPdfBlob(receipt);
      if (!printWindow) {
        downloadBlob(receiptPdf, `${receipt.serialNumber}.pdf`);
        toast.success('تم تنزيل سند القبض بصيغة PDF الجاهزة للطباعة');
        return;
      }
      const receiptPdfUrl = URL.createObjectURL(receiptPdf);
      printWindow.location.replace(receiptPdfUrl);
      window.setTimeout(() => URL.revokeObjectURL(receiptPdfUrl), 60_000);
    } catch (error) {
      printWindow?.close();
      toast.error(error instanceof Error ? error.message : 'تعذر تجهيز سند القبض للطباعة بصيغة PDF');
    }
  };

  const handlePrintWithAttachment = (receipt: any) => {
    recordPrintMutation.mutate({ receiptId: receipt.id, printType: 'receipt_with_attachment' });
    if (!receipt.attachmentUrl) {
      handlePrint(receipt);
      toast.info('تم تجهيز السند، ولا يوجد إيصال تحويل مرفق لهذا السند');
      return;
    }
    void downloadReceiptAndAttachment(receipt);
  };

  const openReceiptPreview = async (receipt: any) => {
    try {
      setPreviewReceipt(await utils.receipts.getById.fetch({ id: receipt.id }));
    } catch {
      // يبقى صف القائمة متاحاً للمراجعة إن تعذر التحديث المؤقت، من دون إيقاف المستخدم عن فتح النافذة.
      setPreviewReceipt(receipt);
      toast.error('تعذر تحديث بيانات السند كاملة؛ قد تظهر بعض التفاصيل بعد إعادة المحاولة');
    }
  };

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{labelFor('nav_receipts', 'سندات القبض')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{labelFor('receipts_subtitle', 'إنشاء وإدارة سندات القبض الإلكترونية')}</p>
        </div>
      </div>

      {/* Receipt tabs and compact record shortcuts */}
      <div className="flex flex-wrap items-center gap-2 border-b pb-2" aria-label="علامات تبويب وإجراءات سندات القبض">
        <Button size="sm" className="h-10 px-3 text-sm" onClick={() => { setView('create'); resetForm(); }}>
          <Plus className="ml-1.5 h-4 w-4" />
          {labelFor('receipts_issue', 'إصدار سند قبض')}
        </Button>
        <Button size="sm" variant={view === 'list' && !filtersExpanded ? 'default' : 'outline'} className="h-10 px-3 text-sm" onClick={() => { setView('list'); setFiltersExpanded(false); }}>
          <List className="ml-1.5 h-4 w-4" />
          {labelFor('receipts_list', 'عرض سندات القبض')}
        </Button>
        <Button size="sm" variant={view === 'list' && filtersExpanded ? 'default' : 'outline'} className="h-10 px-3 text-sm" onClick={() => { setView('list'); setFiltersExpanded(true); }}>
          <Filter className="ml-1.5 h-4 w-4" />
          {labelFor('receipts_filters_title', 'التصفية المتقدمة')}
        </Button>
        {view === 'list' && !filtersExpanded && <div id="receipt-record-tools" className="ms-auto flex items-center gap-1 border-r pr-2 dark:border-border" aria-label="اختصارات أدوات سجل السندات">
          <Button type="button" size="icon" variant="outline" className="h-9 w-9 border-emerald-300 text-emerald-800 hover:bg-emerald-50 dark:text-emerald-300" onClick={() => exportReceipts('xlsx')} aria-label={labelFor('receipts_export_excel', 'تصدير Excel')} title={labelFor('receipts_export_excel', 'تصدير Excel')}><FileSpreadsheet className="h-4 w-4" /></Button>
          <Button type="button" size="icon" variant="outline" className="h-9 w-9 border-rose-300 text-rose-800 hover:bg-rose-50 dark:text-rose-300" onClick={() => exportReceipts('pdf')} aria-label={labelFor('receipts_export_pdf', 'تصدير PDF')} title={labelFor('receipts_export_pdf', 'تصدير PDF')}><FileText className="h-4 w-4" /></Button>
          <Button type="button" size="icon" variant="outline" className="h-9 w-9" disabled={selectedReceipts.length === 0} onClick={() => void printSelectedReceipts(false)} aria-label={labelFor('receipts_print_selected', 'طباعة المحدد ZIP')} title={labelFor('receipts_print_selected', 'طباعة المحدد ZIP')}><Printer className="h-4 w-4" /></Button>
          <Button type="button" size="icon" variant="outline" className="h-9 w-9" disabled={selectedReceipts.length === 0 || (Boolean(singleSelectedReceipt) && !isSingleReceiptDownloadPrepared)} onClick={() => void printSelectedReceipts(true)} aria-label={isPreparingSingleReceiptDownload ? 'يتم تجهيز ملفي PDF للتنزيل' : labelFor('receipts_print_with_attachments', 'طباعة مع الإيصالات ZIP')} title={isPreparingSingleReceiptDownload ? 'يتم تجهيز ملفي PDF للتنزيل' : labelFor('receipts_print_with_attachments', 'طباعة مع الإيصالات ZIP')}>{isPreparingSingleReceiptDownload ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}</Button>
          {canApprove && <Button type="button" size="icon" className="h-9 w-9 bg-emerald-600 text-white hover:bg-emerald-700" disabled={explicitlySelectedReceiptRows.length === 0 || selectedRowsContainNonIssuedReceipt || approveBatchMutation.isPending} onClick={() => setBatchApprovalOpen(true)} aria-label={`اعتماد المحدد (${explicitlySelectedReceiptRows.length})`} title={`اعتماد المحدد (${explicitlySelectedReceiptRows.length})`}>{approveBatchMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}</Button>}
        </div>}
      </div>

      {view === 'create' && (
        <Card>
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div><CardTitle>{editingReceipt ? `تعديل سند القبض ${editingReceipt.serialNumber}` : receiptFormPresentation.title}</CardTitle><p className="mt-1 text-sm font-normal text-muted-foreground">{receiptFormPresentation.subtitle}</p></div>
              <div className="text-sm text-muted-foreground text-end">
                <p>{user?.fullName}</p>
                <p>{branches?.find(b => b.id === user?.branchId)?.name || 'الفرع الرئيسي'}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex flex-col gap-6 p-6">
            {/* Customer Selection */}
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('customer') }} className={receiptFormPresentation.isVisible('customer') ? 'grid grid-cols-1 gap-4 md:grid-cols-2' : 'hidden'}>
              <div className="space-y-2">
                <Label>{receiptLabels.customerSearch} *</Label>
                <Input
                  placeholder={labelFor('receipts_customer_search_placeholder', 'ابحث بالاسم أو الرقم...')}
                  value={customerSearch}
                  onChange={e => { setCustomerSearch(e.target.value); setSelectedCustomer(null); }}
                />
                {customerSearch && customers && customers.length > 0 && !selectedCustomer && (
                  <div className="border rounded-md max-h-40 overflow-y-auto shadow-md bg-popover">
                    {customers.map(c => (
                      <button key={c.id} className="w-full text-right px-3 py-2 hover:bg-accent text-sm border-b last:border-0" onClick={() => { setSelectedCustomer(c); setCustomerSearch(c.name); setForm({ ...form, customerId: c.id }); }}>
                        <span className="font-mono text-xs text-muted-foreground">{c.customerNumber}</span> - {c.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>{receiptLabels.selectedCustomer}</Label>
                <Input value={selectedCustomer ? `${selectedCustomer.customerNumber} - ${selectedCustomer.name}` : ''} readOnly className="bg-muted" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="receipt-customer-statement">بيان اختياري أسفل اسم العميل</Label>
                <Input id="receipt-customer-statement" value={form.customerStatement} maxLength={300} onChange={event => setForm({ ...form, customerStatement: event.target.value })} placeholder="مثال: محمد أحمد سيد" />
                <p className="text-xs text-muted-foreground">يظهر هذا البيان تحت اسم العميل في المعاينة والمطبوعات والسجل.</p>
              </div>
            </div>

            {/* Amount */}
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('amount') }} className={receiptFormPresentation.isVisible('amount') ? 'grid grid-cols-1 gap-4 md:grid-cols-2' : 'hidden'}>
              <div className="space-y-2">
                <Label>{receiptLabels.amount} *</Label>
                <Input type="number" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="0.00" className="text-lg font-bold" />
              </div>
              <div className="space-y-2">
                <Label>{receiptLabels.amountInWords}</Label>
                <Input value={amountInWords} readOnly className="bg-muted text-sm" />
              </div>
            </div>

            {/* Payment Details */}
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('payment') }} className={receiptFormPresentation.isVisible('payment') ? 'grid grid-cols-1 gap-4 rounded-xl border border-primary/15 bg-primary/[0.025] p-4 md:grid-cols-3' : 'hidden'}>
              <div className="space-y-2">
                <Label>{receiptLabels.paymentMethod}</Label>
                <Select value={form.paymentMethodId?.toString() || ''} onValueChange={v => { const paymentMethodId = parseInt(v); const nextPaymentMethod = paymentMethods.find(item => item.id === paymentMethodId); setForm({ ...form, paymentMethodId }); if (isCashPaymentMethod(nextPaymentMethod)) setAttachmentFile(null); }}>
                  <SelectTrigger className="min-h-11 bg-background"><SelectValue placeholder={labelFor('receipts_select_payment_method', 'اختر طريقة الدفع')} /></SelectTrigger>
                  <SelectContent>{paymentMethods.map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{getDepositBankLabel(isCashPayment, receiptLabels.bank)}</Label>
                <Select value={form.bankId?.toString() || ''} onValueChange={v => setForm({ ...form, bankId: parseInt(v) })}>
                  <SelectTrigger className="min-h-11 bg-background"><SelectValue placeholder={labelFor('receipts_select_bank', 'اختر البنك')} /></SelectTrigger>
                  <SelectContent>{banks.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
                {isCashPayment && <p className="text-xs font-medium text-primary">سيتم الإيداع في: {selectedBank?.name || 'اختر البنك'}</p>}
              </div>
              <div className="space-y-2">
                <Label>{receiptLabels.paymentFor}</Label>
                <Select value={form.paymentForId?.toString() || ''} onValueChange={v => setForm({ ...form, paymentForId: parseInt(v) })}>
                  <SelectTrigger className="min-h-11 bg-background"><SelectValue placeholder={labelFor('receipts_select_payment_for', 'اختر المقابل')} /></SelectTrigger>
                  <SelectContent>{paymentFors.map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            {/* Invoices (if payment for invoices) */}
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('invoices') }} className={receiptFormPresentation.isVisible('invoices') ? '' : 'hidden'}>{isPaymentForInvoices && (
              <div className="space-y-3 p-4 border rounded-lg bg-muted/30">
                <Label className="font-semibold">{receiptLabels.invoices}</Label>
                {invoices.map((inv, i) => (
                  <div key={i} className="grid grid-cols-2 gap-2">
                    <Input placeholder={labelFor('receipts_invoice_number_placeholder', 'رقم الفاتورة')} value={inv.invoiceNumber} onChange={e => { const newInv = [...invoices]; newInv[i].invoiceNumber = e.target.value; setInvoices(newInv); }} />
                    <Input placeholder={labelFor('receipts_invoice_amount_placeholder', 'قيمة الفاتورة')} type="number" value={inv.invoiceAmount} onChange={e => { const newInv = [...invoices]; newInv[i].invoiceAmount = e.target.value; setInvoices(newInv); }} />
                  </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={() => setInvoices([...invoices, { invoiceNumber: '', invoiceAmount: '' }])}>
                  <Plus className="h-3 w-3 ml-1" /> {labelFor('receipts_add_invoice', 'إضافة فاتورة')}
                </Button>
                {invoices.length > 0 && form.amount && (
                  <p className={`text-xs ${parseFloat(invoices.reduce((s, i) => s + parseFloat(i.invoiceAmount || '0'), 0).toFixed(2)) !== parseFloat(form.amount) ? 'text-destructive' : 'text-green-600'}`}>
                    {labelFor('receipts_invoices_total', 'إجمالي الفواتير')}: {invoices.reduce((s, i) => s + parseFloat(i.invoiceAmount || '0'), 0).toFixed(2)} ريال
                    {parseFloat(invoices.reduce((s, i) => s + parseFloat(i.invoiceAmount || '0'), 0).toFixed(2)) !== parseFloat(form.amount) && ' - لا يساوي إجمالي السند'}
                  </p>
                )}
              </div>
            )}</div>

            {/* Notes */}
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('attachment') }} className={receiptFormPresentation.isVisible('attachment') ? 'space-y-2' : 'hidden'}>
              <FileDropzone label={`${receiptLabels.attachment}${attachmentRequired && !editingReceipt ? ' *' : ''}`} description={`${attachmentRequired ? 'المرفق إلزامي لطريقة الدفع المختارة.' : 'المرفق اختياري لطريقة الدفع النقدي.'} يُرفع الملف فقط عند حفظ السند.`} accept="image/png,image/jpeg,image/webp,application/pdf" maxBytes={5 * 1024 * 1024} previewImage={false} disabled={createMutation.isPending || updateMutation.isPending || uploadAttachmentMutation.isPending} isUploading={uploadAttachmentMutation.isPending} onFileSelected={file => { setAttachmentFile(file); toast.success(`تم اختيار المرفق: ${file.name}`); }} onClear={() => setAttachmentFile(null)} />
            </div>
            <div style={{ order: receiptFormPresentation.sectionOrder.indexOf('notes') }} className={receiptFormPresentation.isVisible('notes') ? 'space-y-2' : 'hidden'}>
              <Label>{receiptLabels.notes}</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} />
            </div>

            {receiptFormPresentation.customFields.length > 0 && <div style={{ order: receiptFormPresentation.sectionOrder.length + 1 }} className="grid gap-4 rounded-xl border border-dashed bg-muted/20 p-4 md:grid-cols-2">
              {receiptFormPresentation.customFields.map(field => <div key={field.id} className={field.type === 'textarea' ? 'space-y-2 md:col-span-2' : 'space-y-2'}>
                <Label htmlFor={`custom-receipt-${field.id}`}>{field.label}{field.required && <span className="mr-1 text-destructive">*</span>}</Label>
                {field.type === 'textarea' ? <Textarea id={`custom-receipt-${field.id}`} value={customFieldValues[field.id] || ''} onChange={event => setCustomFieldValues(current => ({ ...current, [field.id]: event.target.value }))} rows={3} maxLength={500} /> : field.type === 'select' ? <Select value={customFieldValues[field.id] || ''} onValueChange={value => setCustomFieldValues(current => ({ ...current, [field.id]: value }))}><SelectTrigger id={`custom-receipt-${field.id}`} className="bg-background"><SelectValue placeholder={`اختر ${field.label}`} /></SelectTrigger><SelectContent>{field.options.map(option => <SelectItem value={option} key={option}>{option}</SelectItem>)}</SelectContent></Select> : <Input id={`custom-receipt-${field.id}`} type={field.type} value={customFieldValues[field.id] || ''} onChange={event => setCustomFieldValues(current => ({ ...current, [field.id]: event.target.value }))} maxLength={500} />}
              </div>)}
            </div>}

            {/* Actions */}
            <div className="flex gap-3 border-t pt-4" style={{ order: 999 }}>
              <Button type="button" onClick={() => handleSaveReceipt('approved')} disabled={createMutation.isPending || updateMutation.isPending || uploadAttachmentMutation.isPending} className="flex-1">
                {createMutation.isPending || updateMutation.isPending || uploadAttachmentMutation.isPending ? 'جاري الحفظ...' : isAdmin ? (editingReceipt ? 'حفظ التعديلات واعتماد' : 'حفظ واعتماد') : (editingReceipt ? 'حفظ التعديلات وإصدار' : 'حفظ وإصدار')}
              </Button>
              <Button type="button" variant="secondary" onClick={() => {
                handleSaveReceipt('draft');
              }} disabled={createMutation.isPending || updateMutation.isPending || uploadAttachmentMutation.isPending}>{labelFor('receipts_save_draft', 'حفظ كمسودة')}</Button>
              <Button type="button" variant="outline" onClick={resetForm}>{labelFor('receipts_new', 'سند جديد')}</Button>
              <Button type="button" variant="ghost" onClick={() => setView('list')}>{labelFor('receipts_exit', 'خروج')}</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {view === 'list' && (
        <Card className="overflow-hidden">
          {filtersExpanded && <CardHeader className="border-b bg-gradient-to-l from-sky-50 via-background to-emerald-50/70 py-3 dark:from-sky-950/30 dark:via-background dark:to-emerald-950/20">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-base"><Filter className="h-4 w-4 text-primary" />{labelFor('receipts_filters_title', 'التصفية المتقدمة لسجل السندات')}</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">{labelFor('receipts_filters_description', 'صفِّ السجل ثم حدِّد السندات المطلوبة أو صدِّر جميع النتائج الظاهرة.')}</p>
                </div>
                <Button type="button" size="sm" variant="outline" onClick={clearReceiptFilters}>{labelFor('receipts_reset_filters', 'إعادة ضبط التصفية')}</Button>
              </div>
              <div id="receipt-advanced-filters" className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <div className="space-y-1"><Label className="text-xs">{labelFor('receipts_filter_period', 'الفترة المالية')}</Label><Select value={filterPeriodId?.toString() || 'all'} onValueChange={value => setFilterPeriodId(value === 'all' ? null : Number(value))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{labelFor('receipts_filter_all_periods', 'كل الفترات')}</SelectItem>{periods?.map(period => <SelectItem key={period.id} value={String(period.id)}>{period.name}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_branch', 'الفرع')}</Label><Select value={filterBranchId?.toString() || 'all'} onValueChange={value => setFilterBranchId(value === 'all' ? null : Number(value))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{labelFor('receipts_filter_all_branches', 'كل الفروع')}</SelectItem>{branches?.map(branch => <SelectItem key={branch.id} value={String(branch.id)}>{branch.name}</SelectItem>)}</SelectContent></Select></div>
                {canApprove && <div className="space-y-1"><Label className="text-xs">{labelFor('field_delegate', 'المندوب')}</Label><Select value={filterUserId?.toString() || 'all'} onValueChange={value => setFilterUserId(value === 'all' ? null : Number(value))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{labelFor('receipts_filter_all_delegates', 'كل المندوبين')}</SelectItem>{userDirectory?.map(systemUser => <SelectItem key={systemUser.id} value={String(systemUser.id)}>{systemUser.fullName}</SelectItem>)}</SelectContent></Select></div>}
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_customer', 'العميل')}</Label><Select value={filterCustomerId?.toString() || 'all'} onValueChange={value => setFilterCustomerId(value === 'all' ? null : Number(value))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent className="max-h-72"><SelectItem value="all">{labelFor('receipts_filter_all_customers', 'كل العملاء')}</SelectItem>{allCustomers?.map(customer => <SelectItem key={customer.id} value={String(customer.id)}>{customer.customerNumber} — {customer.name}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_status', 'الحالة')}</Label><Select value={filterStatus || 'all'} onValueChange={value => setFilterStatus(value === 'all' ? '' : value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{labelFor('receipts_filter_all_statuses', 'كل الحالات')}</SelectItem><SelectItem value="draft">{labelFor('status_draft', 'مسودة')}</SelectItem><SelectItem value="issued">{labelFor('status_issued', 'تم الإصدار')}</SelectItem><SelectItem value="approved">{labelFor('status_approved', 'معتمد')}</SelectItem><SelectItem value="rejected">{labelFor('status_rejected', 'مرفوض')}</SelectItem></SelectContent></Select></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_payment_method', 'طريقة الدفع')}</Label><Select value={filterPaymentMethodId?.toString() || 'all'} onValueChange={value => setFilterPaymentMethodId(value === 'all' ? null : Number(value))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{labelFor('receipts_filter_all_payment_methods', 'كل الطرق')}</SelectItem>{paymentMethods.map(method => <SelectItem key={method.id} value={String(method.id)}>{method.name}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_from_date', 'من تاريخ')}</Label><Input type="date" value={filterStartDate} onChange={event => setFilterStartDate(event.target.value)} /></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('field_to_date', 'إلى تاريخ')}</Label><Input type="date" value={filterEndDate} onChange={event => setFilterEndDate(event.target.value)} /></div>
                <div className="space-y-1"><Label className="text-xs">{labelFor('receipts_filter_serial_number', 'الرقم التسلسلي')}</Label><Input value={filterSerialNumber} onChange={event => setFilterSerialNumber(event.target.value)} placeholder={labelFor('receipts_filter_serial_number_placeholder', 'مثال: RYD-0001')} /></div>
              </div>
          </CardHeader>}
          <CardContent className="p-0">
            <div className="w-full overflow-hidden">
              <Table className="w-full table-fixed text-xs">
                <TableHeader>
                  <TableRow className="bg-muted/65 hover:bg-muted/65">
                    <TableHead className="relative px-1" style={{ width: `${receiptColumnWidths.select}%` }}><Checkbox aria-label={labelFor('receipts_select_all', 'تحديد جميع السندات الظاهرة')} checked={allVisibleSelected} onCheckedChange={checked => toggleAllVisibleReceipts(checked === true)} />{resizeHandle('select', 'التحديد')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.serial}%` }}>{labelFor('receipts_table_number', 'الرقم')}{resizeHandle('serial', 'الرقم')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.date}%` }} aria-sort={receiptSortKey === 'date' ? (receiptSortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}><button type="button" className="inline-flex items-center gap-1 rounded text-right hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => toggleReceiptSort('date')}>{labelFor('receipts_table_date', 'التاريخ')}<span aria-hidden="true">{receiptSortIndicator('date')}</span><span className="sr-only">ترتيب حسب التاريخ</span></button>{resizeHandle('date', 'التاريخ')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.customer}%` }}>{labelFor('receipts_table_customer', 'العميل')}{resizeHandle('customer', 'العميل')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.amount}%` }}>{labelFor('receipts_table_amount', 'المبلغ')}{resizeHandle('amount', 'المبلغ')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.payment}%` }} aria-sort={receiptSortKey === 'paymentMethod' ? (receiptSortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}><button type="button" className="inline-flex items-center gap-1 rounded text-right hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => toggleReceiptSort('paymentMethod')}>{labelFor('receipts_table_payment', 'الدفع')}<span aria-hidden="true">{receiptSortIndicator('paymentMethod')}</span><span className="sr-only">ترتيب حسب طريقة الدفع</span></button>{resizeHandle('payment', 'الدفع')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.bank}%` }} aria-sort={receiptSortKey === 'bank' ? (receiptSortDirection === 'asc' ? 'ascending' : 'descending') : 'none'}><button type="button" className="inline-flex items-center gap-1 rounded text-right hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => toggleReceiptSort('bank')}>{labelFor('receipts_table_bank', 'البنك')}<span aria-hidden="true">{receiptSortIndicator('bank')}</span><span className="sr-only">ترتيب حسب البنك</span></button>{resizeHandle('bank', 'البنك')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.statement}%` }}>{labelFor('receipts_table_invoices', 'البيان')}{resizeHandle('statement', 'البيان')}</TableHead>
                    <TableHead className="relative px-1.5 font-bold" style={{ width: `${receiptColumnWidths.status}%` }}>{labelFor('receipts_table_status', 'الحالة')}{resizeHandle('status', 'الحالة')}</TableHead>
                    <TableHead className="relative px-1.5 text-center font-bold" style={{ width: `${receiptColumnWidths.actions}%` }}>{labelFor('receipts_table_actions', 'إجراءات')}{resizeHandle('actions', 'الإجراءات')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedReceipts.map(r => {
                    const statementLines = receiptStatement(r);
                    return <TableRow key={r.id} className="align-top border-b-border/70 odd:bg-background even:bg-muted/20 hover:bg-primary/5">
                      <TableCell className="px-1 py-2.5"><Checkbox aria-label={`تحديد سند ${r.serialNumber}`} checked={selectedReceipts.includes(r.id)} onCheckedChange={checked => toggleReceiptSelection(r.id, checked === true)} /></TableCell>
                      <TableCell className="px-1.5 py-2.5 font-mono text-xs font-bold leading-5 break-words text-foreground">{r.serialNumber}</TableCell>
                      <TableCell className="px-1.5 py-2.5 text-xs font-medium leading-5">{new Date(r.createdAt).toLocaleDateString('ar-SA')}</TableCell>
                      <TableCell className="px-1.5 py-2.5 text-xs leading-5 break-words"><p className="font-semibold text-foreground">{allCustomers?.find(c => c.id === r.customerId)?.name || '-'}</p><p className="text-[10px] text-muted-foreground">{allCustomers?.find(c => c.id === r.customerId)?.customerNumber || ''}</p></TableCell>
                      <TableCell className="px-1.5 py-2.5 text-sm font-extrabold leading-5 tabular-nums text-foreground">{parseFloat(r.amount).toLocaleString('ar-SA')} <span className="text-[11px] font-semibold text-muted-foreground">ريال</span></TableCell>
                      <TableCell className="px-1.5 py-2.5 text-xs font-medium leading-5 break-words">{paymentMethods.find(p => p.id === r.paymentMethodId)?.name || '-'}</TableCell>
                      <TableCell className="px-1.5 py-2.5 text-xs font-medium leading-5 break-words">{banks.find(bank => bank.id === r.bankId)?.name || '-'}</TableCell>
                      <TableCell className="px-1.5 py-2.5 text-[11px] leading-5 text-muted-foreground break-words">{statementLines.map((statementLine: string) => <p key={statementLine} className="font-medium">{statementLine}</p>)}</TableCell>
                      <TableCell className="px-1.5 py-2.5"><div className="flex flex-col items-start gap-1.5"><Badge className="whitespace-normal px-1.5 py-0.5 text-[10px] font-semibold leading-4" variant={r.status === 'approved' ? 'default' : r.status === 'rejected' ? 'destructive' : 'secondary'}>{statusLabel(r.status)}</Badge>{canApprove && r.status === 'issued' && <div className="flex gap-1"><Button type="button" variant="outline" size="sm" className="h-6 border-emerald-300 px-1.5 text-[9px] text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800" onClick={() => openReceiptDecision(r, 'approved')}><CheckCircle2 className="ml-0.5 h-3 w-3" />اعتماد</Button><Button type="button" variant="outline" size="sm" className="h-6 border-rose-300 px-1.5 text-[9px] text-rose-700 hover:bg-rose-50 hover:text-rose-800" onClick={() => openReceiptDecision(r, 'rejected')}><XCircle className="ml-0.5 h-3 w-3" />رفض</Button></div>}</div></TableCell>
                      <TableCell className="px-1.5 py-2.5 text-center">
                        <div className="flex min-w-max flex-nowrap justify-center gap-1 overflow-x-auto pb-1" role="group" aria-label={`اختصارات سند ${r.serialNumber}`}>
                          {r.attachmentUrl && canApprove && <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0 border-sky-300 text-sky-700 hover:bg-sky-50" title="معاينة الإيصال" aria-label={`معاينة إيصال ${r.serialNumber}`} onClick={() => setAttachmentPreviewReceipt(r)}><Eye className="h-4 w-4" /></Button>}
                          <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0 border-indigo-300 text-indigo-700 hover:bg-indigo-50" title="تحميل السند" aria-label={`تحميل السند ${r.serialNumber}`} onClick={() => void downloadReceiptDocument(r)}><FileDown className="h-4 w-4" /></Button>
                          <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0 border-violet-300 text-violet-700 hover:bg-violet-50" title={r.attachmentUrl ? 'تحميل السند مع الإيصال' : 'لا يوجد إيصال مرفق'} aria-label={`تحميل السند مع الإيصال ${r.serialNumber}`} disabled={!r.attachmentUrl} onClick={() => downloadReceiptAndAttachment(r)}><Download className="h-4 w-4" /></Button>
                          {isAdmin && <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0 border-amber-300 text-amber-700 hover:bg-amber-50" title="تعديل السند" aria-label={`تعديل السند ${r.serialNumber}`} onClick={() => handleEditReceipt(r)}><Pencil className="h-4 w-4" /></Button>}
                          <Button type="button" variant="outline" size="icon" className="h-8 w-8 shrink-0 border-slate-300 text-slate-700 hover:bg-slate-100" title="سجل الطباعة" aria-label={`سجل طباعة السند ${r.serialNumber}`} onClick={() => setPrintAuditReceiptId(r.id)}><History className="h-4 w-4" /></Button>
                          {isAdmin && <DropdownMenu dir="rtl">
                            <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8" title={`إجراءات إضافية للسند ${r.serialNumber}`}><MoreHorizontal className="h-4 w-4" /><span className="sr-only">إجراءات إضافية</span></Button></DropdownMenuTrigger>
                            <DropdownMenuContent align="start" className="min-w-48 text-right">
                              <DropdownMenuLabel>إجراءات إدارية إضافية</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => setAuditReceiptId(r.id)}><History className="ml-2 h-4 w-4" />سجل القرارات</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteReceipt(r)}><Trash2 className="ml-2 h-4 w-4" />حذف السند</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>}
                        </div>
                      </TableCell>
                    </TableRow>;
                  })}
                  {sortedReceipts.length === 0 && <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">{labelFor('receipts_empty_filtered', 'لا توجد سندات قبض ضمن نطاق التصفية الحالي')}</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={decisionTarget !== null} onOpenChange={open => {
        if (!open && !decideMutation.isPending) {
          setDecisionTarget(null);
          setDecisionNote('');
        }
      }}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{decisionTarget?.decision === 'approved' ? 'اعتماد سند القبض' : 'رفض سند القبض'}</DialogTitle>
          </DialogHeader>
          {decisionTarget && <div className="space-y-5">
            <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-4 text-sm dark:border-sky-900 dark:bg-sky-950/30">
              <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-semibold">السند: {decisionTarget.receipt.serialNumber}</span><Badge variant="secondary">تم الإصدار</Badge></div>
              <p className="mt-2 text-muted-foreground">القيمة: <span className="font-semibold text-foreground">{Number(decisionTarget.receipt.amount).toLocaleString('ar-SA')} ريال</span></p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="receipt-decision-note">{decisionTarget.decision === 'rejected' ? 'سبب الرفض (مطلوب)' : 'ملاحظة الاعتماد (اختيارية)'}</Label>
              <Textarea id="receipt-decision-note" value={decisionNote} onChange={event => setDecisionNote(event.target.value)} placeholder={decisionTarget.decision === 'rejected' ? 'اكتب سبب الرفض بوضوح ليظهر في سجل القرارات' : 'أضف ملاحظة اختيارية للاعتماد'} className={decisionTarget.decision === 'rejected' ? 'min-h-28 border-rose-300 focus-visible:ring-rose-400' : 'min-h-28'} />
              {decisionTarget.decision === 'rejected' && <p className="text-xs text-destructive">لن يُنفذ الرفض ما لم يُدخل سبب واضح، وسيظهر السبب في سجل القرارات.</p>}
            </div>
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-start">
              <Button type="button" variant="outline" disabled={decideMutation.isPending} onClick={() => { setDecisionTarget(null); setDecisionNote(''); }}>إلغاء</Button>
              <Button type="button" disabled={decideMutation.isPending || (decisionTarget.decision === 'rejected' && !decisionNote.trim())} className={decisionTarget.decision === 'rejected' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'} onClick={() => void submitReceiptDecision()}>{decideMutation.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}{decisionTarget.decision === 'approved' ? 'تأكيد الاعتماد' : 'تأكيد الرفض'}</Button>
            </div>
          </div>}
        </DialogContent>
      </Dialog>

      <Dialog open={batchApprovalOpen} onOpenChange={open => !approveBatchMutation.isPending && setBatchApprovalOpen(open)}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تأكيد اعتماد السندات المحددة</DialogTitle></DialogHeader>
          <div className="space-y-5">
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 text-sm dark:border-emerald-900 dark:bg-emerald-950/30">
              <p className="font-semibold text-emerald-900 dark:text-emerald-200">سيتم اعتماد {selectedIssuedReceiptRows.length} سند قبض صادر.</p>
              <p className="mt-1 text-muted-foreground">يتحقق النظام من أن كل السندات المحددة ما زالت بحالة «تم الإصدار» قبل تنفيذ العملية الذرية وتسجيل قرار لكل سند.</p>
            </div>
            {selectedIssuedReceiptRows.length > 0 && <div className="rounded-lg border p-3"><p className="mb-2 text-sm font-medium">السندات المحددة</p><ul className="max-h-36 space-y-1 overflow-y-auto text-sm text-muted-foreground">{selectedIssuedReceiptRows.map(receipt => <li key={receipt.id} className="flex items-center justify-between gap-2"><span>{receipt.serialNumber}</span><span>{Number(receipt.amount).toLocaleString('ar-SA')} ريال</span></li>)}</ul></div>}
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-start">
              <Button type="button" variant="outline" disabled={approveBatchMutation.isPending} onClick={() => setBatchApprovalOpen(false)}>إلغاء</Button>
              <Button type="button" className="bg-emerald-600 hover:bg-emerald-700" disabled={approveBatchMutation.isPending || selectedIssuedReceiptRows.length === 0 || selectedRowsContainNonIssuedReceipt} onClick={() => void submitBatchApproval()}>{approveBatchMutation.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}تأكيد اعتماد المحدد</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={auditReceiptId !== null} onOpenChange={open => !open && setAuditReceiptId(null)}>
        <DialogContent className="max-h-[80vh] max-w-2xl overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><History className="h-5 w-5 text-primary" />سجل قرارات السند</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {auditLog?.map(entry => (
              <div key={entry.id} className="rounded-lg border bg-muted/20 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2"><div className="flex items-center gap-2"><Badge variant={entry.decision === 'approved' ? 'default' : 'destructive'}>{entry.decision === 'approved' ? 'اعتماد' : 'رفض'}</Badge><span className="text-sm font-medium">{userDirectory?.find(systemUser => systemUser.id === entry.decidedBy)?.fullName || 'مستخدم النظام'}</span></div><span className="text-xs text-muted-foreground">{new Date(entry.createdAt).toLocaleString('ar-SA')}</span></div>
                <p className="mt-3 text-sm">تغيرت حالة السند من <strong>{statusLabel(entry.previousStatus)}</strong> إلى <strong>{statusLabel(entry.nextStatus)}</strong>.</p>
                {entry.note && <p className="mt-2 rounded-md bg-background p-2 text-sm text-muted-foreground">الملاحظة: {entry.note}</p>}
              </div>
            ))}
            {(!auditLog || auditLog.length === 0) && <div className="py-8 text-center text-sm text-muted-foreground">لا توجد قرارات مسجلة لهذا السند حتى الآن.</div>}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={printAuditReceiptId !== null} onOpenChange={open => !open && setPrintAuditReceiptId(null)}>
        <DialogContent dir="rtl" className="max-h-[80vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader><DialogTitle>{labelFor('receipt_print_log_title')}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {printAuditLog?.length ? printAuditLog.map((entry: any) => (
              <div key={entry.id} className="rounded-lg border p-3 text-sm">
                <div className="flex items-center justify-between gap-3"><span className="font-semibold">{entry.fullName || labelFor('receipt_print_log_system_user')}</span><Badge variant="outline">{entry.printType === 'receipt_with_attachment' ? labelFor('receipt_print_log_with_attachment') : labelFor('receipt_print_log_receipt_only')}</Badge></div>
                <p className="mt-1 text-xs text-muted-foreground">{new Date(entry.createdAt).toLocaleString('ar-SA')}</p>
              </div>
            )) : <p className="py-6 text-center text-sm text-muted-foreground">{labelFor('receipt_print_log_empty')}</p>}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={attachmentPreviewReceipt !== null} onOpenChange={open => !open && setAttachmentPreviewReceipt(null)}>
        <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>{labelFor('receipts_attachment_preview_dialog_title', 'معاينة إيصال التحويل')} — {attachmentPreviewReceipt?.serialNumber}</DialogTitle></DialogHeader>
          {attachmentPreviewReceipt?.attachmentUrl && <div className="min-h-72 rounded-lg border bg-muted/20 p-2">{attachmentPreviewReceipt.attachmentUrl.toLowerCase().includes('.pdf') ? <iframe title={`إيصال التحويل ${attachmentPreviewReceipt.serialNumber}`} src={attachmentPreviewReceipt.attachmentUrl} className="h-[65vh] w-full rounded" /> : <img src={attachmentPreviewReceipt.attachmentUrl} alt={`إيصال التحويل ${attachmentPreviewReceipt.serialNumber}`} className="mx-auto max-h-[65vh] max-w-full rounded object-contain" />}</div>}
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => attachmentPreviewReceipt && downloadAttachment(attachmentPreviewReceipt)}><Download className="ml-2 h-4 w-4" />تنزيل الإيصال</Button><Button variant="secondary" onClick={() => setAttachmentPreviewReceipt(null)}>إغلاق</Button></div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={!!previewReceipt} onOpenChange={() => setPreviewReceipt(null)}>
        <DialogContent
          className="flex min-h-0 flex-col overflow-hidden p-0"
          dir="rtl"
          style={{
            width: 'min(34rem, calc(100vw - 2rem))',
            maxWidth: 'min(34rem, calc(100vw - 2rem))',
            height: '72dvh',
            maxHeight: 'calc(100dvh - 1rem)',
          }}
        >
          <DialogHeader className="shrink-0 border-b bg-background px-4 py-3 text-right sm:px-6">
            <DialogTitle>{labelFor('receipts_preview_dialog_title', 'معاينة سند القبض')}</DialogTitle>
          </DialogHeader>
          {previewReceipt && (
            <div className="min-h-0 flex-1 overflow-x-hidden overflow-y-scroll overscroll-contain bg-muted p-3" aria-label="منطقة تمرير معاينة سند القبض" data-receipt-preview-scroll tabIndex={0} style={{ WebkitOverflowScrolling: 'touch', scrollbarGutter: 'stable' }}>
              <div className="w-full overflow-hidden rounded-lg border border-border bg-white shadow-sm">
                <PrintableReceipt
                  receipt={previewReceipt}
                  customer={allCustomers?.find(c => c.id === previewReceipt.customerId)}
                  company={company}
                  paymentMethod={paymentMethods.find(p => p.id === previewReceipt.paymentMethodId)}
                  bank={banks.find(b => b.id === previewReceipt.bankId)?.name}
                  paymentFor={paymentFors.find(p => p.id === previewReceipt.paymentForId)?.name}
                  delegateName={getReceiptDelegateName(allCustomers?.find(c => c.id === previewReceipt.customerId), userDirectory)}
                  printSettings={printSettings}
                />
              </div>
            </div>
          )}
          <div className="flex shrink-0 justify-end gap-3 border-t bg-background px-4 py-3 no-print sm:px-6">
            <Button onClick={() => previewReceipt && handlePrint(previewReceipt)}>
              <Printer className="h-4 w-4 ml-2" /> طباعة
            </Button>
            <Button variant="outline" onClick={() => setPreviewReceipt(null)}>إغلاق</Button>
          </div>
        </DialogContent>
      </Dialog>
      <DeleteConfirmationDialog
        open={Boolean(deleteReceipt)}
        onOpenChange={open => !open && setDeleteReceipt(null)}
        title="تأكيد حذف سند القبض"
        itemName={`سند القبض ${deleteReceipt?.serialNumber || ''}`}
        details={[
          `العميل: ${allCustomers?.find(customer => customer.id === deleteReceipt?.customerId)?.name || '-'}`,
          `المبلغ: ${Number(deleteReceipt?.amount || 0).toLocaleString('ar-SA')} ريال`,
          `الحالة: ${deleteReceipt ? statusLabel(deleteReceipt.status) : '-'}`,
          `الفواتير المسددة: ${getReceiptInvoiceSummary(deleteReceipt?.invoices).length || 0}`,
        ]}
        isPending={deleteMutation.isPending}
        onConfirm={() => { if (deleteReceipt) deleteMutation.mutate({ id: deleteReceipt.id }); setDeleteReceipt(null); }}
      />
    </div>
  );
}
