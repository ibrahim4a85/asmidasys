type SystemUserData = {
  userType?: string | null;
  userLevel?: string | null;
  boardPosition?: string | null;
  permissions?: unknown;
};

function toPermissionRecord(permissions: unknown): Record<string, unknown> {
  if (Array.isArray(permissions)) return Object.fromEntries(permissions.map(permission => [permission, true]));
  return permissions && typeof permissions === 'object' ? { ...permissions } : {};
}

/**
 * تمنح صلاحية طلب التعميد افتراضياً للمستخدم الفرعي فقط عندما لا يكون المدير
 * قد اختار لها قيمة صريحة. وبذلك يبقى إلغاء المدير للصلاحية محفوظاً.
 */
export function applySecondaryUserApprovalRequestDefault<T extends SystemUserData>(data: T, currentUser?: SystemUserData): T {
  const userLevel = data.userLevel ?? currentUser?.userLevel;
  const userType = data.userType ?? currentUser?.userType;
  const boardPosition = data.boardPosition ?? currentUser?.boardPosition;
  const isNonSigningPartner = userType === 'authorized_partner' && boardPosition === 'شريك فقط';
  const incomingPermissions = data.permissions ?? currentUser?.permissions;
  const permissions = toPermissionRecord(incomingPermissions);

  if (userLevel !== 'secondary' || isNonSigningPartner || Object.prototype.hasOwnProperty.call(permissions, 'approvalRequest')) {
    return data;
  }

  return { ...data, permissions: { ...permissions, approvalRequest: true } } as T;
}
