import { useState, useRef } from 'react';
import { trpc } from '@/lib/trpc';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Plus, List, Printer, Trash2, Eye, Pencil } from 'lucide-react';
import { toast } from 'sonner';
import { numberToArabicWords } from '@/lib/numberToArabicWords';
import { DeleteConfirmationDialog } from '@/components/DeleteConfirmationDialog';
import { useSystemLabels } from '@/hooks/useSystemLabels';

function PrintablePayment({ payment, company }: any) {
  const { labelFor } = useSystemLabels();
  const qrData = encodeURIComponent(JSON.stringify({ serial: payment.serialNumber, amount: payment.amount, date: payment.createdAt }));
  return (
    <div className="p-8 bg-white text-black max-w-[210mm] mx-auto" dir="rtl" style={{ fontFamily: 'Cairo, sans-serif' }}>
      <div className="flex items-center justify-between border-b-2 border-red-600 pb-4 mb-6">
        <div className="text-center flex-1">
          <h1 className="text-xl font-bold">{company?.companyName || 'شركة الاسمدة المتحدة السعودية'}</h1>
          <p className="text-sm text-gray-600">{company?.address || 'المملكة العربية السعودية'}</p>
        </div>
        <img src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${qrData}`} alt={labelFor('payment_print_qr_alt', 'رمز QR لسند الصرف')} width={80} height={80} className="border" />
      </div>
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold border-2 border-red-600 inline-block px-8 py-2 rounded-lg text-red-700">{labelFor('nav_payments', 'سندات الصرف')}</h2>
      </div>
      <div className="grid grid-cols-3 gap-4 mb-6 text-sm">
        <div className="border rounded p-2"><span className="text-gray-500">{labelFor('field_serial_number', 'الرقم')}:</span> <span className="font-bold">{payment.serialNumber}</span></div>
        <div className="border rounded p-2"><span className="text-gray-500">{labelFor('field_date', 'التاريخ')}:</span> <span className="font-bold">{new Date(payment.createdAt).toLocaleDateString('ar-SA')}</span></div>
        <div className="border rounded p-2"><span className="text-gray-500">{labelFor('field_status', 'الحالة')}:</span> <span className="font-bold">{payment.status === 'approved' ? labelFor('status_approved', 'معتمد') : labelFor('status_draft', 'مسودة')}</span></div>
      </div>
      <table className="w-full border-collapse mb-6 text-sm">
        <tbody>
          <tr className="border"><td className="p-3 bg-gray-50 font-semibold w-32">{labelFor('field_beneficiary', 'المستفيد')}</td><td className="p-3">{payment.beneficiary}</td></tr>
          <tr className="border"><td className="p-3 bg-gray-50 font-semibold">{labelFor('field_amount', 'المبلغ')}</td><td className="p-3 font-bold text-lg">{parseFloat(payment.amount).toLocaleString('ar-SA')} {labelFor('currency_sar', 'ريال')}</td></tr>
          <tr className="border"><td className="p-3 bg-gray-50 font-semibold">{labelFor('field_amount_in_words', 'المبلغ كتابة')}</td><td className="p-3">{payment.amountInWords || numberToArabicWords(parseFloat(payment.amount))}</td></tr>
          {payment.expenseCategory && <tr className="border"><td className="p-3 bg-gray-50 font-semibold">{labelFor('field_expense_category', 'بند المصروف')}</td><td className="p-3">{payment.expenseCategory}</td></tr>}
          {payment.description && <tr className="border"><td className="p-3 bg-gray-50 font-semibold">{labelFor('field_description', 'البيان')}</td><td className="p-3">{payment.description}</td></tr>}
          {payment.notes && <tr className="border"><td className="p-3 bg-gray-50 font-semibold">{labelFor('field_notes', 'ملاحظات')}</td><td className="p-3">{payment.notes}</td></tr>}
        </tbody>
      </table>
      <div className="grid grid-cols-3 gap-8 mt-12 text-center text-sm">
        <div><div className="border-b border-gray-400 pb-8 mb-2"></div><p className="font-semibold">{labelFor('payment_print_recipient', 'المستلم')}</p></div>
        <div><div className="border-b border-gray-400 pb-8 mb-2"></div><p className="font-semibold">{labelFor('payment_print_accountant', 'المحاسب')}</p></div>
        <div><div className="border-b border-gray-400 pb-8 mb-2"></div><p className="font-semibold">{labelFor('payment_print_finance_manager', 'المدير المالي')}</p></div>
      </div>
    </div>
  );
}

export default function PaymentsPage() {
  const { user, isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const [view, setView] = useState<'list' | 'create'>('list');
  const [form, setForm] = useState({ beneficiary: '', amount: '', expenseCategory: '', paymentMethodId: 0, bankId: 0, description: '', notes: '' });
  const [previewPayment, setPreviewPayment] = useState<any>(null);
  const [editingPayment, setEditingPayment] = useState<any>(null);
  const [deletePayment, setDeletePayment] = useState<any>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const { data: payments, refetch } = trpc.payments.list.useQuery(isAdmin ? {} : { userId: user?.id });
  const { data: inputLists } = trpc.inputLists.list.useQuery({});
  const { data: branches } = trpc.branches.list.useQuery();
  const { data: company } = trpc.company.get.useQuery();
  const createMutation = trpc.payments.create.useMutation({ onSuccess: () => { refetch(); setView('list'); toast.success('تم إنشاء سند الصرف بنجاح'); resetForm(); } });
  const updateMutation = trpc.payments.update.useMutation({ onSuccess: () => { refetch(); setView('list'); toast.success('تم تعديل سند الصرف بنجاح'); resetForm(); } });
  const deleteMutation = trpc.payments.delete.useMutation({ onSuccess: () => { refetch(); toast.success('تم حذف السند'); } });

  const paymentMethods = inputLists?.filter(i => i.listType === 'payment_method') || [];
  const banks = inputLists?.filter(i => i.listType === 'bank') || [];

  const resetForm = () => { setForm({ beneficiary: '', amount: '', expenseCategory: '', paymentMethodId: 0, bankId: 0, description: '', notes: '' }); setEditingPayment(null); };
  const amountInWords = form.amount ? numberToArabicWords(parseFloat(form.amount)) : '';

  const handleSavePayment = () => {
    if (!form.beneficiary || !form.amount) { toast.error('يرجى ملء البيانات المطلوبة'); return; }
    const payload = {
      branchId: editingPayment?.branchId || user?.branchId || 1,
      userId: editingPayment?.userId || user?.id || 1,
      beneficiary: form.beneficiary,
      amount: form.amount,
      amountInWords,
      expenseCategory: form.expenseCategory || undefined,
      paymentMethodId: form.paymentMethodId || undefined,
      bankId: form.bankId || undefined,
      description: form.description || undefined,
      notes: form.notes || undefined,
      status: 'approved' as const,
    };
    if (editingPayment) {
      updateMutation.mutate({ id: editingPayment.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEditPayment = (payment: any) => {
    setEditingPayment(payment);
    setForm({
      beneficiary: payment.beneficiary || '',
      amount: String(payment.amount || ''),
      expenseCategory: payment.expenseCategory || '',
      paymentMethodId: payment.paymentMethodId || 0,
      bankId: payment.bankId || 0,
      description: payment.description || '',
      notes: payment.notes || '',
    });
    setView('create');
  };

  const handlePrint = (payment: any) => {
    setPreviewPayment(payment);
    setTimeout(() => {
      const printContent = printRef.current;
      if (!printContent) return;
      const printWindow = window.open('', '_blank');
      if (!printWindow) return;
      printWindow.document.write(`<html dir="rtl"><head><title>${labelFor('payment_print_window_title', 'سند صرف')} - ${payment.serialNumber}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet"><style>* { margin: 0; padding: 0; box-sizing: border-box; } body { font-family: 'Cairo', sans-serif; direction: rtl; padding: 20px; } table { border-collapse: collapse; width: 100%; } td { border: 1px solid #ddd; padding: 8px; } .font-bold { font-weight: bold; } .text-center { text-align: center; } .bg-gray-50 { background: #f9fafb; } @media print { body { padding: 0; } }</style></head><body>${printContent.innerHTML}</body></html>`);
      printWindow.document.close();
      printWindow.print();
    }, 300);
  };

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold">{labelFor('nav_payments', 'سندات الصرف')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{labelFor('payment_subtitle', 'إنشاء وإدارة سندات الصرف الإلكترونية')}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg">
        <Button size="lg" className="h-24 text-lg bg-red-600 hover:bg-red-700" onClick={() => { setView('create'); resetForm(); }}>
          <Plus className="h-6 w-6 ml-3" /> {labelFor('payment_issue', 'إصدار سند صرف')}
        </Button>
        <Button size="lg" variant="outline" className="h-24 text-lg" onClick={() => setView('list')}>
          <List className="h-6 w-6 ml-3" /> {labelFor('payment_list', 'عرض سندات الصرف')}
        </Button>
      </div>

      {view === 'create' && (
        <Card>
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <CardTitle>{editingPayment ? `${labelFor('action_edit', 'تعديل')} ${labelFor('nav_payments', 'سندات الصرف')} ${editingPayment.serialNumber}` : labelFor('payment_new', 'إصدار سند صرف جديد')}</CardTitle>
              <div className="text-sm text-muted-foreground text-end">
                <p>{user?.fullName}</p>
                <p>{branches?.find(b => b.id === user?.branchId)?.name || labelFor('payment_default_branch', 'الفرع الرئيسي')}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{labelFor('field_beneficiary', 'المستفيد')} *</Label>
                <Input value={form.beneficiary} onChange={e => setForm({ ...form, beneficiary: e.target.value })} placeholder={labelFor('field_beneficiary', 'المستفيد')} />
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_expense_category', 'بند المصروف')}</Label>
                <Input value={form.expenseCategory} onChange={e => setForm({ ...form, expenseCategory: e.target.value })} placeholder={labelFor('payment_expense_category_placeholder', 'مثال: مصاريف إدارية')} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{labelFor('field_amount', 'المبلغ')} ({labelFor('currency_sar', 'ريال')}) *</Label>
                <Input type="number" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="0.00" className="text-lg font-bold" />
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_amount_in_words', 'المبلغ كتابة')}</Label>
                <Input value={amountInWords} readOnly className="bg-muted text-sm" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{labelFor('field_payment_method', 'طريقة الدفع')}</Label>
                <Select value={form.paymentMethodId?.toString() || ''} onValueChange={v => setForm({ ...form, paymentMethodId: parseInt(v) })}>
                  <SelectTrigger><SelectValue placeholder={labelFor('action_select', 'اختر')} /></SelectTrigger>
                  <SelectContent>{paymentMethods.map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{labelFor('field_bank', 'البنك')}</Label>
                <Select value={form.bankId?.toString() || ''} onValueChange={v => setForm({ ...form, bankId: parseInt(v) })}>
                  <SelectTrigger><SelectValue placeholder={labelFor('action_select', 'اختر')} /></SelectTrigger>
                  <SelectContent>{banks.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{labelFor('field_description', 'البيان')}</Label>
              <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={2} placeholder={labelFor('payment_description_placeholder', 'وصف تفصيلي للصرف')} />
            </div>
            <div className="space-y-2">
              <Label>{labelFor('field_notes', 'ملاحظات')}</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} />
            </div>
            <div className="flex gap-3 pt-4 border-t">
              <Button onClick={handleSavePayment} disabled={createMutation.isPending || updateMutation.isPending} className="flex-1 bg-red-600 hover:bg-red-700">
                {createMutation.isPending || updateMutation.isPending ? labelFor('payment_saving', 'جارٍ الحفظ...') : labelFor('action_save', 'حفظ')}
              </Button>
              <Button variant="outline" onClick={resetForm}>{labelFor('action_add', 'إضافة')} {labelFor('nav_payments', 'سندات الصرف')}</Button>
              <Button variant="ghost" onClick={() => setView('list')}>{labelFor('action_close', 'إغلاق')}</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {view === 'list' && (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{labelFor('field_serial_number', 'الرقم')}</TableHead>
                  <TableHead>{labelFor('field_date', 'التاريخ')}</TableHead>
                  <TableHead>{labelFor('field_beneficiary', 'المستفيد')}</TableHead>
                  <TableHead>{labelFor('field_amount', 'المبلغ')}</TableHead>
                  <TableHead>{labelFor('field_expense_category', 'بند المصروف')}</TableHead>
                  <TableHead>{labelFor('field_status', 'الحالة')}</TableHead>
                  <TableHead>{labelFor('field_actions', 'إجراءات')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments?.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="font-mono text-sm">{p.serialNumber}</TableCell>
                    <TableCell>{new Date(p.createdAt).toLocaleDateString('ar-SA')}</TableCell>
                    <TableCell>{p.beneficiary}</TableCell>
                    <TableCell className="font-semibold">{parseFloat(p.amount).toLocaleString('ar-SA')} {labelFor('currency_sar', 'ريال')}</TableCell>
                    <TableCell>{p.expenseCategory || '-'}</TableCell>
                    <TableCell><Badge variant={p.status === 'approved' ? 'default' : 'secondary'}>{p.status === 'approved' ? labelFor('status_approved', 'معتمد') : labelFor('status_draft', 'مسودة')}</Badge></TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" title={labelFor('action_preview', 'معاينة')} onClick={() => setPreviewPayment(p)}><Eye className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" title={labelFor('action_print', 'طباعة')} onClick={() => handlePrint(p)}><Printer className="h-4 w-4" /></Button>
                        {isAdmin && <Button variant="ghost" size="icon" title={labelFor('action_edit', 'تعديل')} onClick={() => handleEditPayment(p)}><Pencil className="h-4 w-4" /></Button>}
                        {isAdmin && <Button variant="ghost" size="icon" className="text-destructive" title={labelFor('action_delete', 'حذف')} onClick={() => setDeletePayment(p)}><Trash2 className="h-4 w-4" /></Button>}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!payments || payments.length === 0) && (
                  <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">{labelFor('payment_empty', 'لا توجد سندات صرف')}</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!previewPayment} onOpenChange={() => setPreviewPayment(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{labelFor('payment_preview', 'معاينة سند الصرف')}</DialogTitle></DialogHeader>
          {previewPayment && <div ref={printRef}><PrintablePayment payment={previewPayment} company={company} /></div>}
          <div className="flex gap-3 justify-end mt-4">
            <Button onClick={() => previewPayment && handlePrint(previewPayment)}><Printer className="h-4 w-4 ml-2" /> {labelFor('action_print', 'طباعة')}</Button>
            <Button variant="outline" onClick={() => setPreviewPayment(null)}>{labelFor('action_close', 'إغلاق')}</Button>
          </div>
        </DialogContent>
      </Dialog>
      <DeleteConfirmationDialog
        open={Boolean(deletePayment)}
        onOpenChange={open => !open && setDeletePayment(null)}
        title="تأكيد حذف سند الصرف"
        itemName={`سند الصرف ${deletePayment?.serialNumber || ''}`}
        details={[
          `المستفيد: ${deletePayment?.beneficiary || '-'}`,
          `المبلغ: ${Number(deletePayment?.amount || 0).toLocaleString('ar-SA')} ريال`,
          `بند المصروف: ${deletePayment?.expenseCategory || '-'}`,
        ]}
        isPending={deleteMutation.isPending}
        onConfirm={() => { if (deletePayment) deleteMutation.mutate({ id: deletePayment.id }); setDeletePayment(null); }}
      />
    </div>
  );
}
