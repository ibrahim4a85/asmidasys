import { getBankCollectionDateRange } from './bankCollectionPresets';

describe('فلاتر مدة المتحصلات البنكية', () => {
  const now = new Date(2026, 7, 20, 12, 0, 0);

  it('يحسب اليوم والأمس وآخر أسبوع بالتواريخ المحلية الصحيحة', () => {
    expect(getBankCollectionDateRange('today', undefined, undefined, now)).toEqual({ startDate: '2026-08-20', endDate: '2026-08-20' });
    expect(getBankCollectionDateRange('yesterday', undefined, undefined, now)).toEqual({ startDate: '2026-08-19', endDate: '2026-08-19' });
    expect(getBankCollectionDateRange('last_week', undefined, undefined, now)).toEqual({ startDate: '2026-08-14', endDate: '2026-08-20' });
  });

  it('يمرر تاريخي الفترة المخصصة دون تغيير', () => {
    expect(getBankCollectionDateRange('custom', '2026-08-01', '2026-08-15', now)).toEqual({ startDate: '2026-08-01', endDate: '2026-08-15' });
  });
});
