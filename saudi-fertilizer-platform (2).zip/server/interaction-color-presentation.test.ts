import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

const settingsPagePath = fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url));
const themeContextPath = fileURLToPath(new URL('../client/src/contexts/ThemeContext.tsx', import.meta.url));
const globalStylesPath = fileURLToPath(new URL('../client/src/index.css', import.meta.url));
const tabsPath = fileURLToPath(new URL('../client/src/components/ui/tabs.tsx', import.meta.url));
const appPath = fileURLToPath(new URL('../client/src/App.tsx', import.meta.url));
const partnerRightsPath = fileURLToPath(new URL('../client/src/pages/PartnerRightsPage.tsx', import.meta.url));
const notFoundPath = fileURLToPath(new URL('../client/src/pages/NotFound.tsx', import.meta.url));

describe('لوحات لون التفاعل', () => {
  it('يعرض خمس لوحات حديثة ويحفظ الاختيار في إعداد مستقل', () => {
    const source = readFileSync(settingsPagePath, 'utf8');
    const context = readFileSync(themeContextPath, 'utf8');
    const styles = readFileSync(globalStylesPath, 'utf8');

    expect(source).toContain("key: 'interaction_color'");
    expect(source).toContain('لون التفاعل والتحديد');
    expect(context).toContain('type InteractionColor = "azure" | "emerald" | "violet" | "coral" | "amber"');
    expect(context).toContain('settings?.interaction_color');

    expect(context).toContain('interactionColorValues.map(value => `interaction-${value}`)');
    expect(context).toContain('`interaction-${interactionColor}`');
    for (const color of ['azure', 'emerald', 'violet', 'coral', 'amber']) {
      expect(styles).toContain(`.interaction-${color}`);
    }
  });

  it('يقصر لون التفاعل على متغيرات السطح والتركيز ولا يبدل قواعد الحالة', () => {
    const styles = readFileSync(globalStylesPath, 'utf8');
    const tabs = readFileSync(tabsPath, 'utf8');
    expect(styles).toContain('The interaction palette only controls focus, hover and selected surfaces.');
    expect(styles).not.toContain('.interaction-azure { --status-approved');
    expect(styles).not.toContain('.interaction-azure { --color-primary');
    expect(styles).toContain('.dark.interaction-azure');
    expect(tabs).toContain('data-[state=active]:border-ring data-[state=active]:bg-accent');
  });

  it('يحفظ الوضع الداكن عبر إعداد مركزي ويطبقه فوراً دون ترك سطوح الأعمال فاتحة', () => {
    const source = readFileSync(settingsPagePath, 'utf8');
    const context = readFileSync(themeContextPath, 'utf8');
    const app = readFileSync(appPath, 'utf8');
    const partnerRights = readFileSync(partnerRightsPath, 'utf8');
    const notFound = readFileSync(notFoundPath, 'utf8');

    expect(source).toContain("key: 'appearance_color_mode'");
    expect(source).toContain('applyColorMode');
    expect(context).toContain('isColorMode');
    expect(context).toContain('settings?.appearance_color_mode');
    expect(context).toContain('if (colorMode === "dark") root.classList.add("dark")');
    expect(app).toContain('bg-background');
    expect(app).toContain('text-foreground');
    expect(partnerRights).toContain('bg-popover p-0 text-popover-foreground');
    expect(partnerRights).toContain('dark:bg-sky-950/40');
    expect(notFound).toContain('from-background to-muted');
  });

  it('يربط أدوات Tailwind بمتغيرات الألوان القابلة للتبديل وقت التشغيل', () => {
    const styles = readFileSync(globalStylesPath, 'utf8');

    expect(styles).toContain('@theme {');
    expect(styles).not.toContain('@theme inline {');
    expect(styles).toContain('.dark {');
    expect(styles).toContain('.theme-green {');
    expect(styles).toContain('.interaction-emerald');
  });
});
