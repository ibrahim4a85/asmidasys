import JSZip from 'jszip';
import { describe, expect, it } from 'vitest';
import { buildReceiptPrintBundle, getReceiptPrintArchiveName } from '../client/src/lib/receiptPrintBundle';

describe('حزمة طباعة السندات المحددة', () => {
  const receipts = [
    { serialNumber: '1-26-001', attachmentUrl: 'https://files.example/receipt.pdf' },
    { serialNumber: '1-26-002', attachmentUrl: 'https://files.example/receipt.png' },
  ];

  it('ينشئ ZIP للسندات المحددة فقط باسم واضح دون الإيصالات', async () => {
    const result = await buildReceiptPrintBundle({ receipts, includeAttachments: false, createPdf: () => new Blob(['pdf']) });
    const zip = await JSZip.loadAsync(await result.archive.arrayBuffer());
    expect(result.fileName).toBe('سندات-قبض-محددة-2.zip');
    expect(Object.keys(zip.files).sort()).toEqual(['1-26-001.pdf', '1-26-002.pdf']);
  });

  it('يضيف إيصال كل سند إلى الحزمة كملف PDF باسم ESAL عند تمرير محوّل الإيصالات', async () => {
    const result = await buildReceiptPrintBundle({
      receipts,
      includeAttachments: true,
      createPdf: () => new Blob(['pdf']),
      createAttachmentPdf: () => new Blob(['attachment-pdf'], { type: 'application/pdf' }),
      fetchAttachment: async () => new Response(new Blob(['attachment']), { status: 200 }),
    });
    const zip = await JSZip.loadAsync(await result.archive.arrayBuffer());
    expect(result.fileName).toBe('سندات-قبض-محددة-2-مع-الإيصالات.zip');
    expect(Object.keys(zip.files).sort()).toEqual(['1-26-001-ESAL.pdf', '1-26-001.pdf', '1-26-002-ESAL.pdf', '1-26-002.pdf']);
  });

  it('ينتظر إنشاء PDF السند غير المتزامن قبل ضغط السند والإيصال في ملف واحد', async () => {
    const result = await buildReceiptPrintBundle({
      receipts: [receipts[0]],
      includeAttachments: true,
      createPdf: async () => new Blob(['receipt-with-logo-and-qr']),
      createAttachmentPdf: async () => new Blob(['transfer-slip-pdf'], { type: 'application/pdf' }),
      fetchAttachment: async () => new Response(new Blob(['transfer-slip']), { status: 200 }),
    });
    const zip = await JSZip.loadAsync(await result.archive.arrayBuffer());
    expect(result.fileName).toBe('سندات-قبض-محددة-1-مع-الإيصالات.zip');
    expect(Object.keys(zip.files).sort()).toEqual(['1-26-001-ESAL.pdf', '1-26-001.pdf']);
    expect(await zip.file('1-26-001.pdf')?.async('text')).toBe('receipt-with-logo-and-qr');
  });

  it('يعرض اسم الحزمة بصورة مستقلة عن عملية البناء', () => {
    expect(getReceiptPrintArchiveName(3, true)).toBe('سندات-قبض-محددة-3-مع-الإيصالات.zip');
  });
});
