ALTER TABLE `approval_requests` MODIFY COLUMN `status` enum('pending','draft','review_pending','sent','approved','rejected','postponed') NOT NULL DEFAULT 'draft';--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `approvalNumber` varchar(80);--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `requesterName` varchar(255);--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `requesterPosition` varchar(255);--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `attachmentName` varchar(255);--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewerUserId` int;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewStatus` varchar(32) DEFAULT 'not_started' NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewNote` text;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `reviewedAt` timestamp;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `submittedAt` timestamp;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `reviewerUserId` int;--> statement-breakpoint
ALTER TABLE `document_types` ADD `templateUrl` text;--> statement-breakpoint
ALTER TABLE `document_types` ADD `templateName` varchar(255);--> statement-breakpoint
ALTER TABLE `document_types` ADD `templateMimeType` varchar(100);--> statement-breakpoint
ALTER TABLE `approval_requests` ADD CONSTRAINT `approval_requests_approvalNumber_unique` UNIQUE(`approvalNumber`);