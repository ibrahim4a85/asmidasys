type SettingsValues = Record<string, unknown> | null | undefined;

function clamp(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}

export function getCompanyNameDisplaySettings(settings: SettingsValues) {
  return {
    fontSize: clamp(Number(settings?.sidebar_company_name_font_size || 12), 10, 24),
    width: clamp(Number(settings?.sidebar_company_name_width || 370), 160, 470),
  };
}
