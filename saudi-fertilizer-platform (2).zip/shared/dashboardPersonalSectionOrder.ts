export const DASHBOARD_SECTION_IDS = ['summary', 'activity', 'records', 'bank'] as const;

export type DashboardSectionId = (typeof DASHBOARD_SECTION_IDS)[number];

export function parseDashboardPersonalSectionOrder(value: unknown, fallback: readonly string[] = DASHBOARD_SECTION_IDS): string[] {
  if (!Array.isArray(value)) return [...fallback];
  const allowed = new Set(fallback);
  const seen = new Set<string>();
  const ordered = value.filter((id): id is string => {
    if (typeof id !== 'string' || !allowed.has(id) || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return ordered.length ? [...ordered, ...fallback.filter(id => !seen.has(id))] : [...fallback];
}

export function moveDashboardPersonalSection(order: readonly string[], sourceId: string, targetId: string): string[] {
  const from = order.indexOf(sourceId);
  const to = order.indexOf(targetId);
  if (from < 0 || to < 0 || from === to) return [...order];
  const next = [...order];
  next.splice(from, 1);
  next.splice(to, 0, sourceId);
  return next;
}

export function getDashboardPersonalSectionOrderKey(userId: number | string): string {
  return `dashboard-section-order:${userId}`;
}
