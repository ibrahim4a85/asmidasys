import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';

const appLayoutSource = readFileSync(new URL('../client/src/components/AppLayout.tsx', import.meta.url), 'utf8');

describe('تسميات الغلاف الحي', () => {
  it('يستعمل القاموس للنص البديل للشعار واسم الشركة الاحتياطي', () => {
    expect(appLayoutSource).toContain("alt={labelFor('login_logo_alt', 'شعار الشركة')}");
    expect(appLayoutSource).toContain("company?.companyName || labelFor('login_default_company_name', 'شركة الأسمدة المتحدة السعودية')");
  });

  it('يبقي قرارات وصول الشريط الجانبي مستقلة عن تسميات العرض', () => {
    expect(appLayoutSource).toContain("if (isAdmin) return true;");
    expect(appLayoutSource).toContain("if (item.adminOnly) return false;");
    expect(appLayoutSource).toContain("sidebar_${item.id}");
  });
});

