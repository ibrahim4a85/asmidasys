import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const settingsPage = readFileSync(fileURLToPath(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url)), 'utf8');

describe('تسميات محرر نوع دورة التعميد', () => {
  it('يوفر القيم الافتراضية ويسمح بتجاوزات العرض الإدارية', () => {
    expect(getSystemLabel(undefined, 'settings_approval_editor_add_type')).toBe('إضافة نوع تعميد');
    expect(getSystemLabel(undefined, 'settings_approval_editor_reviewers')).toBe('المراجعون');
    expect(getSystemLabel(
      { system_label_overrides: JSON.stringify({ settings_approval_editor_template_requirement: 'سياسة النموذج' }) },
      'settings_approval_editor_template_requirement',
    )).toBe('سياسة النموذج');
  });

  it('يربط تسميات العرض فقط ويبقي الحفظ والحذف والتسلسل وقرارات التعميد كما هي', () => {
    expect(settingsPage).toContain("labelFor('settings_approval_editor_add_type'");
    expect(settingsPage).toContain("labelFor('settings_approval_editor_template_requirement'");
    expect(settingsPage).toContain("labelFor('settings_approval_editor_reviewers'");
    expect(settingsPage).toContain("labelFor('settings_approval_editor_approvers'");
    expect(settingsPage).toContain("labelFor('settings_approval_editor_minimum'");
    expect(settingsPage).toContain('updateDocumentType.mutate({ id: selectedType.id, name: selectedName.trim(), templateRequirement })');
    expect(settingsPage).toContain('onClick={() => setDeleteTypeOpen(true)}');
    expect(settingsPage).toContain('saveWorkflow.mutate({ documentTypeId: Number(documentTypeId), reviewerUserIds, reviewerSequential, approverUserIds, approverSequential, requiredApprovals: required })');
    expect(settingsPage).toContain('onClick={saveTemplate}');
  });
});
