export type LoginPresentationText = {
  subtitle: string;
  copyright: string;
};

export function getLoginPresentationText(
  settings: Record<string, string | undefined> | undefined,
  companyName?: string | null,
  year = new Date().getFullYear(),
): LoginPresentationText {
  const resolvedCompanyName = companyName || 'شركة الاسمدة المتحدة السعودية';
  return {
    subtitle: settings?.login_subtitle || 'نظام الإدارة المالية المتكامل',
    copyright: settings?.login_copyright || `جميع الحقوق محفوظة © ${year} - ${resolvedCompanyName}`,
  };
}
