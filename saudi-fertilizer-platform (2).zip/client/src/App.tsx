import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider, useSystemAuth } from "./contexts/AuthContext";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import UsersManagement from "./pages/UsersManagement";
import ReceiptsPage from "./pages/ReceiptsPage";
import PaymentsPage from "./pages/PaymentsPage";
import CustomersPage from "./pages/CustomersPage";
import TargetsPage from "./pages/TargetsPage";
import SettingsPage from "./pages/SettingsPage";
import DelegatesPage from "./pages/DelegatesPage";
import ReportsPage from "./pages/ReportsPage";
import PerformanceReportsPage from "./pages/PerformanceReportsPage";
import NotificationsPage from "./pages/NotificationsPage";
import PartnerRightsPage from "./pages/PartnerRightsPage";
import NotFound from "./pages/NotFound";
import AppLayout from "./components/AppLayout";
import { hasSidebarAccess, type SidebarItemId } from '../../shared/sidebarPermissions';
import { useSystemLabels } from './hooks/useSystemLabels';

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isSessionLoading } = useSystemAuth();
  if (isSessionLoading) return <SessionVerification />;
  if (!isAuthenticated) return <Redirect to="/" />;
  return <AppLayout><Component /></AppLayout>;
}

function PermissionRoute({ component: Component, permission }: { component: React.ComponentType; permission: 'customersManage' | 'targetsManage' }) {
  const { user, isAuthenticated, isAdmin, isSessionLoading } = useSystemAuth();
  const permitted = isAdmin || (Array.isArray(user?.permissions)
    ? user.permissions.includes(permission)
    : Boolean(user?.permissions?.[permission]));
  const sidebarItem = permission === 'customersManage' ? 'customers' : 'targets';
  const sidebarAllowed = hasSidebarAccess({ isAdmin, userType: user?.userType, permissions: user?.permissions, item: sidebarItem });

  if (isSessionLoading) return <SessionVerification />;
  if (!isAuthenticated) return <Redirect to="/" />;
  if (!permitted || !sidebarAllowed) return <Redirect to="/dashboard" />;
  return <AppLayout><Component /></AppLayout>;
}

function GoalsRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isAuthenticated, isAdmin, isSessionLoading } = useSystemAuth();
  const goalPermissions = ['targetsManage', 'goalsView', 'goalsManage', 'goalsReview', 'goalsExecute', 'commissionsManage'];
  const permitted = isAdmin || (Array.isArray(user?.permissions)
    ? goalPermissions.some(permission => user.permissions.includes(permission))
    : goalPermissions.some(permission => Boolean(user?.permissions?.[permission])));
  const sidebarAllowed = hasSidebarAccess({ isAdmin, userType: user?.userType, permissions: user?.permissions, item: 'targets' });
  if (isSessionLoading) return <SessionVerification />;
  if (!isAuthenticated) return <Redirect to="/" />;
  if (!permitted || !sidebarAllowed) return <Redirect to="/dashboard" />;
  return <AppLayout><Component /></AppLayout>;
}

function SidebarPermissionRoute({ component: Component, item }: { component: React.ComponentType; item: SidebarItemId }) {
  const { user, isAuthenticated, isAdmin, isSessionLoading } = useSystemAuth();
  if (isSessionLoading) return <SessionVerification />;
  if (!isAuthenticated) return <Redirect to="/" />;
  const allowed = hasSidebarAccess({ isAdmin, userType: user?.userType, permissions: user?.permissions, item });
  if (!allowed) return <Redirect to="/dashboard" />;
  return <AppLayout><Component /></AppLayout>;
}

function SessionVerification() {
  const { labelFor } = useSystemLabels();
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground" dir="rtl">
      <p className="rounded-xl border border-border bg-card px-5 py-3 text-sm text-card-foreground shadow-sm">{labelFor('session_verification_loading')}</p>
    </main>
  );
}

/**
 * Keeps administrator-managed presentation inside the providers while the
 * outer boundary in App remains responsible for provider-level failures.
 */
function ManagedErrorBoundary({ children }: { children: React.ReactNode }) {
  const { labelFor } = useSystemLabels();
  return (
    <ErrorBoundary
      title={labelFor('error_boundary_title')}
      reloadLabel={labelFor('error_boundary_reload')}
    >
      {children}
    </ErrorBoundary>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/dashboard">{() => <SidebarPermissionRoute component={Dashboard} item="dashboard" />}</Route>
      <Route path="/users">{() => <SidebarPermissionRoute component={UsersManagement} item="users" />}</Route>
      <Route path="/receipts">{() => <SidebarPermissionRoute component={ReceiptsPage} item="receipts" />}</Route>
      <Route path="/payments">{() => <SidebarPermissionRoute component={PaymentsPage} item="payments" />}</Route>
      <Route path="/customers">{() => <PermissionRoute component={CustomersPage} permission="customersManage" />}</Route>
      <Route path="/targets">{() => <GoalsRoute component={TargetsPage} />}</Route>
      <Route path="/settings">{() => <SidebarPermissionRoute component={SettingsPage} item="settings" />}</Route>
      <Route path="/delegates">{() => <SidebarPermissionRoute component={DelegatesPage} item="delegates" />}</Route>
      <Route path="/reports">{() => <SidebarPermissionRoute component={ReportsPage} item="reports" />}</Route>
      <Route path="/partner-rights">{() => <SidebarPermissionRoute component={PartnerRightsPage} item="partner-rights" />}</Route>
      <Route path="/performance-reports">{() => <SidebarPermissionRoute component={PerformanceReportsPage} item="performance-reports" />}</Route>
      <Route path="/notifications">{() => <SidebarPermissionRoute component={NotificationsPage} item="notifications" />}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="blue">
        <AuthProvider>
          <ManagedErrorBoundary>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </ManagedErrorBoundary>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
