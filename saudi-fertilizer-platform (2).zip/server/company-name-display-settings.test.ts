import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { getCompanyNameDisplaySettings } from '../shared/companyNameDisplaySettings';

describe('إعدادات عرض اسم الشركة', () => {
  it('تستخدم القيم الافتراضية وتحد القيم المخزنة ضمن نطاق العرض الآمن', () => {
    expect(getCompanyNameDisplaySettings()).toEqual({ fontSize: 12, width: 370 });
    expect(getCompanyNameDisplaySettings({ sidebar_company_name_font_size: '30', sidebar_company_name_width: '20' })).toEqual({ fontSize: 24, width: 160 });
    expect(getCompanyNameDisplaySettings({ sidebar_company_name_font_size: '16', sidebar_company_name_width: '405' })).toEqual({ fontSize: 16, width: 405 });
  });

  it('يربط شاشة الإعدادات ورأس الشريط الجانبي بمفاتيح التخزين نفسها', () => {
    const layout = readFileSync(new URL('../client/src/components/AppLayout.tsx', import.meta.url), 'utf8');
    const settingsPage = readFileSync(new URL('../client/src/pages/SettingsPage.tsx', import.meta.url), 'utf8');
    expect(layout).toContain('getCompanyNameDisplaySettings');
    expect(layout).toContain('expandedSidebarWidth');
    expect(settingsPage).toContain('sidebar_company_name_font_size');
    expect(settingsPage).toContain('sidebar_company_name_width');
  });
});
