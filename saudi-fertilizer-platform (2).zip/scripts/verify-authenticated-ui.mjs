import { mkdir, writeFile } from 'node:fs/promises';

const baseUrl = process.env.VERIFY_BASE_URL || 'http://127.0.0.1:3000';
const username = process.env.VERIFY_USERNAME;
const password = process.env.VERIFY_PASSWORD;
if (!username || !password) throw new Error('يلزم تمرير VERIFY_USERNAME وVERIFY_PASSWORD وقت التشغيل فقط.');

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
async function getTarget() {
  const targets = await (await fetch('http://127.0.0.1:9231/json')).json();
  return targets.find(target => target.type === 'page');
}
const target = await getTarget();
if (!target) throw new Error('لم يتم العثور على صفحة متصفح تحقق.');
const socket = new WebSocket(target.webSocketDebuggerUrl);
let nextId = 0;
const pending = new Map();
socket.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (message.id) pending.get(message.id)?.(message);
});
await new Promise(resolve => socket.addEventListener('open', resolve));
function cdp(method, params = {}) {
  const id = ++nextId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, message => message.error ? reject(message.error) : resolve(message.result)));
}
async function evaluate(expression) {
  const result = await cdp('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  return result.result.value;
}
async function screenshot(label) {
  const image = await cdp('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  await mkdir('/tmp/asmidasys-auth-ui', { recursive: true });
  await writeFile(`/tmp/asmidasys-auth-ui/${label}.png`, Buffer.from(image.data, 'base64'));
}
async function fill(selector, value) {
  await evaluate(`(() => { const el = document.querySelector(${JSON.stringify(selector)}); if (!el) throw new Error('missing '+${JSON.stringify(selector)}); const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; setter.call(el, ${JSON.stringify(value)}); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); })()`);
}
await cdp('Page.navigate', { url: baseUrl });
await delay(1200);
await fill('input[placeholder*="اسم المستخدم"]', username);
await fill('input[type="password"]', password);
await evaluate(`Array.from(document.querySelectorAll('button')).find(button => button.textContent.includes('تسجيل الدخول'))?.click()`);
await delay(1600);
const afterLogin = await evaluate('location.pathname');
if (afterLogin === '/' || afterLogin === '/login') throw new Error('تعذر تسجيل الدخول بحساب التحقق.');
await cdp('Page.navigate', { url: `${baseUrl}/users` });
await delay(1100);
const usersInfo = await evaluate(`(() => ({ path: location.pathname, text: document.body.innerText, buttons: Array.from(document.querySelectorAll('button')).map(button => ({ text: button.innerText.trim(), aria: button.getAttribute('aria-label'), title: button.getAttribute('title') })) }))()`);
await screenshot('users-before');
console.log(JSON.stringify(usersInfo));
socket.close();
