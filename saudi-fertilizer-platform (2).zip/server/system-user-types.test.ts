import { describe, expect, it } from 'vitest';
import { DEFAULT_SYSTEM_USER_TYPES, readSystemUserTypeDefinitions, validateSystemUserTypeDefinitions } from '../shared/systemUserTypes';

describe('كتالوج أنواع مستخدمي النظام', () => {
  it('يوفر الأنواع النظامية المطلوبة عند عدم وجود إعداد محفوظ', () => {
    expect(readSystemUserTypeDefinitions().map(definition => definition.code)).toEqual([
      'admin', 'reviewer', 'reviewer_approver', 'delegate', 'sales_manager', 'finance_manager', 'authorized_partner',
    ]);
  });

  it('يسمح بتعديل التسمية ويحمي بقاء مدير النظام نشطاً', () => {
    const definitions = DEFAULT_SYSTEM_USER_TYPES.map(definition => definition.code === 'admin'
      ? { ...definition, label: 'إدارة المنصة', isActive: false }
      : definition);
    const result = validateSystemUserTypeDefinitions(definitions);
    expect(result.find(definition => definition.code === 'admin')).toMatchObject({ label: 'إدارة المنصة', isSystem: true, isActive: true });
  });

  it('يقبل نوعاً مخصصاً صالحاً وفريداً', () => {
    const result = validateSystemUserTypeDefinitions([
      ...DEFAULT_SYSTEM_USER_TYPES,
      { code: 'inventory_manager', label: 'مدير المخزون', category: 'custom', defaultPermissions: ['reports'], isSystem: false, isActive: true },
    ]);
    expect(result).toContainEqual(expect.objectContaining({ code: 'inventory_manager', label: 'مدير المخزون', isActive: true }));
  });

  it('يرفض الرمز غير الصحيح والرمز المكرر', () => {
    expect(() => validateSystemUserTypeDefinitions([{ code: 'رمز', label: 'غير صالح', category: 'custom', defaultPermissions: [], isSystem: false, isActive: true }])).toThrow('تحقق من رمز ومسميات وفئة أنواع المستخدمين');
    expect(() => validateSystemUserTypeDefinitions([...DEFAULT_SYSTEM_USER_TYPES, { ...DEFAULT_SYSTEM_USER_TYPES[0], label: 'مدير آخر' }])).toThrow('لا يمكن تكرار رمز نوع المستخدم');
  });
});
