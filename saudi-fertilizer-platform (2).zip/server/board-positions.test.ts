import { describe, expect, it } from 'vitest';
import { isBoardMemberPosition, normalizeBoardPosition } from '../shared/boardPositions';

describe('توحيد مناصب مجلس الإدارة', () => {
  it('يحوّل الصياغة السابقة من الواجهة إلى القيمة المعتمدة في سياسة التعميد', () => {
    expect(normalizeBoardPosition('رئيس مجلس الادارة')).toBe('رئيس مجلس الإدارة');
    expect(normalizeBoardPosition('عضو مجلس الادارة')).toBe('عضو مجلس الإدارة');
  });

  it('يحتسب الرئيس والعضو فقط ضمن سياسة موافقة عضوين ولا يحتسب الشريك فقط', () => {
    expect(isBoardMemberPosition('رئيس مجلس الإدارة')).toBe(true);
    expect(isBoardMemberPosition('عضو مجلس الادارة')).toBe(true);
    expect(isBoardMemberPosition('شريك فقط')).toBe(false);
  });
});
