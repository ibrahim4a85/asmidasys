import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getPerformanceReports: vi.fn(),
  getPerformanceReport: vi.fn(),
  getDailyReceiptMetrics: vi.fn(),
  createPerformanceReport: vi.fn(),
  updatePerformanceReport: vi.fn(),
}));

import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function systemUserContext(overrides: Partial<NonNullable<TrpcContext["systemUser"]>> = {}): TrpcContext {
  return {
    user: null,
    systemUser: {
      id: 42,
      username: "branch-user",
      fullName: "مستخدم الفرع",
      userType: "branch_supervisor",
      userLevel: "secondary",
      branchId: 5,
      permissions: {},
      ...overrides,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

describe("performanceReports", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it("يعرض للمستخدم الفرعي تقارير فرعه فقط", async () => {
    vi.mocked(db.getPerformanceReports).mockResolvedValue([]);
    const result = await appRouter.createCaller(systemUserContext()).performanceReports.list();

    expect(result).toEqual([]);
    expect(db.getPerformanceReports).toHaveBeenCalledWith({ branchId: 5 });
  });

  it("يرفض جلب متحصلات فرع لا يرتبط بالمستخدم الفرعي", async () => {
    const caller = appRouter.createCaller(systemUserContext());

    await expect(caller.performanceReports.dailyMetrics({ branchId: 9, reportDate: "2026-08-13" })).rejects.toMatchObject({
      code: "FORBIDDEN",
      message: "لا يمكنك الاطلاع على بيانات فرع آخر",
    });
  });

  it("يعرض للمستخدم الرئيسي تقارير جميع الفروع", async () => {
    vi.mocked(db.getPerformanceReports).mockResolvedValue([]);
    const caller = appRouter.createCaller(systemUserContext({ userLevel: "primary" }));

    await caller.performanceReports.list();

    expect(db.getPerformanceReports).toHaveBeenCalledWith();
  });

  it("يمنع المستخدم الفرعي من تعديل تقرير سابق دون الإذن المخصص", async () => {
    vi.mocked(db.getPerformanceReport).mockResolvedValue({ id: 77 } as never);
    const caller = appRouter.createCaller(systemUserContext());

    await expect(caller.performanceReports.save({
      branchId: 5,
      reportDate: "2000-01-01",
      salesInvoicesCount: 1,
      salesInvoicesValue: 100,
      returnsInvoicesCount: 0,
      returnsInvoicesValue: 0,
    })).rejects.toMatchObject({
      code: "FORBIDDEN",
      message: "لا تملك صلاحية تعديل تقرير سابق",
    });
  });

  it("يحفظ الصافي والمتحصلات المحسوبة من الخادم بدلاً من أي قيم مرسلة من الواجهة", async () => {
    vi.mocked(db.getPerformanceReport).mockResolvedValue(null);
    vi.mocked(db.getDailyReceiptMetrics).mockResolvedValue({ receiptsCount: 3, collectionsValue: "725.50" });
    vi.mocked(db.createPerformanceReport).mockResolvedValue({} as never);
    const caller = appRouter.createCaller(systemUserContext());

    await caller.performanceReports.save({
      branchId: 5,
      reportDate: "2026-08-13",
      salesInvoicesCount: 8,
      salesInvoicesValue: 1200,
      returnsInvoicesCount: 2,
      returnsInvoicesValue: 350,
    });

    expect(db.createPerformanceReport).toHaveBeenCalledWith(expect.objectContaining({
      branchId: 5,
      reportDate: new Date("2026-08-13T00:00:00.000Z"),
      salesInvoicesCount: 8,
      netSalesValue: "850.00",
      receiptsCount: 3,
      collectionsValue: "725.50",
      createdBy: 42,
      updatedBy: 42,
    }));
  });
});
