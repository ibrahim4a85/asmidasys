import { describe, expect, it } from 'vitest';
import { isPdfApprovalAttachment } from './approvalAttachmentPreview';

describe('معاينة مرفق طلب التعميد', () => {
  it('يعرض ملف PDF داخل نافذة المعاينة حتى عند وجود معاملات في الرابط', () => {
    expect(isPdfApprovalAttachment('طلب-تعميد.pdf', '/manus-storage/approval-attachments/request.pdf?signature=abc')).toBe(true);
  });

  it('يبقي ملفات Word ضمن مسار التنزيل بدلاً من معاينة غير مدعومة', () => {
    expect(isPdfApprovalAttachment('طلب-تعميد.docx', '/manus-storage/approval-attachments/request.docx')).toBe(false);
  });
});
