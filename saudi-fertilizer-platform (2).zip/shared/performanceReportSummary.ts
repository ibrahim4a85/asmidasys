export type PerformanceReportLike = {
  branchId: number;
  reportDate: string | Date;
  salesInvoicesCount?: string | number | null;
  salesInvoicesValue?: string | number | null;
  returnsInvoicesCount?: string | number | null;
  returnsInvoicesValue?: string | number | null;
  netSalesValue?: string | number | null;
  receiptsCount?: string | number | null;
  collectionsValue?: string | number | null;
};

const numeric = (value: string | number | null | undefined) => Number(value || 0);
const reportDay = (value: string | Date) => new Date(value).toISOString().slice(0, 10);

export function filterPerformanceReports<T extends PerformanceReportLike>(reports: T[], filters: { branchId?: string; day?: string; startDate?: string; endDate?: string }) {
  return reports.filter(report => {
    const day = reportDay(report.reportDate);
    if (filters.branchId && filters.branchId !== 'all' && String(report.branchId) !== filters.branchId) return false;
    if (filters.day && day !== filters.day) return false;
    if (filters.startDate && day < filters.startDate) return false;
    if (filters.endDate && day > filters.endDate) return false;
    return true;
  }).sort((left, right) => reportDay(right.reportDate).localeCompare(reportDay(left.reportDate)));
}

export function summarizePerformanceReports(reports: PerformanceReportLike[]) {
  return reports.reduce((result, report) => ({
    salesCount: result.salesCount + numeric(report.salesInvoicesCount),
    salesValue: result.salesValue + numeric(report.salesInvoicesValue),
    returnsCount: result.returnsCount + numeric(report.returnsInvoicesCount),
    returnsValue: result.returnsValue + numeric(report.returnsInvoicesValue),
    netSales: result.netSales + numeric(report.netSalesValue),
    receiptsCount: result.receiptsCount + numeric(report.receiptsCount),
    collectionsValue: result.collectionsValue + numeric(report.collectionsValue),
  }), { salesCount: 0, salesValue: 0, returnsCount: 0, returnsValue: 0, netSales: 0, receiptsCount: 0, collectionsValue: 0 });
}
