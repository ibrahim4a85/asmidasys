import { describe, expect, it } from 'vitest';
import { assertBoardWorkflowMembers } from './db';

describe('سياسة مسار موافقة عضوي مجلس الإدارة', () => {
  const member = { id: 91, userType: 'authorized_partner', boardPosition: 'عضو مجلس الإدارة', isActive: true } as const;
  const chairman = { id: 92, userType: 'authorized_partner', boardPosition: 'رئيس مجلس الإدارة', isActive: true } as const;
  const partnerOnly = { id: 93, userType: 'authorized_partner', boardPosition: 'شريك فقط', isActive: true } as const;

  it('يقبل عضو مجلس الإدارة المفوض بالقيمة الموحدة داخل مسار الموافقة الثنائية', () => {
    expect(() => assertBoardWorkflowMembers([member, chairman], [91, 92])).not.toThrow();
  });

  it('يستبعد الشريك فقط ولو كان مفوضاً ونشطاً من مسار الموافقة الثنائية', () => {
    expect(() => assertBoardWorkflowMembers([member, partnerOnly], [91, 93])).toThrow('يقتصر هذا المسار على الشركاء المفوضين أعضاء مجلس الإدارة النشطين');
  });
});
