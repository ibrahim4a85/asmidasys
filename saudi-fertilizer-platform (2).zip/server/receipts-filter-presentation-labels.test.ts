import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const receiptsPagePath = fileURLToPath(new URL('../client/src/pages/ReceiptsPage.tsx', import.meta.url));

describe('تسميات فلاتر سندات القبض', () => {
  it('تعيد القيم الافتراضية وتقبل تجاوز المدير لتسميات الفلاتر المرئية', () => {
    expect(getSystemLabel({}, 'receipts_filter_period')).toBe('الفترة المالية');
    expect(getSystemLabel({}, 'receipts_filter_all_statuses')).toBe('كل الحالات');
    expect(getSystemLabel({}, 'receipts_filter_serial_number_placeholder')).toBe('مثال: RYD-0001');
    expect(getSystemLabel({}, 'status_issued')).toBe('تم الإصدار');
    expect(getSystemLabel({}, 'status_rejected')).toBe('مرفوض');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ receipts_filter_all_branches: 'فروع الشركة' }) }, 'receipts_filter_all_branches')).toBe('فروع الشركة');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ receipts_filter_serial_number_placeholder: 'اكتب الرقم كما يظهر في السند' }) }, 'receipts_filter_serial_number_placeholder')).toBe('اكتب الرقم كما يظهر في السند');
  });

  it('يربط العرض بقاموس التسميات ويحافظ على رموز التصفية والطباعة كما هي', () => {
    const source = readFileSync(receiptsPagePath, 'utf8');
    expect(source).toContain("labelFor('receipts_filter_all_statuses', 'كل الحالات')");
    expect(source).toContain("labelFor('receipts_filter_serial_number_placeholder', 'مثال: RYD-0001')");
    expect(source).toContain("labelFor('status_issued', 'تم الإصدار')");
    expect(source).toContain("labelFor('status_rejected', 'مرفوض')");
    expect(source).toContain("value=\"issued\"");
    expect(source).toContain("value=\"rejected\"");
    expect(source).toContain("const statusLabel = (status: string) => status === 'approved' ? 'معتمد'");
    expect(source).toContain('setFilterSerialNumber(event.target.value)');
    expect(source).toContain("...(filterSerialNumber.trim() ? { serialNumber: filterSerialNumber.trim() } : {}),");
    expect(source).toContain('trpc.receipts.list.useQuery(listFilters)');
  });
});
