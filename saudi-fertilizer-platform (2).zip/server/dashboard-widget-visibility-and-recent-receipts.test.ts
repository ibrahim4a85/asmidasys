import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const dashboard = readFileSync(new URL('../client/src/pages/Dashboard.tsx', import.meta.url), 'utf8');

describe('عرض آخر سندات القبض وإخفاء عناصر لوحة التحكم', () => {
  it('يربط آخر السندات بالفروع والعملاء ويحافظ على فتح التفاصيل بالنقر', () => {
    expect(dashboard).toContain('const customerById = useMemo');
    expect(dashboard).toContain('const branchById = useMemo');
    expect(dashboard).toContain('branchName: branch?.name || \'\'');
    expect(dashboard).toContain('customerNumber: customer?.customerNumber || \'\'');
    expect(dashboard).toContain('رقم السند: {receipt.serialNumber || \'-\'}');
    expect(dashboard).toContain('الفرع: {receipt.branchName || \'-\'}');
    expect(dashboard).toContain('رقم العميل: {receipt.customerNumber || \'-\'}');
    expect(dashboard).toContain('اسم العميل: {receipt.customerName ||');
    expect(dashboard).toContain('`/receipts?receiptId=${receipt.id}`');
  });

  it('يعرض زر إخفاء موحداً لكل إطار وشريطاً عائماً للاستعادة ويحفظ التفضيل محلياً', () => {
    expect(dashboard).toContain('hideDashboardPersonalWidget');
    expect(dashboard).toContain('showDashboardPersonalWidget');
    expect(dashboard).toContain('ordering.isHidden(group, id)');
    expect(dashboard).toContain('إخفاء هذا العنصر من لوحة التحكم');
    expect(dashboard).toContain('<HiddenDashboardWidgetsRail widgets={hiddenDashboardWidgets} onShow={widgetOrdering.onShow} />');
    expect(dashboard).toContain('<HiddenDashboardWidgetsRail widgets={hiddenWidgets} onShow={widgetOrdering.onShow} />');
    expect(dashboard).toContain('العناصر المخفية');
    expect(dashboard).toContain('getDashboardPersonalWidgetLayoutKey(user.id)');
  });

  it('يوفر بحثاً محلياً داخل البطاقة باسم العميل أو رقمه مع رسالة واضحة عند عدم التطابق', () => {
    expect(dashboard).toContain('function RecentReceiptsCard({');
    expect(dashboard).toContain('[receipt.customerName, receipt.customerNumber]');
    expect(dashboard).toContain("placeholder=\"ابحث باسم العميل أو رقمه\"");
    expect(dashboard).toContain('لا توجد سندات مطابقة لاسم العميل أو رقمه.');
    expect(dashboard).toContain('.slice(0, 5)');
  });
});
