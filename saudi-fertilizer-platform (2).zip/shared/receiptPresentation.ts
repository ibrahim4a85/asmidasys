export type ReceiptCustomerReference = {
  delegateId?: number | null;
};

export type ReceiptDelegateReference = {
  id: number;
  fullName: string;
};

export type ReceiptInvoiceReference = {
  invoiceNumber: string;
  invoiceAmount: string;
};

export type ReceiptNotificationReference = {
  receiptId?: number | string | null;
  relatedReceiptId?: number | string | null;
  approvalRequestId?: number | string | null;
  relatedApprovalRequestId?: number | string | null;
};

export function getReceiptIdFromNotification(notification: ReceiptNotificationReference) {
  const receiptId = Number(notification.receiptId ?? notification.relatedReceiptId);
  return Number.isInteger(receiptId) && receiptId > 0 ? receiptId : null;
}

export function getApprovalRequestIdFromNotification(notification: ReceiptNotificationReference) {
  const requestId = Number(notification.approvalRequestId ?? notification.relatedApprovalRequestId);
  return Number.isInteger(requestId) && requestId > 0 ? requestId : null;
}

export function getNotificationTargetPath(notification: ReceiptNotificationReference) {
  const receiptId = getReceiptIdFromNotification(notification);
  if (receiptId) return `/receipts?receiptId=${receiptId}`;
  const approvalRequestId = getApprovalRequestIdFromNotification(notification);
  return approvalRequestId ? `/delegates?approvalRequestId=${approvalRequestId}` : '/notifications';
}

export function getReceiptDelegateName(
  customer: ReceiptCustomerReference | null | undefined,
  delegates: ReceiptDelegateReference[] | null | undefined,
) {
  if (!customer?.delegateId) return "غير محدد";
  return delegates?.find((delegate) => delegate.id === customer.delegateId)?.fullName || "غير محدد";
}

export function hasReceiptInvoices(invoices: ReceiptInvoiceReference[] | null | undefined) {
  return Boolean(invoices?.some((invoice) => invoice.invoiceNumber.trim() && Number(invoice.invoiceAmount) > 0));
}

export function getReceiptInvoiceSummary(invoices: ReceiptInvoiceReference[] | null | undefined) {
  return (invoices || [])
    .filter((invoice) => invoice.invoiceNumber.trim() && Number(invoice.invoiceAmount) > 0)
    .map((invoice) => `ف ${invoice.invoiceNumber} - ${Number(invoice.invoiceAmount).toLocaleString("ar-SA", { maximumFractionDigits: 2 })} ريال`);
}

export function getReceiptStatement(
  invoices: ReceiptInvoiceReference[] | null | undefined,
  paymentForName?: string | null,
) {
  const invoiceSummary = getReceiptInvoiceSummary(invoices);
  if (invoiceSummary.length > 0) return invoiceSummary;

  const statement = paymentForName?.trim();
  return statement ? [statement] : ['-'];
}
