export const SYSTEM_BACKUP_FORMAT = 'asmidasys-full-system-backup';
export const SYSTEM_BACKUP_VERSION = 2;

export type SystemBackupFile = {
  sourceUrl: string;
  contentType: string;
  dataBase64: string;
};

export function getSystemBackupRecordCount(data: Record<string, unknown[]>) {
  return Object.values(data).reduce((total, rows) => total + rows.length, 0);
}

export function createSystemBackupFileName(date = new Date()) {
  const timestamp = date.toISOString().replace(/[:.]/g, '-');
  return `asmidasys-full-backup-${timestamp}.json`;
}

export function getManagedStorageKey(url: string) {
  const prefix = '/manus-storage/';
  return url.startsWith(prefix) ? url.slice(prefix.length) : null;
}

export function collectManagedStorageUrls(data: Record<string, unknown[]>) {
  const urls = new Set<string>();
  for (const rows of Object.values(data)) {
    for (const row of rows) {
      if (!row || typeof row !== 'object') continue;
      for (const [key, value] of Object.entries(row as Record<string, unknown>)) {
        if (key.endsWith('Url') && typeof value === 'string' && getManagedStorageKey(value)) urls.add(value);
      }
    }
  }
  return Array.from(urls);
}

export function relinkManagedStorageUrls<T>(value: T, urlMap: Map<string, string>): T {
  if (typeof value === 'string') return (urlMap.get(value) || value) as T;
  if (value instanceof Date || value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(item => relinkManagedStorageUrls(item, urlMap)) as T;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, item]) => [key, relinkManagedStorageUrls(item, urlMap)])) as T;
}
