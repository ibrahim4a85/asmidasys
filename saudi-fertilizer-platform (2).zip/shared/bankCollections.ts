export type BankCollectionRow = {
  day: string;
  bankId: number | null;
  bankName: string | null;
  totalAmount: string | number;
  receiptCount: number;
};

export function summarizeBankCollections(rows: BankCollectionRow[]) {
  const banks = Array.from(new Set(rows.map(row => row.bankName || 'بنك غير محدد'))).sort((a, b) => a.localeCompare(b, 'ar'));
  const byDay = new Map<string, Record<string, string | number>>();
  for (const row of rows) {
    const key = row.day;
    const current = byDay.get(key) || { day: key, total: 0 };
    const bankName = row.bankName || 'بنك غير محدد';
    const amount = Number(row.totalAmount || 0);
    current[bankName] = Number(current[bankName] || 0) + amount;
    current.total = Number(current.total || 0) + amount;
    byDay.set(key, current);
  }
  return {
    banks,
    daily: Array.from(byDay.values()).sort((a, b) => String(a.day).localeCompare(String(b.day))),
    totalAmount: rows.reduce((total, row) => total + Number(row.totalAmount || 0), 0),
    totalReceipts: rows.reduce((total, row) => total + Number(row.receiptCount || 0), 0),
  };
}
