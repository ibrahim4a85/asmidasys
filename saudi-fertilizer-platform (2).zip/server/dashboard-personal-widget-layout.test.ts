import { describe, expect, it } from 'vitest';
import {
  getDashboardPersonalWidgetLayoutKey,
  hideDashboardPersonalWidget,
  isDashboardPersonalWidgetHidden,
  moveDashboardPersonalWidget,
  parseDashboardPersonalWidgetLayout,
  resizeDashboardPersonalWidget,
  showDashboardPersonalWidget,
} from '../shared/dashboardPersonalWidgetLayout';

describe('تخطيط بطاقات لوحة التحكم الشخصي', () => {
  it('يعزل مفتاح التخزين لكل مستخدم', () => {
    expect(getDashboardPersonalWidgetLayoutKey(101)).toBe('dashboard-widget-layout:101');
    expect(getDashboardPersonalWidgetLayoutKey('manager')).toBe('dashboard-widget-layout:manager');
  });

  it('يتجاهل المعرفات غير المعتمدة ويستكمل بطاقات المجموعة الناقصة', () => {
    const layout = parseDashboardPersonalWidgetLayout({
      summary: { order: ['approved_receipts', 'unknown', 'approved_receipts'], spans: { approved_receipts: 9, unknown: 2 } },
    });
    expect(layout.summary.order).toEqual(['approved_receipts', 'receipts_total', 'payments_total', 'pending_receipts']);
    expect(layout.summary.spans.approved_receipts).toBe(4);
    expect(layout.summary.spans.receipts_total).toBe(1);
  });

  it('ينقل البطاقة ويقيد التكبير والتصغير حسب أعمدة الشبكة المتاحة', () => {
    const initial = parseDashboardPersonalWidgetLayout(undefined);
    const moved = moveDashboardPersonalWidget(initial, 'activity', 'quick_actions', 'collections_trend');
    expect(moved.activity.order).toEqual(['quick_actions', 'collections_trend']);

    const enlarged = resizeDashboardPersonalWidget(moved, 'activity', 'quick_actions', 1, 2);
    expect(enlarged.activity.spans.quick_actions).toBe(2);
    expect(resizeDashboardPersonalWidget(enlarged, 'activity', 'quick_actions', 1, 2).activity.spans.quick_actions).toBe(2);
    expect(resizeDashboardPersonalWidget(enlarged, 'activity', 'quick_actions', -1, 2).activity.spans.quick_actions).toBe(1);
  });

  it('يبقى متوافقاً مع التخطيط السابق من دون حقل الإخفاء ويرشح المعرفات غير الصالحة', () => {
    const layout = parseDashboardPersonalWidgetLayout({
      summary: { order: ['receipts_total'], spans: { receipts_total: 1 } },
      records: { hidden: ['recent_receipts', 'unknown', 'recent_receipts'] },
    });

    expect(layout.summary.hidden).toEqual([]);
    expect(layout.records.hidden).toEqual(['recent_receipts']);
    expect(layout.activity.hidden).toEqual([]);
  });

  it('يخفي الودجت ويعيد إظهاره بصورة نقية ومنفصلة عن ترتيب وحجم الودجت', () => {
    const initial = parseDashboardPersonalWidgetLayout(undefined);
    const hidden = hideDashboardPersonalWidget(initial, 'records', 'recent_receipts');

    expect(isDashboardPersonalWidgetHidden(hidden, 'records', 'recent_receipts')).toBe(true);
    expect(hidden.records.order).toEqual(initial.records.order);
    expect(hidden.records.spans).toEqual(initial.records.spans);
    expect(hideDashboardPersonalWidget(hidden, 'records', 'recent_receipts')).toBe(hidden);

    const shown = showDashboardPersonalWidget(hidden, 'records', 'recent_receipts');
    expect(isDashboardPersonalWidgetHidden(shown, 'records', 'recent_receipts')).toBe(false);
    expect(showDashboardPersonalWidget(shown, 'records', 'recent_receipts')).toBe(shown);
    expect(hideDashboardPersonalWidget(initial, 'records', 'unknown')).toBe(initial);
  });
});
