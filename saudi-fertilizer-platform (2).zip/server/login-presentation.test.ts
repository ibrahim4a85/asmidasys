import { describe, expect, it } from 'vitest';
import { getLoginPresentationText } from '../client/src/lib/loginPresentation';

describe('نصوص شاشة الدخول وحقوق النشر', () => {
  it('يستخدم النصوص المحفوظة في الإعدادات عند تخصيصها', () => {
    expect(getLoginPresentationText({
      login_subtitle: 'بوابة المبيعات المالية',
      login_copyright: 'حقوق نشر مخصصة للشركة',
    }, 'شركة الاختبار', 2026)).toEqual({
      subtitle: 'بوابة المبيعات المالية',
      copyright: 'حقوق نشر مخصصة للشركة',
    });
  });

  it('يعيد النصوص الافتراضية مع اسم الشركة والسنة عند عدم وجود إعدادات', () => {
    expect(getLoginPresentationText(undefined, 'شركة الأسمدة المتحدة السعودية', 2026)).toEqual({
      subtitle: 'نظام الإدارة المالية المتكامل',
      copyright: 'جميع الحقوق محفوظة © 2026 - شركة الأسمدة المتحدة السعودية',
    });
  });
});
