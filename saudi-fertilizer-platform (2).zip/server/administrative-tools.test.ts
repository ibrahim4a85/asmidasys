import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getInternalNotifications: vi.fn(),
  markInternalNotificationRead: vi.fn(),
  markAllInternalNotificationsRead: vi.fn(),
  getOperationalDataCounts: vi.fn(),
  verifySystemUserPassword: vi.fn(),
  clearOperationalData: vi.fn(),
  clearSelectedOperationalData: vi.fn(),
}));

import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function context(userType: "admin" | "accountant" = "admin", permissions: Record<string, boolean> = {}): TrpcContext {
  return {
    user: null,
    systemUser: {
      id: 9,
      username: "system-user",
      fullName: "مستخدم النظام",
      userType,
      userLevel: "primary",
      branchId: null,
      permissions,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

describe("الإشعارات الداخلية وإدارة البيانات المحمية", () => {
  beforeEach(() => vi.resetAllMocks());

  it("يجلب الإشعارات غير المقروءة الخاصة بالمستخدم الحالي فقط", async () => {
    vi.mocked(db.getInternalNotifications).mockResolvedValue([]);

    await appRouter.createCaller(context("accountant")).notifications.list({ unreadOnly: true });

    expect(db.getInternalNotifications).toHaveBeenCalledWith(9, true);
  });

  it("يمنع غير مدير النظام من الوصول إلى معاينة حذف البيانات", async () => {
    await expect(appRouter.createCaller(context("accountant")).dataAdministration.previewOperationalClear())
      .rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("لا يحذف البيانات عند إدخال كلمة مرور خاطئة", async () => {
    vi.mocked(db.verifySystemUserPassword).mockResolvedValue(false);
    const caller = appRouter.createCaller(context());

    await expect(caller.dataAdministration.clearOperationalData({ password: "incorrect", confirmation: "حذف البيانات التشغيلية" }))
      .rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(db.clearOperationalData).not.toHaveBeenCalled();
  });

  it("يحذف البيانات التشغيلية فقط بعد تحقق كلمة المرور وعبارة التأكيد", async () => {
    vi.mocked(db.verifySystemUserPassword).mockResolvedValue(true);
    vi.mocked(db.clearOperationalData).mockResolvedValue(undefined as never);
    const caller = appRouter.createCaller(context());

    await expect(caller.dataAdministration.clearOperationalData({ password: "verified", confirmation: "حذف البيانات التشغيلية" }))
      .resolves.toEqual({ success: true });

    expect(db.verifySystemUserPassword).toHaveBeenCalledWith(9, "verified");
    expect(db.clearOperationalData).toHaveBeenCalledWith(9);
  });

  it("يسمح للمستخدم المفوض بحذف نطاقات البيانات التي يختارها بعد التحقق", async () => {
    vi.mocked(db.verifySystemUserPassword).mockResolvedValue(true);
    vi.mocked(db.clearSelectedOperationalData).mockResolvedValue(undefined as never);
    const caller = appRouter.createCaller(context("accountant", { dataDelete: true }));

    await expect(caller.dataAdministration.clearSelectedOperationalData({
      password: "verified",
      confirmation: "حذف البيانات المحددة",
      scopes: ["vouchers", "targets"],
    })).resolves.toEqual({ success: true });

    expect(db.verifySystemUserPassword).toHaveBeenCalledWith(9, "verified");
    expect(db.clearSelectedOperationalData).toHaveBeenCalledWith(9, ["vouchers", "targets"]);
  });

  it("يرفض الحذف الانتقائي عند غياب الصلاحية القابلة للمنح", async () => {
    await expect(appRouter.createCaller(context("accountant")).dataAdministration.clearSelectedOperationalData({
      password: "verified",
      confirmation: "حذف البيانات المحددة",
      scopes: ["customers"],
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(db.clearSelectedOperationalData).not.toHaveBeenCalled();
  });
});
