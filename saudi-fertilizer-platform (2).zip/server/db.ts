import { eq, and, like, desc, asc, sql, between, inArray, or, isNotNull, gt, isNull, lt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, systemUsers, passwordResetCodes, systemSettings, companyProfile, regions, branches, financialPeriods, partners, partnerPeriodSettings, partnerPeriodAllocations, partnerAccountEntries, partnerPeriodMemberships, partnerPeriodEquityLines, partnerProfitDistributions, partnerPeriodDocuments, branchTargets, goalTypes, administrativeGoals, administrativeGoalReviewers, administrativeGoalActions, administrativeGoalActionAttachments, salesGoalPlans, salesGoalMetrics, commissionPlans, commissionTiers, customers, inputLists, receipts, receiptInvoices, payments, performanceReports, delegates, documentTypes, approvalWorkflows, approvalWorkflowReviewers, approvalWorkflowApprovers, approvalRequests, approvalRequestReviewerSteps, approvalRequestSteps, newsItems, loginBackgrounds, activityLog, internalNotifications, receiptDecisionAudit, backupLogs } from "../drizzle/schema";
import { ENV } from './_core/env';
import { buildAnnualVoucherSerial, getConfiguredBranchNumber, getVoucherYearSuffix, sortBranchesByConfiguredOrder } from "@shared/branchOrdering";
import { toSafeSystemUser } from "../shared/systemUserSafe";
import { isBoardMemberPosition } from "../shared/boardPositions";
import { readApprovalParticipantCatalogs } from "../shared/approvalParticipantCatalogs";
import { calculateAggregateSharePercentage, calculateEquityLineTotal, calculatePartnerAccountSummary, isValidShareTotal } from "../shared/partnerRights";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== Auth ====================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ==================== System Auth ====================
export async function authenticateSystemUser(username: string, password: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(systemUsers).where(and(eq(systemUsers.username, username), eq(systemUsers.password, password), eq(systemUsers.isActive, true))).limit(1);
  if (result.length > 0) {
    await db.update(systemUsers).set({ lastSignedIn: new Date() }).where(eq(systemUsers.id, result[0].id));
    return result[0];
  }
  return null;
}

export async function getAllSystemUsers() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(systemUsers).orderBy(desc(systemUsers.createdAt));
  return rows.map(toSafeSystemUser);
}

export async function getSystemUserDirectory() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ id: systemUsers.id, fullName: systemUsers.fullName, userType: systemUsers.userType, branchId: systemUsers.branchId })
    .from(systemUsers)
    .where(eq(systemUsers.isActive, true))
    .orderBy(asc(systemUsers.fullName));
}

export async function createSystemUser(data: any) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(systemUsers).values(data);
  return result;
}

export async function updateSystemUser(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(systemUsers).set(data).where(eq(systemUsers.id, id));
}

export async function deleteSystemUser(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(systemUsers).where(eq(systemUsers.id, id));
}

export async function getEligibleSystemUserForPasswordReset(username: string) {
  const database = await getDb();
  if (!database) return null;
  const rows = await database.select({ id: systemUsers.id, username: systemUsers.username, isActive: systemUsers.isActive })
    .from(systemUsers)
    .where(and(eq(systemUsers.username, username), eq(systemUsers.isActive, true)))
    .limit(1);
  return rows[0] || null;
}

export async function replacePasswordResetCode(input: { userId: number; recoveryEmail: string; codeHash: string; expiresAt: Date }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async tx => {
    await tx.delete(passwordResetCodes).where(eq(passwordResetCodes.userId, input.userId));
    return tx.insert(passwordResetCodes).values({ ...input, attempts: 0 });
  });
}

export async function deletePasswordResetCodeForUser(userId: number) {
  const database = await getDb();
  if (!database) return null;
  return database.delete(passwordResetCodes).where(eq(passwordResetCodes.userId, userId));
}

export async function confirmPasswordResetCode(input: { username: string; codeHash: string; password: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async tx => {
    const usersFound = await tx.select({ id: systemUsers.id })
      .from(systemUsers)
      .where(and(eq(systemUsers.username, input.username), eq(systemUsers.isActive, true)))
      .limit(1);
    const user = usersFound[0];
    if (!user) return { success: false as const, reason: 'invalid' as const };

    const codes = await tx.select()
      .from(passwordResetCodes)
      .where(eq(passwordResetCodes.userId, user.id))
      .limit(1);
    const code = codes[0];
    if (!code || code.consumedAt || code.expiresAt <= new Date() || code.attempts >= 5) {
      return { success: false as const, reason: 'invalid' as const };
    }

    if (code.codeHash !== input.codeHash) {
      await tx.update(passwordResetCodes).set({ attempts: code.attempts + 1 }).where(eq(passwordResetCodes.id, code.id));
      return { success: false as const, reason: 'invalid' as const };
    }

    const consumed = await tx.update(passwordResetCodes)
      .set({ consumedAt: new Date() })
      .where(and(eq(passwordResetCodes.id, code.id), isNull(passwordResetCodes.consumedAt), gt(passwordResetCodes.expiresAt, new Date()), lt(passwordResetCodes.attempts, 5)));
    if (!consumed[0]?.affectedRows) return { success: false as const, reason: 'invalid' as const };

    await tx.update(systemUsers).set({ password: input.password, updatedAt: new Date() }).where(eq(systemUsers.id, user.id));
    return { success: true as const, reason: 'success' as const };
  });
}

export async function clearPasswordResetCodes() {
  const database = await getDb();
  if (!database) return null;
  return database.delete(passwordResetCodes);
}

// ==================== Company Profile ====================
export async function getCompanyProfile() {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(companyProfile).limit(1);
  return result[0] || null;
}

export async function updateCompanyProfile(data: any) {
  const db = await getDb();
  if (!db) return null;
  const existing = await getCompanyProfile();
  if (existing) {
    return db.update(companyProfile).set(data).where(eq(companyProfile.id, existing.id));
  } else {
    return db.insert(companyProfile).values(data);
  }
}

// ==================== Settings ====================
export async function getSettings() {
  const db = await getDb();
  if (!db) return {};
  const result = await db.select().from(systemSettings);
  const settings: Record<string, string> = {};
  result.forEach(r => { settings[r.settingKey] = r.settingValue || ''; });
  return settings;
}

export async function updateSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) return null;
  const existing = await db.select().from(systemSettings).where(eq(systemSettings.settingKey, key)).limit(1);
  if (existing.length > 0) {
    return db.update(systemSettings).set({ settingValue: value }).where(eq(systemSettings.settingKey, key));
  } else {
    return db.insert(systemSettings).values({ settingKey: key, settingValue: value });
  }
}

export async function updateSettings(entries: Array<{ key: string; value: string }>) {
  const db = await getDb();
  if (!db) return null;
  return db.transaction(async tx => {
    for (const entry of entries) {
      const existing = await tx.select({ id: systemSettings.id }).from(systemSettings).where(eq(systemSettings.settingKey, entry.key)).limit(1);
      if (existing.length > 0) {
        await tx.update(systemSettings).set({ settingValue: entry.value }).where(eq(systemSettings.id, existing[0].id));
      } else {
        await tx.insert(systemSettings).values({ settingKey: entry.key, settingValue: entry.value });
      }
    }
    return { updated: entries.length };
  });
}

export async function assertActiveSystemUserIds(userIds: number[]) {
  const ids = Array.from(new Set(userIds));
  if (!ids.length) return;
  const db = await getDb();
  if (!db) throw new Error('تعذر الاتصال بقاعدة البيانات');
  const activeUsers = await db.select({ id: systemUsers.id }).from(systemUsers).where(and(inArray(systemUsers.id, ids), eq(systemUsers.isActive, true)));
  if (activeUsers.length !== ids.length) throw new Error('تحتوي القائمة على مستخدمين غير نشطين أو غير موجودين');
}

// ==================== Regions & Branches ====================
export async function getRegions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(regions).orderBy(asc(regions.name));
}

export async function createRegion(name: string) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(regions).values({ name });
}

export async function getBranches() {
  const db = await getDb();
  if (!db) return [];
  const branchRows = await db.select().from(branches);
  return sortBranchesByConfiguredOrder(branchRows);
}

export async function createBranch(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(branches).values(data);
}

export async function updateBranch(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(branches).set(data).where(eq(branches.id, id));
}

export async function deleteBranch(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(branches).where(eq(branches.id, id));
}

// ==================== Financial Periods ====================
export async function getFinancialPeriods() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(financialPeriods).orderBy(desc(financialPeriods.startDate));
}

export async function createFinancialPeriod(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(financialPeriods).values(data);
}

export async function updateFinancialPeriod(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(financialPeriods).set(data).where(eq(financialPeriods.id, id));
}

export async function getActivePeriod() {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(financialPeriods).where(eq(financialPeriods.isActive, true)).limit(1);
  return result[0] || null;
}

// ==================== Partner Rights ====================
export async function getPartners() {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(partners).orderBy(desc(partners.isActive), asc(partners.name));
}

export async function getPartnerBySystemUserId(systemUserId: number) {
  const database = await getDb();
  if (!database) return null;
  const rows = await database.select().from(partners).where(eq(partners.systemUserId, systemUserId)).limit(1);
  return rows[0] || null;
}

async function assertActivePartner(database: any, partnerId: number) {
  const rows = await database.select({ id: partners.id }).from(partners).where(and(eq(partners.id, partnerId), eq(partners.isActive, true))).limit(1);
  if (!rows[0]) throw new Error("الشريك المحدد غير موجود أو غير نشط");
}

async function assertPartnerExists(database: any, partnerId: number) {
  const rows = await database.select({ id: partners.id }).from(partners).where(eq(partners.id, partnerId)).limit(1);
  if (!rows[0]) throw new Error("الشريك المحدد غير موجود");
}

async function assertFinancialPeriod(database: any, periodId: number) {
  const rows = await database.select({ id: financialPeriods.id }).from(financialPeriods).where(eq(financialPeriods.id, periodId)).limit(1);
  if (!rows[0]) throw new Error("الفترة المالية المحددة غير موجودة");
}

export async function createPartner(data: {
  name: string; systemUserId?: number | null; profileImageUrl?: string | null; profileImageName?: string | null; profileImageMimeType?: string | null; isActive?: boolean; createdBy: number; updatedBy: number;
}) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  if (data.systemUserId) {
    const usersFound = await database.select({ id: systemUsers.id }).from(systemUsers).where(eq(systemUsers.id, data.systemUserId)).limit(1);
    if (!usersFound[0]) throw new Error("المستخدم المرتبط بالشريك غير موجود");
  }
  return database.insert(partners).values(data);
}

export async function updatePartner(id: number, data: {
  name?: string; systemUserId?: number | null; profileImageUrl?: string | null; profileImageName?: string | null; profileImageMimeType?: string | null; isActive?: boolean; updatedBy: number;
}) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  if (data.systemUserId) {
    const usersFound = await database.select({ id: systemUsers.id }).from(systemUsers).where(eq(systemUsers.id, data.systemUserId)).limit(1);
    if (!usersFound[0]) throw new Error("المستخدم المرتبط بالشريك غير موجود");
  }
  return database.update(partners).set(data).where(eq(partners.id, id));
}

export async function upsertPartnerPeriodSettings(data: {
  periodId: number; openingProfitBalance: string; distributionDecisionUrl?: string | null; distributionDecisionName?: string | null; distributionDecisionMimeType?: string | null; userId: number;
}) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.transaction(async tx => {
    await assertFinancialPeriod(tx, data.periodId);
    const existing = await tx.select({ id: partnerPeriodSettings.id }).from(partnerPeriodSettings).where(eq(partnerPeriodSettings.periodId, data.periodId)).limit(1);
    const values = {
      openingProfitBalance: data.openingProfitBalance,
      distributionDecisionUrl: data.distributionDecisionUrl ?? null,
      distributionDecisionName: data.distributionDecisionName ?? null,
      distributionDecisionMimeType: data.distributionDecisionMimeType ?? null,
      updatedBy: data.userId,
    };
    if (existing[0]) return tx.update(partnerPeriodSettings).set(values).where(eq(partnerPeriodSettings.id, existing[0].id));
    return tx.insert(partnerPeriodSettings).values({ periodId: data.periodId, ...values, createdBy: data.userId });
  });
}

export async function upsertPartnerPeriodAllocation(data: { periodId: number; partnerId: number; sharePercentage: string; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.transaction(async tx => {
    await Promise.all([assertFinancialPeriod(tx, data.periodId), assertActivePartner(tx, data.partnerId)]);
    const percentage = Number(data.sharePercentage);
    if (!Number.isFinite(percentage) || percentage < 0 || percentage > 100) throw new Error("نسبة الحصة يجب أن تكون بين 0 و100");
    const existingRows = await tx.select().from(partnerPeriodAllocations).where(eq(partnerPeriodAllocations.periodId, data.periodId));
    const current = existingRows.find(row => row.partnerId === data.partnerId);
    const aggregate = calculateAggregateSharePercentage(existingRows.filter(row => row.partnerId !== data.partnerId)) + percentage;
    if (!isValidShareTotal(aggregate)) throw new Error("إجمالي حصص الشركاء لا يمكن أن يتجاوز 100%");
    if (current) {
      await tx.update(partnerPeriodAllocations).set({ sharePercentage: data.sharePercentage, updatedBy: data.userId }).where(eq(partnerPeriodAllocations.id, current.id));
    } else {
      await tx.insert(partnerPeriodAllocations).values({ periodId: data.periodId, partnerId: data.partnerId, sharePercentage: data.sharePercentage, createdBy: data.userId, updatedBy: data.userId });
    }
    return { aggregateSharePercentage: aggregate };
  });
}

export async function removePartnerPeriodAllocation(periodId: number, partnerId: number) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.delete(partnerPeriodAllocations).where(and(eq(partnerPeriodAllocations.periodId, periodId), eq(partnerPeriodAllocations.partnerId, partnerId)));
}

export async function getPartnerPeriodMemberships(periodId: number) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(partnerPeriodMemberships).where(eq(partnerPeriodMemberships.periodId, periodId)).orderBy(asc(partnerPeriodMemberships.partnerId));
}

export async function upsertPartnerPeriodMembership(data: { periodId: number; partnerId: number; isIncluded: boolean; shareUnits?: string | null; nominalShareValue?: string | null; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.transaction(async tx => {
    await Promise.all([assertFinancialPeriod(tx, data.periodId), assertPartnerExists(tx, data.partnerId)]);
    const numericValues = [data.shareUnits, data.nominalShareValue].filter((value): value is string => value !== null && value !== undefined && value !== "");
    if (numericValues.some(value => !Number.isFinite(Number(value)) || Number(value) < 0)) throw new Error("عدد الحصص وقيمتها الاسمية يجب أن تكون أرقاماً موجبة أو صفراً");
    const existing = await tx.select({ id: partnerPeriodMemberships.id }).from(partnerPeriodMemberships).where(and(eq(partnerPeriodMemberships.periodId, data.periodId), eq(partnerPeriodMemberships.partnerId, data.partnerId))).limit(1);
    const values = { isIncluded: data.isIncluded, shareUnits: data.shareUnits || null, nominalShareValue: data.nominalShareValue || null, updatedBy: data.userId };
    if (existing[0]) return tx.update(partnerPeriodMemberships).set(values).where(eq(partnerPeriodMemberships.id, existing[0].id));
    return tx.insert(partnerPeriodMemberships).values({ periodId: data.periodId, partnerId: data.partnerId, ...values, createdBy: data.userId });
  });
}

export async function getPartnerPeriodEquityLines(periodId: number) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(partnerPeriodEquityLines).where(eq(partnerPeriodEquityLines.periodId, periodId)).orderBy(asc(partnerPeriodEquityLines.sortOrder), asc(partnerPeriodEquityLines.id));
}

export async function upsertPartnerPeriodEquityLine(data: { id?: number; periodId: number; lineType: "opening_balance" | "capital" | "legal_reserve" | "retained_earnings" | "profit_distribution" | "net_income" | "actuarial_remeasurement" | "custom"; label: string; capitalAmount: string; legalReserveAmount: string; retainedEarningsAmount: string; notes?: string | null; sortOrder: number; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  await assertFinancialPeriod(database, data.periodId);
  if (!data.label.trim()) throw new Error("يلزم إدخال بيان السطر");
  if (![data.capitalAmount, data.legalReserveAmount, data.retainedEarningsAmount].every(value => Number.isFinite(Number(value)))) throw new Error("قيم حقوق الملكية يجب أن تكون أرقاماً صالحة");
  const values = { lineType: data.lineType, label: data.label.trim(), capitalAmount: data.capitalAmount, legalReserveAmount: data.legalReserveAmount, retainedEarningsAmount: data.retainedEarningsAmount, notes: data.notes?.trim() || null, sortOrder: data.sortOrder, updatedBy: data.userId };
  if (data.id) return database.update(partnerPeriodEquityLines).set(values).where(and(eq(partnerPeriodEquityLines.id, data.id), eq(partnerPeriodEquityLines.periodId, data.periodId)));
  return database.insert(partnerPeriodEquityLines).values({ periodId: data.periodId, ...values, createdBy: data.userId });
}

export async function deletePartnerPeriodEquityLine(id: number, periodId: number) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.delete(partnerPeriodEquityLines).where(and(eq(partnerPeriodEquityLines.id, id), eq(partnerPeriodEquityLines.periodId, periodId)));
}

export async function getPartnerProfitDistributions(periodId: number) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(partnerProfitDistributions).where(eq(partnerProfitDistributions.periodId, periodId)).orderBy(asc(partnerProfitDistributions.partnerId));
}

export async function upsertPartnerProfitDistribution(data: { periodId: number; partnerId: number; distributionAmount: string; distributionDate?: Date | null; statement?: string | null; attachmentKey?: string | null; attachmentUrl?: string | null; attachmentName?: string | null; attachmentMimeType?: string | null; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.transaction(async tx => {
    await Promise.all([assertFinancialPeriod(tx, data.periodId), assertPartnerExists(tx, data.partnerId)]);
    if (!Number.isFinite(Number(data.distributionAmount)) || Number(data.distributionAmount) < 0) throw new Error("قيمة التوزيع الموثق يجب أن تكون صفراً أو أكبر");
    const membership = await tx.select({ isIncluded: partnerPeriodMemberships.isIncluded }).from(partnerPeriodMemberships).where(and(eq(partnerPeriodMemberships.periodId, data.periodId), eq(partnerPeriodMemberships.partnerId, data.partnerId))).limit(1);
    if (!membership[0]?.isIncluded) throw new Error("يلزم إدراج الشريك ضمن عضوية هذه الفترة قبل تسجيل توزيع موثق له");
    const existing = await tx.select({ id: partnerProfitDistributions.id }).from(partnerProfitDistributions).where(and(eq(partnerProfitDistributions.periodId, data.periodId), eq(partnerProfitDistributions.partnerId, data.partnerId))).limit(1);
    const values = { distributionAmount: data.distributionAmount, distributionDate: data.distributionDate ?? null, statement: data.statement?.trim() || null, attachmentKey: data.attachmentKey ?? null, attachmentUrl: data.attachmentUrl ?? null, attachmentName: data.attachmentName ?? null, attachmentMimeType: data.attachmentMimeType ?? null, updatedBy: data.userId };
    if (existing[0]) return tx.update(partnerProfitDistributions).set(values).where(eq(partnerProfitDistributions.id, existing[0].id));
    return tx.insert(partnerProfitDistributions).values({ periodId: data.periodId, partnerId: data.partnerId, ...values, createdBy: data.userId });
  });
}

export async function getPartnerPeriodDocuments(periodId: number) {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(partnerPeriodDocuments).where(eq(partnerPeriodDocuments.periodId, periodId)).orderBy(asc(partnerPeriodDocuments.sortOrder), asc(partnerPeriodDocuments.id));
}

export async function createPartnerPeriodDocument(data: { periodId: number; documentType: "distribution_minutes" | "year_end_settlement" | "financial_statements" | "custom"; title: string; attachmentKey?: string | null; attachmentUrl: string; attachmentName: string; attachmentMimeType: string; notes?: string | null; sortOrder: number; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  await assertFinancialPeriod(database, data.periodId);
  if (!data.title.trim()) throw new Error("يلزم إدخال اسم المستند");
  return database.insert(partnerPeriodDocuments).values({ ...data, title: data.title.trim(), notes: data.notes?.trim() || null, attachmentKey: data.attachmentKey ?? null, createdBy: data.userId, updatedBy: data.userId });
}

export async function updatePartnerPeriodDocument(id: number, data: { periodId: number; documentType: "distribution_minutes" | "year_end_settlement" | "financial_statements" | "custom"; title: string; attachmentKey?: string | null; attachmentUrl: string; attachmentName: string; attachmentMimeType: string; notes?: string | null; sortOrder: number; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  if (!data.title.trim()) throw new Error("يلزم إدخال اسم المستند");
  return database.update(partnerPeriodDocuments).set({ ...data, title: data.title.trim(), notes: data.notes?.trim() || null, attachmentKey: data.attachmentKey ?? null, updatedBy: data.userId }).where(and(eq(partnerPeriodDocuments.id, id), eq(partnerPeriodDocuments.periodId, data.periodId)));
}

export async function deletePartnerPeriodDocument(id: number, periodId: number) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.delete(partnerPeriodDocuments).where(and(eq(partnerPeriodDocuments.id, id), eq(partnerPeriodDocuments.periodId, periodId)));
}

export async function getPartnerAccountEntries(filters?: { periodId?: number; partnerId?: number }) {
  const database = await getDb();
  if (!database) return [];
  const conditions = [];
  if (filters?.periodId) conditions.push(eq(partnerAccountEntries.periodId, filters.periodId));
  if (filters?.partnerId) conditions.push(eq(partnerAccountEntries.partnerId, filters.partnerId));
  const query = database.select().from(partnerAccountEntries);
  return conditions.length ? query.where(and(...conditions)).orderBy(desc(partnerAccountEntries.entryDate), desc(partnerAccountEntries.id)) : query.orderBy(desc(partnerAccountEntries.entryDate), desc(partnerAccountEntries.id));
}

export async function createPartnerAccountEntry(data: {
  periodId: number; partnerId: number; entryType: "withdrawal" | "entitlement" | "year_end_settlement"; settlementDirection?: "credit" | "debit" | null; amount: string; entryDate: Date; statement: string; attachmentUrl?: string | null; attachmentName?: string | null; attachmentMimeType?: string | null; createdBy: number; updatedBy: number;
}) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("قيمة الحركة يجب أن تكون أكبر من صفر");
  if (data.entryType === "year_end_settlement" && !data.settlementDirection) throw new Error("يلزم تحديد اتجاه تسوية نهاية العام");
  if (data.entryType !== "year_end_settlement" && data.settlementDirection) throw new Error("اتجاه التسوية متاح لتسوية نهاية العام فقط");
  await Promise.all([assertFinancialPeriod(database, data.periodId), assertActivePartner(database, data.partnerId)]);
  return database.insert(partnerAccountEntries).values({ ...data, settlementDirection: data.entryType === "year_end_settlement" ? data.settlementDirection : null });
}

export async function updatePartnerAccountEntry(id: number, data: {
  entryType: "withdrawal" | "entitlement" | "year_end_settlement"; settlementDirection?: "credit" | "debit" | null; amount: string; entryDate: Date; statement: string; attachmentUrl?: string | null; attachmentName?: string | null; attachmentMimeType?: string | null; updatedBy: number;
}) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("قيمة الحركة يجب أن تكون أكبر من صفر");
  if (data.entryType === "year_end_settlement" && !data.settlementDirection) throw new Error("يلزم تحديد اتجاه تسوية نهاية العام");
  if (data.entryType !== "year_end_settlement" && data.settlementDirection) throw new Error("اتجاه التسوية متاح لتسوية نهاية العام فقط");
  return database.update(partnerAccountEntries).set({ ...data, settlementDirection: data.entryType === "year_end_settlement" ? data.settlementDirection : null }).where(eq(partnerAccountEntries.id, id));
}

export async function deletePartnerAccountEntry(id: number) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  return database.delete(partnerAccountEntries).where(eq(partnerAccountEntries.id, id));
}

export async function getPartnerRightsReport(periodId: number, restrictedSystemUserId?: number) {
  const database = await getDb();
  if (!database) throw new Error("تعذر الاتصال بقاعدة البيانات");
  const [period] = await database.select().from(financialPeriods).where(eq(financialPeriods.id, periodId)).limit(1);
  if (!period) throw new Error("الفترة المالية المحددة غير موجودة");
  const [settings] = await database.select().from(partnerPeriodSettings).where(eq(partnerPeriodSettings.periodId, periodId)).limit(1);
  const [membershipRows, allocationRows, equityLines, distributionRows, documents] = await Promise.all([
    getPartnerPeriodMemberships(periodId),
    database.select().from(partnerPeriodAllocations).where(eq(partnerPeriodAllocations.periodId, periodId)),
    getPartnerPeriodEquityLines(periodId),
    getPartnerProfitDistributions(periodId),
    getPartnerPeriodDocuments(periodId),
  ]);
  const includedPartnerIds = membershipRows.filter(row => row.isIncluded).map(row => row.partnerId);
  const partnerRows = restrictedSystemUserId
    ? await database.select().from(partners).where(eq(partners.systemUserId, restrictedSystemUserId)).orderBy(asc(partners.name))
    : includedPartnerIds.length
      ? await database.select().from(partners).where(inArray(partners.id, includedPartnerIds)).orderBy(asc(partners.name))
      : await database.select().from(partners).where(eq(partners.isActive, true)).orderBy(asc(partners.name));
  const partnerIds = partnerRows.map(partner => partner.id);
  const entryRows = partnerIds.length
    ? await database.select().from(partnerAccountEntries).where(and(eq(partnerAccountEntries.periodId, periodId), inArray(partnerAccountEntries.partnerId, partnerIds))).orderBy(desc(partnerAccountEntries.entryDate), desc(partnerAccountEntries.id))
    : [];
  const visibleAllocations = allocationRows.filter(allocation => partnerIds.includes(allocation.partnerId));
  const aggregateSharePercentage = calculateAggregateSharePercentage(allocationRows);
  const openingProfitBalance = settings?.openingProfitBalance || "0";
  return {
    period,
    settings: settings || null,
    memberships: membershipRows,
    equityLines: equityLines.map(line => ({ ...line, totalAmount: calculateEquityLineTotal(line) })),
    documents,
    documentedDistributionTotal: distributionRows.reduce((total, distribution) => total + Number(distribution.distributionAmount || 0), 0),
    aggregateSharePercentage,
    sharesComplete: Math.abs(aggregateSharePercentage - 100) < 0.000001,
    partners: partnerRows.map(partner => {
      const allocation = visibleAllocations.find(row => row.partnerId === partner.id);
      const entries = entryRows.filter(row => row.partnerId === partner.id);
      const distribution = distributionRows.find(row => row.partnerId === partner.id) || null;
      return {
        partner,
        membership: membershipRows.find(row => row.partnerId === partner.id) || null,
        allocation: allocation || null,
        distribution,
        entries,
        summary: calculatePartnerAccountSummary({ openingProfitBalance, sharePercentage: allocation?.sharePercentage || "0", entries }),
      };
    }),
  };
}

// ==================== Branch Targets ====================
export async function getBranchTargets(branchId: number, periodId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(branchTargets).where(and(eq(branchTargets.branchId, branchId), eq(branchTargets.periodId, periodId)));
}

export async function createBranchTarget(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(branchTargets).values(data);
}

export async function updateBranchTarget(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(branchTargets).set(data).where(eq(branchTargets.id, id));
}

export async function deleteBranchTarget(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(branchTargets).where(eq(branchTargets.id, id));
}

// ==================== إدارة الأهداف والعمولات ====================
export async function getGoalTypes(category?: "administrative" | "sales") {
  const database = await getDb();
  if (!database) return [];
  return category
    ? database.select().from(goalTypes).where(eq(goalTypes.category, category)).orderBy(asc(goalTypes.name))
    : database.select().from(goalTypes).orderBy(asc(goalTypes.category), asc(goalTypes.name));
}

export async function createGoalType(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(goalTypes).values(data);
}

export async function updateGoalType(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(goalTypes).set(data).where(eq(goalTypes.id, id));
}

export async function getGoalTypeById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [goalType] = await database.select().from(goalTypes).where(eq(goalTypes.id, id)).limit(1);
  return goalType || null;
}

export async function getAdministrativeGoals() {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(administrativeGoals).orderBy(desc(administrativeGoals.updatedAt), desc(administrativeGoals.id));
}

export async function getAdministrativeGoalReviewers(goalId?: number) {
  const database = await getDb();
  if (!database) return [];
  return goalId
    ? database.select().from(administrativeGoalReviewers).where(eq(administrativeGoalReviewers.goalId, goalId))
    : database.select().from(administrativeGoalReviewers);
}

export async function getAdministrativeGoalActions(goalId?: number) {
  const database = await getDb();
  if (!database) return [];
  return goalId
    ? database.select().from(administrativeGoalActions).where(eq(administrativeGoalActions.goalId, goalId)).orderBy(asc(administrativeGoalActions.sortOrder), asc(administrativeGoalActions.id))
    : database.select().from(administrativeGoalActions).orderBy(asc(administrativeGoalActions.sortOrder), asc(administrativeGoalActions.id));
}

export async function getAdministrativeGoalActionAttachments(actionId?: number) {
  const database = await getDb();
  if (!database) return [];
  return actionId
    ? database.select().from(administrativeGoalActionAttachments).where(eq(administrativeGoalActionAttachments.actionId, actionId)).orderBy(desc(administrativeGoalActionAttachments.createdAt))
    : database.select().from(administrativeGoalActionAttachments).orderBy(desc(administrativeGoalActionAttachments.createdAt));
}

export async function getAdministrativeGoalById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [goal] = await database.select().from(administrativeGoals).where(eq(administrativeGoals.id, id)).limit(1);
  return goal || null;
}

export async function getAdministrativeGoalActionById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [action] = await database.select().from(administrativeGoalActions).where(eq(administrativeGoalActions.id, id)).limit(1);
  return action || null;
}

export async function isAdministrativeGoalReviewer(goalId: number, userId: number) {
  const database = await getDb();
  if (!database) return false;
  const [reviewer] = await database.select({ id: administrativeGoalReviewers.id })
    .from(administrativeGoalReviewers)
    .where(and(eq(administrativeGoalReviewers.goalId, goalId), eq(administrativeGoalReviewers.userId, userId)))
    .limit(1);
  return Boolean(reviewer);
}

export async function createAdministrativeGoal(data: any, reviewerIds: number[]) {
  const database = await getDb();
  if (!database) return null;
  return database.transaction(async (tx: any) => {
    const inserted = await tx.insert(administrativeGoals).values(data);
    const goalId = Number((inserted as any)[0]?.insertId);
    if (reviewerIds.length > 0) {
      await tx.insert(administrativeGoalReviewers).values(reviewerIds.map(userId => ({ goalId, userId, createdBy: data.createdBy })));
    }
    return { id: goalId };
  });
}

export async function updateAdministrativeGoal(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(administrativeGoals).set(data).where(eq(administrativeGoals.id, id));
}

export async function replaceAdministrativeGoalReviewers(goalId: number, reviewerIds: number[], createdBy: number) {
  const database = await getDb();
  if (!database) return null;
  return database.transaction(async (tx: any) => {
    await tx.delete(administrativeGoalReviewers).where(eq(administrativeGoalReviewers.goalId, goalId));
    if (reviewerIds.length > 0) {
      await tx.insert(administrativeGoalReviewers).values(reviewerIds.map(userId => ({ goalId, userId, createdBy })));
    }
  });
}

export async function createAdministrativeGoalAction(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(administrativeGoalActions).values(data);
}

export async function updateAdministrativeGoalAction(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(administrativeGoalActions).set(data).where(eq(administrativeGoalActions.id, id));
}

export async function createAdministrativeGoalActionAttachment(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(administrativeGoalActionAttachments).values(data);
}

export async function getSalesGoalPlans() {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(salesGoalPlans).orderBy(desc(salesGoalPlans.updatedAt), desc(salesGoalPlans.id));
}

export async function getSalesGoalPlanById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [plan] = await database.select().from(salesGoalPlans).where(eq(salesGoalPlans.id, id)).limit(1);
  return plan || null;
}

export async function getSalesGoalMetrics(salesGoalPlanId?: number) {
  const database = await getDb();
  if (!database) return [];
  return salesGoalPlanId
    ? database.select().from(salesGoalMetrics).where(eq(salesGoalMetrics.salesGoalPlanId, salesGoalPlanId)).orderBy(asc(salesGoalMetrics.sortOrder), asc(salesGoalMetrics.id))
    : database.select().from(salesGoalMetrics).orderBy(asc(salesGoalMetrics.sortOrder), asc(salesGoalMetrics.id));
}

export async function getSalesGoalMetricById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [metric] = await database.select().from(salesGoalMetrics).where(eq(salesGoalMetrics.id, id)).limit(1);
  return metric || null;
}

export async function getCommissionPlans(salesGoalPlanId?: number) {
  const database = await getDb();
  if (!database) return [];
  return salesGoalPlanId
    ? database.select().from(commissionPlans).where(eq(commissionPlans.salesGoalPlanId, salesGoalPlanId)).orderBy(asc(commissionPlans.id))
    : database.select().from(commissionPlans).orderBy(asc(commissionPlans.id));
}

export async function getCommissionPlanById(id: number) {
  const database = await getDb();
  if (!database) return null;
  const [plan] = await database.select().from(commissionPlans).where(eq(commissionPlans.id, id)).limit(1);
  return plan || null;
}

export async function getCommissionTiers(commissionPlanId?: number) {
  const database = await getDb();
  if (!database) return [];
  return commissionPlanId
    ? database.select().from(commissionTiers).where(eq(commissionTiers.commissionPlanId, commissionPlanId)).orderBy(asc(commissionTiers.sortOrder), asc(commissionTiers.id))
    : database.select().from(commissionTiers).orderBy(asc(commissionTiers.sortOrder), asc(commissionTiers.id));
}

export async function createSalesGoalPlan(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(salesGoalPlans).values(data);
}

export async function updateSalesGoalPlan(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(salesGoalPlans).set(data).where(eq(salesGoalPlans.id, id));
}

export async function createSalesGoalMetric(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(salesGoalMetrics).values(data);
}

export async function updateSalesGoalMetric(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(salesGoalMetrics).set(data).where(eq(salesGoalMetrics.id, id));
}

export async function createCommissionPlan(data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.insert(commissionPlans).values(data);
}

export async function updateCommissionPlan(id: number, data: any) {
  const database = await getDb();
  if (!database) return null;
  return database.update(commissionPlans).set(data).where(eq(commissionPlans.id, id));
}

export async function replaceCommissionTiers(commissionPlanId: number, tiers: any[]) {
  const database = await getDb();
  if (!database) return null;
  return database.transaction(async (tx: any) => {
    await tx.delete(commissionTiers).where(eq(commissionTiers.commissionPlanId, commissionPlanId));
    if (tiers.length > 0) await tx.insert(commissionTiers).values(tiers.map((tier, sortOrder) => ({ ...tier, commissionPlanId, sortOrder })));
  });
}

// ==================== Customers ====================
export async function getCustomers(filters?: { branchId?: number; delegateId?: number; search?: string }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(customers);
  const conditions = [];
  if (filters?.branchId) conditions.push(eq(customers.branchId, filters.branchId));
  if (filters?.delegateId) conditions.push(eq(customers.delegateId, filters.delegateId));
  if (filters?.search) conditions.push(or(like(customers.name, `%${filters.search}%`), like(customers.customerNumber, `%${filters.search}%`)));
  if (conditions.length > 0) query = query.where(and(...conditions)) as any;
  return query.orderBy(asc(customers.customerNumber));
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result[0] || null;
}

export async function getCustomerByNumber(customerNumber: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(customers).where(eq(customers.customerNumber, customerNumber)).limit(1);
  return result[0] || null;
}

export async function createCustomer(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(customers).values(data);
}

export async function updateCustomer(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(customers).set(data).where(eq(customers.id, id));
}

export async function deleteCustomer(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(customers).where(eq(customers.id, id));
}

export async function deleteCustomers(ids: number[]) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(customers).where(inArray(customers.id, ids));
}

// ==================== Input Lists ====================
export async function getInputLists(type?: string) {
  const db = await getDb();
  if (!db) return [];
  if (type) {
    return db.select().from(inputLists).where(eq(inputLists.listType, type as any)).orderBy(asc(inputLists.sortOrder));
  }
  return db.select().from(inputLists).orderBy(asc(inputLists.sortOrder));
}

export async function createInputList(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(inputLists).values(data);
}

export async function updateInputList(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(inputLists).set(data).where(eq(inputLists.id, id));
}

export async function deleteInputList(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(inputLists).where(eq(inputLists.id, id));
}

export async function hasInputListChildren(id: number) {
  const db = await getDb();
  if (!db) return false;
  const children = await db.select({ id: inputLists.id }).from(inputLists).where(eq(inputLists.parentId, id)).limit(1);
  return children.length > 0;
}

export async function getInputListById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(inputLists).where(eq(inputLists.id, id)).limit(1);
  return rows[0] || null;
}

// ==================== Receipts ====================
export async function getReceipts(filters?: {
  branchId?: number;
  userId?: number;
  periodId?: number;
  customerId?: number;
  status?: "draft" | "issued" | "approved" | "rejected";
  paymentMethodId?: number;
  serialNumber?: string;
  startDate?: Date;
  endDate?: Date;
}) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(receipts);
  const conditions = [];
  if (filters?.branchId) conditions.push(eq(receipts.branchId, filters.branchId));
  if (filters?.userId) conditions.push(eq(receipts.userId, filters.userId));
  if (filters?.periodId) conditions.push(eq(receipts.periodId, filters.periodId));
  if (filters?.customerId) conditions.push(eq(receipts.customerId, filters.customerId));
  if (filters?.status) conditions.push(eq(receipts.status, filters.status));
  if (filters?.paymentMethodId) conditions.push(eq(receipts.paymentMethodId, filters.paymentMethodId));
  if (filters?.serialNumber?.trim()) conditions.push(like(receipts.serialNumber, `%${filters.serialNumber.trim()}%`));
  if (filters?.startDate && filters?.endDate) conditions.push(between(receipts.createdAt, filters.startDate, filters.endDate));
  if (conditions.length > 0) query = query.where(and(...conditions)) as any;
  const rows = await query.orderBy(desc(receipts.createdAt));
  return Promise.all(rows.map(async (receipt) => ({ ...receipt, invoices: await getReceiptInvoices(receipt.id) })));
}

export async function getReceiptById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(receipts).where(eq(receipts.id, id)).limit(1);
  if (!result[0]) return null;
  return { ...result[0], invoices: await getReceiptInvoices(id) };
}

export async function createReceipt(data: any) {
  const db = await getDb();
  if (!db) return null;
  const branch = await db.select().from(branches).where(eq(branches.id, data.branchId)).limit(1);
  if (!branch[0]) throw new Error("Branch not found");
  const branchNumber = getConfiguredBranchNumber(branch[0].name);
  if (!branchNumber) throw new Error("لا يمكن إنشاء سند لفرع غير موجود ضمن الترتيب التشغيلي المعتمد");
  const prefix = `${branchNumber}-${getVoucherYearSuffix()}-`;
  const existing = await db.select({ serialNumber: receipts.serialNumber }).from(receipts)
    .where(and(eq(receipts.branchId, data.branchId), like(receipts.serialNumber, `${prefix}%`)));
  const nextNum = existing.reduce((maximum, item) => Math.max(maximum, Number(item.serialNumber.split("-").pop() || 0)), 0) + 1;
  const serialNumber = buildAnnualVoucherSerial({ branchName: branch[0].name, sequence: nextNum, kind: "receipt" });
  await db.update(branches).set({ currentReceiptNumber: nextNum }).where(eq(branches.id, data.branchId));
  const receiptData = { ...data, serialNumber };
  const result = await db.insert(receipts).values(receiptData);
  return { ...result, serialNumber, id: Number((result as any)[0]?.insertId) };
}

export async function createReceiptWithInvoices(data: any, invoices: Array<{ invoiceNumber: string; invoiceAmount: string }>) {
  const db = await getDb();
  if (!db) return null;
  const branch = await db.select().from(branches).where(eq(branches.id, data.branchId)).limit(1);
  if (!branch[0]) throw new Error("Branch not found");
  const branchNumber = getConfiguredBranchNumber(branch[0].name);
  if (!branchNumber) throw new Error("لا يمكن إنشاء سند لفرع غير موجود ضمن الترتيب التشغيلي المعتمد");
  const prefix = `${branchNumber}-${getVoucherYearSuffix()}-`;
  const existing = await db.select({ serialNumber: receipts.serialNumber }).from(receipts)
    .where(and(eq(receipts.branchId, data.branchId), like(receipts.serialNumber, `${prefix}%`)));
  const nextNum = existing.reduce((maximum, item) => Math.max(maximum, Number(item.serialNumber.split("-").pop() || 0)), 0) + 1;
  const serialNumber = buildAnnualVoucherSerial({ branchName: branch[0].name, sequence: nextNum, kind: "receipt" });
  const { invoices: _ignoredInvoices, ...receiptData } = data;

  return db.transaction(async (tx) => {
    await tx.update(branches).set({ currentReceiptNumber: nextNum }).where(eq(branches.id, data.branchId));
    const result = await tx.insert(receipts).values({ ...receiptData, serialNumber });
    let receiptId = Number((result as any)[0]?.insertId || (result as any).insertId);
    if (!receiptId) {
      const inserted = await tx.select({ id: receipts.id }).from(receipts).where(eq(receipts.serialNumber, serialNumber)).limit(1);
      receiptId = inserted[0]?.id || 0;
    }
    if (!receiptId) throw new Error("تعذر تحديد السند الذي تم إنشاؤه");
    const validInvoices = invoices.filter((invoice) => invoice.invoiceNumber.trim() && Number(invoice.invoiceAmount) > 0);
    if (validInvoices.length) {
      await tx.insert(receiptInvoices).values(validInvoices.map((invoice) => ({
        receiptId,
        invoiceNumber: invoice.invoiceNumber.trim(),
        invoiceAmount: invoice.invoiceAmount,
      })));
    }
    return { id: receiptId, serialNumber };
  });
}

export async function updateReceipt(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  const { invoices: _ignoredInvoices, ...receiptData } = data;
  return db.update(receipts).set(receiptData).where(eq(receipts.id, id));
}

export async function updateReceiptWithInvoices(id: number, data: any, invoices: Array<{ invoiceNumber: string; invoiceAmount: string }>) {
  const db = await getDb();
  if (!db) return null;
  const { invoices: _ignoredInvoices, ...receiptData } = data;
  const validInvoices = invoices.filter((invoice) => invoice.invoiceNumber.trim() && Number(invoice.invoiceAmount) > 0);

  return db.transaction(async (tx) => {
    await tx.update(receipts).set(receiptData).where(eq(receipts.id, id));
    await tx.delete(receiptInvoices).where(eq(receiptInvoices.receiptId, id));
    if (validInvoices.length) {
      await tx.insert(receiptInvoices).values(validInvoices.map((invoice) => ({
        receiptId: id,
        invoiceNumber: invoice.invoiceNumber.trim(),
        invoiceAmount: invoice.invoiceAmount,
      })));
    }
  });
}

export async function deleteReceipt(id: number) {
  const db = await getDb();
  if (!db) return null;
  await db.delete(receiptInvoices).where(eq(receiptInvoices.receiptId, id));
  return db.delete(receipts).where(eq(receipts.id, id));
}

export async function createReceiptIssuedNotifications(input: {
  receiptId: number;
  serialNumber: string;
  issuerName: string;
}) {
  const db = await getDb();
  if (!db) return [];
  const managers = await db.select({ id: systemUsers.id }).from(systemUsers).where(and(
    eq(systemUsers.isActive, true),
    or(eq(systemUsers.userType, "admin"), eq(systemUsers.userLevel, "primary")),
  ));
  if (!managers.length) return [];
  return db.insert(internalNotifications).values(managers.map((manager) => ({
    recipientUserId: manager.id,
    notificationType: "receipt_issued",
    title: "سند قبض جديد بانتظار الاعتماد",
    message: `أصدر ${input.issuerName} السند ${input.serialNumber} وهو بانتظار المراجعة والاعتماد.`,
    receiptId: input.receiptId,
  })));
}

export async function getInternalNotifications(recipientUserId: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(internalNotifications.recipientUserId, recipientUserId)];
  if (unreadOnly) conditions.push(eq(internalNotifications.isRead, false));
  return db.select().from(internalNotifications).where(and(...conditions)).orderBy(desc(internalNotifications.createdAt));
}

export async function markInternalNotificationRead(notificationId: number, recipientUserId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(internalNotifications).set({ isRead: true, readAt: new Date() })
    .where(and(eq(internalNotifications.id, notificationId), eq(internalNotifications.recipientUserId, recipientUserId)));
}

export async function markAllInternalNotificationsRead(recipientUserId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.update(internalNotifications).set({ isRead: true, readAt: new Date() })
    .where(and(eq(internalNotifications.recipientUserId, recipientUserId), eq(internalNotifications.isRead, false)));
}

export async function decideReceiptWithAudit(input: {
  receiptId: number;
  decision: "approved" | "rejected";
  decidedBy: number;
  note?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  return db.transaction(async (tx) => {
    const current = await tx.select().from(receipts).where(eq(receipts.id, input.receiptId)).limit(1);
    const receipt = current[0];
    if (!receipt) throw new Error("السند غير موجود");
    if (receipt.status !== "issued") throw new Error("لا يمكن اتخاذ قرار إلا على سند بحالة تم الإصدار");
    await tx.update(receipts).set({ status: input.decision, updatedBy: input.decidedBy }).where(eq(receipts.id, input.receiptId));
    await tx.insert(receiptDecisionAudit).values({
      receiptId: input.receiptId,
      decision: input.decision,
      previousStatus: receipt.status,
      nextStatus: input.decision,
      decidedBy: input.decidedBy,
      note: input.note?.trim() || null,
    });
    await tx.insert(activityLog).values({
      userId: input.decidedBy,
      action: `receipt_${input.decision}`,
      details: `اتخاذ قرار ${input.decision} على السند ${receipt.serialNumber}`,
    });
    return { receipt, nextStatus: input.decision };
  });
}

export async function approveReceiptsWithAudit(input: {
  receiptIds: number[];
  decidedBy: number;
  note?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const receiptIds = Array.from(new Set(input.receiptIds));
  if (!receiptIds.length) throw new Error("اختر سند قبض واحداً على الأقل للاعتماد");
  return db.transaction(async (tx) => {
    const selectedReceipts = await tx.select().from(receipts).where(inArray(receipts.id, receiptIds));
    if (selectedReceipts.length !== receiptIds.length) throw new Error("تعذر العثور على أحد السندات المحددة");
    const nonIssuedReceipt = selectedReceipts.find(receipt => receipt.status !== "issued");
    if (nonIssuedReceipt) throw new Error("يمكن اعتماد السندات التي تم إصدارها فقط");

    await tx.update(receipts)
      .set({ status: "approved", updatedBy: input.decidedBy })
      .where(inArray(receipts.id, receiptIds));
    await tx.insert(receiptDecisionAudit).values(selectedReceipts.map(receipt => ({
      receiptId: receipt.id,
      decision: "approved" as const,
      previousStatus: receipt.status,
      nextStatus: "approved",
      decidedBy: input.decidedBy,
      note: input.note?.trim() || null,
    })));
    await tx.insert(activityLog).values({
      userId: input.decidedBy,
      action: "receipts_batch_approved",
      details: JSON.stringify({ receiptIds, count: receiptIds.length }),
    });
    return { count: receiptIds.length, receiptIds };
  });
}

export async function getReceiptDecisionAudit(receiptId?: number) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(receiptDecisionAudit);
  if (receiptId) return query.where(eq(receiptDecisionAudit.receiptId, receiptId)).orderBy(desc(receiptDecisionAudit.createdAt));
  return query.orderBy(desc(receiptDecisionAudit.createdAt));
}

export async function recordReceiptPrint(input: { receiptId: number; userId: number; printType: 'receipt' | 'receipt_with_attachment' }) {
  const db = await getDb();
  if (!db) return null;
  const receipt = await getReceiptById(input.receiptId);
  if (!receipt) throw new Error('السند غير موجود');
  return db.insert(activityLog).values({
    userId: input.userId,
    action: 'receipt_print',
    details: JSON.stringify({ receiptId: input.receiptId, serialNumber: receipt.serialNumber, printType: input.printType }),
  });
}

export async function getReceiptPrintAudit(receiptId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ id: activityLog.id, userId: activityLog.userId, fullName: systemUsers.fullName, details: activityLog.details, createdAt: activityLog.createdAt })
    .from(activityLog).leftJoin(systemUsers, eq(activityLog.userId, systemUsers.id))
    .where(and(eq(activityLog.action, 'receipt_print'), sql`${activityLog.details} LIKE ${`%"receiptId":${receiptId}%`}`))
    .orderBy(desc(activityLog.createdAt));
  return rows.map(row => {
    let printType = 'receipt';
    try { printType = JSON.parse(row.details || '{}').printType || printType; } catch { /* سجل قديم */ }
    return { ...row, printType };
  });
}

export async function verifySystemUserPassword(userId: number, password: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select({ id: systemUsers.id }).from(systemUsers)
    .where(and(eq(systemUsers.id, userId), eq(systemUsers.password, password), eq(systemUsers.isActive, true)))
    .limit(1);
  return result.length === 1;
}

export async function getOperationalDataCounts() {
  const db = await getDb();
  if (!db) return null;
  const count = async (table: any) => Number((await db.select({ count: sql<number>`count(*)` }).from(table))[0]?.count || 0);
  return {
    receipts: await count(receipts), receiptInvoices: await count(receiptInvoices), customers: await count(customers),
    branches: await count(branches), branchTargets: await count(branchTargets), administrativeGoals: await count(administrativeGoals),
    salesGoalPlans: await count(salesGoalPlans), commissionPlans: await count(commissionPlans), performanceReports: await count(performanceReports),
    payments: await count(payments), notifications: await count(internalNotifications), decisionAudit: await count(receiptDecisionAudit),
  };
}

export async function clearOperationalData(actorId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.transaction(async (tx) => {
    await tx.delete(receiptDecisionAudit);
    await tx.delete(internalNotifications);
    await tx.delete(receiptInvoices);
    await tx.delete(receipts);
    await tx.delete(payments);
    await tx.delete(performanceReports);
    await tx.delete(administrativeGoalActionAttachments);
    await tx.delete(administrativeGoalActions);
    await tx.delete(administrativeGoalReviewers);
    await tx.delete(administrativeGoals);
    await tx.delete(commissionTiers);
    await tx.delete(commissionPlans);
    await tx.delete(salesGoalMetrics);
    await tx.delete(salesGoalPlans);
    await tx.delete(goalTypes);
    await tx.delete(branchTargets);
    await tx.delete(customers);
    await tx.delete(delegates);
    await tx.delete(approvalRequests);
    await tx.delete(financialPeriods);
    await tx.delete(branches);
    await tx.insert(activityLog).values({
      userId: actorId,
      action: "clear_operational_data",
      details: "حذف بيانات التشغيل: السندات والعملاء والفروع والأهداف والتقارير والإشعارات وسجلات القرارات.",
    });
  });
}

export async function clearSelectedOperationalData(actorId: number, scopes: Array<"vouchers" | "customers" | "targets">) {
  const db = await getDb();
  if (!db) return null;
  const selected = new Set(scopes);
  return db.transaction(async (tx) => {
    if (selected.has("vouchers")) {
      await tx.delete(receiptDecisionAudit);
      await tx.delete(internalNotifications);
      await tx.delete(receiptInvoices);
      await tx.delete(receipts);
      await tx.delete(payments);
    }
    if (selected.has("customers")) {
      const linkedReceipts = await tx.select({ count: sql<number>`count(*)` }).from(receipts);
      if (Number(linkedReceipts[0]?.count || 0) > 0) {
        throw new Error("لا يمكن حذف العملاء مع وجود سندات قبض مرتبطة. اختر حذف السندات أيضاً أو أبقِ سجلات العملاء.");
      }
      await tx.delete(customers);
    }
    if (selected.has("targets")) {
      await tx.delete(administrativeGoalActionAttachments);
      await tx.delete(administrativeGoalActions);
      await tx.delete(administrativeGoalReviewers);
      await tx.delete(administrativeGoals);
      await tx.delete(commissionTiers);
      await tx.delete(commissionPlans);
      await tx.delete(salesGoalMetrics);
      await tx.delete(salesGoalPlans);
      await tx.delete(goalTypes);
      await tx.delete(branchTargets);
    }
    const labels = [
      selected.has("vouchers") && "سندات القبض والصرف",
      selected.has("customers") && "العملاء",
      selected.has("targets") && "الأهداف",
    ].filter(Boolean).join("، ");
    await tx.insert(activityLog).values({ userId: actorId, action: "clear_selected_operational_data", details: `حذف انتقائي للبيانات: ${labels}.` });
  });
}

// ==================== Receipt Invoices ====================
export async function getReceiptInvoices(receiptId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(receiptInvoices).where(eq(receiptInvoices.receiptId, receiptId));
}

export async function createReceiptInvoice(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(receiptInvoices).values(data);
}

// ==================== Payments ====================
export async function getPayments(filters?: { branchId?: number; userId?: number; periodId?: number }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(payments);
  const conditions = [];
  if (filters?.branchId) conditions.push(eq(payments.branchId, filters.branchId));
  if (filters?.userId) conditions.push(eq(payments.userId, filters.userId));
  if (filters?.periodId) conditions.push(eq(payments.periodId, filters.periodId));
  if (conditions.length > 0) query = query.where(and(...conditions)) as any;
  return query.orderBy(desc(payments.createdAt));
}

export async function createPayment(data: any) {
  const db = await getDb();
  if (!db) return null;
  const branch = await db.select().from(branches).where(eq(branches.id, data.branchId)).limit(1);
  if (!branch[0]) throw new Error("Branch not found");
  const branchNumber = getConfiguredBranchNumber(branch[0].name);
  if (!branchNumber) throw new Error("لا يمكن إنشاء سند صرف لفرع غير موجود ضمن الترتيب التشغيلي المعتمد");
  const prefix = `PY-${branchNumber}-${getVoucherYearSuffix()}-`;
  const existing = await db.select({ serialNumber: payments.serialNumber }).from(payments)
    .where(and(eq(payments.branchId, data.branchId), like(payments.serialNumber, `${prefix}%`)));
  const nextNum = existing.reduce((maximum, item) => Math.max(maximum, Number(item.serialNumber.split("-").pop() || 0)), 0) + 1;
  const serialNumber = buildAnnualVoucherSerial({ branchName: branch[0].name, sequence: nextNum, kind: "payment" });
  await db.update(branches).set({ currentPaymentNumber: nextNum }).where(eq(branches.id, data.branchId));
  return db.insert(payments).values({ ...data, serialNumber });
}

export async function updatePayment(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(payments).set(data).where(eq(payments.id, id));
}

export async function deletePayment(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(payments).where(eq(payments.id, id));
}

// ==================== Daily Performance Reports ====================
export async function getPerformanceReports(filters?: { branchId?: number }) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(performanceReports);
  if (filters?.branchId) {
    return query.where(eq(performanceReports.branchId, filters.branchId)).orderBy(desc(performanceReports.reportDate));
  }
  return query.orderBy(desc(performanceReports.reportDate));
}

export async function getPerformanceReport(branchId: number, reportDate: string) {
  const db = await getDb();
  if (!db) return null;
  const normalizedDate = new Date(`${reportDate}T00:00:00.000Z`);
  const result = await db.select().from(performanceReports)
    .where(and(eq(performanceReports.branchId, branchId), eq(performanceReports.reportDate, normalizedDate)))
    .limit(1);
  return result[0] || null;
}

export async function getDailyReceiptMetrics(branchId: number, reportDate: string) {
  const dayStart = new Date(`${reportDate}T00:00:00.000Z`);
  const dayEnd = new Date(`${reportDate}T23:59:59.999Z`);
  const rows = await getReceipts({ branchId, startDate: dayStart, endDate: dayEnd });
  const approvedReceipts = rows.filter(receipt => receipt.status === "approved");
  const collectionsValue = approvedReceipts.reduce((sum, receipt) => sum + Number(receipt.amount || 0), 0);
  return { receiptsCount: approvedReceipts.length, collectionsValue: collectionsValue.toFixed(2) };
}

export async function createPerformanceReport(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(performanceReports).values(data);
}

export async function updatePerformanceReport(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(performanceReports).set(data).where(eq(performanceReports.id, id));
}

// ==================== Delegates ====================
export async function getDelegates() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(delegates).orderBy(asc(delegates.name));
}

export async function createDelegate(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(delegates).values(data);
}

export async function updateDelegate(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(delegates).set(data).where(eq(delegates.id, id));
}

export async function deleteDelegate(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(delegates).where(eq(delegates.id, id));
}

// ==================== Document Types ====================
export async function getDocumentTypes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(documentTypes).orderBy(asc(documentTypes.name));
}

export async function createDocumentType(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(documentTypes).values(data);
}

export async function updateDocumentType(id: number, data: Record<string, unknown>) {
  const db = await getDb();
  if (!db) return null;
  return db.update(documentTypes).set(data).where(eq(documentTypes.id, id));
}

export async function deleteDocumentTypeWithWorkflow(id: number) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx: any) => {
    const [{ count: requestCount }] = await tx
      .select({ count: sql<number>`count(*)` })
      .from(approvalRequests)
      .where(eq(approvalRequests.documentTypeId, id));
    if (Number(requestCount) > 0) {
      throw new Error('لا يمكن حذف نوع تعميد مرتبط بطلبات سابقة. احذف سجل طلبات التعميد المصرح به أولاً.');
    }
    const [workflow] = await tx.select().from(approvalWorkflows).where(eq(approvalWorkflows.documentTypeId, id)).limit(1);
    if (workflow) {
      await tx.delete(approvalWorkflowReviewers).where(eq(approvalWorkflowReviewers.workflowId, workflow.id));
      await tx.delete(approvalWorkflowApprovers).where(eq(approvalWorkflowApprovers.workflowId, workflow.id));
      await tx.delete(approvalWorkflows).where(eq(approvalWorkflows.id, workflow.id));
    }
    return tx.delete(documentTypes).where(eq(documentTypes.id, id));
  });
}

// ==================== Approval Workflows ====================
export type ApprovalMode = 'sequential' | 'any' | 'all' | 'two_board_members';

export function assertBoardWorkflowMembers(
  members: Array<{ id: number; userType: string; boardPosition: string | null; isActive: boolean }>,
  approverIds: number[],
) {
  if (members.length !== approverIds.length || members.some(member => member.userType !== 'authorized_partner' || !isBoardMemberPosition(member.boardPosition) || !member.isActive)) {
    throw new Error('يقتصر هذا المسار على الشركاء المفوضين أعضاء مجلس الإدارة النشطين');
  }
}

export async function getApprovalWorkflows() {
  const database = await getDb();
  if (!database) return [];
  const workflows = await database.select().from(approvalWorkflows).orderBy(asc(approvalWorkflows.documentTypeId));
  const [reviewers, approvers] = await Promise.all([
    database.select().from(approvalWorkflowReviewers).orderBy(asc(approvalWorkflowReviewers.sortOrder)),
    database.select().from(approvalWorkflowApprovers).orderBy(asc(approvalWorkflowApprovers.sortOrder)),
  ]);
  return workflows.map(workflow => ({
    ...workflow,
    reviewers: reviewers.filter(reviewer => reviewer.workflowId === workflow.id),
    approvers: approvers.filter(approver => approver.workflowId === workflow.id),
  }));
}

export async function getApprovalWorkflow(documentTypeId: number) {
  const database = await getDb();
  if (!database) return null;
  const workflow = await database.select().from(approvalWorkflows).where(and(eq(approvalWorkflows.documentTypeId, documentTypeId), eq(approvalWorkflows.isActive, true))).limit(1);
  if (!workflow[0]) return null;
  const [reviewers, approvers] = await Promise.all([
    database.select().from(approvalWorkflowReviewers).where(eq(approvalWorkflowReviewers.workflowId, workflow[0].id)).orderBy(asc(approvalWorkflowReviewers.sortOrder)),
    database.select().from(approvalWorkflowApprovers).where(eq(approvalWorkflowApprovers.workflowId, workflow[0].id)).orderBy(asc(approvalWorkflowApprovers.sortOrder)),
  ]);
  return { ...workflow[0], reviewers, approvers };
}

export async function saveApprovalWorkflow(input: { documentTypeId: number; reviewerUserIds?: number[]; reviewerSequential?: boolean; approverUserIds: number[]; approverSequential?: boolean; requiredApprovals: number; approvalMode?: ApprovalMode }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return saveApprovalWorkflowWithDatabase(database, input);
}

export async function saveApprovalWorkflowWithDatabase(database: any, input: { documentTypeId: number; reviewerUserIds?: number[]; reviewerSequential?: boolean; approverUserIds: number[]; approverSequential?: boolean; requiredApprovals?: number; approvalMode?: ApprovalMode }) {
  const reviewerIds = Array.from(new Set(input.reviewerUserIds || []));
  const approverIds = Array.from(new Set(input.approverUserIds));
  if (!approverIds.length) throw new Error('يجب اختيار مفوض واحد على الأقل لمسار التعميد');
  const requiredApprovals = input.requiredApprovals ?? (input.approvalMode === 'two_board_members' ? 2 : approverIds.length);
  if (requiredApprovals < 1 || requiredApprovals > approverIds.length) {
    throw new Error('الحد الأدنى لعدد المفوضين يجب أن يكون بين واحد وعدد المفوضين المحددين');
  }
  const configuredUsers = Array.from(new Set([...reviewerIds, ...approverIds]));
  const [activeUsers, storedSettings] = await Promise.all([
    database.select({ id: systemUsers.id, userType: systemUsers.userType, boardPosition: systemUsers.boardPosition, isActive: systemUsers.isActive, permissions: systemUsers.permissions }).from(systemUsers).where(and(inArray(systemUsers.id, configuredUsers), eq(systemUsers.isActive, true))),
    database.select().from(systemSettings),
  ]);
  if (activeUsers.length !== configuredUsers.length) throw new Error('يجب اختيار مستخدمين نشطين فقط ضمن مسار التعميد');
  const approvalSettings = Object.fromEntries(storedSettings.map((setting: any) => [setting.settingKey, setting.settingValue]));
  const participantCatalogs = readApprovalParticipantCatalogs(approvalSettings, activeUsers);
  if (reviewerIds.some(id => !participantCatalogs.reviewerUserIds.includes(id))) {
    throw new Error('يجب اختيار المراجعين من قائمة المراجعين المعتمدة فقط');
  }
  if (approverIds.some(id => !participantCatalogs.approverUserIds.includes(id))) {
    throw new Error('يجب اختيار المفوضين من قائمة المفوضين المعتمدة فقط');
  }
  if (input.approvalMode === 'two_board_members') {
    assertBoardWorkflowMembers(activeUsers.filter((user: any) => approverIds.includes(user.id)), approverIds);
    if (requiredApprovals < 2) throw new Error('يتطلب مسار عضوي مجلس الإدارة اعتماد عضوين على الأقل');
  }
  const approvalMode: ApprovalMode = input.approvalMode === 'two_board_members'
    ? 'two_board_members'
    : input.approverSequential ? 'sequential' : requiredApprovals === approverIds.length ? 'all' : 'any';
  await database.transaction(async (tx: any) => {
    const existing = await tx.select().from(approvalWorkflows).where(eq(approvalWorkflows.documentTypeId, input.documentTypeId)).limit(1);
    let workflowId: number;
    if (existing[0]) {
      workflowId = existing[0].id;
      await tx.update(approvalWorkflows).set({
        reviewerUserId: reviewerIds[0] || null,
        reviewerSequential: Boolean(input.reviewerSequential && reviewerIds.length > 1),
        requiredReviews: reviewerIds.length,
        approvalMode,
        approverSequential: Boolean(input.approverSequential && approverIds.length > 1),
        requiredApprovals,
        boardMembersOnly: input.approvalMode === 'two_board_members',
        isActive: true,
      }).where(eq(approvalWorkflows.id, workflowId));
      await tx.delete(approvalWorkflowReviewers).where(eq(approvalWorkflowReviewers.workflowId, workflowId));
      await tx.delete(approvalWorkflowApprovers).where(eq(approvalWorkflowApprovers.workflowId, workflowId));
    } else {
      const inserted = await tx.insert(approvalWorkflows).values({
        documentTypeId: input.documentTypeId,
        reviewerUserId: reviewerIds[0] || null,
        reviewerSequential: Boolean(input.reviewerSequential && reviewerIds.length > 1),
        requiredReviews: reviewerIds.length,
        approvalMode,
        approverSequential: Boolean(input.approverSequential && approverIds.length > 1),
        requiredApprovals,
        boardMembersOnly: input.approvalMode === 'two_board_members',
      });
      workflowId = Number((inserted as any)[0]?.insertId);
    }
    if (reviewerIds.length) await tx.insert(approvalWorkflowReviewers).values(reviewerIds.map((systemUserId, index) => ({ workflowId, systemUserId, sortOrder: index + 1 })));
    await tx.insert(approvalWorkflowApprovers).values(approverIds.map((systemUserId, index) => ({ workflowId, systemUserId, sortOrder: index + 1 })));
  });
}

// ==================== Approval Requests ====================
export async function getApprovalRequests(filters?: { delegateId?: number; status?: string; requestedBy?: number }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(approvalRequests);
  const conditions = [];
  if (filters?.delegateId) conditions.push(eq(approvalRequests.delegateId, filters.delegateId));
  if (filters?.status) conditions.push(eq(approvalRequests.status, filters.status as any));
  if (filters?.requestedBy) conditions.push(eq(approvalRequests.requestedBy, filters.requestedBy));
  if (conditions.length > 0) query = query.where(and(...conditions)) as any;
  const requests = await query.orderBy(desc(approvalRequests.createdAt));
  const requestIds = requests.map(request => request.id);
  if (!requestIds.length) return [];
  const [reviewerSteps, steps, participants] = await Promise.all([
    db.select().from(approvalRequestReviewerSteps).where(inArray(approvalRequestReviewerSteps.requestId, requestIds)).orderBy(asc(approvalRequestReviewerSteps.stepOrder)),
    db.select().from(approvalRequestSteps).where(inArray(approvalRequestSteps.requestId, requestIds)).orderBy(asc(approvalRequestSteps.stepOrder)),
    db.select({ id: systemUsers.id, fullName: systemUsers.fullName, boardPosition: systemUsers.boardPosition }).from(systemUsers),
  ]);
  return requests.map(request => ({
    ...request,
    reviewerSteps: reviewerSteps.filter(step => step.requestId === request.id).map(step => ({
      ...step,
      reviewerName: participants.find(participant => participant.id === step.systemUserId)?.fullName || 'مراجع غير محدد',
      boardPosition: participants.find(participant => participant.id === step.systemUserId)?.boardPosition || null,
    })),
    steps: steps.filter(step => step.requestId === request.id).map(step => ({
      ...step,
      approverName: participants.find(participant => participant.id === step.systemUserId)?.fullName || 'مفوض غير محدد',
      boardPosition: participants.find(participant => participant.id === step.systemUserId)?.boardPosition || null,
    })),
  }));
}

export async function createApprovalRequest(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(approvalRequests).values(data);
}

export async function updateApprovalRequest(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(approvalRequests).set(data).where(eq(approvalRequests.id, id));
}

export async function createApprovalRequestFromWorkflow(input: { documentTypeId: number; requestedBy: number; title: string; description?: string; attachmentUrl?: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  const workflow = await getApprovalWorkflow(input.documentTypeId);
  if (!workflow || !workflow.approvers.length) throw new Error('لا يوجد مسار تعميد نشط لهذا النوع من المستندات');
  const [documentType] = await database.select().from(documentTypes).where(eq(documentTypes.id, input.documentTypeId)).limit(1);
  if (!documentType) throw new Error('نوع التعميد غير موجود');
  if (documentType.templateRequirement === 'required' && !input.attachmentUrl) throw new Error('يلزم إرفاق النموذج المكتمل قبل إرسال طلب التعميد');
  const created = await database.insert(approvalRequests).values({
    ...input,
    workflowId: workflow.id,
    reviewerUserId: workflow.reviewers[0]?.systemUserId || null,
    reviewerSequential: workflow.reviewerSequential,
    requiredReviews: workflow.requiredReviews,
    reviewStatus: workflow.reviewers.length ? 'pending' : 'not_required',
    approverSequential: workflow.approverSequential,
    approvalMode: workflow.approvalMode,
    requiredApprovals: workflow.requiredApprovals,
    templateRequired: documentType.templateRequirement === 'required',
    approvedCount: 0,
    status: workflow.reviewers.length ? 'review_pending' : 'sent',
    currentStepOrder: 1,
  });
  const requestId = Number((created as any)[0]?.insertId);
  if (workflow.reviewers.length) await database.insert(approvalRequestReviewerSteps).values(workflow.reviewers.map(reviewer => ({ requestId, workflowId: workflow.id, systemUserId: reviewer.systemUserId, stepOrder: reviewer.sortOrder })));
  await database.insert(approvalRequestSteps).values(workflow.approvers.map(approver => ({ requestId, workflowId: workflow.id, systemUserId: approver.systemUserId, stepOrder: approver.sortOrder })));
  const recipients = workflow.reviewers.length
    ? (workflow.reviewerSequential ? workflow.reviewers.filter(reviewer => reviewer.sortOrder === 1) : workflow.reviewers)
    : (workflow.approverSequential ? workflow.approvers.filter(approver => approver.sortOrder === 1) : workflow.approvers);
  await database.insert(internalNotifications).values(recipients.map(participant => ({
    recipientUserId: participant.systemUserId,
    notificationType: workflow.reviewers.length ? 'approval_review' : 'approval_request',
    approvalRequestId: requestId,
    title: workflow.reviewers.length ? 'طلب تعميد بانتظار المراجعة' : 'طلب تعميد جديد بانتظار قرارك',
    message: `يوجد طلب تعميد جديد بعنوان «${input.title}» يحتاج إلى ${workflow.reviewers.length ? 'مراجعتك' : 'قرارك'}.`,
  })));
  return { id: requestId };
}

export async function createApprovalDraftFromWorkflow(input: { documentTypeId: number; requestedBy: number; title?: string; description?: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx) => {
    const [workflow] = await tx.select().from(approvalWorkflows)
      .where(and(eq(approvalWorkflows.documentTypeId, input.documentTypeId), eq(approvalWorkflows.isActive, true))).limit(1);
    if (!workflow) throw new Error('لا يوجد مسار تعميد نشط لهذا النوع من المستندات');
    const [reviewers, approvers] = await Promise.all([
      tx.select().from(approvalWorkflowReviewers).where(eq(approvalWorkflowReviewers.workflowId, workflow.id)).orderBy(asc(approvalWorkflowReviewers.sortOrder)),
      tx.select().from(approvalWorkflowApprovers).where(eq(approvalWorkflowApprovers.workflowId, workflow.id)).orderBy(asc(approvalWorkflowApprovers.sortOrder)),
    ]);
    if (!approvers.length) throw new Error('لا يوجد مفوضون محددون لهذا النوع من التعميد');
    const [requester] = await tx.select({ username: systemUsers.username, fullName: systemUsers.fullName, userType: systemUsers.userType, boardPosition: systemUsers.boardPosition })
      .from(systemUsers).where(eq(systemUsers.id, input.requestedBy)).limit(1);
    if (!requester) throw new Error('تعذر تحديد بيانات طالب التعميد');
    const sequence = await tx.select({ value: sql<number>`COALESCE(MAX(CAST(SUBSTRING_INDEX(${approvalRequests.approvalNumber}, '-', -1) AS UNSIGNED)), 0)` })
      .from(approvalRequests).where(eq(approvalRequests.requestedBy, input.requestedBy));
    const approvalNumber = `RA${requester.username}-${String(Number(sequence[0]?.value || 0) + 1).padStart(3, '0')}`;
    const [documentType] = await tx.select().from(documentTypes).where(eq(documentTypes.id, input.documentTypeId)).limit(1);
    const roles: Record<string, string> = { admin: 'مدير النظام', accountant: 'محاسب', delegate: 'مندوب', branch_supervisor: 'مشرف فرع', authorized_partner: 'شريك مفوض' };
    const inserted = await tx.insert(approvalRequests).values({
      documentTypeId: input.documentTypeId,
      requestedBy: input.requestedBy,
      approvalNumber,
      requesterName: requester.fullName,
      requesterPosition: requester.boardPosition || roles[requester.userType] || 'مستخدم النظام',
      workflowId: workflow.id,
      reviewerUserId: reviewers[0]?.systemUserId || null,
      reviewerSequential: workflow.reviewerSequential,
      requiredReviews: reviewers.length,
      reviewedCount: 0,
      currentReviewStepOrder: 1,
      approvalMode: workflow.approvalMode,
      approverSequential: workflow.approverSequential,
      requiredApprovals: workflow.requiredApprovals,
      reviewStatus: reviewers.length ? 'not_started' : 'not_required',
      templateRequired: documentType?.templateRequirement === 'required',
      status: 'draft',
      title: input.title?.trim() || documentType?.name || 'طلب تعميد',
      description: input.description?.trim() || null,
    });
    const requestId = Number((inserted as any)[0]?.insertId);
    if (reviewers.length) await tx.insert(approvalRequestReviewerSteps).values(reviewers.map(reviewer => ({ requestId, workflowId: workflow.id, systemUserId: reviewer.systemUserId, stepOrder: reviewer.sortOrder })));
    await tx.insert(approvalRequestSteps).values(approvers.map(approver => ({ requestId, workflowId: workflow.id, systemUserId: approver.systemUserId, stepOrder: approver.sortOrder })));
    return { id: requestId, approvalNumber, templateAvailable: Boolean(documentType?.templateUrl), templateRequired: documentType?.templateRequirement === 'required' };
  });
}

export async function attachApprovalDraft(input: { requestId: number; requesterId: number; attachmentUrl: string; attachmentName: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  const [request] = await database.select().from(approvalRequests).where(eq(approvalRequests.id, input.requestId)).limit(1);
  if (!request || request.requestedBy !== input.requesterId || request.status !== 'draft') throw new Error('لا يمكن إرفاق نموذج لهذا الطلب');
  await database.update(approvalRequests).set({ attachmentUrl: input.attachmentUrl, attachmentName: input.attachmentName }).where(eq(approvalRequests.id, input.requestId));
}

export async function submitApprovalDraft(input: { requestId: number; requesterId: number }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx) => {
    const [request] = await tx.select().from(approvalRequests).where(eq(approvalRequests.id, input.requestId)).limit(1);
    if (!request || request.requestedBy !== input.requesterId || request.status !== 'draft') throw new Error('الطلب غير متاح للإرسال');
    if (request.templateRequired && !request.attachmentUrl) throw new Error('يرجى إرفاق النموذج المكتمل قبل إرسال طلب التعميد');
    const reviewers = await tx.select().from(approvalRequestReviewerSteps).where(eq(approvalRequestReviewerSteps.requestId, request.id)).orderBy(asc(approvalRequestReviewerSteps.stepOrder));
    const nextStatus = reviewers.length ? 'review_pending' : 'sent';
    await tx.update(approvalRequests).set({ status: nextStatus, reviewStatus: reviewers.length ? 'pending' : 'not_required', submittedAt: new Date() }).where(eq(approvalRequests.id, input.requestId));
    if (reviewers.length) {
      const recipients = request.reviewerSequential ? reviewers.filter(step => step.stepOrder === 1) : reviewers;
      await tx.insert(internalNotifications).values(recipients.map(step => ({ recipientUserId: step.systemUserId, notificationType: 'approval_review', approvalRequestId: request.id, title: 'طلب تعميد بانتظار المراجعة', message: `طلب ${request.approvalNumber || request.title} أُرسل إليك للمراجعة قبل التعميد.` })));
    } else {
      const steps = await tx.select().from(approvalRequestSteps).where(eq(approvalRequestSteps.requestId, request.id)).orderBy(asc(approvalRequestSteps.stepOrder));
      const recipients = request.approverSequential || request.approvalMode === 'sequential' ? steps.filter(step => step.stepOrder === 1) : steps;
      if (recipients.length) await tx.insert(internalNotifications).values(recipients.map(step => ({ recipientUserId: step.systemUserId, notificationType: 'approval_request', approvalRequestId: request.id, title: 'طلب تعميد جديد بانتظار قرارك', message: `يوجد طلب تعميد جديد بعنوان «${request.title}» يحتاج إلى قرارك.` })));
    }
    return { status: nextStatus };
  });
}

export async function reviewApprovalRequest(input: { requestId: number; reviewerId: number; decision: 'approved' | 'rejected'; note?: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx) => {
    const [request] = await tx.select().from(approvalRequests).where(eq(approvalRequests.id, input.requestId)).limit(1);
    if (!request || request.status !== 'review_pending') throw new Error('طلب التعميد غير متاح للمراجعة');
    const reviewerSteps = await tx.select().from(approvalRequestReviewerSteps).where(eq(approvalRequestReviewerSteps.requestId, request.id)).orderBy(asc(approvalRequestReviewerSteps.stepOrder));
    const reviewerStep = reviewerSteps.find(step => step.systemUserId === input.reviewerId && step.status === 'pending');
    if (!reviewerStep) throw new Error('لا تملك خطوة مراجعة معلقة لهذا الطلب');
    if (request.reviewerSequential && reviewerStep.stepOrder !== request.currentReviewStepOrder) throw new Error('ينتظر الطلب مراجعة المستخدم السابق في التسلسل');
    await tx.update(approvalRequestReviewerSteps).set({ status: input.decision, note: input.note || null, actedAt: new Date() }).where(eq(approvalRequestReviewerSteps.id, reviewerStep.id));
    if (input.decision === 'rejected') {
      await tx.update(approvalRequests).set({ status: 'rejected', reviewStatus: 'rejected', reviewNote: input.note || null, reviewedCount: reviewerSteps.filter(step => step.status === 'approved').length, reviewedAt: new Date() }).where(eq(approvalRequests.id, input.requestId));
      return { status: 'rejected' as const };
    }
    const reviewedCount = reviewerSteps.filter(step => step.status === 'approved').length + 1;
    if (reviewedCount >= reviewerSteps.length) {
      await tx.update(approvalRequests).set({ status: 'sent', reviewStatus: 'approved', reviewNote: input.note || null, reviewedCount, reviewedAt: new Date() }).where(eq(approvalRequests.id, input.requestId));
      const approvalSteps = await tx.select().from(approvalRequestSteps).where(eq(approvalRequestSteps.requestId, request.id)).orderBy(asc(approvalRequestSteps.stepOrder));
      const recipients = request.approverSequential || request.approvalMode === 'sequential' ? approvalSteps.filter(step => step.stepOrder === 1) : approvalSteps;
      if (recipients.length) await tx.insert(internalNotifications).values(recipients.map(step => ({ recipientUserId: step.systemUserId, notificationType: 'approval_request', approvalRequestId: request.id, title: 'طلب تعميد بعد المراجعة', message: `راجع ${request.approvalNumber || request.title} وأُحيل إليك للتعميد.` })));
      return { status: 'sent' as const };
    }
    if (request.reviewerSequential) {
      const nextStep = reviewerSteps.find(step => step.stepOrder === reviewerStep.stepOrder + 1);
      await tx.update(approvalRequests).set({ reviewedCount, currentReviewStepOrder: reviewerStep.stepOrder + 1, reviewNote: input.note || null }).where(eq(approvalRequests.id, input.requestId));
      if (nextStep) await tx.insert(internalNotifications).values({ recipientUserId: nextStep.systemUserId, notificationType: 'approval_review', approvalRequestId: request.id, title: 'طلب تعميد بانتظار المراجعة', message: `أصبحت خطوة المراجعة التالية متاحة لك لطلب «${request.title}».` });
    } else {
      await tx.update(approvalRequests).set({ reviewedCount, reviewNote: input.note || null }).where(eq(approvalRequests.id, input.requestId));
    }
    return { status: 'review_pending' as const };
  });
}

export async function decideApprovalRequestStep(input: { requestId: number; systemUserId: number; decision: 'approved' | 'rejected'; note?: string }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx) => {
    const request = await tx.select().from(approvalRequests).where(eq(approvalRequests.id, input.requestId)).limit(1);
    if (!request[0] || request[0].status !== 'sent') throw new Error('طلب التعميد غير متاح لاتخاذ قرار');
    const steps = await tx.select().from(approvalRequestSteps).where(eq(approvalRequestSteps.requestId, input.requestId)).orderBy(asc(approvalRequestSteps.stepOrder));
    const step = steps.find(item => item.systemUserId === input.systemUserId && item.status === 'pending');
    if (!step) throw new Error('لا تملك خطوة تعميد معلقة لهذا الطلب');
    const approverSequential = request[0].approverSequential || request[0].approvalMode === 'sequential';
    if (approverSequential && step.stepOrder !== request[0].currentStepOrder) throw new Error('ينتظر الطلب اعتماد المفوض السابق في التسلسل');
    if (request[0].approvalMode === 'two_board_members') {
      const member = await tx.select({ userType: systemUsers.userType, boardPosition: systemUsers.boardPosition, isActive: systemUsers.isActive })
        .from(systemUsers).where(eq(systemUsers.id, input.systemUserId)).limit(1);
      if (!member[0] || member[0].userType !== 'authorized_partner' || !isBoardMemberPosition(member[0].boardPosition) || !member[0].isActive) {
        throw new Error('يقتصر اعتماد هذا الطلب على أعضاء مجلس الإدارة النشطين');
      }
    }
    await tx.update(approvalRequestSteps).set({ status: input.decision, note: input.note || null, actedAt: new Date() }).where(eq(approvalRequestSteps.id, step.id));
    if (input.decision === 'rejected') {
      await tx.update(approvalRequests).set({ status: 'rejected', approvalNote: input.note || null, approvedAt: new Date() }).where(eq(approvalRequests.id, input.requestId));
      return { status: 'rejected' as const };
    }
    const approvedCount = steps.filter(item => item.status === 'approved').length + 1;
    const complete = approvedCount >= request[0].requiredApprovals;
    if (complete) {
      if (approvedCount < steps.length) await tx.update(approvalRequestSteps).set({ status: 'skipped' }).where(and(eq(approvalRequestSteps.requestId, input.requestId), eq(approvalRequestSteps.status, 'pending')));
      await tx.update(approvalRequests).set({ status: 'approved', approvedCount, approvalNote: input.note || null, approvedAt: new Date() }).where(eq(approvalRequests.id, input.requestId));
      return { status: 'approved' as const };
    }
    if (approverSequential) {
      await tx.update(approvalRequests).set({ currentStepOrder: step.stepOrder + 1, approvedCount }).where(eq(approvalRequests.id, input.requestId));
      const nextApprover = steps.find(item => item.stepOrder === step.stepOrder + 1);
      if (nextApprover) await tx.insert(internalNotifications).values({ recipientUserId: nextApprover.systemUserId, notificationType: 'approval_request', approvalRequestId: input.requestId, title: 'طلب تعميد بانتظار قرارك', message: `أصبحت خطوة التعميد التالية متاحة لك لطلب «${request[0].title}».` });
    } else {
      await tx.update(approvalRequests).set({ approvedCount }).where(eq(approvalRequests.id, input.requestId));
    }
    return { status: 'sent' as const };
  });
}

export async function deleteApprovalHistory() {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات');
  return database.transaction(async (tx: any) => {
    const [{ count: requestCount }] = await tx.select({ count: sql<number>`count(*)` }).from(approvalRequests);
    const [{ count: reviewerStepCount }] = await tx.select({ count: sql<number>`count(*)` }).from(approvalRequestReviewerSteps);
    const [{ count: approvalStepCount }] = await tx.select({ count: sql<number>`count(*)` }).from(approvalRequestSteps);
    const [{ count: notificationCount }] = await tx.select({ count: sql<number>`count(*)` }).from(internalNotifications).where(isNotNull(internalNotifications.approvalRequestId));
    await tx.delete(internalNotifications).where(isNotNull(internalNotifications.approvalRequestId));
    await tx.delete(approvalRequestReviewerSteps);
    await tx.delete(approvalRequestSteps);
    await tx.delete(approvalRequests);
    return {
      approvalRequests: Number(requestCount),
      reviewerSteps: Number(reviewerStepCount),
      approvalSteps: Number(approvalStepCount),
      notifications: Number(notificationCount),
    };
  });
}

// ==================== News Items ====================
export async function getNewsItems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsItems).orderBy(asc(newsItems.sortOrder));
}

export async function createNewsItem(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(newsItems).values(data);
}

export async function updateNewsItem(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(newsItems).set(data).where(eq(newsItems.id, id));
}

export async function deleteNewsItem(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(newsItems).where(eq(newsItems.id, id));
}

// ==================== Login Backgrounds ====================
export async function getLoginBackgrounds() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(loginBackgrounds).where(eq(loginBackgrounds.isActive, true)).orderBy(asc(loginBackgrounds.sortOrder));
}

export async function createLoginBackground(data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(loginBackgrounds).values(data);
}

export async function updateLoginBackground(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return db.update(loginBackgrounds).set(data).where(eq(loginBackgrounds.id, id));
}

export async function deleteLoginBackground(id: number) {
  const db = await getDb();
  if (!db) return null;
  return db.delete(loginBackgrounds).where(eq(loginBackgrounds.id, id));
}

// ==================== Activity Log ====================
export async function logActivity(userId: number, action: string, details?: string) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(activityLog).values({ userId, action, details });
}

// ==================== Reports ====================
export async function getReceiptsSummary(periodId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    branchId: receipts.branchId,
    totalAmount: sql<string>`SUM(${receipts.amount})`,
    count: sql<number>`COUNT(*)`,
  }).from(receipts).where(and(eq(receipts.periodId, periodId), eq(receipts.status, 'approved'))).groupBy(receipts.branchId);
}

export async function getBankCollectionsByPeriod(filters: { periodId?: number; bankId?: number; startDate?: string; endDate?: string }) {
  const database = await getDb();
  if (!database) return [];
  const conditions = [eq(receipts.status, 'approved')];
  if (filters.periodId) conditions.push(eq(receipts.periodId, filters.periodId));
  if (filters.bankId) conditions.push(eq(receipts.bankId, filters.bankId));
  if (filters.startDate) conditions.push(sql`DATE(${receipts.createdAt}) >= ${filters.startDate}`);
  if (filters.endDate) conditions.push(sql`DATE(${receipts.createdAt}) <= ${filters.endDate}`);
  return database.select({
    day: sql<string>`DATE(${receipts.createdAt})`,
    bankId: receipts.bankId,
    bankName: inputLists.name,
    totalAmount: sql<string>`SUM(${receipts.amount})`,
    receiptCount: sql<number>`COUNT(*)`,
  })
    .from(receipts)
    .leftJoin(inputLists, eq(receipts.bankId, inputLists.id))
    .where(and(...conditions))
    .groupBy(sql`DATE(${receipts.createdAt})`, receipts.bankId, inputLists.name)
    .orderBy(desc(sql`DATE(${receipts.createdAt})`), asc(inputLists.name));
}

export async function getReceiptsByUser(userId: number, periodId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(receipts).where(and(eq(receipts.userId, userId), eq(receipts.periodId, periodId))).orderBy(desc(receipts.createdAt));
}

export const SYSTEM_BACKUP_DATA_KEYS = [
  'users', 'systemUsers', 'systemSettings', 'companyProfile', 'regions', 'branches',
  'financialPeriods', 'partners', 'partnerPeriodSettings', 'partnerPeriodAllocations', 'partnerPeriodMemberships', 'partnerPeriodEquityLines', 'partnerProfitDistributions', 'partnerPeriodDocuments', 'partnerAccountEntries',
  'branchTargets', 'goalTypes', 'administrativeGoals', 'administrativeGoalReviewers', 'administrativeGoalActions', 'administrativeGoalActionAttachments',
  'salesGoalPlans', 'salesGoalMetrics', 'commissionPlans', 'commissionTiers', 'customers', 'inputLists', 'receipts',
  'receiptInvoices', 'payments', 'performanceReports', 'delegates', 'documentTypes',
  'approvalRequests', 'newsItems', 'loginBackgrounds', 'activityLog',
  'internalNotifications', 'receiptDecisionAudit', 'backupLogs',
] as const;

export type SystemBackupData = Record<(typeof SYSTEM_BACKUP_DATA_KEYS)[number], Record<string, unknown>[]>;

export async function createFullSystemBackup(): Promise<SystemBackupData> {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات لإنشاء النسخة الاحتياطية');
  return {
    users: await database.select().from(users), systemUsers: await database.select().from(systemUsers),
    systemSettings: await database.select().from(systemSettings), companyProfile: await database.select().from(companyProfile),
    regions: await database.select().from(regions), branches: await database.select().from(branches),
    financialPeriods: await database.select().from(financialPeriods), partners: await database.select().from(partners),
    partnerPeriodSettings: await database.select().from(partnerPeriodSettings), partnerPeriodAllocations: await database.select().from(partnerPeriodAllocations),
    partnerPeriodMemberships: await database.select().from(partnerPeriodMemberships), partnerPeriodEquityLines: await database.select().from(partnerPeriodEquityLines),
    partnerProfitDistributions: await database.select().from(partnerProfitDistributions), partnerPeriodDocuments: await database.select().from(partnerPeriodDocuments), partnerAccountEntries: await database.select().from(partnerAccountEntries),
    branchTargets: await database.select().from(branchTargets), goalTypes: await database.select().from(goalTypes),
    administrativeGoals: await database.select().from(administrativeGoals), administrativeGoalReviewers: await database.select().from(administrativeGoalReviewers),
    administrativeGoalActions: await database.select().from(administrativeGoalActions), administrativeGoalActionAttachments: await database.select().from(administrativeGoalActionAttachments),
    salesGoalPlans: await database.select().from(salesGoalPlans), salesGoalMetrics: await database.select().from(salesGoalMetrics),
    commissionPlans: await database.select().from(commissionPlans), commissionTiers: await database.select().from(commissionTiers),
    customers: await database.select().from(customers), inputLists: await database.select().from(inputLists),
    receipts: await database.select().from(receipts), receiptInvoices: await database.select().from(receiptInvoices),
    payments: await database.select().from(payments), performanceReports: await database.select().from(performanceReports),
    delegates: await database.select().from(delegates), documentTypes: await database.select().from(documentTypes),
    approvalRequests: await database.select().from(approvalRequests), newsItems: await database.select().from(newsItems),
    loginBackgrounds: await database.select().from(loginBackgrounds), activityLog: await database.select().from(activityLog),
    internalNotifications: await database.select().from(internalNotifications), receiptDecisionAudit: await database.select().from(receiptDecisionAudit),
    backupLogs: await database.select().from(backupLogs),
  } as SystemBackupData;
}

function normalizeRestoredRow(row: Record<string, unknown>) {
  return Object.fromEntries(Object.entries(row).map(([key, value]) => {
    if (typeof value === 'string' && (key.endsWith('At') || key.endsWith('Date'))) return [key, new Date(value)];
    return [key, value];
  }));
}

export async function restoreFullSystemBackup(data: SystemBackupData) {
  const database = await getDb();
  if (!database) throw new Error('تعذر الاتصال بقاعدة البيانات لاستيراد النسخة الاحتياطية');
  const tablesInRestoreOrder = [
    [partnerAccountEntries, data.partnerAccountEntries || []], [partnerProfitDistributions, data.partnerProfitDistributions || []], [partnerPeriodDocuments, data.partnerPeriodDocuments || []],
    [partnerPeriodEquityLines, data.partnerPeriodEquityLines || []], [partnerPeriodAllocations, data.partnerPeriodAllocations || []], [partnerPeriodMemberships, data.partnerPeriodMemberships || []],
    [partnerPeriodSettings, data.partnerPeriodSettings || []], [partners, data.partners || []],
    [receiptDecisionAudit, data.receiptDecisionAudit], [receiptInvoices, data.receiptInvoices],
    [internalNotifications, data.internalNotifications], [approvalRequests, data.approvalRequests],
    [receipts, data.receipts], [payments, data.payments], [performanceReports, data.performanceReports],
    [administrativeGoalActionAttachments, data.administrativeGoalActionAttachments || []],
    [administrativeGoalActions, data.administrativeGoalActions || []], [administrativeGoalReviewers, data.administrativeGoalReviewers || []],
    [administrativeGoals, data.administrativeGoals || []], [commissionTiers, data.commissionTiers || []],
    [commissionPlans, data.commissionPlans || []], [salesGoalMetrics, data.salesGoalMetrics || []],
    [salesGoalPlans, data.salesGoalPlans || []], [goalTypes, data.goalTypes || []],
    [branchTargets, data.branchTargets], [customers, data.customers], [delegates, data.delegates],
    [systemUsers, data.systemUsers], [users, data.users], [inputLists, data.inputLists],
    [documentTypes, data.documentTypes], [newsItems, data.newsItems], [loginBackgrounds, data.loginBackgrounds],
    [financialPeriods, data.financialPeriods], [branches, data.branches], [regions, data.regions],
    [systemSettings, data.systemSettings], [companyProfile, data.companyProfile],
    [activityLog, data.activityLog], [backupLogs, data.backupLogs],
  ] as const;
  await database.transaction(async (tx) => {
    await tx.delete(passwordResetCodes);
    for (const [table] of tablesInRestoreOrder) await tx.delete(table);
    for (const [table, rows] of [...tablesInRestoreOrder].reverse()) {
      if (rows.length > 0) await tx.insert(table).values(rows.map(normalizeRestoredRow) as any);
    }
  });
  return SYSTEM_BACKUP_DATA_KEYS.reduce((total, key) => total + (data[key] || []).length, 0);
}

export async function createBackupLog(input: { operation: 'download' | 'restore'; fileName: string; recordsCount: number; status?: 'success' | 'failed'; details?: string; userId: number }) {
  const database = await getDb();
  if (!database) throw new Error('تعذر حفظ سجل النسخة الاحتياطية');
  await database.insert(backupLogs).values({ ...input, status: input.status || 'success' });
}

export async function getBackupLogs() {
  const database = await getDb();
  if (!database) return [];
  return database.select().from(backupLogs).orderBy(desc(backupLogs.createdAt));
}
