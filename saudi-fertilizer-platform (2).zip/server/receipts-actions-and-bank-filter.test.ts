import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const projectRoot = resolve(__dirname, '..');
const receiptsPage = readFileSync(resolve(projectRoot, 'client/src/pages/ReceiptsPage.tsx'), 'utf8');
const dashboardPage = readFileSync(resolve(projectRoot, 'client/src/pages/Dashboard.tsx'), 'utf8');
const router = readFileSync(resolve(projectRoot, 'server/routers.ts'), 'utf8');
const database = readFileSync(resolve(projectRoot, 'server/db.ts'), 'utf8');

describe('إجراءات سندات القبض وفلاتر المتحصلات البنكية', () => {
  it('يعرض اختصارات السند المطلوبة وينقل الاعتماد والرفض إلى الحالة ويبقي الحذف وسجل القرارات ضمن الإجراء الإداري الإضافي', () => {
    const actionSectionStart = receiptsPage.indexOf('aria-label={`اختصارات سند ${r.serialNumber}`}');
    const actionSection = receiptsPage.slice(actionSectionStart, receiptsPage.indexOf('</TableCell>', actionSectionStart));
    expect(actionSection).toContain('معاينة الإيصال');
    expect(actionSection).toContain('تحميل السند');
    expect(actionSection).toContain('تحميل السند مع الإيصال');
    expect(actionSection).not.toContain('اعتماد السند');
    expect(actionSection).not.toContain('رفض السند');
    expect(actionSection).toContain('تعديل السند');
    expect(actionSection).toContain('سجل الطباعة');
    expect(actionSection).toContain('إجراءات إدارية إضافية');
    expect(actionSection).toContain('حذف السند');
    expect(actionSection).toContain('سجل القرارات');
    expect(receiptsPage).toContain("canApprove && r.status === 'issued'");
    expect(receiptsPage).toContain("openReceiptDecision(r, 'approved')");
    expect(receiptsPage).toContain("openReceiptDecision(r, 'rejected')");
  });

  it('يمرر فلتر البنك مع الفترة إلى تقرير المتحصلات ويطبقه استعلام الخادم', () => {
    expect(dashboardPage).toContain('bankId: bankFilter === \'all\' ? undefined : Number(bankFilter)');
    expect(dashboardPage).toContain("aria-label={labelFor('field_bank', 'البنك')}");
    expect(router).toContain('bankId: z.number().optional()');
    expect(database).toContain('if (filters.bankId) conditions.push(eq(receipts.bankId, filters.bankId));');
  });
});
