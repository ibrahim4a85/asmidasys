import { describe, expect, it } from 'vitest';
import { collectManagedStorageUrls, getManagedStorageKey, relinkManagedStorageUrls, SYSTEM_BACKUP_FORMAT, SYSTEM_BACKUP_VERSION, createSystemBackupFileName, getSystemBackupRecordCount } from '../shared/systemBackup';

describe('النسخ الاحتياطي الكامل للنظام', () => {
  it('يحمل معرف التنسيق والإصدار الثابتين للتحقق من توافق ملف النسخة', () => {
    expect(SYSTEM_BACKUP_FORMAT).toBe('asmidasys-full-system-backup');
    expect(SYSTEM_BACKUP_VERSION).toBe(2);
  });

  it('يحسب جميع صفوف أقسام النسخة دون الاعتماد على أسماء الأقسام', () => {
    expect(getSystemBackupRecordCount({
      customers: [{ id: 1 }, { id: 2 }],
      receipts: [{ id: 5 }],
      systemSettings: [],
    })).toBe(3);
  });

  it('ينشئ اسماً فريداً ومنظماً لملف النسخة الكاملة', () => {
    expect(createSystemBackupFileName(new Date('2026-08-19T08:10:11.123Z'))).toBe('asmidasys-full-backup-2026-08-19T08-10-11-123Z.json');
  });

  it('يستخرج فقط الملفات المخزنة داخل المنصة ويعيد ربط عناوينها بعد الاستيراد', () => {
    const data = { receipts: [{ attachmentUrl: '/manus-storage/receipts/slip.pdf', externalUrl: 'https://example.com/file.pdf' }], company: [{ logoUrl: '/manus-storage/company/logo.png' }] };
    expect(collectManagedStorageUrls(data)).toEqual(['/manus-storage/receipts/slip.pdf', '/manus-storage/company/logo.png']);
    expect(getManagedStorageKey('/manus-storage/company/logo.png')).toBe('company/logo.png');
    expect(relinkManagedStorageUrls(data, new Map([['/manus-storage/company/logo.png', '/manus-storage/restored/logo.png']]))).toEqual({ receipts: [{ attachmentUrl: '/manus-storage/receipts/slip.pdf', externalUrl: 'https://example.com/file.pdf' }], company: [{ logoUrl: '/manus-storage/restored/logo.png' }] });
  });
});
