import { useEffect, useMemo, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { FileDropzone } from '@/components/FileDropzone';
import { useSystemAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Download, Eye, FileCheck2, FileText, Plus, Send, Upload, UserCheck } from 'lucide-react';
import { toast } from 'sonner';
import { getApprovalRequesterStatus } from '../../../shared/approvalRequestStatus';
import { isPdfApprovalAttachment } from '@/lib/approvalAttachmentPreview';
import { useSystemLabels } from '@/hooks/useSystemLabels';

type Draft = { id: number; approvalNumber: string; documentTypeId: number; templateAvailable: boolean; templateRequired: boolean; hasAttachment: boolean };
type AttachmentPreview = { requestId: number; approvalNumber: string; fileName: string; url: string; isPdf: boolean };

function toDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة الملف المختار'));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}

function downloadDataUrl(dataUrl: string, fileName: string) {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export default function DelegatesPage() {
  const { user, isAdmin } = useSystemAuth();
  const { labelFor } = useSystemLabels();
  const utils = trpc.useUtils();
  const [requestOpen, setRequestOpen] = useState(false);
  const [documentTypeId, setDocumentTypeId] = useState('');
  const [description, setDescription] = useState('');
  const [draft, setDraft] = useState<Draft | null>(null);
  const [attachment, setAttachment] = useState<File | null>(null);
  const [reviewNotes, setReviewNotes] = useState<Record<number, string>>({});
  const [decisionNotes, setDecisionNotes] = useState<Record<number, string>>({});
  const [openingAttachmentId, setOpeningAttachmentId] = useState<number | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState<AttachmentPreview | null>(null);
  const [activeTab, setActiveTab] = useState('status');
  const highlightedApprovalRequestId = useMemo(() => {
    const value = Number(new URLSearchParams(window.location.search).get('approvalRequestId'));
    return Number.isInteger(value) && value > 0 ? value : null;
  }, []);

  const { data: approvals = [], refetch: refetchApprovals } = trpc.approvals.list.useQuery({});
  const { data: docTypes = [] } = trpc.documentTypes.list.useQuery();
  const canRequestApproval = isAdmin || user?.userLevel === 'primary' || Boolean((user?.permissions as Record<string, boolean> | undefined)?.approvalRequest);
  const myRequests = useMemo(() => approvals.filter((request: any) => request.requestedBy === user?.id), [approvals, user?.id]);
  const visibleRequests = isAdmin ? approvals : myRequests;
  const reviewRequests = useMemo(() => approvals.filter((request: any) => request.status === 'review_pending' && request.reviewerSteps?.some((step: any) => step.systemUserId === user?.id && step.status === 'pending' && (!request.reviewerSequential || step.stepOrder === request.currentReviewStepOrder))), [approvals, user?.id]);
  const decisionRequests = useMemo(() => approvals.filter((request: any) => request.status === 'sent' && request.steps?.some((step: any) => step.systemUserId === user?.id && step.status === 'pending' && (!request.approverSequential || step.stepOrder === request.currentStepOrder))), [approvals, user?.id]);
  const canDecideApproval = decisionRequests.length > 0;

  const createDraftMutation = trpc.approvals.createDraft.useMutation({
    onSuccess: (result, input) => {
      setDraft({ ...result, documentTypeId: input.documentTypeId, hasAttachment: false });
      refetchApprovals();
      toast.success(`تم حفظ المسودة برقم ${result.approvalNumber}`);
    },
    onError: (error) => toast.error(error.message),
  });
  const uploadAttachmentMutation = trpc.files.uploadApprovalAttachment.useMutation();
  const attachDraftMutation = trpc.approvals.attachDraft.useMutation({ onSuccess: () => { setDraft(current => current ? { ...current, hasAttachment: true } : current); refetchApprovals(); toast.success('تم إرفاق النموذج المكتمل'); } });
  const submitDraftMutation = trpc.approvals.submitDraft.useMutation({
    onSuccess: () => { refetchApprovals(); closeRequestDialog(); toast.success('تم إرسال الطلب للمراجع أو المفوضين'); },
    onError: (error) => toast.error(error.message),
  });
  const reviewMutation = trpc.approvals.review.useMutation({ onSuccess: () => { refetchApprovals(); toast.success('تم حفظ قرار المراجعة'); }, onError: error => toast.error(error.message) });
  const decideMutation = trpc.approvals.decide.useMutation({ onSuccess: () => { refetchApprovals(); toast.success('تم حفظ قرار التعميد'); }, onError: error => toast.error(error.message) });
  const templateQuery = trpc.approvals.downloadTemplate.useQuery({ requestId: draft?.id || 0 }, { enabled: Boolean(draft?.id && draft.templateAvailable), retry: false });

  function closeRequestDialog() {
    setRequestOpen(false);
    setDocumentTypeId('');
    setDescription('');
    setDraft(null);
    setAttachment(null);
  }

  async function attachSelectedFile() {
    if (!draft || !attachment) return toast.error('اختر النموذج المكتمل أولاً');
    try {
      const uploaded = await uploadAttachmentMutation.mutateAsync({ fileName: attachment.name, dataUrl: await toDataUrl(attachment) });
      await attachDraftMutation.mutateAsync({ requestId: draft.id, attachmentUrl: uploaded.url, attachmentName: uploaded.fileName });
      setAttachment(null);
    } catch (error: any) {
      toast.error(error?.message || 'تعذر رفع النموذج المكتمل');
    }
  }

  function openDraft(request: any) {
    const documentType = docTypes.find((item: any) => item.id === request.documentTypeId);
    setDraft({ id: request.id, approvalNumber: request.approvalNumber, documentTypeId: request.documentTypeId, templateAvailable: Boolean(documentType?.templateUrl), templateRequired: Boolean(request.templateRequired), hasAttachment: Boolean(request.hasAttachment || request.attachmentUrl) });
    setDocumentTypeId(String(request.documentTypeId));
    setDescription(request.description || '');
    setRequestOpen(true);
  }

  async function previewApprovalAttachment(request: any) {
    try {
      setOpeningAttachmentId(request.id);
      const attachmentData = await utils.approvals.downloadAttachment.fetch({ requestId: request.id });
      const fileName = attachmentData.fileName || request.attachmentName || 'مرفق-التعميد';
      const isPdf = isPdfApprovalAttachment(fileName, attachmentData.url);
      setAttachmentPreview({ requestId: request.id, approvalNumber: request.approvalNumber || `RA-${request.id}`, fileName, url: attachmentData.url, isPdf });
    } catch (error: any) {
      toast.error(error?.message || 'تعذر تحميل النموذج المرفق');
    } finally {
      setOpeningAttachmentId(current => current === request.id ? null : current);
    }
  }

  function downloadPreviewAttachment() {
    if (!attachmentPreview) return;
    const link = document.createElement('a');
    link.href = attachmentPreview.url;
    link.download = attachmentPreview.fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function renderAttachmentButton(request: any, label = labelFor('delegates_preview_attachment', 'معاينة النموذج المرفق')) {
    if (!request.hasAttachment && !request.attachmentUrl) return null;
    const isOpening = openingAttachmentId === request.id;
    return <Button variant="outline" size="sm" disabled={isOpening} onClick={() => previewApprovalAttachment(request)}>
      <Eye className="h-4 w-4 ml-1" />{isOpening ? labelFor('delegates_preparing_preview', 'جارٍ تجهيز المعاينة...') : label}
    </Button>;
  }

  const statusLabels: Record<string, string> = {
    draft: labelFor('delegates_status_draft', 'مسودة بانتظار النموذج'),
    review_pending: labelFor('delegates_status_review_pending', 'بانتظار المراجع'),
    sent: labelFor('delegates_status_sent', 'مرسل للمفوضين'),
    approved: labelFor('delegates_status_approved', 'مكتمل الاعتماد'),
    rejected: labelFor('delegates_status_rejected', 'مرفوض'),
  };
  const statusColors: Record<string, string> = {
    draft: 'bg-slate-100 text-slate-800', review_pending: 'bg-violet-100 text-violet-800', sent: 'bg-blue-100 text-blue-800', approved: 'bg-emerald-100 text-emerald-800', rejected: 'bg-red-100 text-red-800',
  };
  const hasReviewWork = reviewRequests.length > 0 || canDecideApproval || isAdmin;
  const defaultTab = canRequestApproval ? 'request' : hasReviewWork ? 'review' : 'status';

  useEffect(() => {
    if (!highlightedApprovalRequestId) {
      setActiveTab(defaultTab);
      return;
    }
    const isRequesterOrAdmin = isAdmin || myRequests.some((request: any) => request.id === highlightedApprovalRequestId);
    setActiveTab(isRequesterOrAdmin ? 'status' : 'review');
    const frame = window.requestAnimationFrame(() => {
      document.getElementById(`approval-request-${highlightedApprovalRequestId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [defaultTab, highlightedApprovalRequestId, isAdmin, myRequests]);

  const renderStatusRows = (requests: any[], includeActions = true) => requests.map((request: any) => {
    const progress = getApprovalRequesterStatus(request);
    const approved = request.approvedCount || 0;
    const required = request.requiredApprovals || request.steps?.length || 1;
    return <TableRow id={`approval-request-${request.id}`} key={request.id} className={request.id === highlightedApprovalRequestId ? 'bg-primary/10 outline outline-2 outline-primary/30' : undefined}>
      <TableCell className="font-semibold whitespace-nowrap">{request.approvalNumber || `RA-${request.id}`}</TableCell>
      <TableCell><div className="font-medium">{request.title}</div><div className="text-xs text-muted-foreground mt-1">{labelFor('delegates_requester_prefix', 'الطالب')}: {request.requesterName || '-' } — {request.requesterPosition || '-'}</div></TableCell>
      <TableCell className="min-w-[255px]">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs"><span>{approved} من {required} {labelFor('delegates_approvals_progress_suffix', 'تعميدات')}</span><span className="text-muted-foreground">{request.approvalMode === 'sequential' && request.status === 'sent' ? `${labelFor('delegates_current_step_prefix', 'الخطوة')} ${request.currentStepOrder}` : labelFor('delegates_track_approval', 'متابعة التعميد')}</span></div>
          <Progress value={Math.min(100, (approved / Math.max(1, required)) * 100)} className="h-2" />
          <div className="space-y-1 rounded-lg border border-blue-100 bg-blue-50/60 p-2 text-xs leading-5 text-blue-950">{progress.lines.map((line: string, index: number) => <p key={`${request.id}-${index}`}>{line}</p>)}</div>
          {(request.reviewNote || request.approvalNote || request.steps?.some((step: any) => step.note)) && <div className="space-y-1 rounded-lg border border-amber-200 bg-amber-50/70 p-2 text-xs leading-5 text-amber-950">
            {request.reviewNote && <p><strong>{labelFor('delegates_reviewer_note_prefix', 'ملاحظة المراجع')}:</strong> {request.reviewNote}</p>}
            {request.steps?.filter((step: any) => step.note).map((step: any) => <p key={`note-${request.id}-${step.id}`}><strong>{step.systemUserName || step.userName || labelFor('delegates_approver_fallback', 'المفوض')}:</strong> {step.note}</p>)}
            {request.approvalNote && !request.steps?.some((step: any) => step.note === request.approvalNote) && <p><strong>{labelFor('delegates_latest_decision_note_prefix', 'ملاحظة القرار الأخير')}:</strong> {request.approvalNote}</p>}
          </div>}
        </div>
      </TableCell>
      <TableCell><Badge className={statusColors[request.status] || 'bg-gray-100 text-gray-800'}>{statusLabels[request.status] || request.status}</Badge></TableCell>
      <TableCell className="whitespace-nowrap">{new Date(request.createdAt).toLocaleDateString('ar-SA')}</TableCell>
      {includeActions && <TableCell className="whitespace-nowrap">
        <div className="flex flex-wrap gap-2">
          {request.status === 'draft' && request.requestedBy === user?.id && <Button variant="outline" size="sm" onClick={() => openDraft(request)}><Upload className="h-4 w-4 ml-1" />{labelFor('delegates_attach_completed_form', 'إرفاق النموذج المكتمل')}</Button>}
          {renderAttachmentButton(request, labelFor('delegates_preview_attachment', 'معاينة النموذج المرفق'))}
        </div>
      </TableCell>}
    </TableRow>;
  });

  return <div className="rtl-page space-y-6" dir="rtl">
    <div>
          <h1 className="text-2xl font-bold">{labelFor('nav_delegates', 'التعميدات')}</h1>
      <p className="text-sm text-muted-foreground mt-1">{labelFor('delegates_subtitle', 'طلبات التعميد والنماذج والمراجعة والاعتمادات')}</p>
    </div>

    <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="h-auto flex-wrap">
        {canRequestApproval && <TabsTrigger value="request">{labelFor('delegates_request', 'طلب تعميد')}</TabsTrigger>}
        <TabsTrigger value="status">{labelFor('delegates_status', 'حالة الطلبات')}</TabsTrigger>
        {hasReviewWork && <TabsTrigger value="review">{labelFor('delegates_review', 'المراجعة والتعميد')}</TabsTrigger>}
      </TabsList>

      {canRequestApproval && <TabsContent value="request" className="space-y-4">
        <Card><CardHeader><CardTitle>{labelFor('delegates_new_request', 'طلب تعميد جديد')}</CardTitle><CardDescription>{labelFor('delegates_request_description', 'ابدأ بحفظ طلب من نوع محدد، ثم نزّل النموذج، املأه، وأرفقه قبل إرساله.')}</CardDescription></CardHeader><CardContent>
          <Dialog open={requestOpen} onOpenChange={open => open ? setRequestOpen(true) : closeRequestDialog()}>
            <DialogTrigger asChild><Button onClick={() => { setDraft(null); setDocumentTypeId(''); setDescription(''); }}><Plus className="h-4 w-4 ml-2" />{labelFor('delegates_request', 'طلب تعميد')}</Button></DialogTrigger>
            <DialogContent className="max-h-[92dvh] overflow-y-auto border-2 border-primary/30 bg-gradient-to-b from-primary/[0.06] via-background to-background p-0 shadow-2xl sm:max-w-xl" dir="rtl">
              <DialogHeader className="border-b border-primary/20 bg-background/80 px-5 py-4 text-right backdrop-blur-sm sm:px-6"><DialogTitle className="pr-6 text-base font-bold text-foreground sm:text-lg">{draft ? `${labelFor('delegates_request', 'طلب تعميد')} ${draft.approvalNumber}` : labelFor('delegates_select_type', 'اختيار نوع التعميد')}</DialogTitle></DialogHeader>
              {!draft ? <div className="space-y-5 p-5 sm:p-6">
                <div className="space-y-2 rounded-xl border border-sky-200 bg-sky-50/70 p-4 shadow-sm dark:border-sky-900/70 dark:bg-sky-950/20"><Label className="text-sm font-semibold text-sky-950 dark:text-sky-100">{labelFor('delegates_type', 'نوع التعميد')}</Label><Select value={documentTypeId} onValueChange={setDocumentTypeId}><SelectTrigger className="h-11 border-sky-300 bg-background text-right shadow-sm transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20 dark:border-sky-800"><SelectValue placeholder={labelFor('delegates_type', 'نوع التعميد')} /></SelectTrigger><SelectContent>{docTypes.filter((type: any) => type.isActive).map((type: any) => <SelectItem key={type.id} value={String(type.id)}>{type.name}</SelectItem>)}</SelectContent></Select>{documentTypeId && <p className="rounded-md border border-sky-200/80 bg-background/70 px-3 py-2 text-xs leading-5 text-sky-950 dark:border-sky-900/70 dark:bg-sky-950/30 dark:text-sky-100">{docTypes.find((type: any) => type.id === Number(documentTypeId))?.templateRequirement === 'required' ? labelFor('delegates_template_required_hint', 'النموذج إلزامي لهذا النوع قبل الإرسال.') : labelFor('delegates_template_optional_hint', 'النموذج اختياري لهذا النوع.')}</p>}</div>
                <div className="space-y-2 rounded-xl border border-violet-200 bg-violet-50/60 p-4 shadow-sm dark:border-violet-900/70 dark:bg-violet-950/20"><Label className="text-sm font-semibold text-violet-950 dark:text-violet-100">{labelFor('delegates_additional_description', 'بيان إضافي (اختياري)')}</Label><Textarea className="min-h-28 border-violet-300 bg-background text-right shadow-sm transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20 dark:border-violet-800" value={description} onChange={event => setDescription(event.target.value)} placeholder={labelFor('field_description', 'البيان')} /></div>
                <Button className="h-11 w-full shadow-md shadow-primary/20" disabled={!documentTypeId || createDraftMutation.isPending} onClick={() => createDraftMutation.mutate({ documentTypeId: Number(documentTypeId), description: description || undefined })}>{createDraftMutation.isPending ? labelFor('delegates_saving', 'جارٍ الحفظ...') : labelFor('delegates_save_request', 'حفظ طلب التعميد')}</Button>
              </div> : <div className="space-y-5 p-5 sm:p-6">
                <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-right text-sm leading-7 text-amber-950 shadow-sm dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-100"><strong className="block text-base">{labelFor('delegates_number_label', 'رقم التعميد')}: {draft.approvalNumber}</strong><span>{draft.templateRequired ? labelFor('delegates_template_required_instruction', 'النموذج إلزامي لهذا النوع: حمّله إن توفر، ثم أرفق النسخة المكتملة قبل الإرسال.') : labelFor('delegates_template_optional_instruction', 'النموذج اختياري: يمكنك إرفاق نموذج مكتمل أو إرسال الطلب بدون مرفق.')}</span></div>
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 shadow-sm dark:border-emerald-900/70 dark:bg-emerald-950/20"><p className="mb-3 text-sm font-semibold text-emerald-950 dark:text-emerald-100">{labelFor('delegates_download_template', 'تحميل النموذج المرقم')}</p><Button variant="outline" className="w-full border-emerald-300 bg-background hover:bg-emerald-100 dark:border-emerald-800 dark:hover:bg-emerald-950/60 sm:w-auto" disabled={!draft.templateAvailable || templateQuery.isFetching} onClick={() => { if (templateQuery.data) downloadDataUrl(templateQuery.data.dataUrl, templateQuery.data.fileName); else templateQuery.refetch().then(result => result.data && downloadDataUrl(result.data.dataUrl, result.data.fileName)); }}><Download className="h-4 w-4 ml-1" />{draft.templateAvailable ? labelFor('delegates_download_template', 'تحميل النموذج المرقم') : labelFor('delegates_no_template', 'لا يوجد نموذج مرفوع لهذا النوع')}</Button></div>
                <div className="rounded-xl border border-violet-200 bg-violet-50/60 p-4 shadow-sm dark:border-violet-900/70 dark:bg-violet-950/20"><FileDropzone label={labelFor('delegates_attach_completed_form', 'إرفاق النموذج المكتمل')} description={labelFor('delegates_attachment_hint_extended', 'يسمح بملف PDF أو Word أو Excel أو صورة PNG/JPEG حتى 10 ميغابايت. لن يُرفع قبل الضغط على زر رفع النموذج.')} accept=".pdf,.docx,.xlsx,image/png,image/jpeg" maxBytes={10 * 1024 * 1024} previewImage={false} disabled={uploadAttachmentMutation.isPending || attachDraftMutation.isPending} isUploading={uploadAttachmentMutation.isPending || attachDraftMutation.isPending} onFileSelected={file => setAttachment(file)} onClear={() => setAttachment(null)} /></div>
                <div className="flex flex-col gap-2 border-t border-border/70 pt-4 sm:flex-row sm:flex-wrap"><Button variant="outline" className="w-full border-primary/30 bg-background sm:w-auto" disabled={!attachment || uploadAttachmentMutation.isPending || attachDraftMutation.isPending} onClick={attachSelectedFile}><Upload className="h-4 w-4 ml-1" />{labelFor('delegates_upload_form', 'رفع النموذج')}</Button><Button className="w-full shadow-md shadow-primary/20 sm:w-auto" disabled={submitDraftMutation.isPending || (draft.templateRequired && !draft.hasAttachment)} onClick={() => submitDraftMutation.mutate({ requestId: draft.id })}><Send className="h-4 w-4 ml-1" />{labelFor('delegates_send_for_review', 'إرسال للمراجعة والتعميد')}</Button></div>
              </div>}
            </DialogContent>
          </Dialog>
        </CardContent></Card>
      </TabsContent>}

      <TabsContent value="status" className="space-y-4">
        <Card><CardHeader><CardTitle>{isAdmin ? labelFor('delegates_all_status', 'حالة جميع طلبات التعميد') : labelFor('delegates_my_status', 'حالة طلباتي')}</CardTitle><CardDescription>{labelFor('delegates_status_description', 'يشمل السجل تاريخ الرفع والمراجعة وقرارات المفوضين والاعتمادات المتبقية.')}</CardDescription></CardHeader><CardContent className="p-0 overflow-x-auto"><Table><TableHeader><TableRow><TableHead>{labelFor('field_serial_number', 'الرقم')}</TableHead><TableHead>{labelFor('field_request', 'الطلب')}</TableHead><TableHead>{labelFor('field_approval_path', 'مسار التعميد')}</TableHead><TableHead>{labelFor('field_status', 'الحالة')}</TableHead><TableHead>{labelFor('field_upload_date', 'تاريخ الرفع')}</TableHead><TableHead>{labelFor('field_actions', 'إجراء')}</TableHead></TableRow></TableHeader><TableBody>{visibleRequests.length ? renderStatusRows(visibleRequests) : <TableRow><TableCell colSpan={6} className="h-24 text-center text-sm text-muted-foreground">{labelFor('delegates_status_empty', 'لا توجد طلبات تعميد لعرضها.')}</TableCell></TableRow>}</TableBody></Table></CardContent></Card>
      </TabsContent>

      {hasReviewWork && <TabsContent value="review" className="space-y-4">
        <Card><CardHeader><CardTitle>{labelFor('delegates_waiting_review', 'طلبات بانتظار المراجعة')}</CardTitle><CardDescription>{labelFor('delegates_reviewer_description', 'المراجع المحدد يعيد الطلب إلى صاحبه عند الرفض أو يحيله للمفوضين مع ملاحظاته.')}</CardDescription></CardHeader><CardContent className="space-y-3">{reviewRequests.length ? reviewRequests.map((request: any) => <div id={`approval-request-${request.id}`} key={request.id} className={`space-y-3 rounded-xl border p-3 sm:p-4 ${request.id === highlightedApprovalRequestId ? 'border-primary bg-primary/5 ring-2 ring-primary/25' : ''}`}><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold">{request.approvalNumber} — {request.title}</p><p className="text-sm text-muted-foreground">{labelFor('delegates_requester_prefix', 'الطالب')}: {request.requesterName} — {request.requesterPosition}</p></div><Badge className="w-fit bg-violet-100 text-violet-800">{labelFor('delegates_waiting_your_review', 'بانتظار مراجعتك')}</Badge></div>{renderAttachmentButton(request)}<Textarea value={reviewNotes[request.id] || ''} onChange={event => setReviewNotes(current => ({ ...current, [request.id]: event.target.value }))} placeholder={labelFor('delegates_reviewer_notes_placeholder', 'ملاحظات المراجع (تسجل في تاريخ الطلب)')} /><div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap"><Button size="sm" className="w-full sm:w-auto" onClick={() => reviewMutation.mutate({ requestId: request.id, decision: 'approved', note: reviewNotes[request.id] || undefined })}><UserCheck className="h-4 w-4 ml-1" />{labelFor('action_approve', 'موافقة')}</Button><Button variant="outline" size="sm" className="w-full text-destructive sm:w-auto" onClick={() => reviewMutation.mutate({ requestId: request.id, decision: 'rejected', note: reviewNotes[request.id] || undefined })}>{labelFor('action_reject', 'رفض')}</Button></div></div>) : <p className="text-sm text-muted-foreground">{labelFor('delegates_no_review_requests', 'لا توجد طلبات بانتظار مراجعتك.')}</p>}</CardContent></Card>
        {(canDecideApproval || isAdmin) && <Card><CardHeader><CardTitle>{labelFor('delegates_waiting_approval', 'طلبات بانتظار قرار التعميد')}</CardTitle><CardDescription>{labelFor('delegates_decision_description', 'تظهر لك فقط الطلبات التي أنت مفوض عليها في المرحلة الحالية. يمكنك إضافة ملاحظة اختيارية تُحفظ في سجل الطلب.')}</CardDescription></CardHeader><CardContent className="space-y-3">{decisionRequests.length ? decisionRequests.map((request: any) => <div key={request.id} className="space-y-3 rounded-xl border p-3 sm:p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold">{request.approvalNumber} — {request.title}</p><p className="text-sm text-muted-foreground">{labelFor('delegates_post_review_prefix', 'بعد المراجعة')}: {request.reviewStatus === 'approved' ? labelFor('delegates_yes', 'نعم') : labelFor('delegates_no_review_required', 'لا تتطلب مراجعة')} · {request.approvedCount || 0} من {request.requiredApprovals} {labelFor('delegates_approvals_progress_suffix', 'تعميدات')}</p></div>{renderAttachmentButton(request)}</div><Textarea value={decisionNotes[request.id] || ''} onChange={event => setDecisionNotes(current => ({ ...current, [request.id]: event.target.value }))} placeholder={labelFor('delegates_decision_notes_placeholder', 'ملاحظة المفوض عند الموافقة أو الرفض (اختيارية)')} /><div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap"><Button size="sm" className="w-full sm:w-auto" onClick={() => decideMutation.mutate({ requestId: request.id, decision: 'approved', note: decisionNotes[request.id] || undefined })}><FileCheck2 className="h-4 w-4 ml-1" />{labelFor('action_approve', 'موافقة')}</Button><Button size="sm" variant="outline" className="w-full text-destructive sm:w-auto" onClick={() => decideMutation.mutate({ requestId: request.id, decision: 'rejected', note: decisionNotes[request.id] || undefined })}>{labelFor('action_reject', 'رفض')}</Button></div></div>) : <p className="text-sm text-muted-foreground">{labelFor('delegates_no_decision_requests', 'لا توجد طلبات متاحة لقرارك حالياً.')}</p>}</CardContent></Card>}
      </TabsContent>}
    </Tabs>
    <Dialog open={attachmentPreview !== null} onOpenChange={open => !open && setAttachmentPreview(null)}>
      <DialogContent className="flex max-h-[92dvh] max-w-[calc(100%-1rem)] flex-col overflow-hidden p-0 sm:max-w-5xl" dir="rtl">
        <DialogHeader className="shrink-0 border-b px-4 py-3 sm:px-6 sm:py-4"><DialogTitle className="pr-6 text-base sm:text-lg">{labelFor('delegates_preview_attachment', 'معاينة النموذج المرفق')} — {attachmentPreview?.approvalNumber}</DialogTitle></DialogHeader>
        <div className="min-h-0 flex-1 overflow-y-auto p-3 sm:p-4">
          {attachmentPreview?.isPdf ? <iframe title={`${labelFor('delegates_preview_attachment', 'معاينة النموذج المرفق')} ${attachmentPreview.approvalNumber}`} src={attachmentPreview.url} className="h-[62dvh] w-full rounded-lg border bg-muted/20 sm:h-[70vh]" /> : <div className="flex min-h-48 flex-col items-center justify-center gap-3 rounded-lg border border-dashed bg-muted/20 p-6 text-center"><FileText className="h-10 w-10 text-muted-foreground" /><div><p className="font-medium">{labelFor('delegates_pdf_preview_only', 'المعاينة المدمجة متاحة لملفات PDF فقط')}</p><p className="mt-1 text-sm text-muted-foreground">{labelFor('delegates_pdf_preview_download_hint', 'يمكن تنزيل الملف للاطلاع عليه في البرنامج المناسب.')} {attachmentPreview?.fileName}</p></div></div>}
        </div>
        <div className="flex shrink-0 flex-col-reverse gap-2 border-t bg-background px-4 py-3 sm:flex-row sm:justify-end sm:px-6 sm:py-4"><Button variant="outline" className="w-full sm:w-auto" onClick={() => setAttachmentPreview(null)}>{labelFor('action_close', 'إغلاق')}</Button><Button className="w-full sm:w-auto" onClick={downloadPreviewAttachment}><Download className="ml-2 h-4 w-4" />{labelFor('delegates_download_attachment', 'تنزيل المرفق')}</Button></div>
      </DialogContent>
    </Dialog>
  </div>;
}
