export type CommissionTierEstimateInput = {
  minAchievementPercent: string | number;
  maxAchievementPercent?: string | number | null;
  payoutMultiplier?: string | number | null;
  additionalCommissionRate?: string | number | null;
  fixedBonusAmount?: string | number | null;
  isEligible?: boolean | null;
};

export type CommissionEstimateInput = {
  targetValue: string | number | null | undefined;
  actualValue: string | number | null | undefined;
  baseCommissionRate: string | number | null | undefined;
  minimumPayoutAmount?: string | number | null | undefined;
  tiers?: CommissionTierEstimateInput[];
};

export function toCommissionNumber(value: string | number | null | undefined) {
  const numeric = typeof value === 'number' ? value : Number(value || 0);
  return Number.isFinite(numeric) ? numeric : 0;
}

function roundCurrency(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function estimateCommission(input: CommissionEstimateInput) {
  const targetValue = Math.max(0, toCommissionNumber(input.targetValue));
  const actualValue = Math.max(0, toCommissionNumber(input.actualValue));
  const baseCommissionRate = Math.max(0, toCommissionNumber(input.baseCommissionRate));
  const minimumPayoutAmount = Math.max(0, toCommissionNumber(input.minimumPayoutAmount));
  const achievementPercent = targetValue > 0 ? (actualValue / targetValue) * 100 : 0;
  const tiers = [...(input.tiers || [])].sort((a, b) => toCommissionNumber(a.minAchievementPercent) - toCommissionNumber(b.minAchievementPercent));
  const matchedTier = tiers.find((tier) => {
    const min = toCommissionNumber(tier.minAchievementPercent);
    const max = tier.maxAchievementPercent === null || tier.maxAchievementPercent === undefined || tier.maxAchievementPercent === ''
      ? Number.POSITIVE_INFINITY
      : toCommissionNumber(tier.maxAchievementPercent);
    return achievementPercent >= min && achievementPercent <= max;
  }) || null;
  const baseAmount = roundCurrency(actualValue * (baseCommissionRate / 100));

  if (tiers.length > 0 && (!matchedTier || matchedTier.isEligible === false)) {
    return {
      targetValue,
      actualValue,
      achievementPercent: roundCurrency(achievementPercent),
      baseAmount,
      appliedTier: matchedTier,
      multiplierAmount: 0,
      additionalAmount: 0,
      fixedBonusAmount: 0,
      estimatedPayoutAmount: 0,
      eligible: false,
      reason: matchedTier ? 'tier_not_eligible' : 'no_matching_tier',
      isEstimateOnly: true,
    } as const;
  }

  const multiplier = Math.max(0, toCommissionNumber(matchedTier?.payoutMultiplier ?? 1));
  const additionalRate = Math.max(0, toCommissionNumber(matchedTier?.additionalCommissionRate));
  const fixedBonusAmount = Math.max(0, toCommissionNumber(matchedTier?.fixedBonusAmount));
  const multiplierAmount = roundCurrency(baseAmount * multiplier);
  const additionalAmount = roundCurrency(actualValue * (additionalRate / 100));
  const grossPayoutAmount = roundCurrency(multiplierAmount + additionalAmount + fixedBonusAmount);
  const eligible = grossPayoutAmount >= minimumPayoutAmount;

  return {
    targetValue,
    actualValue,
    achievementPercent: roundCurrency(achievementPercent),
    baseAmount,
    appliedTier: matchedTier,
    multiplierAmount,
    additionalAmount,
    fixedBonusAmount,
    estimatedPayoutAmount: eligible ? grossPayoutAmount : 0,
    eligible,
    reason: eligible ? 'eligible' : 'below_minimum_payout',
    isEstimateOnly: true,
  } as const;
}
