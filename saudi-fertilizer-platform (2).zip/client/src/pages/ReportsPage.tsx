import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, Printer } from 'lucide-react';
import { toast } from 'sonner';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { getPdfLogoFormat, type PdfLogoFormat } from '@shared/printAssets';
import { getPrintPresentation } from '@shared/printPresentation';
import { useSystemLabels } from '@/hooks/useSystemLabels';

async function logoUrlToDataUrl(logoUrl?: string): Promise<{ dataUrl: string; format: PdfLogoFormat } | null> {
  if (!logoUrl) return null;
  const response = await fetch(logoUrl);
  if (!response.ok) throw new Error('تعذر تحميل الشعار');
  const blob = await response.blob();
  const format = getPdfLogoFormat(blob.type);
  if (!format) throw new Error('صيغة شعار غير مدعومة لتصدير PDF');
  return new Promise<{ dataUrl: string; format: PdfLogoFormat }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ dataUrl: String(reader.result), format });
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export default function ReportsPage() {
  const { labelFor } = useSystemLabels();
  const [reportType, setReportType] = useState('total_collections');
  const [branchId, setBranchId] = useState<number | null>(null);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const { data: branches } = trpc.branches.list.useQuery();
  const { data: receipts } = trpc.receipts.list.useQuery(branchId ? { branchId } : {});
  const { data: customers } = trpc.customers.list.useQuery({});
  const { data: inputLists } = trpc.inputLists.list.useQuery({});
  const { data: systemUsers } = trpc.systemUsers.list.useQuery();
  const { data: company } = trpc.company.get.useQuery();
  const { data: printSettings } = trpc.settings.getAll.useQuery();

  const paymentMethods = inputLists?.filter(i => i.listType === 'payment_method') || [];
  const reportTypes = [
    { id: 'total_collections', name: labelFor('report_type_total_collections', 'المتحصلات إجمالي') },
    { id: 'detailed_collections', name: labelFor('report_type_detailed_collections', 'المتحصلات تفصيلي') },
    { id: 'branch_collections', name: labelFor('report_type_branch_collections', 'متحصلات فرع') },
    { id: 'delegate_collections', name: labelFor('report_type_delegate_collections', 'متحصلات مندوب') },
  ];
  const selectedReportName = reportTypes.find(report => report.id === reportType)?.name || '';
  const currencyLabel = labelFor('currency_sar', 'ريال');

  const filteredReceipts = receipts?.filter(r => {
    if (startDate && new Date(r.createdAt) < new Date(startDate)) return false;
    if (endDate && new Date(r.createdAt) > new Date(endDate + 'T23:59:59')) return false;
    return true;
  }) || [];

  const totalAmount = filteredReceipts.reduce((sum, r) => sum + parseFloat(r.amount || '0'), 0);

  const handlePrint = () => window.print();

  const handleExportPDF = async () => {
    if (filteredReceipts.length === 0) {
      toast.error(labelFor('report_export_empty', 'لا توجد بيانات للتصدير'));
      return;
    }

    const printPresentation = getPrintPresentation(printSettings, company?.companyName);
    const doc = new jsPDF({ orientation: printPresentation.pageOrientation, unit: 'mm', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const headerLimit = pageHeight * (printPresentation.headerPercent / 100);
    const footerStart = pageHeight * (1 - printPresentation.footerPercent / 100);
    const contentStartY = headerLimit + 7;
    const logoSize = Math.min(Math.max(12, headerLimit - 12), Math.max(12, printPresentation.logoSize / 4));
    const logoPosition = printPresentation.logoPosition;
    const logoX = logoPosition === 'left' ? 15 : logoPosition === 'center' ? (pageWidth - logoSize) / 2 : pageWidth - logoSize - 15;
    const headerText = printPresentation.headerText;
    const footerText = printPresentation.footerText;
    if (company?.logoUrl) {
      try {
        const logoAsset = await logoUrlToDataUrl(company.logoUrl);
        if (logoAsset) {
          (doc as any).addImage(logoAsset.dataUrl, logoAsset.format, logoX, 6, logoSize, logoSize);
        }
      } catch {
        // يبقى التقرير قابلاً للتصدير حتى في حال تعذر تحميل الشعار من المتصفح.
      }
    }
    
    // Add Arabic font support - use built-in helvetica for now
    doc.setFont('helvetica');
    doc.setFontSize(14);
    doc.text(headerText, pageWidth / 2, Math.min(16, headerLimit - 20), { align: 'center' });
    doc.setFontSize(10);
    const reportName = selectedReportName;
    doc.text(`${labelFor('report_pdf_title', 'Report')}: ${reportName}`, pageWidth / 2, Math.min(24, headerLimit - 12), { align: 'center' });
    
    if (startDate || endDate) {
      doc.setFontSize(8);
      doc.text(`${labelFor('report_pdf_period', 'Period')}: ${startDate || labelFor('report_pdf_period_start', 'Start')} - ${endDate || labelFor('report_pdf_period_end', 'End')}`, pageWidth / 2, contentStartY, { align: 'center' });
    }

    // Summary
    const summaryY = contentStartY + (startDate || endDate ? 7 : 0);
    doc.setFontSize(9);
    doc.text(`${labelFor('report_pdf_total_receipts', 'Total Receipts')}: ${filteredReceipts.length}  |  ${labelFor('report_pdf_total_amount', 'Total Amount')}: ${totalAmount.toLocaleString()} ${labelFor('report_pdf_currency', 'SAR')}`, pageWidth / 2, summaryY, { align: 'center' });

    // Table data
    const tableData = filteredReceipts.map(r => [
      r.serialNumber,
      new Date(r.createdAt).toLocaleDateString('en-US'),
      customers?.find(c => c.id === r.customerId)?.name || '-',
      `${parseFloat(r.amount).toLocaleString()} ${labelFor('report_pdf_currency', 'SAR')}`,
      paymentMethods.find(p => p.id === r.paymentMethodId)?.name || '-',
      systemUsers?.find(u => u.id === r.userId)?.fullName || '-',
    ]);

    (doc as any).autoTable({
      startY: summaryY + 6,
      head: [[
        labelFor('report_pdf_column_serial', 'Serial'),
        labelFor('report_pdf_column_date', 'Date'),
        labelFor('report_pdf_column_customer', 'Customer'),
        labelFor('report_pdf_column_amount', 'Amount'),
        labelFor('report_pdf_column_payment_method', 'Payment Method'),
        labelFor('report_pdf_column_user', 'User'),
      ]],
      body: tableData,
      margin: { top: contentStartY, bottom: pageHeight - footerStart + 6, left: 8, right: 8 },
      styles: { fontSize: printPresentation.pageOrientation === 'portrait' ? 7.2 : 9, cellPadding: printPresentation.pageOrientation === 'portrait' ? 1.8 : 3 },
      headStyles: { fillColor: [30, 64, 175], textColor: 255 },
      alternateRowStyles: { fillColor: [245, 247, 250] },
      didDrawPage: () => {
        if (footerText) {
          doc.setFontSize(8);
          doc.text(footerText, pageWidth / 2, footerStart + ((pageHeight - footerStart) / 2), { align: 'center' });
        }
      },
    });

    const fileName = `report_${reportType}_${new Date().toISOString().slice(0, 10)}.pdf`;
    doc.save(fileName);
    toast.success(`تم تصدير التقرير: ${fileName}`);
  };

  const reportPrintPresentation = getPrintPresentation(printSettings, company?.companyName);

  return (
    <div className="rtl-page space-y-6" dir="rtl">
      <div className="no-print">
        <h1 className="text-2xl font-bold">{labelFor('nav_reports', 'التقارير')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{labelFor('report_subtitle', 'استعراض وتصدير التقارير المالية')}</p>
      </div>

      {/* Filters */}
      <Card className="no-print">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-1">
              <Label className="text-xs">{labelFor('field_report_type', 'نوع التقرير')}</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                <SelectContent>{reportTypes.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {(reportType === 'branch_collections') && (
              <div className="space-y-1">
                <Label className="text-xs">{labelFor('field_branch', 'الفرع')}</Label>
                <Select value={branchId?.toString() || ''} onValueChange={v => setBranchId(parseInt(v))}>
                  <SelectTrigger className="w-40"><SelectValue placeholder={labelFor('action_select', 'اختر')} /></SelectTrigger>
                  <SelectContent>{branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1">
              <Label className="text-xs">{labelFor('field_from_date', 'من تاريخ')}</Label>
              <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-40" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">{labelFor('field_to_date', 'إلى تاريخ')}</Label>
              <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-40" />
            </div>
            <Button variant="outline" onClick={handlePrint}><Printer className="h-4 w-4 ml-2" />{labelFor('action_print', 'طباعة')}</Button>
            <Button onClick={handleExportPDF}><Download className="h-4 w-4 ml-2" />{labelFor('action_export_pdf', 'تصدير PDF')}</Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Summary */}
      <div
        className="hidden print:flex items-center justify-between gap-4 border-b-2 border-primary pb-4"
        dir="rtl"
        style={{ minHeight: reportPrintPresentation.headerHeight, flexDirection: reportPrintPresentation.headerFlexDirection }}
      >
        {company?.logoUrl && <img src={company.logoUrl} alt={labelFor('report_print_logo_alt', 'شعار الشركة')} className="shrink-0 object-contain" style={{ width: reportPrintPresentation.logoSize, height: reportPrintPresentation.logoSize }} />}
        <div className="flex-1 text-center">
          <p className="text-lg font-bold">{reportPrintPresentation.headerText}</p>
          <p className="text-sm text-muted-foreground">{labelFor('nav_reports', 'التقارير')} {selectedReportName}</p>
          <p className="mt-1 text-sm">{startDate || endDate ? `${startDate || labelFor('report_period_start', 'البداية')} — ${endDate || labelFor('report_period_end', 'النهاية')}` : labelFor('report_all_periods', 'جميع الفترات')}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground">{labelFor('report_receipt_count', 'عدد السندات')}</p>
            <p className="text-2xl font-bold mt-1">{filteredReceipts.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground">{labelFor('report_total_amount', 'إجمالي المبالغ')}</p>
            <p className="text-2xl font-bold mt-1 text-primary">{totalAmount.toLocaleString('ar-SA')} {currencyLabel}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground">{labelFor('report_average_receipt', 'متوسط السند')}</p>
            <p className="text-2xl font-bold mt-1">{filteredReceipts.length > 0 ? (totalAmount / filteredReceipts.length).toLocaleString('ar-SA', { maximumFractionDigits: 0 }) : '0'} {currencyLabel}</p>
          </CardContent>
        </Card>
      </div>

      {/* Report Table */}
      <Card>
        <CardHeader><CardTitle className="text-base">{labelFor('report_details', 'تفاصيل التقرير')}</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{labelFor('field_serial_number', 'الرقم')}</TableHead>
                <TableHead>{labelFor('field_date', 'التاريخ')}</TableHead>
                <TableHead>{labelFor('field_customer', 'العميل')}</TableHead>
                <TableHead>{labelFor('field_amount', 'المبلغ')}</TableHead>
                <TableHead>{labelFor('field_payment_method', 'طريقة الدفع')}</TableHead>
                <TableHead>{labelFor('field_user', 'المستخدم')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReceipts.map(r => (
                <TableRow key={r.id}>
                  <TableCell className="font-mono text-sm">{r.serialNumber}</TableCell>
                  <TableCell>{new Date(r.createdAt).toLocaleDateString('ar-SA')}</TableCell>
                  <TableCell>{customers?.find(c => c.id === r.customerId)?.name || '-'}</TableCell>
                  <TableCell className="font-semibold">{parseFloat(r.amount).toLocaleString('ar-SA')} {currencyLabel}</TableCell>
                  <TableCell>{paymentMethods.find(p => p.id === r.paymentMethodId)?.name || '-'}</TableCell>
                  <TableCell>{systemUsers?.find(u => u.id === r.userId)?.fullName || '-'}</TableCell>
                </TableRow>
              ))}
              {filteredReceipts.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">{labelFor('report_no_data', 'لا توجد بيانات')}</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <div className="hidden print:flex items-center justify-center border-t pt-2 text-sm text-muted-foreground" style={{ minHeight: reportPrintPresentation.footerHeight }}>
        {reportPrintPresentation.footerText && <p>{reportPrintPresentation.footerText}</p>}
      </div>
    </div>
  );
}
