import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const source = readFileSync(new URL('../client/src/pages/PerformanceReportsPage.tsx', import.meta.url), 'utf8');

describe('performance report loading label', () => {
  it('uses the central presentation label for the visible loading row', () => {
    expect(getSystemLabel({}, 'performance_loading')).toBe('جارٍ تحميل تقارير الأداء...');
    expect(getSystemLabel({ system_label_overrides: JSON.stringify({ performance_loading: 'يتم جلب التقارير الآن' }) }, 'performance_loading')).toBe('يتم جلب التقارير الآن');
    expect(source).toContain("labelFor('performance_loading', 'جارٍ تحميل تقارير الأداء...')");
  });
});

