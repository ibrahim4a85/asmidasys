import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { getSystemLabel } from '../shared/systemLabelPresentation';

const paymentsPageSource = readFileSync(
  resolve(process.cwd(), 'client/src/pages/PaymentsPage.tsx'),
  'utf8',
);

describe('payment print QR alternative-text presentation label', () => {
  it('uses the default alternative text and accepts an administrator override', () => {
    expect(getSystemLabel(undefined, 'payment_print_qr_alt')).toBe('رمز QR لسند الصرف');
    expect(
      getSystemLabel(
        {
          system_label_overrides: JSON.stringify({
            payment_print_qr_alt: 'رمز تحقق لسند المصروف',
          }),
        },
        'payment_print_qr_alt',
      ),
    ).toBe('رمز تحقق لسند المصروف');
  });

  it('customizes only QR alternative text while preserving QR data and print flow', () => {
    const printableTemplate = paymentsPageSource.slice(
      paymentsPageSource.indexOf('function PrintablePayment'),
      paymentsPageSource.indexOf('\n\nexport default function PaymentsPage'),
    );
    const handlerStart = paymentsPageSource.indexOf('const handlePrint');
    const handlerEnd = paymentsPageSource.indexOf('\n\n  return (', handlerStart);
    const handlerSource = paymentsPageSource.slice(handlerStart, handlerEnd);

    expect(printableTemplate).toContain("labelFor('payment_print_qr_alt', 'رمز QR لسند الصرف')");
    expect(printableTemplate).toContain("alt={labelFor('payment_print_qr_alt', 'رمز QR لسند الصرف')}");
    expect(printableTemplate).toContain('const qrData = encodeURIComponent');
    expect(printableTemplate).toContain('payment.serialNumber');
    expect(printableTemplate).toContain('payment.amount');
    expect(printableTemplate).toContain('https://api.qrserver.com/v1/create-qr-code/');
    expect(handlerSource).toContain("window.open('', '_blank')");
    expect(handlerSource).toContain('printWindow.document.write(');
    expect(handlerSource).toContain('printWindow.document.close()');
    expect(handlerSource).toContain('printWindow.print()');
  });
});
