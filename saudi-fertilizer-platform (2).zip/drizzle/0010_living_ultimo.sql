ALTER TABLE `approval_requests` MODIFY COLUMN `approvalMode` enum('sequential','any','all','two_board_members') NOT NULL DEFAULT 'sequential';--> statement-breakpoint
ALTER TABLE `approval_workflows` MODIFY COLUMN `approvalMode` enum('sequential','any','all','two_board_members') NOT NULL DEFAULT 'sequential';--> statement-breakpoint
ALTER TABLE `system_users` MODIFY COLUMN `userType` enum('admin','accountant','delegate','branch_supervisor','authorized_partner') NOT NULL DEFAULT 'delegate';--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `requiredApprovals` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_requests` ADD `approvedCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `requiredApprovals` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `approval_workflows` ADD `boardMembersOnly` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `internal_notifications` ADD `approvalRequestId` int;