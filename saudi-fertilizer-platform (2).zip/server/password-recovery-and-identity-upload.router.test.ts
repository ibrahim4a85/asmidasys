import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./db', () => ({
  getSettings: vi.fn(),
  getEligibleSystemUserForPasswordReset: vi.fn(),
  replacePasswordResetCode: vi.fn(),
  deletePasswordResetCodeForUser: vi.fn(),
  confirmPasswordResetCode: vi.fn(),
  updateSetting: vi.fn(),
  updateSettings: vi.fn(),
}));
vi.mock('./storage', () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));
vi.mock('./passwordRecoveryMailer', () => ({ sendPasswordRecoveryCode: vi.fn() }));

import { appRouter } from './routers';
import * as db from './db';
import { storagePut } from './storage';
import { sendPasswordRecoveryCode } from './passwordRecoveryMailer';
import type { TrpcContext } from './_core/context';

const PASSWORD_RECOVERY_EMAIL_KEY = 'password_recovery_email';

function publicContext(): TrpcContext {
  return {
    user: null,
    systemUser: null,
    req: { protocol: 'https', headers: {} } as TrpcContext['req'],
    res: { clearCookie: () => {} } as TrpcContext['res'],
  };
}

function adminContext(): TrpcContext {
  return {
    ...publicContext(),
    systemUser: { id: 17, username: 'admin', fullName: 'مدير النظام', userType: 'admin', userLevel: 'primary', branchId: null, permissions: {} },
  };
}

describe('استعادة كلمة المرور ورفع هوية الشركة', () => {
  beforeEach(() => {
    vi.resetAllMocks();
    process.env.JWT_SECRET = 'password-recovery-unit-test-secret';
    vi.mocked(db.getSettings).mockResolvedValue({} as never);
    vi.mocked(db.getEligibleSystemUserForPasswordReset).mockResolvedValue(null as never);
    vi.mocked(db.confirmPasswordResetCode).mockResolvedValue({ success: false, reason: 'invalid' } as never);
    vi.mocked(db.updateSetting).mockResolvedValue({ success: true } as never);
    vi.mocked(storagePut).mockResolvedValue({ url: '/manus-storage/company-identity/logo.png' } as never);
  });

  it('يعيد رسالة عامة عند غياب بريد استرداد أو حساب مؤهل ولا يرسل رمزاً', async () => {
    const result = await appRouter.createCaller(publicContext()).systemAuth.requestPasswordReset({ username: 'unknown-user' });

    expect(result).toEqual({ success: true, message: 'إذا كانت بيانات الاسترداد مهيأة للحساب، فسيصل رمز إلى البريد المعتمد.' });
    expect(sendPasswordRecoveryCode).not.toHaveBeenCalled();
    expect(db.replacePasswordResetCode).not.toHaveBeenCalled();
  });

  it('يخزن تجزئة رمز من ستة أرقام ويرسله إلى البريد الإداري المهيأ فقط', async () => {
    vi.mocked(db.getSettings).mockResolvedValue({ [PASSWORD_RECOVERY_EMAIL_KEY]: 'recovery@company.sa' } as never);
    vi.mocked(db.getEligibleSystemUserForPasswordReset).mockResolvedValue({ id: 42 } as never);

    await appRouter.createCaller(publicContext()).systemAuth.requestPasswordReset({ username: 'admin' });

    expect(db.replacePasswordResetCode).toHaveBeenCalledWith(expect.objectContaining({ userId: 42, recoveryEmail: 'recovery@company.sa', codeHash: expect.stringMatching(/^[a-f0-9]{64}$/), expiresAt: expect.any(Date) }));
    expect(sendPasswordRecoveryCode).toHaveBeenCalledWith(expect.objectContaining({ to: 'recovery@company.sa', code: expect.stringMatching(/^\d{6}$/) }));
    const expiresAt = vi.mocked(db.replacePasswordResetCode).mock.calls[0]?.[0].expiresAt as Date;
    expect(expiresAt.getTime()).toBeGreaterThan(Date.now() + 9 * 60 * 1000);
    expect(expiresAt.getTime()).toBeLessThanOrEqual(Date.now() + 10 * 60 * 1000 + 2_000);
  });

  it('يبطل الرمز المخزن إذا تعذر إرسال رسالة Gmail', async () => {
    vi.mocked(db.getSettings).mockResolvedValue({ [PASSWORD_RECOVERY_EMAIL_KEY]: 'recovery@company.sa' } as never);
    vi.mocked(db.getEligibleSystemUserForPasswordReset).mockResolvedValue({ id: 42 } as never);
    vi.mocked(sendPasswordRecoveryCode).mockRejectedValueOnce(new Error('SMTP unavailable'));

    await appRouter.createCaller(publicContext()).systemAuth.requestPasswordReset({ username: 'admin' });

    expect(db.deletePasswordResetCodeForUser).toHaveBeenCalledWith(42);
  });

  it('لا يكشف سبب فشل تأكيد الرمز ويقبل النجاح فقط من طبقة البيانات الذرية', async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(caller.systemAuth.confirmPasswordReset({ username: 'admin', code: '000000', password: 'new-password' })).resolves.toEqual({ success: false, error: 'رمز الاسترداد غير صالح أو انتهت صلاحيته' });

    vi.mocked(db.confirmPasswordResetCode).mockResolvedValueOnce({ success: true, reason: 'success' } as never);
    await expect(caller.systemAuth.confirmPasswordReset({ username: 'admin', code: '123456', password: 'new-password' })).resolves.toEqual({ success: true });
    expect(db.confirmPasswordResetCode).toHaveBeenLastCalledWith(expect.objectContaining({ username: 'admin', password: 'new-password', codeHash: expect.stringMatching(/^[a-f0-9]{64}$/) }));
  });

  it('يحجب بريد الاسترداد من الإعدادات العامة ويتحقق من صيغته عند حفظ المدير', async () => {
    vi.mocked(db.getSettings).mockResolvedValue({ appearance: 'light', [PASSWORD_RECOVERY_EMAIL_KEY]: 'recovery@company.sa' } as never);
    await expect(appRouter.createCaller(publicContext()).settings.getAll()).resolves.toEqual({ appearance: 'light' });
    await expect(appRouter.createCaller(adminContext()).settings.update({ key: PASSWORD_RECOVERY_EMAIL_KEY, value: 'not-an-email' })).rejects.toThrow('أدخل بريداً إلكترونياً صالحاً');
    await appRouter.createCaller(adminContext()).settings.update({ key: PASSWORD_RECOVERY_EMAIL_KEY, value: ' work@company.sa ' });
    expect(db.updateSetting).toHaveBeenLastCalledWith(PASSWORD_RECOVERY_EMAIL_KEY, 'work@company.sa');
  });

  it('يقصر رفع الشعار على مدير النظام ويخزن مرجعاً مداراً لملف صورة صالح', async () => {
    const validLogo = { fileName: 'شعار الشركة.png', dataUrl: 'data:image/png;base64,aGVsbG8=' };
    await expect(appRouter.createCaller(publicContext()).files.uploadCompanyLogo(validLogo)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
    await expect(appRouter.createCaller(adminContext()).files.uploadCompanyLogo(validLogo)).resolves.toEqual({ url: '/manus-storage/company-identity/logo.png', fileName: 'شعار الشركة.png', mimeType: 'image/png' });
    expect(storagePut).toHaveBeenCalledWith(expect.stringMatching(/^company-identity\/logos\/17\//), expect.any(Buffer), 'image/png');
    await expect(appRouter.createCaller(adminContext()).files.uploadCompanyLogo({ fileName: 'logo.svg', dataUrl: 'data:image/svg+xml;base64,PHN2Zy8+' })).rejects.toThrow('يسمح للشعار بصيغ PNG أو JPEG أو WEBP فقط');
  });
});
