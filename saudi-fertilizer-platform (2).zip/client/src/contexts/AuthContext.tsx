import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { trpc } from '@/lib/trpc';

interface SystemUser {
  id: number;
  username: string;
  fullName: string;
  userType: string;
  userLevel: 'primary' | 'secondary';
  branchId: number | null;
  permissions: any;
}

interface AuthContextType {
  user: SystemUser | null;
  isAuthenticated: boolean;
  isSessionLoading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const utils = trpc.useUtils();
  const [hasLoggedOut, setHasLoggedOut] = useState(false);
  const systemSession = trpc.systemAuth.session.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: true,
    // Absence of a management session is the expected state on the public
    // login route. The provider handles it as an unauthenticated user.
    meta: { suppressGlobalErrorLog: true },
  });
  const systemLogout = trpc.systemAuth.logout.useMutation();
  const user = hasLoggedOut ? null : (systemSession.data as SystemUser | undefined) ?? null;

  useEffect(() => {
    if (user) {
      localStorage.setItem('systemUser', JSON.stringify(user));
      return;
    }

    if (systemSession.isError) {
      localStorage.removeItem('systemUser');
    }
  }, [systemSession.isError, user]);

  const login = async () => {
    const sessionResult = await systemSession.refetch();
    if (!sessionResult.data) {
      localStorage.removeItem('systemUser');
      throw new Error('تعذّر تأكيد جلسة نظام الإدارة');
    }
    setHasLoggedOut(false);
    localStorage.setItem('systemUser', JSON.stringify(sessionResult.data));
  };

  const logout = async () => {
    localStorage.removeItem('systemUser');
    // The cached session remains available while a query is invalidated. Mark
    // the client as signed out first so the root login route cannot redirect
    // back to the dashboard during the logout request.
    setHasLoggedOut(true);
    try {
      await systemLogout.mutateAsync();
    } finally {
      await utils.systemAuth.session.reset();
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isSessionLoading: systemSession.isLoading,
      login,
      logout,
      isAdmin: user?.userType === 'admin',
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useSystemAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useSystemAuth must be used within AuthProvider');
  return context;
}
