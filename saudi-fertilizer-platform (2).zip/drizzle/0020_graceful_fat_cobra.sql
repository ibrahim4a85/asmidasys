ALTER TABLE `receipts` ADD COLUMN `customerStatement` text;
