import { describe, expect, it } from "vitest";
import { getPdfLogoFormat } from "../shared/printAssets";

describe("صيغ شعار الطباعة", () => {
  it("يتعرف على صيغ الشعارات المدعومة في تصدير PDF", () => {
    expect(getPdfLogoFormat("image/png")).toBe("PNG");
    expect(getPdfLogoFormat("image/jpeg")).toBe("JPEG");
    expect(getPdfLogoFormat("image/webp; charset=binary")).toBe("WEBP");
  });

  it("يرفض الصيغ غير المدعومة كي يبقى تصدير PDF قابلاً للتنبؤ", () => {
    expect(getPdfLogoFormat("image/svg+xml")).toBeNull();
    expect(getPdfLogoFormat(undefined)).toBeNull();
  });
});
