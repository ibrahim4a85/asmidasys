import { createContext, useContext, useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export type AppearanceTheme = "blue" | "green" | "purple";
export type ColorMode = "light" | "dark";
export type InteractionColor = "azure" | "emerald" | "violet" | "coral" | "amber";

const themeValues: AppearanceTheme[] = ["blue", "green", "purple"];
const interactionColorValues: InteractionColor[] = ["azure", "emerald", "violet", "coral", "amber"];

function isColorMode(value: unknown): value is ColorMode {
  return value === "light" || value === "dark";
}

function isAppearanceTheme(value: unknown): value is AppearanceTheme {
  return typeof value === "string" && themeValues.includes(value as AppearanceTheme);
}

function isInteractionColor(value: unknown): value is InteractionColor {
  return typeof value === "string" && interactionColorValues.includes(value as InteractionColor);
}

interface ThemeContextType {
  theme: AppearanceTheme;
  setTheme: (theme: AppearanceTheme) => void;
  toggleTheme: () => void;
  colorMode: ColorMode;
  setColorMode: (mode: ColorMode) => void;
  toggleColorMode: () => void;
  interactionColor: InteractionColor;
  setInteractionColor: (color: InteractionColor) => void;
  switchable: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: AppearanceTheme;
  switchable?: boolean;
}

export function ThemeProvider({
  children,
  defaultTheme = "blue",
  switchable = true,
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<AppearanceTheme>(() => {
    const stored = localStorage.getItem("appearanceTheme");
    return isAppearanceTheme(stored) ? stored : defaultTheme;
  });
  const [colorMode, setColorMode] = useState<ColorMode>(() => {
    const stored = localStorage.getItem("appearanceColorMode");
    return isColorMode(stored) ? stored : "light";
  });
  const [interactionColor, setInteractionColor] = useState<InteractionColor>(() => {
    const stored = localStorage.getItem("appearanceInteractionColor");
    return isInteractionColor(stored) ? stored : "azure";
  });
  const { data: settings } = trpc.settings.getAll.useQuery();

  useEffect(() => {
    const savedTheme = settings?.theme;
    if (isAppearanceTheme(savedTheme)) setTheme(savedTheme);
  }, [settings?.theme]);

  useEffect(() => {
    const savedInteractionColor = settings?.interaction_color;
    if (isInteractionColor(savedInteractionColor)) setInteractionColor(savedInteractionColor);
  }, [settings?.interaction_color]);

  useEffect(() => {
    const savedColorMode = settings?.appearance_color_mode;
    if (isColorMode(savedColorMode)) setColorMode(savedColorMode);
  }, [settings?.appearance_color_mode]);

  useEffect(() => {
    const root = document.documentElement;
    root.lang = "ar";
    root.dir = "rtl";
    root.classList.remove("dark", "theme-blue", "theme-green", "theme-purple", ...interactionColorValues.map(value => `interaction-${value}`));
    if (colorMode === "dark") root.classList.add("dark");
    root.classList.add(`theme-${theme}`);
    root.classList.add(`interaction-${interactionColor}`);
    localStorage.setItem("appearanceTheme", theme);
    localStorage.setItem("appearanceColorMode", colorMode);
    localStorage.setItem("appearanceInteractionColor", interactionColor);
  }, [colorMode, interactionColor, theme]);

  const toggleTheme = () => {
    const nextIndex = (themeValues.indexOf(theme) + 1) % themeValues.length;
    setTheme(themeValues[nextIndex]);
  };

  const toggleColorMode = () => setColorMode(current => current === "dark" ? "light" : "dark");

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, colorMode, setColorMode, toggleColorMode, interactionColor, setInteractionColor, switchable }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within ThemeProvider");
  }
  return context;
}
